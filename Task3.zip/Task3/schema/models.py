
from database_config.database import Base
from sqlalchemy import Column,Integer,String,ForeignKey,Table,Float
from sqlalchemy.orm import relationship



cart_item_association_table = Table('cart_item_association', Base.metadata,
    Column('cart_id', Integer, ForeignKey('cart.id')),
    Column('item_id', Integer, ForeignKey('item.id'))
)

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    phone_number = Column(String)

    carts = relationship("Cart", back_populates="users")

    billings = relationship("Billing", back_populates="users")

class Cart(Base):
    __tablename__ = 'cart'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))

    users = relationship("User", back_populates="carts")

    items = relationship("Item", secondary=cart_item_association_table, back_populates="carts")

class Item(Base):
    __tablename__ = 'item'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    price = Column(Float)
    availability = Column(Integer)

    carts = relationship("Cart", secondary=cart_item_association_table, back_populates="items")

class Billing(Base):
    __tablename__ = 'billing'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    total_amount = Column(Float)

    users = relationship("User", back_populates="billings")