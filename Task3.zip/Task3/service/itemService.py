

from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from database_config.database import get_db
from pydantic_models_config import responseDto
from schema import models
from query_config import item_queries
from logger_config.fiie_log import logger

def addItem(item: responseDto.ItemCreate, db: Session):
    logger.info("adding Items")
    db_item = models.Item(**item.dict())
    db.add(db_item)
    db.commit()
    logger.info("added successfully")
    return db_item

def getItemById(item_id: int, db: Session):
    db_item = item_queries.findItemById(item_id,db)
    if db_item is None:
        raise HTTPException(status_code=404, detail="Item not found")
    return db_item

def updateItemById(item_id: int, item: responseDto.ItemUpdate, db: Session):
    db_item = item_queries.findItemById(item_id,db)
    if db_item is None:
        raise HTTPException(status_code=404, detail="Item not found")
    for var, value in item:
        setattr(db_item, var, value)
    db.commit()
    logger.info("Item updated successfully")
    return db_item


def deleteItemById(item_id: int, db: Session = Depends(get_db)):
    db_item = item_queries.findItemById(item_id,db)
    if db_item is None:
        raise HTTPException(status_code=404, detail="Item not found")
    db.delete(db_item)
    db.commit()
    logger.info("Item deleted successfully")
    return {"message": "Item deleted successfully"}