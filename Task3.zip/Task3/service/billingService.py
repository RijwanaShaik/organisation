

from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from database_config.database import get_db
from pydantic_models_config import responseDto
from schema import models
from query_config import billing_queries,cart_queires,user_queries
from logger_config.fiie_log import logger


def createBillingById(user_id: int, db: Session):
    db_cart = cart_queires.findCartUserById(user_id, db)
    if db_cart is None:
        raise HTTPException(status_code=404, detail="Cart not found")
    if not db_cart.items:
        raise HTTPException(status_code=400, detail="Cart has no items to purchase")
    total_bill = sum(item.price for item in db_cart.items)
    if total_bill <= 0:
        raise HTTPException(status_code=400, detail="Total bill amount cannot be negative or zero")
    db_billing = models.Billing(user_id=user_id, total_amount=total_bill)
    db.add(db_billing)
    db.commit()
    for item in db_cart.items:
        item.availability = 0
    db.commit()
    db.refresh(db_billing)
    logger.info(f"Billing created successfully for User ID: {user_id}, Total Amount: {total_bill}")
    return db_billing


def getBillingById(billing_id: int, db: Session):
    db_billing = billing_queries.findBillingById(billing_id, db)
    if db_billing is None:
        raise HTTPException(status_code=404, detail="Billing not found")
    return db_billing


def updateBillingById(billing_id: int, billing: responseDto.BillingUpdate, db: Session):
    db_billing = billing_queries.findBillingById(billing_id, db)
    if db_billing is None:
        raise HTTPException(status_code=404, detail="Billing not found")
    for var, value in billing:
        setattr(db_billing, var, value)
    db.commit()
    db.refresh(db_billing)
    logger.info(f"Billing updated successfully for Billing ID: {billing_id}")
    return db_billing


def getBillByPhNo(phone_number: str, db: Session):
    db_user = user_queries.findUserByPhNo(phone_number, db)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    billings = db.query(models.Billing).filter(models.Billing.user_id == db_user.id).all()
    if not billings:
        logger.info(f"No billings found for user with phone number: {phone_number}")
    else:
        for billing in billings:
            logger.info(f"Billing ID: {billing.id}, User ID: {billing.user_id}, Total Amount: {billing.total_amount}")
    return billings


def deleteBillingById(billing_id: int, db: Session = Depends(get_db)):
    db_billing = billing_queries.findBillingById(billing_id, db)
    if db_billing is None:
        raise HTTPException(status_code=404, detail="Billing not found")
    db.delete(db_billing)
    db.commit()
    logger.info(f"Billing deleted successfully for Billing ID: {billing_id}")
    return "Bill Deleted Successfully"
