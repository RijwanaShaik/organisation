from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic_models_config import responseDto
from schema import models
from query_config import cart_queires,item_queries
from logger_config.fiie_log import logger



def addCartToItems(cart: responseDto.CartCreate, db: Session):
    logger.info("Adding Items to the cart process started")
    db_cart = models.Cart(user_id=cart.user_id)
    db.add(db_cart)
    db.commit()
    
    # Add items to the cart
    for item_id in cart.items:
        
        db_item = item_queries.findItemById(item_id, db)
        if db_item.availability ==0:
            logger.info("Items availabilty is 0,out of stock")
            raise HTTPException(status_code=404,detail="OUT OF STOCK")
        if db_item is None:
            logger.info("Item not found while adding items to the cart")
            raise HTTPException(status_code=404, detail="Item not found")
        db_cart.items.append(db_item)
    
    db.commit()
    logger.info("Adding items to the cart process completed")
    return db_cart
    


def getCartById(cart_id: int, db: Session):
    db_cart = cart_queires.findCartById(cart_id,db)
    if db_cart is None:
        logger.info("Cart not found ")
        raise HTTPException(status_code=404, detail="Cart not found")
    return db_cart


def updateCartById(cart_id: int, cart: responseDto.CartUpdate, db: Session):
    db_cart = cart_queires.findCartById(cart_id,db)
    if db_cart is None:
        raise HTTPException(status_code=404, detail="Cart not found")
    for var, value in cart:
        setattr(db_cart, var, value)
    db.commit()
    db.refresh(db_cart)
    logger.info("Cart updated successfully")
    return db_cart


def deleteCartById(cart_id: int, db: Session):
    db_cart = cart_queires.findCartById(cart_id,db)
    if db_cart is None:
        raise HTTPException(status_code=404, detail="Cart not found")
    db.delete(db_cart)
    db.commit()
    logger.info("Cart deleted successfully")
    return {"message": "Cart deleted successfully"}