
from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from database_config.database import get_db
from pydantic_models_config import responseDto
from schema import models
from query_config import user_queries
from logger_config.fiie_log import logger

def createUser(user: responseDto.UserBase, db: Session):
    logger.info("User Creation process started")
    db_user = models.User(name=user.name,phone_number =user.phone_number)
    db.add(db_user)
    db.commit()
    logger.info("User Created successfully")
    return db_user

def getUserById(user_id: int, db: Session):
    user = user_queries.findUserById(user_id,db)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user

def updateUserById(user_id: int, user: responseDto.UserUpdate, db: Session):
    db_user = user_queries.findUserById(user_id,db)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    for var, value in vars(user).items():
        setattr(db_user, var, value) if value else None
    db.commit()
    logger.info("User updated successfully")
    return db_user

def deleteUserById(user_id: int, db: Session):
    db_user = user_queries.findUserById(user_id,db)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(db_user)
    db.commit()
    logger.info("User deleted successfully")
    return "User Deleted Successfully"