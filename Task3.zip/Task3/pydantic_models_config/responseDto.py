from typing import List
from pydantic import BaseModel, EmailStr


class UserBase(BaseModel):
    name: str
    phone_number: str 
   
class User(UserBase):
    id: int
    class Config:
        orm_mode = True
        

class UserUpdate(UserBase):
    pass

class ItemBase(BaseModel):
    name: str
    price: float
    availability: int

class ItemCreate(ItemBase):
    pass

class ItemUpdate(ItemBase):
    pass

class Item(ItemBase):
    id: int

    class Config:
        orm_mode = True


class CartBase(BaseModel):
    user_id: int

class CartCreate(CartBase):
    items: List[int] 
    pass

class CartUpdate(CartBase):
    pass

class Cart(CartBase):
    id: int
    items: List[Item] = []

    class Config:
        orm_mode = True


class BillingBase(BaseModel):
    user_id: int
    total_amount: float

class BillingCreate(BillingBase):
    pass

class BillingUpdate(BillingBase):
    pass

class Billing(BillingBase):
    id: int

    class Config:
        orm_mode = True

