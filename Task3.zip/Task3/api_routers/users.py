from fastapi import APIRouter,Depends, HTTPException
from sqlalchemy.orm import Session
from database_config.database import get_db
from pydantic_models_config import responseDto
from schema.models import User
from service import userService
from fastapi_jwt_auth import AuthJWT

router = APIRouter(tags=["users"])


    

@router.post("/users/",response_model= responseDto.User)
def addUser(user: responseDto.UserBase, db: Session = Depends(get_db)):
    return userService.createUser(user,db)

@router.get("/users/{user_id}",response_model= responseDto.User)
def getUser(user_id: int, db: Session = Depends(get_db),Authorize: AuthJWT = Depends()):
    Authorize.jwt_required()
    return userService.getUserById(user_id,db)

@router.put("/users/{user_id}" ,response_model= responseDto.User)
def updateUser(user_id: int, user: responseDto.UserUpdate, db: Session = Depends(get_db)):
    
    return userService.updateUserById(user_id,user,db)

@router.delete("/users/{user_id}")
def deleteUser(user_id: int, db: Session = Depends(get_db)):
  
    return userService.deleteUserById(user_id,db)

