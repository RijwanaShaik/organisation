from fastapi import APIRouter,Depends, HTTPException
from sqlalchemy.orm import Session
from database_config.database import get_db
from pydantic_models_config import responseDto
from schema.models import Item
from service import itemService
from fastapi_jwt_auth import AuthJWT

router = APIRouter(tags=["item"])


@router.post("/items/", response_model=responseDto.Item)
def createItem(item: responseDto.ItemCreate, db: Session = Depends(get_db)):
   
    return itemService.addItem(item,db)

@router.get("/items/{item_id}", response_model=responseDto.Item)
def getItem(item_id: int, db: Session = Depends(get_db),Authorize: AuthJWT = Depends()):
    Authorize.jwt_required()
    return itemService.getItemById(item_id,db)

@router.put("/items/{item_id}", response_model=responseDto.Item)
def updateItem(item_id: int, item: responseDto.ItemUpdate, db: Session = Depends(get_db)):
    
    return itemService.updateItemById(item_id,item,db)

@router.delete("/items/{item_id}")
def deleteItem(item_id: int, db: Session = Depends(get_db)):
   
    return itemService.deleteItemById(item_id,db)