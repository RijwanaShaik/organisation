
from fastapi import APIRouter,Depends, HTTPException
from sqlalchemy.orm import Session
from database_config.database import get_db
from pydantic_models_config import responseDto
from schema.models import Cart
from service import cartService
from fastapi_jwt_auth import AuthJWT

router = APIRouter(tags=["cart"])


@router.post("/carts/add_item/")
def createCart(cart: responseDto.CartCreate, db: Session = Depends(get_db)):

    return cartService.addCartToItems(cart,db)

@router.get("/carts/{cart_id}", response_model=responseDto.Cart)
def getCart(cart_id: int, db: Session = Depends(get_db),Authorize: AuthJWT = Depends()):
    Authorize.jwt_required()
    return cartService.getCartById(cart_id,db)

@router.put("/carts/{cart_id}", response_model=responseDto.Cart)
def updateCart(cart_id: int, cart: responseDto.CartUpdate, db: Session = Depends(get_db)):
   
    return cartService.updateCartById(cart_id,cart,db)

@router.delete("/carts/{cart_id}")
def deleteCartById(cart_id: int, db: Session = Depends(get_db)):
 
    return cartService.deleteCartById(cart_id,db)


