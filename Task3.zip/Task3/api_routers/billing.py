from fastapi import APIRouter,Depends, HTTPException
from sqlalchemy.orm import Session
from database_config.database import get_db
from pydantic_models_config import responseDto
from schema.models import Billing
from service import billingService
from fastapi_jwt_auth import AuthJWT

router = APIRouter(tags=["billing"])



@router.post("/billings/", response_model=responseDto.Billing)
def createBilling(user_id: int, db: Session = Depends(get_db)):
   
    return billingService.createBillingById(user_id,db)

@router.get("/billings/{billing_id}", response_model=responseDto.Billing)
def getBilling(billing_id: int, db: Session = Depends(get_db),Authorize: AuthJWT = Depends()):
    Authorize.jwt_required()
    return billingService.getBillingById(billing_id,db)


@router.get("/billings-by-ph/{phone_number}")
def getBillByPhoneNumber(phone_number:str, db: Session = Depends(get_db),Authorize: AuthJWT = Depends()):
    Authorize.jwt_required()
    return billingService.getBillByPhNo(phone_number,db)

@router.put("/billings/{billing_id}", response_model=responseDto.Billing)
def updateBilling(billing_id: int, billing:responseDto.BillingUpdate, db: Session = Depends(get_db)):
   
    return billingService.updateBillingById(billing_id,billing,db)

@router.delete("/billings/{billing_id}")
def delete_billing(billing_id: int, db: Session = Depends(get_db)):
    return billingService.deleteBillingById(billing_id,db)