from schema import models
from sqlalchemy.orm import Session


def findItemById(item_id,db: Session):
    return db.query(models.Item).filter(models.Item.id == item_id).first()