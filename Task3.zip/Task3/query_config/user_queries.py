from schema import models
from sqlalchemy.orm import Session


def findUserById(user_id,db: Session):
    return db.query(models.User).filter(models.User.id == user_id).first()

def findUserByPhNo(phone_number,db: Session):
    return db.query(models.User).filter(models.User.phone_number == phone_number).first()

def findUserByName(user_name : str,db: Session):
    return db.query(models.User).filter(models.User.name == user_name).first()