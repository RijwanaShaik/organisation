from schema import models
from sqlalchemy.orm import Session

def findBillingById(billing_id,db : Session):
    return db.query(models.Billing).filter(models.Billing.id == billing_id).first()
