from schema import models
from sqlalchemy.orm import Session


def findCartById(cart_id,db: Session):

    return db.query(models.Cart).filter(models.Cart.id == cart_id).first()

def findCartUserById(user_id,db: Session):

    return db.query(models.Cart).filter(models.Cart.user_id == user_id).first()