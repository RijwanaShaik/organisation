/**
 * Created By Sunil Verma
 * Date: 07/01/23
 * Time: 5:13 PM
 * Project Name: security
 */

package net.thrymr.security.dto;


import lombok.Getter;
import lombok.Setter;
import net.thrymr.security.entity.AppUser;
import net.thrymr.security.enums.RoleType;

@Setter
@Getter
public class SignInResponseDto {

	private Long id;

	private String email;

	private RoleType roleType;

	private String name;

	private String token;

	public SignInResponseDto(AppUser user) {

		this.id = user.getId();
		this.name = user.getName();
		this.email = user.getEmail();
		this.roleType = user.getRoleType();
	}
}
