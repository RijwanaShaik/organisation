package net.thrymr.security.enums;

public enum RoleType {
    ADMIN,
    DOCTOR
}
