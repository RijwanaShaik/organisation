package net.thrymr.security.service;

import net.thrymr.security.dto.AppUserDto;
import net.thrymr.security.dto.GenericResponse;
import net.thrymr.security.dto.HospitalDto;
import net.thrymr.security.entity.AppUser;
import net.thrymr.security.entity.Hospital;

import java.util.List;

public interface HospitalService {

    GenericResponse saveHospital(HospitalDto dto);
    GenericResponse updateHospital(HospitalDto dto);
    GenericResponse deleteHospital(Long id);
     GenericResponse getAll();
    GenericResponse associateDoctor(AppUserDto dto);
    GenericResponse disassociateDoctor(Long id,String email);
    List<HospitalDto> findAllBySearchKeyContainsIgnoreCase(String key);

}
