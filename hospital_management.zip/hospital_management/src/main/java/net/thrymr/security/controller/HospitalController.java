package net.thrymr.security.controller;

import lombok.Getter;
import net.thrymr.security.dto.AppUserDto;
import net.thrymr.security.dto.GenericResponse;
import net.thrymr.security.dto.HospitalDto;
import net.thrymr.security.entity.Hospital;
import net.thrymr.security.service.HospitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.method.P;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/hospital")
public class HospitalController {

    @Autowired
    public HospitalService hospitalService;

    @PreAuthorize("hasAnyAuthority('ADMIN','DOCTOR')")
    @GetMapping("get-all")
    public GenericResponse getAll() {
        return hospitalService.getAll();
    }

    @PreAuthorize("hasAnyAuthority('ADMIN')")
    @PostMapping("/save")
    public GenericResponse saveHospital(@RequestBody HospitalDto dto) {
        return hospitalService.saveHospital(dto);
    }

    @PreAuthorize("hasAnyAuthority('ADMIN')")
    @PutMapping("/update")
    public GenericResponse updateHospita(@RequestBody HospitalDto dto) {
        return hospitalService.updateHospital(dto);
    }

    @PreAuthorize("hasAnyAuthority('ADMIN')")
    @DeleteMapping("/delete/{id}")
    public GenericResponse deleteHospital(@PathVariable("id") Long id) {
        return hospitalService.deleteHospital(id);
    }

    @PreAuthorize("hasAnyAuthority('ADMIN')")
    @PostMapping("/associate")
    public GenericResponse addDoctorsToHospital(@RequestBody AppUserDto dto) {
        return hospitalService.associateDoctor(dto);
    }
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    @DeleteMapping("/dissociate/{id}/{email}")
    public GenericResponse dissociateDoctors(@PathVariable Long id,@PathVariable String email) {
        return hospitalService.disassociateDoctor(id,email);
    }
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    @GetMapping("/search-fields/{key}")
    public List<HospitalDto> searchData(@PathVariable String key){
        return hospitalService.findAllBySearchKeyContainsIgnoreCase(key);
    }
}
