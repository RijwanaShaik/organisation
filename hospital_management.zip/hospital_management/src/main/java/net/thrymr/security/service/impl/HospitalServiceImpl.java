package net.thrymr.security.service.impl;

import net.thrymr.security.dto.AppUserDto;
import net.thrymr.security.dto.GenericResponse;
import net.thrymr.security.dto.HospitalDto;
import net.thrymr.security.entity.AppUser;
import net.thrymr.security.entity.Hospital;
import net.thrymr.security.enums.RoleType;
import net.thrymr.security.exception_handler.IdNotFoundException;
import net.thrymr.security.repository.AppUserRepository;
import net.thrymr.security.repository.HospitalRepository;
import net.thrymr.security.service.HospitalService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HospitalServiceImpl implements HospitalService {

    @Autowired
    HospitalRepository hospitalRepository;
    @Autowired
    AppUserRepository appUserRepository;
    @Autowired
    ModelMapper modelMapper;

    @Override
    public GenericResponse saveHospital(HospitalDto dto) {

        Hospital hospital = new Hospital();
        hospital.setId(dto.getId());
        hospital.setName(dto.getName());
        hospital.setAddress(dto.getAddress());
        hospital.setContactNumber(dto.getContactNumber());
        if(dto.getUsers() != null){
            List<AppUser> appUsers = appUserRepository.saveAll(dto.getUsers().stream().map(users -> modelMapper.map(users,AppUser.class)).toList());
            hospital.setUsers(appUsers);
        }
        hospital.setSearchKey(getHospitalSearchKey(hospital));

        hospitalRepository.save(hospital);
        return new GenericResponse(HttpStatus.OK.value(), "Hospital is saved", "SUCCESS");
    }

    @Override
    public GenericResponse updateHospital(HospitalDto dto) {

        Optional<Hospital> optionalHospital = hospitalRepository.findById(dto.getId());
        Hospital hospital;
        if (optionalHospital.isPresent()) {
            hospital = optionalHospital.get();
            hospital.setId(dto.getId());
            hospital.setName(dto.getName());
            hospital.setAddress(dto.getAddress());
            hospital.setContactNumber(dto.getContactNumber());
            hospitalRepository.save(hospital);
            return new GenericResponse(HttpStatus.OK.value(), "update is done", "SUCCESS");
        } else {
            throw new IdNotFoundException("Given id is invalid");
        }
    }

    @Override
    public GenericResponse deleteHospital(Long id) {
        Optional<Hospital> optionalHospital = hospitalRepository.findById(id);
        if (optionalHospital.isPresent()) {
            hospitalRepository.deleteById(id);
            return new GenericResponse(HttpStatus.OK.value(), "deleted", "SUCCESS");
        } else {
            throw new IdNotFoundException("Given id is invalid");
        }
    }

    @Override
    public GenericResponse getAll() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        List<Hospital> hospitals = new ArrayList<>();
        if (authentication != null) {
            AppUser appUser = (AppUser) authentication.getPrincipal();
            if (appUser != null) {
                if (appUser.getRoleType().equals(RoleType.ADMIN)) {
                    hospitals=hospitalRepository.findAll();
                } /*else if (appUser.getRoleType().equals(RoleType.DOCTOR)) {
                    Optional<AppUser> optionalAppUser = Optional.ofNullable(appUserRepository.findByEmail(appUser.getEmail()));
                    return new GenericResponse(HttpStatus.OK.value(), optionalAppUser);
                }*/
               else {
                    Optional<Hospital> optionalAppUser = Optional.ofNullable(hospitalRepository.findByUsersEmail(appUser.getEmail()));
                    if (optionalAppUser.isPresent()) {
                        hospitals.add(optionalAppUser.get());
                    }
                }
            }
            return new GenericResponse(HttpStatus.OK.value(), hospitals);
        } else {
            return new GenericResponse(HttpStatus.BAD_REQUEST.value(), "UNAUTHORIZED");
        }
    }

    @Override
        public GenericResponse associateDoctor(AppUserDto dto) {
            List<AppUser> users = new ArrayList<>();
            AppUser appUser;
            Optional<Hospital> optionalHospital = hospitalRepository.findById(dto.getHospitalId());
            Hospital hospital;
            if (optionalHospital.isPresent()) {
                hospital = optionalHospital.get();
                for (String email:dto.getEmailList()) {
                    Optional<AppUser> optionalAppUser = Optional.ofNullable(appUserRepository.findByEmail(email));
                    if (optionalAppUser.isPresent()) {
                        appUser = optionalAppUser.get();
                        users.add(appUser);
                    } else {
                        throw new NoSuchElementException("Given email is not Found");
                    }
                    hospital.getUsers().addAll(users);
                    hospital.setSearchKey(getHospitalSearchKey(hospital));
                    hospitalRepository.save(hospital);
                }
                return new GenericResponse(HttpStatus.OK.value(), "Doctors Added Successfully", "SUCCESS");
            }else {
                return new GenericResponse(HttpStatus.BAD_REQUEST.value(), "No hospital found by given id");
            }
        }
        @Override
        public GenericResponse disassociateDoctor(Long id,String email){
        Optional<Hospital> optionalHospital=hospitalRepository.findById(id);
        if (optionalHospital.isPresent()){
         appUserRepository.deleteByEmail(email);
            return new GenericResponse(HttpStatus.OK.value(),"Deleted","SUCCESS");

        }else {
            throw new IdNotFoundException("given id is invalid");
        }
        }
    @Override
    public List<HospitalDto> findAllBySearchKeyContainsIgnoreCase(String key) {
        List<Hospital> hospitals=hospitalRepository.findAllBySearchKeyContainsIgnoreCase(key);
        return hospitals.stream().map(hospital -> modelMapper.map(hospital, HospitalDto.class)).collect(Collectors.toList());
    }
    public String getHospitalSearchKey(Hospital hospital) {

        String searchKey = "";
        if(hospital.getName()!=null){
            searchKey=searchKey+" "+hospital.getName();
        } if(hospital.getAddress()!=null){
            searchKey=searchKey+" "+hospital.getAddress();
        } if(hospital.getContactNumber()!=null){
            searchKey=searchKey+" "+hospital.getContactNumber();
        }
        if(hospital.getUsers()!=null){
            searchKey=searchKey+" "+hospital.getUsers();
        }
        return searchKey;
    }
}
