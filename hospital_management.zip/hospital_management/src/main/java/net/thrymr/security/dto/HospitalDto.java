package net.thrymr.security.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymr.security.entity.AppUser;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HospitalDto {
    private   Long id;
    private   String name;
    private String address;
    private  String contactNumber;
    List<AppUserDto> users = new ArrayList<>();

}
