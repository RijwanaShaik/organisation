package net.thrymr.security.controller;

import com.nimbusds.jose.JOSEException;
import net.thrymr.security.dto.AppUserDto;
import net.thrymr.security.dto.GenericResponse;
import net.thrymr.security.service.AppUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/user")
public class AppUserController {

    @Autowired
    public AppUserService appUserService;


    @PreAuthorize("hasAnyAuthority('ADMIN')")
    @PostMapping("/save")
    public GenericResponse saveUser(@RequestBody AppUserDto dto) throws JOSEException {
        return appUserService.saveUser(dto);
    }
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    @PutMapping("/update")
    public GenericResponse updateUser(@RequestBody AppUserDto dto) throws JOSEException {
        return appUserService.updateUser(dto);
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @DeleteMapping("/delete/{id}")
    public GenericResponse deleteUser(@PathVariable("id") Long id) throws JOSEException {
        return appUserService.deleteUser(id);
    }

    @PostMapping("/sign-in")
    public GenericResponse signIn(@RequestBody AppUserDto dto) throws JOSEException {
        return appUserService.signIn(dto);
    }
    @PostMapping(value = "/sign-up")
    public GenericResponse signUp( @RequestBody AppUserDto dto) throws JOSEException {
        return appUserService.signUp(dto);
    }

}
