package net.thrymr.security.dto;


import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymr.security.entity.AppUser;
import net.thrymr.security.enums.RoleType;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppUserDto {
    private Long id;
    private String email;
    private  String name;
    private  String education;
    private   String specialization;
    private RoleType roleType;
    private   String password;
    private Long hospitalId;
    private List<String> emailList=new ArrayList<>();

}
