package net.thrymr.security.service.impl;

import com.nimbusds.jose.JOSEException;
import net.thrymr.security.config.JwtTokenUtils;
import net.thrymr.security.dto.AppUserDto;
import net.thrymr.security.dto.GenericResponse;
import net.thrymr.security.dto.SignInResponseDto;
import net.thrymr.security.entity.AppUser;
import net.thrymr.security.exception_handler.IdNotFoundException;
import net.thrymr.security.repository.AppUserRepository;
import net.thrymr.security.service.AppUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class AppUserServiceImpl implements AppUserService {

    @Autowired
    AppUserRepository appUserRepository;
    @Autowired
    JwtTokenUtils jwtTokenUtils;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public GenericResponse saveUser(AppUserDto dto) {
        AppUser appUser = new AppUser();
        appUser.setEmail(dto.getEmail());
        appUser.setName(dto.getName());
        appUser.setEducation(dto.getEducation());
        appUser.setSpecialization(dto.getSpecialization());
        appUser.setRoleType(dto.getRoleType());
        appUser.setPassword(bCryptPasswordEncoder.encode(dto.getPassword()));
        appUserRepository.save(appUser);
        return new GenericResponse(HttpStatus.OK.value(), "user data is saved","SUCCESS");
    }
    @Override
    public GenericResponse updateUser(AppUserDto dto) {

        Optional<AppUser> optionalAppUser = Optional.ofNullable(appUserRepository.findByEmail(dto.getEmail()));

        if (optionalAppUser.isPresent()) {
            AppUser appUser = optionalAppUser.get();
              if (appUser.getEmail().equals(dto.getEmail()) || !appUserRepository.existsByEmail(dto.getEmail())) {
                appUser.setEmail(dto.getEmail());
            }
            appUser.setName(dto.getName());
            appUser.setEducation(dto.getEducation());
            appUser.setSpecialization(dto.getSpecialization());
            appUser.setRoleType(dto.getRoleType());
            appUser.setPassword(bCryptPasswordEncoder.encode(dto.getPassword()));
            appUserRepository.save(appUser);
            return new GenericResponse(HttpStatus.OK.value(), "Data is updated", "SUCCESS");
        } else {
            throw new NoSuchElementException("Given email is invalid");
        }
    }
    @Override
    public GenericResponse signIn(AppUserDto dto) throws JOSEException {
        AppUser user = appUserRepository.findByEmail(dto.getEmail());

        if (user == null) {
            return new GenericResponse(HttpStatus.UNAUTHORIZED.value(), "Email id is not Correct", "FAILED");
        }
        if (bCryptPasswordEncoder.matches(dto.getPassword(), user.getPassword())) {
            //AppUserDto response = new AppUserDto(user);
            SignInResponseDto response = new SignInResponseDto(user);
            response.setToken(jwtTokenUtils.getToken(user));
            return new GenericResponse(HttpStatus.OK.value(), response);
        } else {
            return new GenericResponse(HttpStatus.UNAUTHORIZED.value(), "Password is not Correct", "FAILED");
        }
    }
    @Override
    public GenericResponse signUp(AppUserDto dto) throws JOSEException {
        AppUser user = new AppUser();
        user.setEmail(dto.getEmail());
        user.setName(dto.getName());
        user.setRoleType(dto.getRoleType());
        user.setPassword(bCryptPasswordEncoder.encode(dto.getPassword()));
        user.setEducation(dto.getEducation());
        user.setSpecialization(dto.getSpecialization());
        appUserRepository.save(user);

        return new GenericResponse(HttpStatus.OK.value(), "Registration is done", "SUCCESS");
    }

    @Override
    public GenericResponse deleteUser(Long id) {
        Optional<AppUser> optionalAppUser = appUserRepository.findById(id);
        if (optionalAppUser.isPresent()) {
            appUserRepository.deleteById(id);
            return new GenericResponse(HttpStatus.OK.value(), "Deleting is done", "SUCCESS");
        } else {
            throw new IdNotFoundException("Given id is not Found");
        }
    }



}
