package net.thrymr.security.repository;

import net.thrymr.security.dto.GenericResponse;
import net.thrymr.security.entity.AppUser;
import net.thrymr.security.entity.Hospital;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface HospitalRepository extends JpaRepository<Hospital,Long> {

    Hospital findByUsersEmail(String email);
    List<Hospital> findAllBySearchKeyContainsIgnoreCase(String key);
}
