package net.thrymr.security.repository;

import net.thrymr.security.entity.AppUser;
import net.thrymr.security.entity.Hospital;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AppUserRepository extends JpaRepository<AppUser,Long> {
    AppUser findByEmail(String username);
    boolean existsByEmail(String email);

    void deleteByEmail(String email);


}
