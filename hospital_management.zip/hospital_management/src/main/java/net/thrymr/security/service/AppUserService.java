package net.thrymr.security.service;


import com.nimbusds.jose.JOSEException;
import net.thrymr.security.dto.AppUserDto;
import net.thrymr.security.dto.GenericResponse;
import net.thrymr.security.entity.AppUser;

import java.util.List;

public interface AppUserService {
    GenericResponse saveUser(AppUserDto dto)throws JOSEException;;

    GenericResponse signIn(AppUserDto dto) throws JOSEException;
    GenericResponse signUp(AppUserDto dto) throws JOSEException;
    GenericResponse updateUser(AppUserDto dto)throws JOSEException;;

    GenericResponse deleteUser(Long id);

}
