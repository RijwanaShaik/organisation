

from http import HTTPStatus
import json
from fastapi import APIRouter, Depends, Form, HTTPException, Request, Response
from dotenv import load_dotenv
from main_config.database_config.database import get_db_session
from main_config.enums_config.enums import EMAIL_PATTERN, UserStatus
from passlib.context import CryptContext
from main_config.payload_basemodel.beans import UserLogin, Userdetails
import main_config.database_config.models as models
import re
import redis


from jose import ExpiredSignatureError, jwt
from datetime import timedelta, datetime
from main_config.enums_config.message import unSucessMessage, sucessMessage
from main_config.query_config.app_user_queries import findUserByUsername
from main_config.utility_config.utility import apiResponse, create_access_token,decodeKeys, get_current_user, login_response, set_user_details_data, \
    generate_random_string, decode_base64_string
from main_config.loggers_config.file_log import logger
from sqlalchemy import func
from sqlalchemy.orm import Session

router = APIRouter(tags=["User Configuration"])

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
# Connect to the local Redis server
redis_confg = redis.Redis(host='localhost', port=6379, db=0)




@router.post('/signup')
async def signup(user_details: Userdetails,request:Request,db: Session = Depends(get_db_session)):
    logger.info('Starting signup process...')
    # here email validation  as per now only checking email.com
    is_email_valida = re.fullmatch(EMAIL_PATTERN, user_details.email)
    findEmailId = findUserByUsername(user_details.email,db)
    
    if findEmailId:
        logger.error('Email already exists')
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['Email_Exist'])
    if user_details.password != user_details.confirm_password:
        logger.error('Password And Confirm Password Not Matched')
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['Password_Mismatch'])
    if user_details.name != user_details.name.strip():
        logger.error('Invalid name format')
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['Name_Required'])
    if not bool(is_email_valida):
        logger.error('Invalid email format')
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['signup_unmessage'])
    if not user_details.terms_and_condition:
        logger.error('Terms and conditions not accepted')
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['terms_Accept'])
    else:
        verification_token = create_access_token(data={"email":user_details.email},expires_delta=timedelta(minutes=1))
        print(verification_token)
        new_user = set_user_details_data(user_details)
        email_data = {
        "request": request,
        "email": user_details.email.lower(),
        "subject":"Login",
        "query":'login=true',
        "msg": f"Sucessfully Registered. Please Verify Your Email & Login"}
        # email_verification(email_data)
        # adding into db as a new app_user
        db.add(new_user)
        db.commit()
        logger.info('User signed up successfully')
        return apiResponse(HTTPStatus.OK, sucessMessage['signup_message'])
    
    
# Login Api
@router.post("/login")
async def login(username: str = Form(...), password: str = Form(...),db: Session = Depends(get_db_session)):
    
    logger.info('Starting login process...')
    # below we are checking the email validation is present in db are not
    
    find_app_user = findUserByUsername(username,db)
    if find_app_user is not None and find_app_user.status == UserStatus.INACTIVE:
        logger.error('User is inactive')
        return apiResponse(HTTPStatus.FORBIDDEN,unSucessMessage['User_Status'])
    if find_app_user is None:
        logger.error('User not found')
        return apiResponse(HTTPStatus.UNAUTHORIZED, unSucessMessage['login_unmessage'])

    is_password_validation = pwd_context.verify(decode_base64_string(password), find_app_user.password)
    # below we are checking the password validation is present in db are not
    if not is_password_validation:
        logger.error('Incorrect password')
        return apiResponse(HTTPStatus.UNAUTHORIZED, unSucessMessage['login_unmessage'])
    is_email_valida = re.fullmatch(EMAIL_PATTERN, username)
    if not find_app_user.is_email_verified:
        logger.error('User Email Is Not Conformed')
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['Email_Confirmation'])
    if bool(is_email_valida):
        logger.info('Generating access token')
        acess_token = create_access_token(data={'id':find_app_user.id,"email": find_app_user.email,'role':find_app_user.role,}, expires_delta=timedelta(minutes=90))
        return  login_response(acess_token, find_app_user.email, find_app_user.role, find_app_user.id,find_app_user.is_forgot_pwd ,find_app_user.is_email_verified)
    else:
        logger.error('Invalid Enter valid credentials')
        return apiResponse(HTTPStatus.NOT_FOUND, unSucessMessage['login_unmessage'])    
    
    
# forgot don't need token
@router.put('/forgot_password',tags=["Password_configuration"])
async def forgotPassword(user_details:UserLogin,request:Request,db: Session = Depends(get_db_session)):
    logger.info("Forgot Password Process Started..")
    findTheUserEmail= findUserByUsername(user_details.email,db)
    if findTheUserEmail:
        random_code = "Sv@1" + generate_random_string()
        findTheUserEmail.password =  pwd_context.hash(random_code)
        findTheUserEmail.is_forgot_pwd = True
        db.commit()
        email_data = {
         "request": request,
        "email": findTheUserEmail.email,
        "subject":"Forgot password",
        "query":'forgotPass=true',
        "msg": f"Password reset for your account was requested; Please click the button & Your verification code is: {random_code}"}
        # send_email(email_data)
        logger.info(f"Password reset successful for user with email: {findTheUserEmail.email}")
        return apiResponse(HTTPStatus.OK,sucessMessage['Mail_Message'],{'default_password':random_code})
    else:
        logger.error("No user found for password reset.")
        return apiResponse(HTTPStatus.BAD_REQUEST,unSucessMessage['user_notExist'])
    
@router.get('/verify_email')
async def verifyEmail(verify_token: str, db: Session = Depends(get_db_session)):
    try:
        token_data = decodeKeys(verify_token)
        expiry_time=datetime.utcfromtimestamp(token_data['exp'])
        if datetime.utcnow() > expiry_time:
            return apiResponse(HTTPStatus.BAD_REQUEST,unSucessMessage['Token_Expiry'])

        user = findUserByUsername(token_data['email'], db)
        if user:
            if user.is_email_verified == False:
                user.is_email_verified = True
                db.commit()
                return apiResponse(HTTPStatus.OK, sucessMessage["Email_Verification"])
            else:
                return apiResponse(HTTPStatus.OK,unSucessMessage['Email_verified'])
        else:
            return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['user_notExist'])
    except ExpiredSignatureError:
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['Token_Expiry'])
    
@router.post('/resend_email')
async def resendEmail(request:Request,user_details:UserLogin,db: Session = Depends(get_db_session)):
    find_app_user = findUserByUsername(user_details.email, db)
    if find_app_user:
        if find_app_user.is_email_verified == False:
            verification_token = create_access_token(data={"email": user_details.email}, expires_delta=timedelta(minutes=1))
            # Send the email with the new confirmation link
            email_data = {
            "request": request,
            "email": user_details.email.lower(),
            "subject": "Login",
            "query": 'login=true',
            "token":verification_token,
            "msg": f"Successfully Resent Verfication Link, Please Verify Your Email & Login"
            }
            # email_verification(email_data)
            print(email_data)
            return apiResponse(HTTPStatus.OK, sucessMessage['Email_Sent'])
        else:
            return apiResponse(HTTPStatus.OK,unSucessMessage['Email_verified'])
    else:
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['user_notExist']) 
    
@router.post("/logout")
async def logout(response: Response,request:Request):
    response.delete_cookie("Authorization")
    logger.info("User logged out successfully")
    return apiResponse(HTTPStatus.OK, sucessMessage['Logout_message'])      
    



