import csv
import uuid
from http import HTTPStatus
from http.client import HTTPException

from fastapi import APIRouter, Depends, Query, Request, Response
from main_config.database_config.database import get_db_session
import main_config.database_config.models as models
from main_config.enums_config.enums import PurchaseStatus
from main_config.payload_basemodel.beans import PaymentHistory, PaymentIntent, TokenPurchase
from main_config.query_config.app_configuration_queries import getAppConfigurationByName
from main_config.query_config.app_user_queries import findUserById
from main_config.query_config.token_purchase_queries import getTransactionId
from main_config.query_config.user_search_queries import getUserSearchResult
from main_config.utility_config.utility import apiResponse, decodeKeys, get_current_user, payment_history_filters, settokenCreation, transition_history,getTimeInMinute
from main_config.enums_config.message import unSucessMessage
import stripe
import io
from main_config.loggers_config.file_log import logger
from sqlalchemy.orm import Session



router = APIRouter(tags=["Token_configuration"])


# Token Creation By customer
@router.post("/token_creation")
async def tokenCreationByUserByEmail(request:Request,tokenPurchase:TokenPurchase,db: Session = Depends(get_db_session)):
    current_user = get_current_user(request._headers['Authorization'][7:])
    logger.info(f"User {current_user['id']} started tokenCreation Process.")
    find_app_user = findUserById(current_user['id'],db)
    balance_token_forUser = find_app_user.token_balance
    transaction_id_exist = getTransactionId(tokenPurchase.transaction_id,db)
    if find_app_user:
        if transaction_id_exist:
            logger.info(f"Transaction_Id : {transaction_id_exist.transaction_id} Already Exists")
            return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['Transaction_Exist'])
        if tokenPurchase.transaction_id != capturePaymentIntent(tokenPurchase.transaction_id,db):
            return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['INVALID_TRANSACTION'])

        if tokenPurchase.purchase_status == PurchaseStatus.SUCCESS:
            find_app_user.token_balance = balance_token_forUser + tokenPurchase.token_count
            db.commit()
    newPurchaseTokenByUser = settokenCreation(tokenPurchase,find_app_user.id)
    db.add(newPurchaseTokenByUser)
    db.commit() 
    logger.info(f"Token purchase successful for user {find_app_user.id}. Purchase status: {tokenPurchase.purchase_status}")   
    return apiResponse(HTTPStatus.OK,tokenPurchase.purchase_status)



@router.post("/payment_history")
async def paymentHistoryByUserId(request: Request, paymentHistory: PaymentHistory,db: Session = Depends(get_db_session)):
    logger.info("Payment history data is retrieving....")
    current_user = get_current_user(request._headers['Authorization'][7:])
    find_app_user= findUserById(current_user['id'],db)
    if find_app_user is not None:
        filterData = payment_history_filters(paymentHistory, current_user['id'],db)
        if filterData:
            paginated_data = {}
            entity_to_dto = transition_history(filterData)
            size: int = len(entity_to_dto)
            start_index = (paymentHistory.page_number - 1) * 10
            end_index = start_index + 10
            paginated_data["totalRecords"] = size
            paginated_data["data"] = entity_to_dto[start_index:end_index]
            logger.info("Payment history retrieved successfully.")
            return apiResponse(HTTPStatus.OK, None, paginated_data)
        else:
            logger.error("Payment history data is null.")
            return apiResponse(HTTPStatus.OK, unSucessMessage['Data_is_null'])
    else:
        logger.error("User ID does not exist.")
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['Id_Exist'])
    

    
@router.post("/create_payment_intent",)
async def createPaymentIntent(payment:PaymentIntent, request: Request,db: Session = Depends(get_db_session)):
    current_user = get_current_user(request._headers['Authorization'][7:])
    logger.info("Payment intent Process Started...")
    getStripeKey = getAppConfigurationByName('stripe',db)
    stripApiKey = decodeKeys(getStripeKey.key)
    stripe.api_key = stripApiKey['key']
    try:
        intent = stripe.PaymentIntent.create(
            amount=payment.amount,
            currency=payment.currency,
            automatic_payment_methods={"enabled": True},
            description="To buy more tokens for my video uploads in senseVantage application"
        )
        logger.info("Payment intent created successfully")
        return apiResponse(HTTPStatus.OK, None, intent)
    except stripe.error.StripeError as e:
        # Handle specific Stripe errors
        logger.error(f"Stripe Error: {str(e)}")
        return apiResponse(HTTPStatus.INTERNAL_SERVER_ERROR, f"Stripe Error: {str(e)}", None)
    except Exception as e:
        # Handle other general exceptions
        logger.error(f"Internal Server Error: {str(e)}")
        return apiResponse(HTTPStatus.INTERNAL_SERVER_ERROR, f"Internal Server Error: {str(e)}", None)
    
    
    

@router.get("/download_csv", tags=["Token_configuration"])
async def download_csv(video_id: str = Query(),db: Session = Depends(get_db_session)):

    logger.info("Download CSV Process Started...")

    # Query the data
    user_results = getUserSearchResult(video_id,db)

    # Close the database session
    db.close()

    # Check if data is empty
    if not user_results:
        raise apiResponse(HTTPStatus.NOT_FOUND,  unSucessMessage['Data_is_null'])

    # Create a string buffer to hold CSV data
    csv_buffer = io.StringIO()
    csv_writer = csv.writer(csv_buffer)

    # Write headers to CSV
    csv_writer.writerow(["query", "frame1", "frame2", "frame3"])

    # Write data to CSV
    for user_result in user_results:
        # Extract frame_msec values from user_result
        frame_msecs = [getTimeInMinute(frame['frame_msec'])  for frame in user_result.result]
   
    
    
        # Write the row to CSV
        csv_writer.writerow([user_result.query] + frame_msecs)

    # Get CSV content from buffer
    csv_content = csv_buffer.getvalue()

    # Set response headers
    headers = {
        "Content-Disposition": f'attachment; filename="{video_id}.csv"',
        "Content-Type": "text/csv",
    }

    # Return response with CSV data
    logger.info("CSV generated successfully...")
    return  Response(content=csv_content, headers=headers)


def capturePaymentIntent(payment_intent_id: str = Query(),db: Session = Depends(get_db_session)):
    try:
        getStripeKey = getAppConfigurationByName('stripe',db)
        stripApiKey = decodeKeys(getStripeKey.key)
        stripe.api_key = stripApiKey['key']

        # Retrieve the Payment Intent
        payment_intent = stripe.PaymentIntent.retrieve(payment_intent_id)

        # Return the payment_intent using your custom apiResponse function
        return payment_intent.id

    except stripe.error.InvalidRequestError as e:
        return apiResponse(responseCode=404, message=f"Invalid request: {e}")
    except stripe.error.AuthenticationError as e:
        return apiResponse(responseCode=401, message=f"Authentication failed: {e}")
    except stripe.error.APIConnectionError as e:
        return apiResponse(responseCode=503, message=f"Network communication error: {e}")
    except stripe.error.StripeError as e:
        return apiResponse(responseCode=500, message=f"Stripe error occurred: {e}")
    except Exception as e:
        return apiResponse(responseCode=500, message=f"An error occurred: {e}")
