
from datetime import  datetime
from http import HTTPStatus
from fastapi import APIRouter, Depends, Query, Request
from main_config.ai_api_config.ai_apis import AIContextualSearch, isUrlExpringContextFrameUrl
from main_config.database_config.database import get_db_session
from main_config.payload_basemodel.beans import ContextSearch
import main_config.database_config.models as models
from main_config.query_config.user_search_queries import filterUserSearchResults, getUserByUserSearch, \
    getUserSearchResultsForUserAndVideoOrderBy
from main_config.query_config.video_content_queries import getVideoContent
from main_config.utility_config.utility import apiResponse, get_current_user, setContextSearch_data
from main_config.enums_config.message import unSucessMessage
from main_config.loggers_config.file_log import logger
from sqlalchemy.orm import Session




router = APIRouter(tags=["Context_search"])



from sqlalchemy import func
@router.post("/context_search",tags=["Context_search"])
async def context_search(request:Request,userSearchResult:ContextSearch,video_id:str = Query(),db: Session = Depends(get_db_session)):
    current_user = get_current_user(request._headers['Authorization'][7:])
    if current_user is not None and video_id:
        findUserExistandvideoExist = getVideoContent(video_id,db)
        findingQuery = filterUserSearchResults(current_user['id'], video_id, userSearchResult.query,db)
        if findUserExistandvideoExist:
            if findingQuery:
                findingQuery.updated_on = func.now()
                db.commit()
                logger.info("Found existing search results for the user's query.")
                return apiResponse(HTTPStatus.OK,None,findingQuery)
            else:
                if findUserExistandvideoExist.is_example:
                    contextSearchAlResponse = await AIContextualSearch(video_id,"default",userSearchResult.query,findUserExistandvideoExist.video_status,current_user['id'],db)
                else:
                    contextSearchAlResponse = await AIContextualSearch(video_id,current_user['id'],userSearchResult.query,findUserExistandvideoExist.video_status,current_user['id'],db)  
                print(contextSearchAlResponse)    
                if contextSearchAlResponse and 'code' in contextSearchAlResponse.keys():
                    return apiResponse(HTTPStatus.BAD_REQUEST,contextSearchAlResponse['message'],contextSearchAlResponse)
                else:
                    return apiResponse(HTTPStatus.OK,None,contextSearchAlResponse)
        else:
            logger.error("User ID and/or video ID not found or invalid.")
            return apiResponse(HTTPStatus.BAD_REQUEST,unSucessMessage['user_id_and_video_id'])
    else:
        logger.error("User ID or video ID is missing.")
        return apiResponse(HTTPStatus.BAD_REQUEST,unSucessMessage['updated_unmessage'])

@router.get('/context_search',tags=["Context_search"])
async def getContextdataById(request:Request,video_id:str = Query(),db: Session = Depends(get_db_session)):
    current_user = get_current_user(request._headers['Authorization'][7:])
    logger.info(f"User: {current_user['id']}, Video ID: {video_id} of context search is started")
    findUserExist = getContextDataById = getUserByUserSearch(current_user['id'],video_id,db)
    if current_user is not None and findUserExist:
        getContextDataById = getUserSearchResultsForUserAndVideoOrderBy(current_user['id'], video_id,db)
        logger.info("Retrieved context data successfully.")
        getAllContextDataByVideoId = await isUrlExpringContextFrameUrl(getContextDataById,current_user,video_id,db)
        if getAllContextDataByVideoId:
            return  apiResponse(HTTPStatus.OK, None,getAllContextDataByVideoId) 
        else:
            return  apiResponse(HTTPStatus.BAD_REQUEST,'AI API Failed',None) 
    else:
        logger.error("User search data not found.")
        return apiResponse(HTTPStatus.OK, unSucessMessage['Data_is_null'],[])