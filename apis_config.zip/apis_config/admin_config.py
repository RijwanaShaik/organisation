from http import HTTPStatus
from fastapi import APIRouter, Depends, Request
from pydantic import model_serializer
from main_config.database_config.database import get_db_session 
from sqlalchemy.orm import Session

from main_config.payload_basemodel.beans import  AdminConfiguration
from main_config.enums_config.enums import UserRoleEnum
from main_config.query_config.admin_configuration_queries import getAdminConfigurationByEmail
from main_config.utility_config.utility import apiResponse, get_current_user, set_admin_configuration_data
from main_config.enums_config.message import unSucessMessage, sucessMessage
import main_config.database_config.models as models
from main_config.loggers_config.file_log import logger




router = APIRouter(tags=["Admin_configuration"])


@router.post('/admin_configuration',tags=["Admin_configuration"])
async def admin_configuration_token(admin_details: AdminConfiguration,request:Request,db: Session = Depends(get_db_session)):
    logger.info('Admin Configuration Token process started...')
    current_user = get_current_user(request._headers['Authorization'][7:])
    if current_user['role'] == UserRoleEnum.ADMIN and current_user:
        new_config = set_admin_configuration_data(admin_details,current_user['email'])
        db.add(new_config)
        db.commit()
        logger.info('Admin configuration token updated successfully')
        return apiResponse(HTTPStatus.OK, sucessMessage['admin_config_message'])
    else:
        logger.error('Unauthorized access or invalid user')
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['admin_config_unmessage'])


@router.put('/updated_admin_configuration',tags=["Admin_configuration"])
async def admin_configuration_token(admin_details: AdminConfiguration,request:Request,db: Session = Depends(get_db_session)):
    logger.info('Updation of Admin Configuration Token process started...')
    current_user = get_current_user(request._headers['Authorization'][7:])
    find_email_into_updatedConfig = getAdminConfigurationByEmail(current_user['email'],db)
    if find_email_into_updatedConfig and current_user['role'] == UserRoleEnum.ADMIN:
        find_email_into_updatedConfig.toke_price = admin_details.toke_price
        find_email_into_updatedConfig.video_length_in_mins = admin_details.video_length_in_mins
        db.commit()
        logger.info('Updation of Admin Configuration Token process completed successfully')
        return apiResponse(HTTPStatus.OK, sucessMessage['admin_config_message'])
    else:
        logger.error('Unauthorized access or invalid user')
        return apiResponse(HTTPStatus.BAD_REQUEST, sucessMessage['admin_config_unmessage'])