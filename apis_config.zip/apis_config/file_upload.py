
from http import HTTPStatus
from fastapi import APIRouter, Depends, Query, Request, UploadFile
from main_config.ai_api_config.ai_apis import AIDefaultVideos, AIDeleteVideo, AIManualFileUpload, AIYoutubeUpload, AlCompleteMultipleUpload, YoutubeDuration, getVideos, s3MultipartUploadUrl
from main_config.database_config.database import get_db_session
from main_config.enums_config.message import unSucessMessage, sucessMessage
from main_config.payload_basemodel.beans import ManualUpload, YoutubeVideosResponse,YoutubeDurationUrl
import main_config.database_config.models as models
from main_config.query_config.app_user_queries import findUserById
from main_config.query_config.user_search_queries import getUserSearchResultsForUserAndVideo
from main_config.query_config.video_content_queries import getVideoIdIsExample, getVideoIsExample, \
    getVideosIsExampleTrue, getVideoContentForUserPagination, getVideoContentForUser, \
    getVideoContentForUserAndVideo
from main_config.utility_config.utility import apiResponse, get_current_user
from main_config.loggers_config.file_log import logger
from sqlalchemy.orm import Session



router = APIRouter(tags=["Video_configuration"])


@router.post("/upload_videos")
async def uploadVideo(request:Request,manualPayload:ManualUpload,db: Session = Depends(get_db_session)):
    logger.info('UploadVideo process started...')
    if bool(manualPayload.is_uploaded):
        current_user = get_current_user(request._headers['Authorization'][7:])
        find_app_user = findUserById(current_user['id'],db)
        balance_token_forUser = find_app_user.token_balance
        if balance_token_forUser >= manualPayload.token_utilization:
            # current_user.token_balance = balance_token_forUser - manualPayload.token_utilization
            # db.commit()
            completedMultipleResponse = await AlCompleteMultipleUpload(manualPayload,current_user['id'],db)
            if completedMultipleResponse:
                logger.info('Video uploaded successfully')
                return apiResponse(HTTPStatus.OK, sucessMessage['updated_message'])
            else:
                return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['AI_failed'])
                 
        else:
            logger.error('Insufficient token or missing file')
            return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['Insufficient_token'])
    else:
        logger.error('Missing parameters in the request')
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['please_check'])
        
@router.post("/upload_youtube_videos")
async def uploadVideo(request:Request,youtube_response:YoutubeVideosResponse,db: Session = Depends(get_db_session)):
    logger.info('Upload YouTube Video process started...')
    user = get_current_user(request._headers['Authorization'][7:])
    find_app_user = findUserById(user['id'],db)
    balance_token_forUser = find_app_user.token_balance
    # here we are checking the to token balance validation
    if balance_token_forUser >= youtube_response.token_utilization:
        # user.token_balance = balance_token_forUser - youtube_response.token_utilization
        # db.commit()
        if youtube_response.youtube_url:
            newRecord = await AIYoutubeUpload(youtube_response.title,youtube_response.token_utilization,youtube_response.youtube_url,user['id'])
            if newRecord:
                db.add(newRecord)
                db.commit()
                logger.info('YouTube Video uploaded successfully')
                return apiResponse(HTTPStatus.OK, sucessMessage['updated_message'])
            else:
                return apiResponse(HTTPStatus.BAD_REQUEST, 'please upload again video')
        else:
            logger.error('Invalid YouTube URL provided')
            return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['provide_valid'])
    else:
        logger.error('Insufficient token')
        return apiResponse(HTTPStatus.OK, unSucessMessage['Insufficient_token'])    

@router.get("/get_video_by_video_id")
async def getVideoByVideoId(request:Request,video_id:str=Query(...),is_example:bool=Query(...),db: Session = Depends(get_db_session)):
    current_user = get_current_user(request._headers['Authorization'][7:])
    logger.info(f"User: {current_user['id']}, Video ID: {video_id} is started retrieving data....")
    if is_example:
        example_videos = getVideoIdIsExample(video_id, is_example,db)
        if example_videos :
            logger.info(f"Example video retrieved successfully. Video ID: {video_id}")
            return apiResponse(HTTPStatus.OK,None,example_videos)
        else:
            logger.error(f"No example video found for Video ID: {video_id}")
            return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['Data_is_null'])
    else:
        getVideosById = getVideoIsExample(video_id, current_user['id'], is_example,db)
        if getVideosById:
            logger.info(f"Video retrieved successfully. Video ID: {video_id}, User ID: {current_user['id']}")
            return apiResponse(HTTPStatus.OK,None,getVideosById)
        else:
            logger.error(f"No video found for Video ID: {video_id}, User ID: {current_user['id']}")
            return apiResponse(HTTPStatus.OK, unSucessMessage['Data_is_null'],[])
        
@router.get("/get_upload_example_videos")
async def getUploadExampleVideos(request:Request,page: int = 1, per_page: int = 8,db: Session = Depends(get_db_session)):
    await AIDefaultVideos('default',db)
    current_user = get_current_user(request._headers['Authorization'][7:])
    logger.info(f"User {current_user['id']} is accessing the getUploadExampleVideos API.")
    example_videos =  getVideosIsExampleTrue(db)
    offset = (page - 1) * per_page
    getUploadVideos = getVideoContentForUserPagination(current_user['id'], offset, per_page,db)
    getTotalRecord = getVideoContentForUser(current_user['id'], True, False,db)
    if getUploadVideos or example_videos :
        video_details = await getVideos(getUploadVideos,current_user,example_videos,offset,per_page,db)
        if video_details:
            video_details.update({'total_my_upload':len(getTotalRecord)})
            logger.info("getUploadExampleVideos API call successful.")
            return apiResponse(HTTPStatus.OK,None,video_details)
        else:
            return apiResponse(HTTPStatus.BAD_REQUEST,'AI API Failed',[])
    else:
         logger.error("No videos found for the user.")
         return apiResponse(HTTPStatus.OK, unSucessMessage['Data_is_null'],[]) 
@router.delete("/delete_videos")
async def deleteVideos(request:Request, video_id: str = Query(),db: Session = Depends(get_db_session)):
    current_user = get_current_user(request._headers['Authorization'][7:])
    logger.info(f"User {current_user['id']} is attempting to delete video {video_id}.")
    findTheVideosByUserId = getVideoContentForUserAndVideo(video_id, current_user['id'],db)
    findSearchResult = getUserSearchResultsForUserAndVideo(current_user['id'], video_id,db)
    if findTheVideosByUserId:
        await AIDeleteVideo(video_id,current_user['id'])
        findTheVideosByUserId.is_active = False
        findTheVideosByUserId.video_link = None    
        findTheVideosByUserId.thumb = None
        # db.delete(findTheVideosByUserId)
        if findSearchResult:
           for result in findSearchResult:
               db.delete(result)
        db.commit()
        logger.info(f"Video {video_id} deleted successfully.")
        return apiResponse(HTTPStatus.OK, sucessMessage['Delete_message'] )
    else:
        logger.error(f"Video {video_id} not found for user {current_user['id']}.")
        return apiResponse(HTTPStatus.BAD_REQUEST, unSucessMessage['Delete_unmessage'])
    
    
@router.post('/youtube_duration')
async def youtubeUrlDuration(request:Request, youtube_response:YoutubeDurationUrl):
    logger.info("YouTube Duration Process Started")
    current_user = get_current_user(request._headers['Authorization'][7:])
    logger.info("YouTube Duration Process Completed")
    return await  YoutubeDuration(youtube_response.youtube_url)



@router.get('/s3_multi_part')
async  def sendTheS3Multipart(request:Request,file_size: int = Query(), token_utilization: int = Query(),db: Session = Depends(get_db_session)):
    current_user = get_current_user(request._headers['Authorization'][7:])
    find_user_from_db = findUserById(current_user['id'],db)
    if find_user_from_db.token_balance >= token_utilization:
        if file_size > 0:
          logger.info("S3 MultipartUpload started") 
          return await  s3MultipartUploadUrl(file_size,current_user['id'])
        else:
          return apiResponse(HTTPStatus.BAD_GATEWAY,unSucessMessage['filed_size'] )
    else:
        logger.error('Insufficient token')
        return apiResponse(HTTPStatus.OK, unSucessMessage['Insufficient_token'])

