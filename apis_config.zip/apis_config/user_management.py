
from http import HTTPStatus
from fastapi import APIRouter, Depends, Form, Request, Response
from main_config.apis_config.file_upload import deleteVideos
from main_config.database_config.database import get_db_session
from main_config.enums_config.enums import EMAIL_PATTERN, UserStatus
from dotenv import load_dotenv
from sqlalchemy import func
from main_config.payload_basemodel.beans import  ChangePassword
import main_config.database_config.models as models
from main_config.enums_config.message import unSucessMessage, sucessMessage
from main_config.query_config.admin_configuration_queries import getAdmin
from main_config.query_config.app_user_queries import findUserById, findUserByUsername
from main_config.query_config.video_content_queries import calculateSumOfTokensUtilized, getVideosOfAUser
from main_config.utility_config.utility import apiResponse, get_current_user, getUserResponse, decode_base64_string
from passlib.context import CryptContext
from main_config.loggers_config.file_log import logger
import uuid
from sqlalchemy.orm import Session


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")  

router = APIRouter(tags=["User Configuration"])

load_dotenv()

 
@router.delete("/delete_user")
async def deleteUser(request:Request,db: Session = Depends(get_db_session)):
    current_user = get_current_user(request._headers['Authorization'][7:])
    logger.info(f"Deleting the User: {current_user['id']} process started")
    find_app_user = findUserById(current_user['id'],db)
    if find_app_user:
        if find_app_user.status == UserStatus.ACTIVE:
            user_videos= getVideosOfAUser(current_user['id'],db)
            for video in user_videos:
               await deleteVideos(request,video.video_id,db)
               
            find_app_user.status = UserStatus.INACTIVE
            find_app_user.email = str(uuid.uuid4())
            db.commit()
            logger.info("User deleted successfully.")
            return apiResponse(HTTPStatus.OK,sucessMessage['Delete_message'])
        else:
            logger.error("User status is not active.")
            return apiResponse(HTTPStatus.FORBIDDEN, unSucessMessage['User_Status'])
    else:
        logger.error("User ID does not exist.")
        return apiResponse(HTTPStatus.NOT_FOUND, unSucessMessage['Id_Exist'])
    
    

@router.get('/getuserdetails',tags=["Get_all_user_details"])
async def getUserdetails(request:Request,db: Session = Depends(get_db_session)):
    current_user = get_current_user(request._headers['Authorization'][7:])
    find_app_user = findUserById(current_user['id'],db)
    if find_app_user is not None:
        total_tokens_utilized = calculateSumOfTokensUtilized(current_user['id'],db)
        admin_config_details = getAdmin(db)
        logger.info(f"User details retrieved successfully for user ID: {find_app_user.id}")
        return apiResponse(HTTPStatus.OK,None,getUserResponse(find_app_user,total_tokens_utilized,admin_config_details))
    else:
        logger.error("User ID not found or invalid.")
        return apiResponse(HTTPStatus.BAD_REQUEST,unSucessMessage['user_id_error']) 
    
# change password need token to changes     
@router.put('/change_password')
async def changePassword(request:Request, user_passwiord_details:ChangePassword,db: Session = Depends(get_db_session)):
    logger.info("Change password process started...")
    current_user = get_current_user(request._headers['Authorization'][7:])
    findTheUserEmail= findUserByUsername(user_passwiord_details.email,db)
    if findTheUserEmail is not None:
        is_current_password_valid = pwd_context.verify(decode_base64_string(user_passwiord_details.currentPassword), findTheUserEmail.password)
        if user_passwiord_details.new_password != user_passwiord_details.confirm_password:
            logger.error('Password And Confirm Password Not Matched')
        if findTheUserEmail  and is_current_password_valid:
            findTheUserEmail.password = pwd_context.hash(decode_base64_string(user_passwiord_details.new_password))
            findTheUserEmail.is_forgot_pwd = False
            db.commit()
            logger.info(f"Password changed successfully for user {user_passwiord_details.email}.")
            return apiResponse(HTTPStatus.OK, sucessMessage['password_message'])
        else:
           logger.error(f"Current password provided for user {user_passwiord_details.email} does not match.")
           return apiResponse(HTTPStatus.BAD_REQUEST,unSucessMessage['password_not_matched'])
    else:
        logger.error(f"No user found with email {user_passwiord_details.email}.")
        return apiResponse(HTTPStatus.BAD_REQUEST,unSucessMessage['login_unmessage']) 
  
    