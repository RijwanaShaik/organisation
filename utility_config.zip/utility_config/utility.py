import base64
import calendar
from datetime import timedelta, datetime
from http import HTTPStatus
import math
from typing import List
import json
import redis

from fastapi import HTTPException
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from starlette import status
import os
import secrets
import string

from main_config.database_config.database import get_db_session
import main_config.database_config.models as models
from main_config.payload_basemodel.beans import AdminConfiguration, PaymentHistory, TokenPurchase, UserSearchResult, VideoContentEntities, \
    Userdetails, UpdateVideoContent, ContextSearch
from main_config.enums_config.enums import  ALGORITHM, SECRET_KEY, UserStatus, UserRoleEnum
from passlib.context import CryptContext
from jose import jwt, JWTError

from main_config.query_config.app_user_queries import findUserByUsername
from main_config.query_config.token_purchase_queries import getTokenPurchasesUserStatus, \
    getTokenPurchasesByUser, getTokenPurchases

from sqlalchemy import desc, asc,func


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
# common function every api response
def apiResponse(responseCode = None,message = None,payload =None):
    return  JSONResponse({'statusCode':responseCode,"message":message,'payload':jsonable_encoder(payload) }, status_code=responseCode) 

def entityValidationError(responseCode,exc):
    missing_field_dict = {}
    for i in exc.errors():
        errorResponse = {
            list(i['loc'])[1] :f" Field Should Not Empty"
        }
        missing_field_dict.update(errorResponse)
    return JSONResponse(
        status_code=responseCode,
        content=missing_field_dict,
)  
def setUploadVideos(newVideoData):
    return models.VideoContent(
            name = newVideoData["title"],
            video_link =  newVideoData["presigned_url"],
            tokens_utilized = newVideoData["token_utilization"],
            video_length_in_sec = newVideoData["length_videos_sec"],
            user_id = newVideoData["user_id"],
            video_id = newVideoData["video_id"],
            video_status = newVideoData["state"],
            thumb = newVideoData["thumb_url"],
            is_example= newVideoData["is_example"]
            )  
    
def settokenCreation(tokenPurchase:TokenPurchase, loggedInUserId:int):
    return models.TokenPurchase(
            token_count = tokenPurchase.token_count,
            user_id = loggedInUserId,
            transaction_id = tokenPurchase.transaction_id,
            purchase_status = tokenPurchase.purchase_status,
        )

def login_response(access_token, user_email, role,id,is_forgot_pwd,is_email_verified):
        return {
            "statusCode":200,
            "message":HTTPStatus.OK,
            "access_token": access_token,
            "token_type": "bearer",
            'user_id' : id,
            "user_email": user_email,
            "role": role.upper(),
            "is_forgot_pwd":is_forgot_pwd,
            "is_email_verified":is_email_verified
        }
def getUserResponse(current_user,total_tokens_utilized,admin_config):
    return {
            'user_id' : current_user.id,
            "user_email": current_user.email,
            "user_name": current_user.name,
            "role": current_user.role.upper(),
            'total_token':current_user.token_balance,
            'available_token': current_user.token_balance - total_tokens_utilized if total_tokens_utilized else current_user.token_balance ,
            'admin_config':{
                'admin_email':admin_config.admin_email,
                'token_price':admin_config.toke_price,
                'video_length_in_mins':admin_config.video_length_in_mins
            } 
        }         


def set_admin_configuration_data(admin_details: AdminConfiguration,loggedInUserEmail:str):
    return models.AdminConfiguration(
        admin_email=loggedInUserEmail,
        toke_price=admin_details.toke_price,
        video_length_in_mins=admin_details.video_length_in_mins
    )


def set_video_contact_data(video_details: VideoContentEntities):
    return models.VideoContent(
        name=video_details.name,
        video_link=video_details.video_link,
        tokens_utilized=video_details.token_utilization,
        video_length_in_mins=video_details.length_videos_min,
        video_type=video_details.videos_type,
        user_id=video_details.user_id
    )

def set_user_details_data(user_details: Userdetails):
    return models.AppUser(
        name=user_details.name,
        email=user_details.email.lower(),
        password=pwd_context.hash(decode_base64_string(user_details.password)),  # bcrypt  the password store in db
        status=UserStatus.ACTIVE,  # default user status and role
        role=UserRoleEnum.USER,
        terms_and_condition=user_details.terms_and_condition,
        is_email_verified=False,
    )



def transition_history(transition_history_list):
    return[
        {
            "s_no": transition_history.id,
            "purchase_date":transition_history.created_on.strftime('%d-%m-%Y'),
            "token_count":transition_history.token_count,
            "status":transition_history.purchase_status
        }
        for transition_history in transition_history_list
    ]


def payment_history_filters(paymentHistory: PaymentHistory, user_id: int,db) -> List[TokenPurchase]:
    from_date, to_date = date_filters(paymentHistory)

    if paymentHistory.status.strip() == paymentHistory.status and from_date is not None and to_date is not None:
        transitionHistory = getTokenPurchasesUserStatus(user_id, from_date, to_date, paymentHistory.status.strip(),db)
    elif from_date is not None and to_date is not None:
        transitionHistory = getTokenPurchasesByUser(user_id, from_date, to_date,db)
    else:
        transitionHistory = getTokenPurchases(user_id, paymentHistory.status.strip(),db)

    if paymentHistory.new_to_old is not None:
        if paymentHistory.new_to_old:  # True for descending order
            transitionHistory = sorted(transitionHistory, key=lambda x: x.created_on, reverse=True)
        else:  # False for ascending order
            transitionHistory = sorted(transitionHistory, key=lambda x: x.created_on)
    return transitionHistory



def date_filters(paymentHistory: PaymentHistory):
    today = datetime.now()
    if paymentHistory.to_day:
        from_date = datetime(today.year, today.month, today.day, 0, 0, 0)
        to_date = datetime(today.year, today.month, today.day, 23, 59, 59)
        return from_date, to_date
    
    elif paymentHistory.this_month:
        # Calculate from_date as 30 days ago
        from_date = today - timedelta(days=30)
        to_date = today - timedelta(seconds=1)  # End of yesterday
        return from_date, to_date

    elif paymentHistory.this_week:
        # Calculate from_date as 7 days ago
        from_date = today - timedelta(days=7)
        to_date = today - timedelta(seconds=1)  # End of yesterday
        return from_date, to_date
    elif paymentHistory.from_date  and paymentHistory.to_date:
            try:
                # Assuming paymentHistory.from_date and paymentHistory.to_date are already datetime.date objects
                 from_date = paymentHistory.from_date
                 to_date = paymentHistory.to_date + timedelta(days=1)  # Add one day to include the entire end day
                 return from_date, to_date
            except TypeError:
                # Handle invalid date format
                raise TypeError("Invalid date format. Please provide datetime.date objects or update the request format.")
     
    else:
        # Handle other cases if needed
        return None, None
    
def setContextSearch_data(contextSearchResponse,user_id:int,video_id:str):
    return models.UserSearchResult(
            user_search_id = user_id,
            video_id = video_id,
            query = contextSearchResponse['query'],
            result = contextSearchResponse['results']
    )
    


def get_current_user(token: str):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Your session is expired. Please login again",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        decode_jwt= jwt.decode(token,SECRET_KEY, algorithms=ALGORITHM)
        expires_datetime = datetime.utcfromtimestamp(decode_jwt['exp'])
        if datetime.utcnow() > expires_datetime:
            raise credentials_exception
        else:
            return decode_jwt
       
    except JWTError:
        raise credentials_exception 
    

from dotenv import load_dotenv
def decodeKeys(token):
    return jwt.decode(token,SECRET_KEY, algorithms=ALGORITHM)
def create_access_token(data: dict, expires_delta: timedelta):
    to_encode = data.copy()
    expire = datetime.utcnow() + expires_delta
    to_encode.update({'exp': expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def generate_random_string(length=6):
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


def decode_base64_string(password):
    try:
        # Decode the Base64 string
        decoded_bytes = base64.b64decode(password)

        # Convert the bytes back to a string
        decoded_string = decoded_bytes.decode('utf-8')

        return decoded_string
    except Exception as e:
        print("Error decoding Base64 string:", e)
        return None
    
    
    
def getTimeInMinute(value:int):
    seconds = math.ceil((value / 1000) % 60)
    minutes = math.floor((value / 1000) / 60);
    return f'{minutes}:{seconds}'    








        
    
   
