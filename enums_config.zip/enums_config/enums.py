
# Secret key to sign JWT tokens
SECRET_KEY = '7120d7628710519e235fef105b58ad294482391d2bae9e9a18e6d520238b2832'
ALGORITHM = "HS256"

# email validation pattern
EMAIL_PATTERN = r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'


class UserRoleEnum:
    ADMIN = "admin" 
    USER = "user"
    
class UserStatus:
    ACTIVE = "active"  
    INACTIVE = "inactive" 

class VideoType:
    USER = "user_upload"
    EXAMPLE = "example_upload"

class PurchaseStatus:
    INITIATED = "INITIATED"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    
class AIVideoStatus:
    CREATED = "created"
    UPLOADING = 'uploading'
    PROCESSING= 'processing'
    READY= 'ready'
    ERROR = 'error'
    UNKNOW = 'unkown'
    EXPIRED = 'expired'
class AppUserResponse:
    responseCode:int
    message:str
    payload:dict  = {}   
global_error_handle_msg ={'statusCode':500, "message": "Something went wrong","payload":{}}

    
    
    
        
    
      
    


    
    

    
    
        
