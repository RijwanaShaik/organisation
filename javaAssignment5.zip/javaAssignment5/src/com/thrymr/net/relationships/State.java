package com.thrymr.net.relationships;

import java.util.Arrays;

public class State {
    int sId;
    String sName;
    Country[] country;

    public State(int sId, String sName, Country[] country) {
        this.sId = sId;
        this.sName = sName;
        this.country = country;
    }

    @Override
    public String toString() {
        return "State{" +
                "sId=" + sId +
                ", sName='" + sName + '\'' +
                ", country=" + Arrays.toString(country) +
                '}';
    }

}
