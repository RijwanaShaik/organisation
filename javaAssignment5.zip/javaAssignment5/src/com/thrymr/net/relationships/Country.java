package com.thrymr.net.relationships;

public class Country {
    int cId;
    String cName;

    public Country(int cId, String cName) {
        this.cId = cId;
        this.cName = cName;
    }

    @Override
    public String toString() {
        return "Country{" +
                "cId=" + cId +
                ", cName='" + cName + '\'' +
                '}';
    }
}
