package com.thrymr.net.relationships;

import java.util.Arrays;

public class River {
    int rId;
    String rName;
    State[] state;

    public River(int rId, String rName, State[] state) {
        this.rId = rId;
        this.rName = rName;
        this.state = state;
    }

    @Override
    public String toString() {
        return "River{" +
                "rId=" + rId +
                ", rName='" + rName + '\'' +
                ", state=" + Arrays.toString(state) +
                '}';
    }

    public static void main(String[] args) {
        Country[] country1=new Country[1];
        country1[0]=new Country(1,"India");

        Country[] country2=new Country[1];
        country2[0]=new Country(2,"China");

        State[] state1=new State[2];
        state1[0]=new State(11,"Maharastra",country1);
        state1[1]=new State(12,"AndhraPradesh",country1);
        State[] state2=new State[2];

        state2[0]=new State(10,"Tokyo",country2);
        state2[1]=new State(15,"Macau",country2);

        River[] river1=new River[2];
        river1[0]=new River(101,"Narmada",state1);
        river1[1]=new River(102,"Tapati",state1);
        for(int i=0;i<river1.length;i++){
            System.out.println(river1[i]);
        }
    }
}
