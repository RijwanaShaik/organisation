package com.thrymr.net.oneDArray;

public class StudentHighestMarks {
    int id;
    String name;
    int st_code;
    int marks;


    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", st_code=" + st_code +
                ", marks=" + marks +
                '}';
    }

    public static void main(String[] args) {
        Student[] student=new Student[10];
        Student student1 = new Student(1,"Anusha",1,85);
        Student student2 = new Student(2,"Hema",2,75);
        Student student3 = new Student(3,"Afreen",3,25);
        Student student4 = new Student(4,"Amar",4,65);
        Student student5 = new Student(5,"Kunal",5,55);
        Student student6 = new Student(6,"Naziya",6,95);
        Student student7 = new Student(7,"Anitha",7,95);
        Student student8 = new Student(8,"Shaheena",8,55);
        Student student9 = new Student(9,"Anuradha",9,45);
        Student student10 = new Student(10,"Sohal",10,85);

        student[0] = student1;
        student[1] = student2;
        student[2] = student3;
        student[3] = student4;
        student[4] = student5;
        student[5] = student6;
        student[6] = student7;
        student[7] = student8;
        student[8] = student9;
        student[9] = student10;

        Student temp = new Student();
        for (int i = 0; i < student.length - 1; i++) {
            for (int j = i + 1; j < student.length; j++) {
                if (student[i].marks < student[j].marks) {
                    temp = student[i];
                    student[i]= student[j];
                    student[j] = temp;
                }

            }
        }
        System.out.println("Descending order of marks");
        for (int k = 0; k < student.length; k++) {
            System.out.println(student[k]);
        }
    }


}


