package com.thrymr.net.inheritance;

public class Alto extends Maruti{
    int speed;


    @Override
    public void wheels() {
        super.wheels();
        System.out.println("Wheels method from Alto class");

    }

    @Override
    public void engine() {
        super.engine();
        System.out.println("engine method from Alto class");

    }

    @Override
    public void doors() {
        super.doors();
        System.out.println("doors method from Alto class");
    }

    @Override
    public void vehicleType() {
        super.vehicleType();
        System.out.println("vehicleType method from Alto class");
    }
    public void speed(){
        System.out.println("Speed method from Alto class contain speed 80 & 90 ");
    }
}
