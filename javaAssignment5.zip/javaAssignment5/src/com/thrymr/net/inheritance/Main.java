package com.thrymr.net.inheritance;

public class Main {
    public static void main(String[] args) {
        Vehicle vehicle=new Vehicle();//with vehicle object we can access class objects only
        vehicle.doors();
        vehicle.engine();
        vehicle.wheels();
        Car car=new Car();//with car object we can access class objects only

        // Maruti maruti=new Maruti();
            Maruti maruti=new Alto();//with Maruthi class reference we are creating object with Alto constructor.
            maruti.wheels();
            maruti.engine();
            maruti.doors();
            //maruti.speed;
    }

}
