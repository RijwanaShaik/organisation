package com.thrymr.net.inheritance;

public class Vehicle {
    public void wheels(){
        System.out.println("wheels method from Vehicle class");
    }
    public void engine(){
        System.out.println("engine method from Vehicle class");
    }
    public void doors(){
        System.out.println("doors method from Vehicle class");
    }
}
