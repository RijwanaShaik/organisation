package com.thrymr.net.inheritance;

public class Maruti extends Car{



    @Override
    public void wheels() {
        super.wheels();
        System.out.println("Wheels method from Maruti class");
    }

    @Override
    public void engine() {
        super.engine();
        System.out.println("engine method from Maruti class");
    }

    @Override
    public void doors() {
        super.doors();
        System.out.println("doors method from Maruti class");
    }

    @Override
    public void vehicleType() {
        super.vehicleType();
        System.out.println("vehicleType method from Maruti class");
    }
    void speed(){
        int speed=90;
        System.out.println("speed method from Maruti class contain speed :"+speed);
    }
}



