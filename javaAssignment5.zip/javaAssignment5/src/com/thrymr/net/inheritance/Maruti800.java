package com.thrymr.net.inheritance;

public class Maruti800 extends Maruti{
    @Override
    public void wheels() {
        super.wheels();
        System.out.println("Wheels method from Maruti800 class");

    }

    @Override
    public void engine() {
        super.engine();
        System.out.println("engine method from Maruti800 class");

    }

    @Override
    public void doors() {
        super.doors();
        System.out.println("doors method from Maruti800 class");

    }

    @Override
    public void vehicleType() {
        super.vehicleType();
        System.out.println("vehicleType method from Maruti800 class");

    }

    @Override
    public void speed() {
        super.speed();
        System.out.println("speed method from Maruti800 contain speed 80 & 70");

    }

    public static void main(String[] args) {
      // Maruti maruti=new Maruti();
         Maruti maruti=new Alto();//with Maruthi class reference we are creating object with Alto constructor.
        maruti.wheels();
        maruti.engine();
        maruti.doors();
       //maruti.speed;
    }

}
// vehicle extends to car
//
//car extends to maruti
//
//Maruti extends to Alto
// upto this is multilevel inheritance.
//
//Maruti extends to Alto & Maruti800-it is hierarchical inheritance.



// Memory representation ...
// In Java  all objects are dynamically allocated on Heap memory. when we allocate the object using new(), the object is allocated on Heap, otherwise on Stack if not global or static.
//In Java, when we only declare a variable of a class type, only a reference is created (memory is not allocated for the object). To allocate memory to an object, we must use new(). So the object is always allocated memory on the heap .