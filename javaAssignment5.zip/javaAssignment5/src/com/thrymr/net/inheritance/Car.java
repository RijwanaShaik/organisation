package com.thrymr.net.inheritance;

public class Car extends Vehicle{
    @Override
    public void wheels() {
        super.wheels();
        System.out.println("Wheels method from Car class");
    }

    @Override
    public void engine() {
        super.engine();
        System.out.println("engine method from Car class");

    }

    @Override
    public void doors() {
        super.doors();
        System.out.println("doors method from Car class");
    }
    public void vehicleType(){
        System.out.println("vehicleType method from Car class");
    }
}
