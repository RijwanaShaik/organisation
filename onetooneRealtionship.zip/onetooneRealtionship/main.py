from typing import List
from fastapi import FastAPI, Depends, HTTPException, status
from sqlalchemy.orm import Session
from entites.entityClasses import User, UserBase, Profile, ProfileCreate, AddressCreate, Address
from database_config.database import engine, get_db
from schema import models
app = FastAPI()
models.Base.metadata.create_all(engine)


# Dependency

@app.post("/users/", response_model=User)
def create_user(user:UserBase, db: Session = Depends(get_db)):
    db_user = models.User(username=user.username, password=user.password, firstname = user.firstname)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


@app.post("/profiles/", response_model=Profile)
def create_user_profile(profile: ProfileCreate, db: Session = Depends(get_db)):
    # Get the user from the database based on the provided username
    user = db.query(models.User).filter(models.User.username == profile.full_name).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    # Create the profile with the retrieved user's ID
    db_profile = models.Profile(**profile.dict(), user_id=user.id)
    db.add(db_profile)
    db.commit()
    db.refresh(db_profile)
    return db_profile


@app.post("/profiles/{profile_id}/addresses/", response_model=Address)
def create_address_for_profile(profile_id: int, address: AddressCreate, db: Session = Depends(get_db)):
    db_address = models.Address(**address.dict(), profile_id=profile_id)
    db.add(db_address)
    db.commit()
    db.refresh(db_address)
    return db_address


@app.get("/profiles/{profile_id}/addresses/", response_model=List[Address])
def get_addresses_for_profile(profile_id: int, db: Session = Depends(get_db)):
    return db.query(models.Address).filter(models.Address.profile_id == profile_id).all()