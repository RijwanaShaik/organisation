from pydantic import BaseModel


class UserBase(BaseModel):
    username: str
    password: str
    firstname: str


class User(UserBase):
    id: int

    class Config:
        orm_mode = True


class ProfileBase(BaseModel):
    full_name: str


class ProfileCreate(ProfileBase):
    pass


class Profile(ProfileBase):
    id: int
    user_id: int

    class Config:
        orm_mode = True


class AddressBase(BaseModel):
    address_line: str
    city: str
    state: str
    country: str


class AddressCreate(AddressBase):
    pass


class Address(AddressBase):
    id: int
    profile_id: int

    class Config:
        orm_mode = True
