

from fastapi import Depends, FastAPI,Request
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordBearer
from http import HTTPStatus
from main_config.enums_config.enums import  global_error_handle_msg
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from main_config.utility_config.utility import entityValidationError
import uvicorn
from .apis_config.admin_config import  router as adminRouter
from .apis_config.user_management import  router as userManagement
from .apis_config.file_upload import router as fileUpload
from .apis_config.purchase_history import router as purchaseHistory
from .apis_config.authentication import router as auth
from .apis_config.context_search import router as contextSearch
import os
from dotenv import load_dotenv



# from main_config.aws_config.aws_ses import  send_email
app = FastAPI( title='SenseVantage Cloud')
load_dotenv()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")



@app.exception_handler(Exception)
async def exception_callback(request: Request, exc: Exception):
    return JSONResponse(global_error_handle_msg, status_code=HTTPStatus.INTERNAL_SERVER_ERROR)

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return entityValidationError(HTTPStatus.UNPROCESSABLE_ENTITY,exc)

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
if __name__ == "__main__":
    # Run FastAPI application on 127.0.0.1 and port 9024
    uvicorn.run(app, host=os.getenv('APPLICATION_RUN_HOST'), port=9024)



app.include_router(adminRouter,dependencies=[Depends(oauth2_scheme)])
app.include_router(userManagement,dependencies=[Depends(oauth2_scheme)])
app.include_router(fileUpload,dependencies=[Depends(oauth2_scheme)])
app.include_router(purchaseHistory,dependencies=[Depends(oauth2_scheme)])
app.include_router(auth)
app.include_router(contextSearch,dependencies=[Depends(oauth2_scheme)])
