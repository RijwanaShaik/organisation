package com.example.testing.controller;

import com.example.testing.entity.Message;
import com.example.testing.service.MessageService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/messages")
public class MessageController {
    private final MessageService messageService;

    public MessageController(MessageService messageService) {
        this.messageService = messageService;
    }

    @PostMapping("/encrypt")
    public Message encryptMessage(@RequestBody Message message) {
        return messageService.saveMessage(message);
    }

    @PostMapping("/decrypt")
    public ResponseEntity<Message> decryptMessage(@RequestBody Message message) {
        Message decryptedMessage = messageService.decryptMessage(message);
        return new ResponseEntity<>(decryptedMessage, HttpStatus.OK);
    }
}

