package com.example.testing.service;

import com.example.testing.entity.Employee;

import java.util.List;

public interface EmployeeService {
    List<Employee> getAllEmployee();
}
