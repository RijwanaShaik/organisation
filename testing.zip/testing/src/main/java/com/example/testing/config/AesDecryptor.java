package com.example.testing.config;

import jakarta.persistence.AttributeConverter;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.util.SerializationUtils;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

@Component
public class AesDecryptor  {


private static final String encryptionKey = "this-is-test-key";

    public static String encrypt(String data) {
        try {
            byte[] key = encryptionKey.getBytes();
            SecretKey secretKey = new SecretKeySpec(key, "AES");

            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);

            byte[] encryptedData =(cipher.doFinal(data.getBytes()));
            return Base64.getEncoder().encodeToString(encryptedData);
        } catch (GeneralSecurityException e) {
           throw new RuntimeException("Encryption error: " + e.getMessage());
        }
    }

    public static Object decrypt(String encryptedValue) {
        try {
            byte[] key = encryptionKey.getBytes();
            SecretKey secretKey = new SecretKeySpec(key, "AES");

            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);

            byte[] decryptedData = cipher.doFinal(Base64.getDecoder().decode(encryptedValue));
            return  SerializationUtils.deserialize(decryptedData);
          //  return new String(decryptedData);

        } catch (GeneralSecurityException e) {
            throw new RuntimeException("Decryption error: " + e.getMessage());
        }
    }


    public static void main(String[] args) {

       // String encryptedValue = "rO0ABXVyAAJbQqzzF/gGCFTgAgAAeHAAAAAQ9r/WNKlCvs6yH5OvVCwrIQ==";
        String encryptedValue = "uAUBJpND1bVxjRpjvoclaA==";
    //   System.out.println("Encrypted Value: " + encrypt(encryptedValue));

        System.out.println("Decrypted Value: " + decrypt(encryptedValue));

    }
//
}


