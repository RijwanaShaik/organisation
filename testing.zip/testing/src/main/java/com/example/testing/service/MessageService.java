package com.example.testing.service;

import com.example.testing.entity.Message;

public interface MessageService {
    Message encryptMessage(Message message);
    Message decryptMessage(Message message);
    Message saveMessage(Message message);
}