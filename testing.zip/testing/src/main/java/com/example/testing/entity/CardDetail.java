package com.example.testing.entity;

import com.example.testing.config.AesEncryptor;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class CardDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Convert(converter = AesEncryptor.class)
    private String cardHolderName;

    @Convert(converter = AesEncryptor.class)
    private Long cvv;

    @Convert(converter = AesEncryptor.class)
    private Double amount;

    @Convert(converter = AesEncryptor.class)
    private Boolean isActive;
}
