package com.example.testing.service;

import com.example.testing.entity.CardDetail;

public interface CardDetailService {
    CardDetail saveCardDetail(CardDetail cardDetail);

    CardDetail getCardDetail(Long id);
}
