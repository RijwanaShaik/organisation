package com.example.testing.service.impl;


import com.example.testing.entity.Message;
import com.example.testing.repository.MessageRepo;
import com.example.testing.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import java.security.*;
import java.util.Base64;

import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

@Service
public class MessageServiceImpl implements MessageService {

    @Autowired
    private MessageRepo messageRepo;
    private final KeyPair keyPair;
    private final Cipher cipher;

    public MessageServiceImpl() throws NoSuchAlgorithmException, NoSuchPaddingException {
        keyPair = generateKeyPair();
        cipher = Cipher.getInstance("RSA");
    }

    private KeyPair generateKeyPair() throws NoSuchAlgorithmException {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        return keyPairGenerator.generateKeyPair();
    }

    @Override
    public Message encryptMessage(Message message) {
        try {
            cipher.init(Cipher.ENCRYPT_MODE, keyPair.getPublic());
            System.out.println(keyPair.getPublic());
            byte[] encryptedContent = cipher.doFinal(message.getContent().getBytes());

            message.setContent(Base64.getEncoder().encodeToString(encryptedContent));
            return message;
        } catch (GeneralSecurityException e) {
            throw new RuntimeException("Encryption error: " + e.getMessage());
        }
    }

    @Override
    public Message decryptMessage(Message message) {
        try {
            System.out.println(keyPair.getPrivate());
            cipher.init(Cipher.DECRYPT_MODE, keyPair.getPrivate());
            byte[] decodedContent = Base64.getDecoder().decode(message.getContent());
            byte[] decryptedContent = cipher.doFinal(decodedContent);

            message.setContent(new String(decryptedContent));
            return message;
        } catch (BadPaddingException e) {
            throw new RuntimeException("Bad Padding: " + e.getMessage());
        } catch (IllegalBlockSizeException e) {
            throw new RuntimeException("Illegal Block Size: " + e.getMessage());
        } catch (InvalidKeyException e) {
            throw new RuntimeException("Invalid Key: " + e.getMessage());
        }
    }

    public Message saveMessage(Message message) {
        try {
            Message encryptedMessage = encryptMessage(message);
            return messageRepo.save(encryptedMessage);
        } catch (Exception e) {
            throw new RuntimeException("Error while saving encrypted message: " + e.getMessage());
        }
    }
}


