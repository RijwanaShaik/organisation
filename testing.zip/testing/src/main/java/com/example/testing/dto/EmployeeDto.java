package com.example.testing.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeDto {
    private Boolean intCol;
    private Boolean stringCol;
    private Boolean floatCol;
    private  Boolean booleanCol;
}
