package com.example.testing.service;

import com.example.testing.entity.AppUser;
import com.example.testing.entity.BankDetails;
import com.example.testing.entity.Car;

public interface AppUserService {
    AppUser saveAppUser(AppUser appUser);
    Car saveCar(Car car);
    BankDetails saveBank(BankDetails bankDetails) throws Exception;
}
