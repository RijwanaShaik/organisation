package com.example.testing.service.impl;

import com.example.testing.entity.CardDetail;
import com.example.testing.repository.CardDetailRepository;
import com.example.testing.service.CardDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CardDetailServiceImpl implements CardDetailService {
    @Autowired
    private CardDetailRepository cardDetailRepository;

    public CardDetail saveCardDetail(CardDetail cardDetail) {
        return cardDetailRepository.save(cardDetail);
    }

    @Override
    public CardDetail getCardDetail(Long id) {
        return cardDetailRepository.findById(id).orElse(null);
    }


}
