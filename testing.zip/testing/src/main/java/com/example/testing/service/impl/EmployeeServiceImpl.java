package com.example.testing.service.impl;

import com.example.testing.entity.Employee;
import com.example.testing.repository.EmployeeRepo;
import com.example.testing.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    EmployeeRepo employeeRepo;

    @Override
    public List<Employee> getAllEmployee() {
        List<Employee> employees=employeeRepo.findAll();
        return employees;
    }
}
