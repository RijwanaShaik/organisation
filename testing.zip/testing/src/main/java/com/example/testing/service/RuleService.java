package com.example.testing.service;

import com.example.testing.dto.ChartSelectionResponse;
import com.example.testing.dto.EmployeeDto;
import com.example.testing.entity.Employee;

public interface RuleService {

     ChartSelectionResponse getSelectionCharts(EmployeeDto employeeDto);
}
