package com.example.testing.controller;

import com.example.testing.dto.ChartSelectionResponse;
import com.example.testing.dto.EmployeeDto;
import com.example.testing.entity.Employee;
import com.example.testing.service.EmployeeService;
import com.example.testing.service.RuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/employee")
public class EmployeeController {
    @Autowired
    EmployeeService employeeService;
    @Autowired
    RuleService ruleService;

  @GetMapping("/get-all")
    public List<Employee> getAllEmployees(){
      return employeeService.getAllEmployee();
  }
  @PostMapping("/charts")
    public ChartSelectionResponse getChartSelection(@RequestBody EmployeeDto employeeDto){
      return ruleService.getSelectionCharts(employeeDto);
  }
}
