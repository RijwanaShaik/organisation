package com.example.testing.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChartSelectionResponse {
    String barGraph;
    String pieChart;
    String clusterChart;
}
