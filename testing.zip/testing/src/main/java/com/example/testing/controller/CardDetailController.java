package com.example.testing.controller;

import com.example.testing.entity.AppUser;
import com.example.testing.entity.Car;
import com.example.testing.entity.CardDetail;
import com.example.testing.service.AppUserService;
import com.example.testing.service.CardDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/card-details")
public class CardDetailController {

    @Autowired
    private CardDetailService cardDetailService;
    @Autowired
    private AppUserService appUserService;

    @PostMapping("/save")
    public CardDetail saveCardDetail(@RequestBody CardDetail cardDetail) {
        return cardDetailService.saveCardDetail(cardDetail);
    }

    @GetMapping("/{id}")
    public CardDetail getCardDetail(@PathVariable Long id) {
        return cardDetailService.getCardDetail(id);
    }

    @PostMapping("/save/app-user")
    public AppUser saveAppUser(@RequestBody AppUser appUser){
        return appUserService.saveAppUser(appUser);
    }
    @PostMapping("/save/car")
    public Car saveAppUser(@RequestBody Car car){
        return appUserService.saveCar(car);
    }
}
