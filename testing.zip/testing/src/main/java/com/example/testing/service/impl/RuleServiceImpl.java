package com.example.testing.service.impl;

import com.example.testing.dto.ChartSelectionResponse;
import com.example.testing.dto.EmployeeDto;
import com.example.testing.service.RuleService;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.io.ResourceFactory;
import org.springframework.stereotype.Service;

@Service
public class RuleServiceImpl implements RuleService {



    @Override
    public ChartSelectionResponse getSelectionCharts(EmployeeDto employeeDto) {
        KieSession kieSession = kiaSession("rules/employee.drl");
        ChartSelectionResponse responseDto=new ChartSelectionResponse();
        kieSession.insert(employeeDto);
        kieSession.setGlobal("responseDto",responseDto);
        kieSession.fireAllRules();
        kieSession.dispose();
        return responseDto ;
    }


    public KieSession kiaSession(String rdlFile){

        KieFileSystem kieFileSystem = getKieFileSystem(rdlFile);
        KieBuilder kieBuilder = KieServices.Factory.get().newKieBuilder(kieFileSystem);
        kieBuilder.buildAll();
        KieModule kieModule = kieBuilder.getKieModule();
        KieContainer kieContainer = KieServices.Factory.get().newKieContainer(kieModule.getReleaseId());
        KieSession kieSession = kieContainer.newKieSession();
        return kieSession;
    }

    private KieFileSystem getKieFileSystem(String rdlFile) {
        KieFileSystem kieFileSystem = KieServices.Factory.get().newKieFileSystem();
        kieFileSystem.write(ResourceFactory.newClassPathResource(rdlFile));
        return kieFileSystem;
    }


}
