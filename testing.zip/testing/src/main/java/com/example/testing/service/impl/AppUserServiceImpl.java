package com.example.testing.service.impl;

import com.example.testing.config.AesDecryptor;
import com.example.testing.config.AesEncryptor;
import com.example.testing.config.RSAEncryptionExample;
import com.example.testing.entity.AppUser;
import com.example.testing.entity.BankDetails;
import com.example.testing.entity.Car;
import com.example.testing.repository.AppUserRepo;
import com.example.testing.repository.BankDetailsRepo;
import com.example.testing.repository.CarRepo;
import com.example.testing.service.AppUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Base64;

@Service
public class AppUserServiceImpl implements AppUserService {
@Autowired
private AppUserRepo appUserRepo;
@Autowired
private CarRepo carRepo;
@Autowired
private AesEncryptor aesEncryptor;

@Autowired
private BankDetailsRepo bankRepo;

    @Override
    public AppUser saveAppUser(AppUser appUser) {
//        Long encryptedPassword = Long.valueOf(aesEncryptor.convertToDatabaseColumn(appUser.getPassword()));
//        appUser.setPassword(encryptedPassword);
        return appUserRepo.save(appUser);
    }

    @Override
    public Car saveCar(Car car) {
        // String pswd= aesDecryptor.convertToDatabaseColumn(car.getNumber());

      //  car.setNumber(new BCryptPasswordEncoder().encode(car.getNumber()));
        car.setNumber(aesEncryptor.convertToDatabaseColumn(car.getNumber()));
        System.out.println(car.getNumber());
        return carRepo.save(car);
    }

    @Override
    public BankDetails saveBank(BankDetails bankDetails) throws Exception {
        bankDetails.setAccountNo(Long.valueOf(RSAEncryptionExample.encryptData(String.valueOf(bankDetails.getAccountNo()),"this-is-key")));
        return null;
    }

}
