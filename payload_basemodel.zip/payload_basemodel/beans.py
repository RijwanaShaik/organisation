
from datetime import date
from typing import Optional,List
from pydantic import BaseModel,Field

class OurBaseModel(BaseModel):
    class Config:
        orm_mode = True

class Userdetails(OurBaseModel):
    name:str = Field(min_length=1)
    email:str = Field(min_length=1)
    password:str = Field(min_length=1)
    confirm_password:str = Field(min_length=1)
    terms_and_condition:bool

class UserLogin(OurBaseModel):
    email:str = Field(min_length=1)
    # right now comment thing the password because as per figma flow when user  click can forgot we will capturing email fields 
    # new_password: Optional[str] = Field(default= None)
    # confirm_password:Optional[str] = Field(default= None)


class AdminConfiguration(OurBaseModel):
    toke_price:int = Field(ge=1)
    video_length_in_mins:int = Field(ge=1)       
class VideoContentEntities(OurBaseModel):
    name:str = Field(min_length=1)
    video_link:str = Field(min_length=1)
    token_utilization:int = Field(ge=1)
    length_videos_sec:int = Field(ge=1)
    videos_type:str = Field(min_length=1)
   
    
class ChangePassword(OurBaseModel):
    email:str =  Field(min_length=1)
    currentPassword:str =  Field(min_length=1)
    new_password:str =  Field(min_length=1)
    confirm_password:str  =  Field(min_length=1)
    
    
class TokenPurchase(OurBaseModel):
    token_count:int =  Field(ge=1)
    transaction_id:str =  Field(min_length=1)
    purchase_status:str =  Field(min_length=1)

class UpdateVideoContent(OurBaseModel):
    name:str = Field(min_length=1)
    video_link:str = Field(min_length=1)
    token_utilization:int = Field(ge=1)
    length_videos_min:int = Field(ge=1)
    videos_type:str = Field(min_length=1)
    video_id:int


class PaymentHistory(OurBaseModel):
    new_to_old:bool
    to_day:bool
    this_week:bool
    this_month:bool
    from_date:Optional[date]
    to_date:Optional[date]
    status:str
    page_number:int

class FrameUrlWithTime(OurBaseModel):
    frame_url:str
    msec:float
    score:float = 0.0
class UserSearchResult(OurBaseModel):
    query:str
    frame_url:List[FrameUrlWithTime]
    
class ContextSearch(OurBaseModel):
    query:str
    
class YoutubeVideosResponse(OurBaseModel):
    title:str = Field(min_length=1)
    token_utilization:int = Field(ge=1)
    length_videos_sec:int = Field(ge=1)
    youtube_url:str = Field(min_length=1)


class YoutubeDurationUrl(OurBaseModel):
    youtube_url:str   

class PaymentIntent(OurBaseModel):
    amount:int
    currency:str
class ManualUpload(OurBaseModel):
    title:str = Field(min_length=1)
    token_utilization:int = Field(ge=1)
    length_videos_sec:int = Field(ge=1)
    upload_id:str = Field(min_length=1)
    video_id:str = Field(min_length=1)
    is_uploaded:bool
