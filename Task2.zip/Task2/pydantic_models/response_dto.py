from pydantic import BaseModel

class LibraryBase(BaseModel):
    name: str
    location: str

class LibraryCreate(LibraryBase):
    pass

class BookBase(BaseModel):
    title: str
    author: str
    library_id: int

class BookCreate(BookBase):
    pass

class UserBase(BaseModel):
    username: str
    password: str

class UserCreate(UserBase):
    pass

class User(UserBase):
    id:int
    pass

    class Config:
        orm_mode = True


class BookAssignCreate(BaseModel):
    book_id: int
    user_id: int
