
from sqlalchemy.orm import Session
from schema import models


def findBookById(book_id,db : Session):
   return db.query(models.Book).filter(models.Book.id == book_id).first()