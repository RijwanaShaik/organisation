
from sqlalchemy.orm import Session
from schema import models

def findUserById(user_id,db : Session):
    return db.query(models.User).filter(models.User.id == user_id).first()
def findUserByName(username,db : Session):
    return db.query(models.User).filter(models.User.username == username).first()