
from sqlalchemy.orm import Session
from schema import models

def findLibraryById(library_id,db : Session):
    return db.query(models.Library).filter(models.Library.id == library_id).first()
