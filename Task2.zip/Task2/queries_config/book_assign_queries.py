from sqlalchemy.orm import Session
from schema import models

def findBookAssignByUserId(user_id,db: Session):
    return db.query(models.BookAssign).filter(models.BookAssign.user_id == user_id,models.BookAssign.returned_date == None).all()
    
def findCountOfBooksAssigned(user_id,db: Session):
    return db.query(models.BookAssign).filter(models.BookAssign.user_id == user_id,models.BookAssign.returned_date == None).count()