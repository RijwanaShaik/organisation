from fastapi import APIRouter,Depends,HTTPException
from schema import models
from pydantic_models import response_dto
from sqlalchemy.orm import Session
from database_config.database import get_db
from service import book_assign_service
from datetime import date, datetime, timedelta

router =APIRouter(tags=["book_assign"])


@router.post("/book-assign/")
def assignBookToUser(assign_data: response_dto.BookAssignCreate, db: Session = Depends(get_db)):
   
    return book_assign_service.assignBook(assign_data,db)

@router.put("/book-return/{user_id}")
def returnBooksOfUser(user_id: int, db: Session = Depends(get_db)):
    return book_assign_service.returnBook(user_id,db)


