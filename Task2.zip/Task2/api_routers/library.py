from fastapi import APIRouter,Depends,HTTPException
from schema import models
from pydantic_models import response_dto
from sqlalchemy.orm import Session
from database_config.database import get_db
from service import library_service
from fastapi_jwt_auth import AuthJWT

router =APIRouter(tags=["library"])

@router.post("/libraries/")
def createLibrary(library:response_dto.LibraryCreate, db: Session = Depends(get_db)):
   
    return library_service.addLibrary(library,db)

@router.get("/libraries/{library_id}")
def getLibrary(library_id: int, db: Session = Depends(get_db),Authorize: AuthJWT = Depends()):
    Authorize.jwt_required()
    return library_service.getLibraryById(library_id,db)


@router.put("/libraries/{library_id}")
def updateLibrary(library_id: int, library: response_dto.LibraryCreate, db: Session = Depends(get_db)):
   
    return library_service.updateLibraryById(library_id,library,db)

@router.delete("/libraries/{library_id}")
def deleteLibrary(library_id: int, db: Session = Depends(get_db)):
   
    return library_service.deleteLibraryById(library_id,db)