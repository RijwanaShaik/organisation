from fastapi import APIRouter,Depends,HTTPException
from schema import models
from pydantic_models import response_dto
from sqlalchemy.orm import Session
from database_config.database import get_db
from service import user_service
from fastapi_jwt_auth import AuthJWT

router =APIRouter(tags=["user"])


@router.post("/users/")
def createUser(user: response_dto.UserCreate, db: Session = Depends(get_db)):
    return user_service.addUser(user,db)

@router.get("/users/{user_id}",response_model=response_dto.User)
def getUser(user_id: int, db: Session = Depends(get_db),Authorize: AuthJWT = Depends()):
    # Authorize.jwt_required()
    return user_service.getUserById(user_id,db)


@router.put("/users/{user_id}", response_model=response_dto.User)
def updateUser(user_id: int, user:response_dto.UserCreate, db: Session = Depends(get_db)):
  
    return user_service.updateUserById(user_id,user)

@router.delete("/users/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db)):
    
    return user_service.deleteUserById(user_id,db)