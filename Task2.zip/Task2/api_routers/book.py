from fastapi import APIRouter,Depends,HTTPException
from schema import models
from pydantic_models import response_dto
from sqlalchemy.orm import Session
from database_config.database import get_db
from service import book_service
from fastapi_jwt_auth import AuthJWT

router =APIRouter(tags=["book"])



@router.post("/books/")
def createBook(book: response_dto.BookCreate, db: Session = Depends(get_db)):
    return   book_service.addBook(book,db)

@router.get("/books/{book_id}")
def getBook(book_id: int, db: Session = Depends(get_db),Authorize: AuthJWT = Depends()):
    Authorize.jwt_required()
    return book_service.getBookById(book_id,db)


@router.put("/books/{book_id}")
def updateBook(book_id: int, book: response_dto.BookCreate, db: Session = Depends(get_db)):
  
    return book_service.updateBookById(book_id,book,db)

@router.delete("/books/{book_id}")
def deleteBook(book_id: int, db: Session = Depends(get_db)):
   
    return book_service.deleteBookById(book_id,db)