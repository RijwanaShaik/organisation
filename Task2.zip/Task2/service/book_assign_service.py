

from fastapi import APIRouter,Depends,HTTPException
from schema import models
from pydantic_models import response_dto
from sqlalchemy.orm import Session
from queries_config import book_assign_queries,user_queries
from datetime import date, datetime, timedelta
from logger_config.file_log import logger


def assignBook(assign_data: response_dto.BookAssignCreate, db: Session):
    user = user_queries.findUserById(assign_data.user_id,db)
    if user is None:
        raise HTTPException(status_code=404,detail="User Not Found")
    returned_books = book_assign_queries.findCountOfBooksAssigned(assign_data.user_id,db)
    if returned_books >= 3:
        raise HTTPException(status_code=400, detail="Maximum limit of user's borrowed books reached")
    else:
        if len(user.books) >= 3:
            raise HTTPException(status_code=400, detail="Maximum limit of user's borrowed books reached")

    db_book = db.query(models.Book).filter(models.Book.id == assign_data.book_id).first()
    if db_book is None:
        raise HTTPException(status_code=404,detail="Book Not Found")   
    
    assign_date = datetime.now() 
    due_date = datetime.now() + timedelta(days=30)    
    assignment = models.BookAssign(book_id=assign_data.book_id, user_id=assign_data.user_id,assign_date= assign_date,due_date=due_date)
    db.add(assignment)
    db.commit()
    db.refresh(assignment)
    return assignment


def returnBook(user_id: int, db: Session):
    assignments = book_assign_queries.findBookAssignByUserId(user_id,db)
    if not assignments:
        raise HTTPException(status_code=404, detail="No assignments found for this user")

    total_penalty = 0
    for assignment in assignments:
        assignment.returned_date = datetime.now()
        penalty = calculate_penalty(assignment.due_date, assignment.returned_date)
        assignment.penalty = penalty
        total_penalty += penalty

    db.commit()
    logger.info(f"Books returned successfully and the total penalty is: {total_penalty}")
    return {"message": f"Books returned successfully and the total penalty is: {total_penalty}"}


def calculate_penalty(due_date: datetime, returned_date: datetime) -> int:
    if isinstance(due_date, date):
        due_date = datetime.combine(due_date, datetime.min.time())
    if returned_date <= due_date:
        return 0
    else:
        days_overdue = (returned_date - due_date).days
        charge = days_overdue * 10
        return charge