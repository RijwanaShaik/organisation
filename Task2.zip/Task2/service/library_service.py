
from fastapi import HTTPException
from schema import models
from pydantic_models import response_dto
from sqlalchemy.orm import Session
from database_config.database import get_db
from queries_config import library_queries

def addLibrary(library:response_dto.LibraryCreate, db: Session):
    db_library = models.Library(**library.dict())
    db.add(db_library)
    db.commit()
    db.refresh(db_library)
    return db_library


def getLibraryById(library_id: int, db: Session):
    library = library_queries.findLibraryById(library_id,db)
    if library is None:
        raise HTTPException(status_code=404, detail="Library not found")
    return library

def updateLibraryById(library_id: int, library: response_dto.LibraryCreate, db: Session):
    db_library = library_queries.findLibraryById(library_id,db)
    if db_library is None:
        raise HTTPException(status_code=404, detail="Library not found")
    if library:
        db_library.name = library.name
        db_library.location = library.location
    
    db.commit()
    db.refresh(db_library)
    return db_library

def deleteLibraryById(library_id: int, db: Session):
    db_library =library_queries.findLibraryById(library_id,db)
    if db_library is None:
        raise HTTPException(status_code=404, detail="Library not found")
    db.delete(db_library)
    db.commit()
    return {"message": "Library deleted successfully"}