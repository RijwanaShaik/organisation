from fastapi import APIRouter,Depends,HTTPException
from schema import models
from pydantic_models import response_dto
from sqlalchemy.orm import Session
from queries_config import user_queries


def addUser(user: response_dto.UserCreate, db: Session):
    db_user = models.User(username=user.username,password=user.password)
    db.add(db_user)
    db.commit()
    return "User added Scuccessfully"

def getUserById(user_id: int, db: Session):
    user = user_queries.findUserById(user_id,db)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user 

def updateUserById(user_id: int, user:response_dto.UserCreate, db: Session):
    db_user = user_queries.findUserById(user_id,db)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    if user:
        db_user.username = user.username
        db_user.password = user.password
        
    db.commit()
    db.refresh(db_user)
    return db_user

def deleteUserById(user_id: int, db: Session):
    db_user = user_queries.findUserById(user_id,db)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(db_user)
    db.commit()
    return {"message": "User deleted successfully"}