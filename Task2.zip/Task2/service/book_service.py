
from fastapi import APIRouter,Depends,HTTPException
from schema import models
from pydantic_models import response_dto
from sqlalchemy.orm import Session
from database_config.database import get_db
from queries_config import book_queries


def addBook(book: response_dto.BookCreate, db: Session):
    db_book = models.Book(**book.dict())
    db.add(db_book)
    db.commit()
    db.refresh(db_book)
    return db_book

def getBookById(book_id: int, db: Session):
    book = book_queries.findBookById(book_id,db)
    if book is None:
        raise HTTPException(status_code=404, detail="Book not found")
    return book

def updateBookById(book_id: int, book: response_dto.BookCreate, db: Session):
    db_book = book_queries.findBookById(book_id,db)
    if db_book is None:
        raise HTTPException(status_code=404, detail="Book not found")
    if book:
        db_book.title = book.title
        db_book.author = book.author
        db_book.library_id =  book.library_id
    db.commit()
    db.refresh(db_book)
    return db_book

def deleteBookById(book_id: int, db: Session):
    db_book = book_queries.findBookById(book_id,db)
    if db_book is None:
        raise HTTPException(status_code=404, detail="Book not found")
    db.delete(db_book)
    db.commit()
    return {"message": "Book deleted successfully"}