from datetime import timedelta
from fastapi import Depends, FastAPI, HTTPException, Request
from pydantic import BaseModel
from api_routers.book import router as book
from api_routers.library import router as library
from api_routers.user import router as user
from api_routers.book_assign import router as book_assign
from schema import models
from database_config.database import engine
from pydantic_models import response_dto
from fastapi.security import OAuth2PasswordBearer
import os
from fastapi.responses import JSONResponse
from fastapi_jwt_auth import AuthJWT
from fastapi_jwt_auth.exceptions import AuthJWTException
from queries_config import user_queries
from logger_config.file_log import logger
from sqlalchemy.orm import Session
from database_config.database import get_db
from passlib.context import CryptContext

app =FastAPI()

models.Base.metadata.create_all(engine)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

class Settings(BaseModel):
  authjwt_secret_key: str =os.getenv("AUTHJWT_SECRET_KEY")


@AuthJWT.load_config
def get_config():
    return Settings()

@app.exception_handler(AuthJWTException)
def authjwt_exception_handler(request: Request, exc: AuthJWTException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.message}
    )
    
 
@app.post("/login")
def login(user: response_dto.UserBase, Authorize: AuthJWT = Depends(),db: Session = Depends(get_db)):
    db_user= user_queries.findUserByName(user.username,db)
    print(db_user.username,'uuuuuuuu')
    if db_user and pwd_context.verify(user.password, str(db_user.password)):
      access_token = Authorize.create_access_token(subject=user.username, expires_time=timedelta(minutes=30))
      refresh_token = Authorize.create_refresh_token(
        subject=user.username, expires_time=timedelta(days=1)
      )
      logger.info("login successfull")
      return {"access_token": access_token, "refresh_token": refresh_token, }
    else: 
        raise HTTPException(status_code=401, detail="Invalid username or password")


@app.post("/refresh-token")
def refresh_token(Authorize: AuthJWT = Depends(),db: Session = Depends(get_db)):
    Authorize.jwt_refresh_token_required()
    current_user = Authorize.get_jwt_subject()
    if current_user is not None:
        user = user_queries.findUserByName(current_user,db)
        if user:
            new_access_token = Authorize.create_access_token(subject=user.username, expires_time=timedelta(minutes=5))
            logger.info("refresh token  successfully")
            return {"access_token": new_access_token}
        else:
            raise HTTPException(status_code=401, detail="User not found")
    else:
        raise HTTPException(status_code=401, detail="Invalid token")
    
app.include_router(user)
app.include_router(library)
app.include_router(book)
app.include_router(book_assign)





