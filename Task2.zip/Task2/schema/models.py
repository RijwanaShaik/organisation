from sqlalchemy import Column, Integer, String, ForeignKey, Date
from sqlalchemy.orm import relationship,validates
from sqlalchemy.ext.declarative import declarative_base
from passlib.context import CryptContext

Base = declarative_base()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class Library(Base):
    __tablename__ = 'libraries'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    location = Column(String)
    books=relationship("Book",back_populates="library")

class Book(Base):
    __tablename__ = 'books'
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    author = Column(String)
    library_id = Column(Integer, ForeignKey('libraries.id'))
    library = relationship("Library", back_populates="books")

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    password = Column(String)
    books = relationship("Book", secondary="book_assign")
    
    @validates('password')
    def validate_password(self, key, password):
        return pwd_context.hash(password)

class BookAssign(Base):
    __tablename__ = 'book_assign'
    id = Column(Integer, primary_key=True, index=True)
    book_id = Column(Integer, ForeignKey('books.id'))
    user_id = Column(Integer, ForeignKey('users.id'))
    assign_date =Column(Date)
    due_date = Column(Date)
    returned_date = Column(Date)
    penalty = Column(Integer)
