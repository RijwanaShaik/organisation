import logging
import os

def setup_logger():
    # Create a logger
    logging.basicConfig(filename=os.getenv('FILENAME'), level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create a rotating file handler
    handler = logging.FileHandler(os.getenv('FILENAME'))
    handler.setLevel(logging.DEBUG)

    # Create a formatter
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)
    return logger

logger = setup_logger()

