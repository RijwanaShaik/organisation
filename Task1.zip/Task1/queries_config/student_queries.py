
from sqlalchemy.orm import Session
from schema import models


def findStudentById(student_id,db: Session):
 return db.query(models.Student).filter(models.Student.id == student_id).first()