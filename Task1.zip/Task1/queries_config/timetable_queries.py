from sqlalchemy.orm import Session
from schema import models


def findTimeTableById(timetable_id:int,db: Session):

    return db.query(models.TimeTable).filter(models.TimeTable.id == timetable_id).first()
