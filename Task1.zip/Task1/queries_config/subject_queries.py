

from sqlalchemy.orm import Session
from schema import models

def findSubjectById(subject_id,db: Session):
    return db.query(models.Subject).filter(models.Subject.id == subject_id).first()