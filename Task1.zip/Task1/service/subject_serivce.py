
from fastapi import HTTPException
from sqlalchemy.orm import Session
from schema import models
from pydantic_models import response_dto
from queries_config import subject_queries



def addSubject(subject: response_dto.SubjectCreate,db : Session):
    new_subject = models.Subject(name=subject.name)
    db.add(new_subject)
    db.commit()
    return new_subject

def getSubjectById(subject_id: int,db : Session):
    subject = subject_queries.findSubjectById(subject_id,db)
    if subject is None:
        raise HTTPException(status_code=404, detail="Subject not found")
    return subject


def updateSubjectById(subject_id: int, subject: response_dto.SubjectUpdate,db : Session):
    db_subject = subject_queries.findSubjectById(subject_id,db)
    if db_subject is None:
        raise HTTPException(status_code=404, detail="Subject not found")
    if subject.name is not None:
        db_subject.name = subject.name
    
    db.commit()
    return db_subject


def deleteSubjectById(subject_id: int,db : Session):
    db_subject = subject_queries.findSubjectById(subject_id,db)
    if db_subject is None:
        raise HTTPException(status_code=404, detail="Subject not found")
    db.delete(db_subject)
    db.commit()
    return {"message": "Subject deleted successfully"}

def getAll(db: Session):
    subjects = db.query(models.Subject).all()
    return subjects





