
from fastapi import HTTPException
from pydantic_models import response_dto
from schema import models
from sqlalchemy.orm import Session
from queries_config import student_queries
from loggers_config.file_log import logger

def addStudent(student: response_dto.StudentCreate,db : Session):
    db_student = models.Student(name=student.name,semester=student.semester)
    db.add(db_student)
    db.commit()
    return db_student

def getAllstd(db: Session, skip: int = 0, limit: int = 10):
    return db.query(models.Student).offset(skip).limit(limit).all()


def getStudentById(student_id: int,db : Session):
    db_student= student_queries.findStudentById(student_id,db)
    if db_student is None:
        raise HTTPException(status_code=404, detail="Student not found")
    return db_student

def updateStudentById(student_id: int, student: response_dto.StudentUpdate,db: Session):
    db_student = student_queries.findStudentById(student_id,db)
    if db_student:
        if student.name is not None:
            db_student.name= student.name
        if student.semester is not None:
            db_student.semester = student.semester
        db.commit()
        return db_student
    else:
        raise HTTPException(status_code=404, detail="Student not found")

def deleteStudentById(student_id: int,db: Session):
    db_student = student_queries.findStudentById(student_id,db)
    if db_student:
        db.delete(db_student)
        db.commit()
        return {"message": "Student deleted successfully"}
    else:
        raise HTTPException(status_code=404, detail="Student not found")
    
def generate_hall_ticket(student_id: int,db: Session):
    student = student_queries.findStudentById(student_id, db)
    if not student:
        logger.error(f"Student with ID {student_id} not found.")
        raise HTTPException(status_code=404, detail="Student not found")

    subjects = student.subjects
    hall_ticket_data = []
    for subject in subjects:
        subject_name = subject.name
        exam_date = subject.timetables[0].exam_date  
        hall_ticket_data.append({"subject_name": subject_name, "exam_date": exam_date})

    
    student.hall_ticket = str(hall_ticket_data)
    db.commit()

    logger.info(f"Hall ticket generated for student {student_id}")

    return hall_ticket_data
    
    