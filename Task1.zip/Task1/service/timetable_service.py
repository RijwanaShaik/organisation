
from fastapi import HTTPException
from sqlalchemy.orm import Session
from schema import models
from pydantic_models import response_dto
from queries_config import timetable_queries,subject_queries


def addTimetable(timetable: response_dto.TimeTable,subject_id:int, db: Session):
    db_subject=subject_queries.findSubjectById(subject_id,db)
    
    db_timetable = models.TimeTable(semester=timetable.semester,exam_date=timetable.exam_date)
    db.add(db_timetable)
    db_timetable.subjects.append(db_subject)
    db.commit()
    db.refresh(db_timetable)
    return db_timetable

def getAlltimetables( db: Session,skip: int = 0, limit: int = 10):
    timetables = db.query(models.TimeTable).offset(skip).limit(limit).all()
    return timetables


def getTimetableById(timetable_id: int, db: Session):
    timetable = timetable_queries.findTimeTableById(timetable_id,db)
    if timetable is None:
        raise HTTPException(status_code=404, detail="TimeTable not found")
    return timetable


def updateTimetableById(timetable_id: int, timetable: response_dto.TimeTable, db: Session):
    db_timetable = timetable_queries.findTimeTableById(timetable_id,db)
    if db_timetable is None:
        raise HTTPException(status_code=404, detail="TimeTable not found")
    if timetable.semester is not None:
        db_timetable.semester = timetable.semester
    if timetable.exam_date is not None:
        db_timetable.exam_date = timetable.exam_date
    db.commit()
    return db_timetable


def deleteTimetableById(timetable_id: int, db: Session):
    db_timetable = timetable_queries.findTimeTableById(timetable_id,db)
    if db_timetable is None:
        raise HTTPException(status_code=404, detail="TimeTable not found")
    db.delete(db_timetable)
    db.commit()
    return {"message": "TimeTable deleted successfully"}