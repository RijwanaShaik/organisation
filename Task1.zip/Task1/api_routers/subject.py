from typing import List
from fastapi import APIRouter,Depends, HTTPException
from database_config.database import get_db
from pydantic_models import response_dto
from service import subject_serivce
from sqlalchemy.orm import Session
from schema import models


router = APIRouter(tags=["subject"])

@router.post("/subjects/", response_model=response_dto.SubjectResponse)
def createSubject(subject: response_dto.SubjectCreate,db : Session =Depends(get_db)):
    
    return subject_serivce.addSubject(subject,db)

@router.get("/subjects/{subject_id}", response_model=response_dto.SubjectResponse)
def getSubject(subject_id: int,db : Session =Depends(get_db)):
    
    return subject_serivce.getSubjectById(subject_id,db)

@router.put("/subjects/{subject_id}", response_model=response_dto.SubjectResponse)
def updateSubject(subject_id: int, subject: response_dto.SubjectUpdate,db : Session =Depends(get_db)):
   
    return subject_serivce.updateSubjectById(subject_id,subject,db)

@router.delete("/subjects/{subject_id}")
def deleteSubject(subject_id: int,db : Session =Depends(get_db)):

    return subject_serivce.deleteSubjectById(subject_id,db)

@router.get("/subjects/", response_model=List[response_dto.SubjectResponse])
def getAllSubjects(db: Session =Depends(get_db)):
    return subject_serivce.getAll(db)


