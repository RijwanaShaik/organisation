from typing import List
from fastapi import APIRouter,Depends, HTTPException, Path
from database_config.database import get_db
from pydantic_models import response_dto
from service import student_service
from sqlalchemy.orm import Session
from schema import models


router = APIRouter(tags=["student"])


@router.post("/students/", response_model=response_dto.StudentResponse)
def createStudent(student: response_dto.StudentCreate, db: Session = Depends(get_db)):
    return student_service.addStudent(student,db)

@router.get("/students/", response_model=List[response_dto.StudentResponse])
def getAllStudents(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return student_service.getAllstd(db, skip, limit)

@router.get("/students/{student_id}", response_model=response_dto.StudentResponse)
def getStudent(student_id: int, db: Session = Depends(get_db)):
    
    return student_service.getStudentById(student_id,db)

@router.put("/students/{student_id}", response_model=response_dto.StudentResponse)
def updateStudent(student_id: int, student: response_dto.StudentUpdate, db: Session = Depends(get_db)):
    return student_service.updateStudentById(student_id, student,db)

@router.delete("/students/{student_id}")
def deleteStudent(student_id: int, db: Session = Depends(get_db)):
    return student_service.deleteStudentById(student_id,db)

@router.get("/get_hall_ticket/{student_id}")
def get_hall_ticket(student_id, db: Session = Depends(get_db)):
    return student_service.generate_hall_ticket(student_id,db)


