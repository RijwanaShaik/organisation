from typing import List
from fastapi import APIRouter,Depends
from database_config.database import get_db
from pydantic_models import response_dto
from service import timetable_service
from sqlalchemy.orm import Session


router = APIRouter(tags=["timetable"])

@router.post("/timetables/", response_model=response_dto.TimeTableResponse)
def createTimetable(timetable: response_dto.TimeTable,subject_id:int, db: Session = Depends(get_db)):
   
    return timetable_service.addTimetable(timetable,subject_id,db)


@router.get("/get-timetables/", response_model=List[response_dto.TimeTableResponse])
def getTimetables(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):

    return timetable_service.getAlltimetables(db,skip,limit)


@router.get("/get-timetable/{timetable_id}", response_model=response_dto.TimeTableResponse)
def getTimetable(timetable_id: int, db: Session = Depends(get_db)):
 
    return timetable_service.getTimetableById(timetable_id,db)


@router.put("/timetables/{timetable_id}", response_model=response_dto.TimeTableResponse)
def updateTimetable(timetable_id: int, timetable: response_dto.TimeTableUpdate, db: Session = Depends(get_db)):

    return timetable_service.updateTimetableById(timetable_id,timetable,db)


@router.delete("/timetables/{timetable_id}")
def deleteTimetable(timetable_id: int, db: Session = Depends(get_db)):

    return timetable_service.deleteTimetableById(timetable_id,db)