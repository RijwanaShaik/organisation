from datetime import date
from typing import Optional
from pydantic import BaseModel

class StudentBase(BaseModel):
    name: str
    semester: int

class StudentCreate(StudentBase):
    pass

class StudentUpdate(StudentBase):
    pass

class StudentResponse(StudentBase):
    id: int
    
    class Config:
        orm_mode = True
    
class SubjectCreate(BaseModel):
    name: str
    
class SubjectUpdate(SubjectCreate):
    pass
    
class SubjectResponse(SubjectCreate):
    id: int
    class Config:
        orm_mode = True
    
class TimeTable(BaseModel):
    semester: int
    exam_date: date
    
class studentLogin(BaseModel):
    name:str


class TimeTableUpdate(TimeTable):
    pass



class TimeTableResponse(TimeTable):
    id: int
    
    class Config:
        orm_mode = True
