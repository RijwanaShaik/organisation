


from datetime import timedelta
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from requests import Session
from schema import models
from database_config.database import engine,get_db
from api_routers.student import router as student
from api_routers.subject import router as subject
from api_routers.timetable import router as timeTable
import os
from fastapi_jwt_auth import AuthJWT
from fastapi_jwt_auth.exceptions import AuthJWTException
from fastapi.security import OAuth2PasswordBearer
from pydantic_models import response_dto
from passlib.context import CryptContext


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

app =FastAPI()
models.Base.metadata.create_all(engine)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")


class Settings(BaseModel):
  authjwt_secret_key: str =os.getenv("AUTHJWT_SECRET_KEY")


@AuthJWT.load_config
def get_config():
    return Settings()

@app.exception_handler(AuthJWTException)
def authjwt_exception_handler(request: Request, exc: AuthJWTException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.message}
    )
    
 

@app.post("/login")
def login(student: response_dto.studentLogin, Authorize: AuthJWT = Depends(), db: Session = Depends(get_db)):
    student_data = db.query(models.Student).filter(models.Student.name == student.name).first()
    if student_data is None:
        raise HTTPException(status_code=401, detail="Bad username or password")
    access_token = Authorize.create_access_token(subject=student.name, expires_time=timedelta(minutes=30))
    refresh_token = Authorize.create_refresh_token(
        subject=student.email, expires_time=timedelta(days=1)
    )
    return {"access_token": access_token, "refresh_token": {refresh_token}}


@app.post("/refresh")
def refresh(Authorize: AuthJWT = Depends(), db: Session = Depends(get_db)):
    Authorize.jwt_refresh_token_required()
    current_user = Authorize.get_jwt_subject()
    if current_user is not None:
        user = (db.query(models.Student).filter(models.Student.name == current_user).first())
        if user:
            new_access_token = Authorize.create_access_token(subject=current_user, expires_time=timedelta(minutes=5))
            return {"access_token": new_access_token}
        else:
            raise HTTPException(status_code=401, detail="User not found")
    else:
        raise HTTPException(status_code=401, detail="Invalid token")
   
app.include_router(student)
app.include_router(subject)
app.include_router(timeTable)
