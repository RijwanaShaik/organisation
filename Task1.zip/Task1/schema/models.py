from sqlalchemy import Column, Integer, String, Date, ForeignKey, Table
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


# many-to-many relationship between Student and Subject
student_subject_association = Table(
    'student_subject_association',
    Base.metadata,
    Column('student_id', Integer, ForeignKey('students.id')),
    Column('subject_id', Integer, ForeignKey('subjects.id'))
)
# many-to-many relationship between Subject and TimeTable
subject_timetable_association = Table(
    'subject_timetable_association',
    Base.metadata,
    Column('subject_id', Integer, ForeignKey('subjects.id')),
    Column('timetable_id', Integer, ForeignKey('timetables.id'))
)

class Student(Base):
    __tablename__ = 'students'
    
    id = Column(Integer, primary_key=True)
    name = Column(String)
    semester = Column(Integer)
    hall_ticket = Column(String)
    subjects = relationship('Subject', secondary=student_subject_association, back_populates='students')

class Subject(Base):
    __tablename__ = 'subjects'
    
    id = Column(Integer, primary_key=True)
    name = Column(String,unique=True)
    
    students = relationship('Student', secondary=student_subject_association, back_populates='subjects')
    timetables = relationship('TimeTable', secondary=subject_timetable_association, back_populates='subjects')

class TimeTable(Base):
    __tablename__ = 'timetables'
    
    id = Column(Integer, primary_key=True)
    semester = Column(Integer)
    exam_date = Column(Date)
    subjects = relationship('Subject', secondary=subject_timetable_association, back_populates='timetables')
