class UserRoleEnum:
    ADMIN = "admin" 
    STUDENT = "student"