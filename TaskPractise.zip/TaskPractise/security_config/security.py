from sqlalchemy import Column, Integer, String, ForeignKey, Table
from sqlalchemy.orm import relationship, Session 
from database_config.database import Base, get_db
from schema import models
from fastapi import Depends, HTTPException
from fastapi_jwt_auth import AuthJWT
from fastapi_jwt_auth.exceptions import AuthJWTException


def has_role(roles: list):
    def decorator(func):
        def wrapper(role: str = Depends(get_current_user_role)):
            print(role,"vvvvvvvvvvvvvvvvvvvvvvvvv")
            print(roles,"ddddddddddddddddddddd")
            if role not in roles:
                raise HTTPException(status_code=403, detail="You are not authorized to access this resource.")
            return func()
        return wrapper
    return decorator


def authenticate_user(username: str, hall_ticket_no: int,db: Session):
    print("entered into authenticate_user method ....")
    user_data = db.query(models.Student).filter(models.Student.username == username).first()
    print("ussssss",user_data.hall_ticket_number)
    if user_data and user_data.hall_ticket_number == hall_ticket_no:
        print("ussssss",user_data.hall_ticket_number)
        return user_data
    
    
def get_current_user_role(Authorize: AuthJWT = Depends(),db: Session = Depends(get_db))->str:
    try:
        Authorize.jwt_required()
        current_user = Authorize.get_jwt_subject()
        print(current_user,'Ccccccccccc')
        user_data = db.query(models.Student).filter(models.Student.username == current_user).first()
        print(user_data.role,'rrrrrrrrrrrrrrr')
        return user_data.role
    except AuthJWTException as e:
        print("error")
        raise HTTPException(status_code=401, detail=str(e))