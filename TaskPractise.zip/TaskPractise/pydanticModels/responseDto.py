from pydantic import BaseModel, Field,constr


class studentBase(BaseModel):
    username:str
    hallticket: constr(max_length=10) # type: ignore
    role:str

class subjectBase(BaseModel):
    subName:str
    
    
class marksCreate(BaseModel):
    marks:int
    std_id:int
    sub_id:int
    
class studentSubject(studentBase):
    subName:list[str]
    
class studentLogin(BaseModel):
    username:str
    hallticket:int 