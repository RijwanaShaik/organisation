

#student
#subject
#marks


from database_config.database import Base
from sqlalchemy import Column,Integer,String,ForeignKey,Table
from sqlalchemy.orm import relationship
from enums_config.enums import UserRoleEnum

Student_Subject=Table('Student_Subject',Base.metadata,
    Column('student_id',Integer,ForeignKey('student.id')) ,          
                      
    Column('subject_id',Integer, ForeignKey('subject.id')) 
 ) 


class Student(Base):
  __tablename__ = "student"
      
  id=Column(Integer,primary_key=True,index =True)
  username=Column(String, nullable=False,unique=True,index=True)
  hall_ticket_number = Column(Integer)
  role = Column(String, nullable=False,server_default=UserRoleEnum.STUDENT)
  
  std_marks=relationship("Marks",uselist=False,back_populates="student")
  std_subject=relationship("Subject",secondary=Student_Subject,back_populates="sub_student")
  
class Subject(Base):
    __tablename__ = "subject"
    
    id=Column(Integer,primary_key=True,index =True)
    subject_name=Column(String, nullable=False,unique=True,index=True)
    
    sub_marks=relationship("Marks",uselist=False,back_populates="subject")
    sub_student=relationship("Student",secondary=Student_Subject,back_populates="std_subject")
    
class Marks(Base):
    __tablename__ = "marks"
    
    id=Column(Integer,primary_key=True,index =True)
    marks=Column(Integer,index=True)   
    student_id=Column(Integer,ForeignKey("student.id"))
    student=relationship("Student",back_populates="std_marks")
    
    subject_id=Column(Integer,ForeignKey("subject.id"))
    subject=relationship("Subject",back_populates="sub_marks")
    
    
    
    
    
   
