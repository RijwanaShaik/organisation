

import os
from fastapi.responses import JSONResponse
from fastapi_jwt_auth import AuthJWT
from fastapi_jwt_auth.exceptions import AuthJWTException


from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from database_config.database import engine

from fastapi import Depends, FastAPI, HTTPException, Request
from api_routers.student import router as student
from api_routers.subject import router as subject
from api_routers.marks import router as marks
from schema import models
from pydanticModels import responseDto
from sqlalchemy.orm import Session
from database_config.database import get_db
from security_config.security import authenticate_user

app = FastAPI()

models.Base.metadata.create_all(engine)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

class Settings(BaseModel):
  authjwt_secret_key: str =os.getenv("AUTHJWT_SECRET_KEY")

@AuthJWT.load_config
def get_config():
    return Settings()

@app.exception_handler(AuthJWTException)
def authjwt_exception_handler(request: Request, exc: AuthJWTException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.message}
    )
    
 
@app.post("/login")
def login(user: responseDto.studentLogin, Authorize: AuthJWT = Depends(),db: Session = Depends(get_db)):
    authenticated_user = authenticate_user(user.username, user.hallticket,db)
    if authenticated_user:
        # Providing a unique identifier (such as username) as subject
        access_token = Authorize.create_access_token(subject=authenticated_user.username)
        return {"access_token": access_token, "token_type": "bearer"}
    raise HTTPException(status_code=401, detail="Invalid username or password")

@app.post("/refresh-token")
async def refresh_token(Authorize: AuthJWT = Depends()):
    Authorize.jwt_refresh_token_required()
    current_user = Authorize.get_jwt_subject()   
    
app.include_router(student)
app.include_router(subject)
app.include_router(marks)
    