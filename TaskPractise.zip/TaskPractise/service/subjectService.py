from pydanticModels import responseDto
from schema import models
from sqlalchemy.orm import Session
from query_config import subject_queries




def saveSubject(subject:responseDto.subjectBase,db:Session):
    if subject:
        add_sub= models.Subject(subject_name=subject.subName)
        db.add(add_sub)
        db.commit()
        return "Subject added Scucessfully"
    else:
        return "Please fill the data"
    
    
def getSubjectById(sub_id,db:Session) :
    if sub_id:
        db_sub=subject_queries.findSubjectById(sub_id,db)
        if db_sub:
            return db_sub
        else:
            return "Subject Not Found"
    else:
        return "Please Provide valid Id"