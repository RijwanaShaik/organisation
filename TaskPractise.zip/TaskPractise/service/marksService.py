
from pydanticModels import responseDto
from sqlalchemy.orm import Session
from schema import models
from query_config import student_queries,subject_queries,marks_queries

def addMarks(add_Marks:responseDto.marksCreate,db:Session):
    if add_Marks:
        db_std=student_queries.findStudentById(add_Marks.std_id,db)
        if db_std is None:
            return "Student Not Found"
        db_sub=subject_queries.findSubjectById(add_Marks.sub_id,db)
        if db_sub is None:
            return "Subject Not Found"
        if db_sub in db_std.std_subject:
            return "Marks for this subject already exist for the student"
        add_marks=models.Marks(marks=add_Marks.marks,student_id=add_Marks.std_id,subject_id=add_Marks.sub_id)
        db.add(add_marks)
        db.commit()
        db_std.std_subject.append(db_sub)
        db.commit()
        return "Marks Added SccuessFully"
    else:
        return "Please provide data"
    
    
def getMarks(std_id,db:Session):
    if std_id:
        db_std=marks_queries.findMarksByStdId(std_id,db)
        return db_std
    else:
        return "Marks Not Found"
    
def getResult(hallticket,db: Session):
    marksList=[]
    if hallticket:
        db_std=student_queries.findStudentByHallTicket(hallticket,db)
        db_marks=getMarks(db_std.id,db)
        taotal_score = sum(score.marks for score in db_marks)
        print(taotal_score, "dsdasdasdasdasdas")
        subjects =len(db_marks)
        percentage=taotal_score*(subjects)/100
        print(percentage,'ppppppp')
    if percentage>40:
        return "PASS"
    else:
        return "FAIL"
        
        
        
        

    