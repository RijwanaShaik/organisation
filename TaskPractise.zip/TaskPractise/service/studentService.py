
from fastapi import Depends
from database_config.database import get_db
from pydanticModels import responseDto
from schema import models
from sqlalchemy.orm import Session
from query_config import student_queries,subject_queries

def saveStudent(student:responseDto.studentBase,db:Session):
    if student:
        add_std= models.Student(username=student.username,hall_ticket_number=student.hallticket,role=student.role)
        db.add(add_std)
        db.commit()
        return "Student added Scucessfully"
    else:
        return "Please fill the data"
def getAll(db: Session =Depends(get_db)):
    students=student_queries.findAllStudents(db)
    return students
    
def getStudentById(std_id,db:Session):
    if std_id:
        db_std=student_queries.findStudentById(std_id,db)
        if db_std:
            return db_std
        else:
            return "Student Not Found"
    else:
        return "Please Provide valid Id"
    
def addStdToSub(std_sub:responseDto.studentSubject,db: Session):
    if std_sub:
        saveStudent(std_sub,db)
        student=student_queries.findStudentByName(std_sub.username,db)
        for sub in std_sub.subName:
            sub_id=subject_queries.findSubjectByName(sub,db)
            if sub_id:
               student.std_subject.append(sub_id)
               db.commit()
               return "Successfully added"
            else:
                return "Subject is Not Found"
    else:
        return "Please fill the data"
    
def addOneStdToOneSub(std_id,sub_name,db:Session):
    student=student_queries.findStudentById(std_id,db)
    subject=subject_queries.findSubjectByName(sub_name,db)
    
    student.std_subject.append(subject)
  
    db.commit()
    
    