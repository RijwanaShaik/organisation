from fastapi import APIRouter,Depends
from database_config.database import get_db
from pydanticModels import responseDto
from service import marksService
from sqlalchemy.orm import Session


router = APIRouter(tags=["Marks"])

@router.post("/add-marks")
def addMarksToStdToSub(marks:responseDto.marksCreate,db: Session =Depends(get_db)):
    return marksService.addMarks(marks,db)

@router.get("/get-marks-of-student/{std_id}")
def getMarksOfAStudent(std_id:int,db:Session =Depends(get_db)):
    return marksService.getMarks(std_id,db)

@router.get("/get-result/{hall_ticket}")
def getResultOfStdHallTicket(hall_ticket:int,db: Session = Depends(get_db)):
    return marksService.getResult(hall_ticket,db)