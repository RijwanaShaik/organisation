
from fastapi import APIRouter,Depends
from pydanticModels import responseDto
from database_config.database import get_db
from sqlalchemy.orm import Session
from security_config.security import has_role
from service import studentService

router = APIRouter(tags=["student"])


@router.post("/add-student")
def addStudent(student:responseDto.studentBase,db: Session =Depends(get_db)):
    return studentService.saveStudent(student,db)

@router.get("/student-by-id/{std_id}")
@has_role(["student"])
def getStudent(std_id:int,db: Session =Depends(get_db)):
     return studentService.getStudentById(std_id,db)
 
@router.get("/get-all")
@has_role(["student"])
def getAllStudents(db: Session = Depends(get_db)):
    return studentService.getAll(db)
 
 
@router.post("/add-std-to-subject")
def addStdToSubject(std_sub:responseDto.studentSubject,db:Session=Depends(get_db)):
    return studentService.addStdToSub(std_sub,db)

@router.post("/add-std-sub/{std_id}/{sub_name}")
def addStdToSub(std_id:int,sub_name:str,db:Session=Depends(get_db)):
    return studentService.addOneStdToOneSub(std_id,sub_name,db)
 
