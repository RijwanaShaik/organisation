from fastapi import APIRouter,Depends
from pydanticModels import responseDto
from service import subjectService
from sqlalchemy.orm import Session
from database_config.database import get_db

router = APIRouter(tags=['subject'])

@router.post("/add-subject")
def addSubject(subject:responseDto.subjectBase,db: Session =Depends(get_db)):
    return subjectService.saveSubject(subject,db)

@router.get("/subject-by-id/{sub_id}")
def getSubject(sub_id:int,db: Session =Depends(get_db)):
     return subjectService.getSubjectById(sub_id,db)