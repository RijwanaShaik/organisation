from schema import models
from sqlalchemy.orm import Session

def findStudentById(std_id,db:Session):
    return db.query(models.Student).where(models.Student.id ==std_id).first()

def findStudentByName(std_name,db:Session):
    return db.query(models.Student).where(models.Student.username ==std_name).first()

def findStudentByHallTicket(hallTicket,db:Session):
    return db.query(models.Student).where(models.Student.hall_ticket_number ==hallTicket).first()

def findAllStudents(db: Session):
    return db.query(models.Student).all()
