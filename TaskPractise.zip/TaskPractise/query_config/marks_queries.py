from schema import models
from sqlalchemy.orm import Session

def findMarksByStdIdAndSubId(std_id,sub_id,db: Session):
    return db.query(models.Marks).filter(models.Marks.student_id == std_id,models.Marks.subject_id ==sub_id).all()

def findMarksByStdId(std_id,db: Session):
    return db.query(models.Marks).filter(models.Marks.student_id == std_id).all()