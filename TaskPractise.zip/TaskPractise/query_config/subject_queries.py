from schema import models
from sqlalchemy.orm import Session

def findSubjectById(sub_id,db:Session):
    return db.query(models.Subject).where(models.Subject.id ==sub_id).first()

def findSubjectByName(name,db:Session):
   return db.query(models.Subject).where(models.Subject.subject_name ==name).first()
