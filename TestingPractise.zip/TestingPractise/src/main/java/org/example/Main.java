package org.example;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
  /*  // Load Excel file
    FileInputStream file = new FileInputStream(new File(filePath));
    XSSFWorkbook workbook = new XSSFWorkbook(file);
    XSSFSheet sheet = workbook.getSheet(sheetName);

    // Read data from Excel into a list of maps
    List<Map<String, String>> data = new ArrayList<>();
    Iterator<Row> rowIterator = sheet.iterator();
    Row headerRow = rowIterator.next();
while (rowIterator.hasNext()) {
        Row row = rowIterator.next();
        Map<String, String> rowData = new HashMap<>();
        for (int i = 0; i < headerRow.getLastCellNum(); i++) {
            Cell cell = row.getCell(i, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
            String header = headerRow.getCell(i).getStringCellValue();
            String value = cell.getStringCellValue();
            rowData.put(header, value);
        }
        data.add(rowData);
    }
file.close();

// Find elements and fill data from Excel
for (Map<String, String> row : data) {
        // Find elements and fill with data from Excel
        WebElement field1 = driver.findElement(By.id("field1"));
        field1.sendKeys(row.get("Column1"));
        WebElement field2 = driver.findElement(By.id("field2"));
        field2.sendKeys(row.get("Column2"));
        // Repeat for other fields on the trade details form

        // Click on the button to proceed to shipping details
        WebElement nextButton = driver.findElement(By.id("nextButton"));
        nextButton.click();
    }

    // Wait for the shipping details form to load
    WebDriverWait wait = new WebDriverWait(driver, 10);
wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("shippingDetailsForm")));

    // Find elements and fill shipping details
    WebElement field1 = driver.findElement(By.id("shippingField1"));
field1.sendKeys("Shipping value 1");
    WebElement field2 = driver.findElement(By.id("shippingField2"));
field2.sendKeys("Shipping value 2");
// Repeat for other fields on the shipping details form

    // Click on the submit button
    WebElement submitButton = driver.findElement(By.id("submitButton"));
submitButton.click();*/


    //next
   /* To allow the user to choose the data from Excel and fill the fields on the webpage without specifying a specific row number in the code, you can implement the following steps:

  1.  First, create a UI that allows the user to select the Excel file and the sheet from which they want to read the data. You can use a file chooser dialog box and a dropdown list to display the available sheets in the Excel file.

  2.  Use Apache POI to read the selected sheet from the Excel file and store the data in a data structure that can be easily accessed by the Selenium code. You can use an ArrayList of HashMaps to store the data for each row, where the keys of the HashMap represent the column names and the values represent the cell values.
    FileInputStream file = new FileInputStream(new File(filePath));
    XSSFWorkbook workbook = new XSSFWorkbook(file);
    XSSFSheet sheet = workbook.getSheet(sheetName);

    ArrayList<HashMap<String, String>> data = new ArrayList<>();

    Iterator<Row> rowIterator = sheet.iterator();
    Row headerRow = rowIterator.next();

while (rowIterator.hasNext()) {
        Row row = rowIterator.next();
        HashMap<String, String> rowData = new HashMap<>();

        for (int i = 0; i < headerRow.getLastCellNum(); i++) {
            Cell cell = row.getCell(i, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
            String header = headerRow.getCell(i).getStringCellValue();
            String value = cell.getStringCellValue();

            rowData.put(header, value);
        }

        data.add(rowData);
    }

file.close();

   3. Use Selenium to navigate to the webpage and fill in the fields with the data selected by the user. You can use the findElement() method to locate the fields on the webpage and the sendKeys() method to input text into the fields.
    WebDriver driver = new ChromeDriver();
driver.get("https://example.com");

for (HashMap<String, String> row : data) {
        WebElement field1 = driver.findElement(By.id("field1"));
        field1.sendKeys(row.get("Column1"));

        WebElement field2 = driver.findElement(By.id("field2"));
        field2.sendKeys(row.get("Column2"));

        // Repeat for other fields*/
   // }





/*

    Question:suppose i have a list of item names like choclates,jucies,biscuits.print the list to excel and send the item name which are selected by the user from excel to item field on webpage using java.
    i don't have to take the user selected item from console, if user choose juices from list,i
    have to bring that juices to the top of list and have to extract the juice row number from excel and has to send to that juice value in web page


    Answer:


    // Create a list of item names
    List<String> itemNames = Arrays.asList("chocolates", "juices", "biscuits");

    // Create a new workbook and worksheet
    Workbook workbook = new XSSFWorkbook();
    Sheet sheet = workbook.createSheet("Items");

    // Write the item names to the worksheet
    int rowNum = 0;
for (String itemName : itemNames) {
        Row row = sheet.createRow(rowNum++);
        Cell cell = row.createCell(0);
        cell.setCellValue(itemName);
    }

    // Write the workbook to a file
    FileOutputStream outputStream = new FileOutputStream("items.xlsx");
workbook.write(outputStream);

// Close the workbook and output stream
workbook.close();
outputStream.close();

    // Initialize the WebDriver and navigate to the webpage
    WebDriver driver = new ChromeDriver();
driver.get("http://example.com");

    // Read the item names from the file into a list
    File file = new File("items.xlsx");
    FileInputStream inputStream = new FileInputStream(file);
    Workbook workbook = new XSSFWorkbook(inputStream);
    Sheet sheet = workbook.getSheet("Items");

    List<String> itemNamesList = new ArrayList<>();
for (Row row : sheet) {
        Cell cell = row.getCell(0);
        String itemName = cell.getStringCellValue();
        itemNamesList.add(itemName);
    }

// Display the list to the user and prompt them to select an item
System.out.println("Choose an item:");
for (int i = 0; i < itemNamesList.size(); i++) {
        System.out.println((i + 1) + ". " + itemNamesList.get(i));
    }
    Scanner scanner = new Scanner(System.in);
    int selectedItemIndex = scanner.nextInt() - 1;

    // Move the selected item to the top of the list
    String selectedItem = itemNamesList.remove(selectedItemIndex);
itemNamesList.add(0, selectedItem);

    // Get the row number for the selected item
    int selectedRowIndex = -1;
for (int i = 0; i < sheet.getLastRowNum() + 1; i++) {
        Row row = sheet.getRow(i);
        Cell cell = row.getCell(0);
        if (cell.getStringCellValue().equalsIgnoreCase(selectedItem)) {
            selectedRowIndex = i;
            break;
        }
    }

    // Enter the selected item into the web page
    WebElement itemField = driver.findElement(By.id("itemField"));
itemField.sendKeys(selectedItem);

// Close the workbook and input stream
workbook.close();
inputStream.close();

// Close the WebDriver
driver.quit();


    This code writes the item names to an Excel file, reads them back into a list, displays the list to the user, prompts them to select an item, moves the selected item to the top of the list, gets the row number for the selected item, enters the selected item into the web page, and then closes the workbook, input stream, and WebDriver.
*/

}