package org.example.example.tdis.website;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class FrieghtForwarder {
    @Test
    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver","/home/thrymr123/Desktop/chromedriver");

        WebDriver driver=new ChromeDriver();
        driver.get("https://qa.tdis-marine.com/login");

        driver.manage().window().maximize();
        //find the username and password fields
        WebElement usernameField=driver.findElement(By.id("username"));
        WebElement passwordField=driver.findElement(By.id("password"));
        usernameField.sendKeys("adam@gmail.com");
        passwordField.sendKeys("Adam@123");
        WebElement loginButton=driver.findElement(By.xpath("//*[text()='Login']"));;
        loginButton.click();
        String expectedUrl="https://qa.tdis-marine.com/login";
        Assert.assertEquals(driver.getCurrentUrl(),expectedUrl);

        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"field_PolicyManagement\"]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"navbarResponsive\"]/ul/li[4]/ul/li[4]/a/span[2]")).click();
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);

        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"jh-create-entity\"]/span")).click();
        Thread.sleep(1000);

        if(driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody")).isDisplayed()) {//before clikcing get certificate page

            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody/tr[4]/td[5]/div/button/span")).click(); //clicked the button get certficate and enter into trade details
        }
        Thread.sleep(1000);
       //frieght forwarder trade details
        driver.findElement(By.xpath("//span[@class='dropdown-btn']")).click();

        driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-trade-details/section/form/article[2]/div/article/div[1]/div[1]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
        Thread.sleep(1000);

        driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-trade-details/section/form/article[2]/div/article/div[2]/div[2]/div/input")).sendKeys("20");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-trade-details/section/form/article[2]/div/article/div[3]/div[2]/div/input")).sendKeys("10");
        Thread.sleep(1000);

        //add certificate client
        driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-trade-details/section/form/article[2]/div/article/div[1]/div[2]/button")).click();
        Thread.sleep(1000);
        if(driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div")).isDisplayed()){
            WebElement TypeOfClient=driver.findElement(By.xpath("//*[@id=\"field_activeStatus\"]"));
            TypeOfClient.click();
            Thread.sleep(1000);
            TypeOfClient.sendKeys(Keys.ENTER);
            //company name
            driver.findElement(By.xpath("//*[@id=\"field_name\"]")).sendKeys("Tata");
            Thread.sleep(1000);
            //contact person
            driver.findElement(By.xpath("//*[@id=\"field_contactPerson\"]")).sendKeys("John");
            Thread.sleep(1000);
            //contact email
            driver.findElement(By.xpath("//*[@id=\"field_email\"]")).sendKeys("tata@gmail.com");
            Thread.sleep(1000);
            //contact number select country
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/div[3]/div[1]/ng-multiselect-dropdown/div/div[1]/span")).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/div[3]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[102]/div")).click();
            //contact number
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/div[3]/div[2]/div/input")).sendKeys("7865438234");
            Thread.sleep(1000);

            //address-street address
            driver.findElement(By.xpath("//*[@id=\"field_streetAddress\"]")).sendKeys("21/B Banjara Hilss");
            Thread.sleep(1000);
            //city
            driver.findElement(By.xpath("//*[@id=\"field_city\"]")).sendKeys("Hyderabad");
            Thread.sleep(1000);
           //select country
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/article/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[1]/span/span[1]")).click();

            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/article/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li[102]/div")).click();

            Thread.sleep(1000);

            driver.findElement(By.xpath("//*[@id=\"field_postalCode\"]")).sendKeys("512765");
            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[@id=\"save-entity\"]/span")).submit();

            Thread.sleep(1000);
        }
        driver.findElement(By.xpath("//button[normalize-space()='Next']")).click();//clicked next button and entered into shipping details
        Thread.sleep(1000);
    }
}
