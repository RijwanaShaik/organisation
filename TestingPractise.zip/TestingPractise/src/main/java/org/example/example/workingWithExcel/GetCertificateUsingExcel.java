package org.example.example.workingWithExcel;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class GetCertificateUsingExcel {
    @Test
    public static void main(String[] args) throws InterruptedException, IOException {
      try {
          System.setProperty("webdriver.chrome.driver", "/home/thrymr123/Desktop/chromedriver");

          WebDriver driver = new ChromeDriver();
          driver.get("https://qa.tdis-marine.com/login");

          driver.manage().window().maximize();
          FileInputStream fileInputStream = new FileInputStream("C:\\demo\\LoginCredentials.xlsx");
          Workbook wb = new XSSFWorkbook(fileInputStream);
          Sheet wbSheet = wb.getSheet("Credentials");
          Row rowOfSheet = wbSheet.getRow(1);
          Cell usernameCell = rowOfSheet.getCell(0);
          String username = usernameCell.getStringCellValue();
          Cell passwordCell = rowOfSheet.getCell(1);
          String password = passwordCell.getStringCellValue();
          wb.close();
          fileInputStream.close();
          //find the username and password fields
          WebElement usernameField = driver.findElement(By.id("username"));
          WebElement passwordField = driver.findElement(By.id("password"));
          usernameField.sendKeys(username);
          passwordField.sendKeys(password);
          WebElement loginButton = driver.findElement(By.xpath("//*[text()='Login']"));
          loginButton.click();

          String expectedUrl = "https://qa.tdis-marine.com/login";
          Assert.assertEquals(driver.getCurrentUrl(), expectedUrl);

          driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
          Thread.sleep(2000);
          driver.findElement(By.xpath("//*[@id=\"field_PolicyManagement\"]")).click();
          Thread.sleep(1000);
          driver.findElement(By.xpath("//*[@id=\"navbarResponsive\"]/ul/li[4]/ul/li[4]/a/span[2]")).click();
          driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);

          Thread.sleep(1000);
          driver.findElement(By.xpath("//*[@id=\"jh-create-entity\"]/span")).click();
          Thread.sleep(1000);

          if (driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody")).isDisplayed()) {//before clikcing get certificate page
              WebElement table = driver.findElement(By.tagName("table"));//table

              if (table.isDisplayed()) {
                  int rowNum = driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/thead/tr")).size();//table rows
                  System.out.println(rowNum);
                  int colNum = driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/thead/tr/th")).size();//table columns
                  System.out.println("Number of rows =" + rowNum);
                  System.out.println("Number of columns =" + colNum);
                  List<WebElement> rowVals = table.findElements(By.tagName("tr"));
                  List<WebElement> headers = table.findElements(By.tagName("th"));

                 //create a new workbook and worksheet
                  FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

                  XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
                  XSSFSheet sheet = workbook.getSheet("GetCertificate");

                  Row headerRow = sheet.createRow(0);
                  for (int i = 0; i < headers.size(); i++) {
                      Cell headerCell = headerRow.createCell(i);
                      headerCell.setCellValue(headers.get(i).getText());
                  }

                  int rowno = 0;
                  for (WebElement row : rowVals) {
                      Row excelrow = sheet.createRow(rowno++);
                      List<WebElement> colVals = row.findElements(By.tagName("td"));
                      int cellNum = 0;
                      for (WebElement cell : colVals) {
                          Cell excelCell = excelrow.createCell(cellNum++);
                          excelCell.setCellValue(cell.getText());
                      }
                  }

                  Thread.sleep(5000);
                  XSSFRow row = null;
                  row = sheet.getRow(1);

                  driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody/tr[1]/td[5]/div/button/span")).click();

                  Cell cell = null;
                  cell = row.createCell(4);
                  cell.setCellValue("Clicked");



                  if (driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form")).isDisplayed()) {//filling details page 1
                      //trader details

                      row = sheet.getRow(7);
                      WebElement select = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[1]/div/select"));
                      select.click();
                      cell = row.getCell(0);
                      String iam = cell.getStringCellValue();
                      select.sendKeys(iam);
                      Thread.sleep(1000);

                      row = sheet.getRow(10);

                      WebElement incoterms = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[2]/div/select"));
                      incoterms.click();
                      cell = row.getCell(0);
                      String incoterm = cell.getStringCellValue();
                      incoterms.sendKeys(incoterm);

                      Thread.sleep(1000);


                      String nextButton = "//button[normalize-space()='Next']";
                      driver.findElement(By.xpath(nextButton)).click();//clicked next button and entered into shipping details
                      Thread.sleep(1000);

                      //shipping details

                      WebElement selectM=driver.findElement(By.tagName("select"));
                      Select select1=new Select(selectM);
                      List<WebElement> options=select1.getOptions();
                      int rows=23;
                      for(WebElement option:options){
                          Row row1=sheet.createRow(rows++);
                          Cell cell1=row1.createCell(0);
                          cell1.setCellValue(option.getText());
                      }

                      inputStream.close();


                      System.out.println("rows enter into excel");
                      row= sheet.getRow(23);

                     WebElement meanOfConveyance= driver.findElement(By.xpath("//select[@name='meansOfConveynace']"));
                    meanOfConveyance.click();
                     cell=row.getCell(0);
                     String transportBy=cell.getStringCellValue();
                     Thread.sleep(1000);
                     meanOfConveyance.sendKeys(transportBy);
                      System.out.println("successfully enter the mode of transport");

                      WebElement fromAriport = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[1]/div/input"));
                      fromAriport.click();
                      row=sheet.getRow(26);
                      cell=row.getCell(0);
                      String origin=cell.getStringCellValue();
                      driver.findElement(By.xpath("//input[@name='fromStation']")).sendKeys(origin);
                      Thread.sleep(2000);
                      Thread.sleep(2000);
                      driver.findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ARROW_DOWN);
                      Thread.sleep(2000);
                      driver.findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ENTER);
                      Thread.sleep(2000);

                      System.out.println("from airport is completed");

                      WebElement toAirport = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[2]/div/input"));
                      toAirport.click();
                      row=sheet.getRow(26);
                      cell=row.getCell(1);
                      String discharge=cell.getStringCellValue();
                      driver.findElement(By.xpath("//input[@name='toStation']")).sendKeys(discharge);
                      Thread.sleep(2000);
                      driver.findElement(By.xpath("//input[@name='toStation']")).sendKeys(Keys.ARROW_DOWN);
                      Thread.sleep(2000);
                      driver.findElement(By.xpath("//input[@name='toStation']")).sendKeys(Keys.ENTER);
                      Thread.sleep(2000);

                      System.out.println("to airport is completed");

                      WebElement shipmentDate = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[5]/div[2]/div/div/my-date-picker/div/div/input"));
                SimpleDateFormat formDate = new SimpleDateFormat("dd/MM/yyyy");
                String strDate = formDate.format(new Date());
                      System.out.println("Enter your date of shipping in dd/MM/yyyy format");
                      row=sheet.createRow(27);
                        cell=row.createCell(0);
                        cell.setCellValue(strDate);
                        String date=cell.getStringCellValue();
                      shipmentDate.sendKeys(date);
                      Thread.sleep(2000);

                      JavascriptExecutor js1 = (JavascriptExecutor) driver;
                      Thread.sleep(2000);
                      js1.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)","");
                      Thread.sleep(2000);


                      driver.findElement(By.xpath(nextButton)).click();//clicked next button and entered into shipping details
                      Thread.sleep(1000);
                      System.out.println("entering into cargo details");

                      //cargo details
                      driver.findElement(By.xpath("//ng-multiselect-dropdown[@name='cargoObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']")).click();
                      Thread.sleep(1000);
                         row=sheet.createRow(27);
                         cell=row.createCell(0);
                         cell.setCellValue("Goods");
                      List<WebElement> ele=driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div"));

                      int lastrows=28;
                      for(WebElement element:ele){
                      Row rowIncr=sheet.createRow(lastrows++);
                       Cell   cells=rowIncr.createCell(0);
                          cells.setCellValue(element.getText());

                      }
                    row= sheet.getRow(30);
                      cell=row.getCell(0);
                      String cargo=cell.getStringCellValue();
                      //cargos
                      WebElement cargoSearch=driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input"));
                      cargoSearch.click();
                      cargoSearch.sendKeys(cargo);
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
                      Thread.sleep(1000);

                      //loadingType
                      System.out.println("Choose loading type");
                      row=sheet.createRow(44);
                      cell=row.createCell(0);
                      cell.setCellValue("Loading Type");
                      //loading type list
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[1]/span")).click();//click on search box
                      Thread.sleep(1000);

                      List<WebElement> elem=driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div"));
                       int ltRow=45;
                      for(WebElement element:elem){
                          Row rowIncr=sheet.createRow(ltRow++);
                          Cell   cells=rowIncr.createCell(0);
                          cells.setCellValue(element.getText());
                      }
                      row= sheet.getRow(49);//forklift
                      cell=row.getCell(0);
                      String loadType=cell.getStringCellValue();
                      WebElement loadingType= driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input"));
                      loadingType.sendKeys(loadType);
                      Thread.sleep(1000);
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();


                      //subType
                      System.out.println("Choose sub type");
                      row=sheet.createRow(63);
                      cell=row.createCell(0);
                      cell.setCellValue("sub type");
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[1]/span")).click();//click on search box
                      Thread.sleep(1000);
                      List<WebElement> eleme=driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div"));
                        int lastrow=64;
                      for(WebElement element:eleme){
                          Row rowIncr=sheet.createRow(lastrow++);
                          Cell   cells=rowIncr.createCell(0);
                          cells.setCellValue(element.getText());
                      }
                      System.out.println("---subtype---");
                      row= sheet.getRow(64);//forklift
                      cell=row.getCell(0);
                      String loadSubtype=cell.getStringCellValue();
                      WebElement subType= driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input"));
                      subType.sendKeys(loadSubtype);
                      Thread.sleep(1000);
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click(); //subtype
                      Thread.sleep(1000);

                      //packingType
                      System.out.println("Choose packing type");
                      row=sheet.createRow(65);
                      cell=row.createCell(0);
                      cell.setCellValue("packing type");
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[1]/span")).click();//click on search box

                      Thread.sleep(1000);
                      List<WebElement> elemen=driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div"));
                      int bottomRow=66;
                      for(WebElement element:elemen){
                          Row rowIncr=sheet.createRow(bottomRow++);
                          Cell   cells=rowIncr.createCell(0);
                          cells.setCellValue(element.getText());
                      }
                      System.out.println("---packingtype----");
                      WebElement packingType=driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input"));
                      row= sheet.getRow(76);//forklift
                      cell=row.getCell(0);
                      String packType=cell.getStringCellValue();
                      packingType.sendKeys(packType);
                      Thread.sleep(1000);
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[1]/div")).click(); //packing type
                      Thread.sleep(1000);

                      //cargo value
                      System.out.println("Enter cargo value");
                      row=sheet.createRow(78);
                      cell=row.createCell(0);
                      cell.setCellValue("cargo value");
                     WebElement cargoValue= driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[2]/div[1]/div/div/div[1]/input")); //cargo value
                      row= sheet.getRow(79);//forklift
                      cell=row.getCell(0);
                      double cargoAmt=cell.getNumericCellValue();
                      String cargoAmount= String.valueOf(cargoAmt);
                      cargoValue.sendKeys(cargoAmount);
                      Thread.sleep(1000);

                      //scrolling up window
                      JavascriptExecutor js2 = (JavascriptExecutor) driver;
                      Thread.sleep(2000);
                      js2.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
                      Thread.sleep(2000);


                      driver.findElement(By.xpath(nextButton)).click();//clicked next button and entered into shipping details
                      Thread.sleep(1000);
                      System.out.println("completed cargo details");

                      //clicking on contiune button after successful scope
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-quotation-details/section/form/article[2]/div/article/div/div/div[2]/div[3]/div/div[3]/button")).click();

                      Thread.sleep(4000);

                      //certificate summary details

                      //cancel pop-up
                      String cancelButton="(//*[text()='Cancel'])[5]";
                      driver.findElement(By.xpath(cancelButton)).click();
                      Thread.sleep(2000);

                      //additonal premium
                      System.out.println("Enter additional premium amount");
                      row= sheet.getRow(80);//forklift
                      cell=row.getCell(0);
                      String amount= String.valueOf(cell.getNumericCellValue());
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[4]/div/div[1]/input")).sendKeys(amount);
                      Thread.sleep(2000);

                      //confirm button
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[4]/div/div[1]/div/button")).click();
                      Thread.sleep(2000);

                      //action button click
                      WebElement addSurveyor=driver.findElement(By.xpath("//button[@id='button-basic']"));
                      addSurveyor.click();
                      //add surveyor
                     driver.findElement(By.xpath("//a[normalize-space()='Add Surveyor']")).click();

                      //search bar click of survey agent
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[1]/span")).click();
                      Thread.sleep(2000);

                      List<WebElement> elements=driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[2]/li/div"));
                      int edgeRow=82;
                      for(WebElement element:elements){
                          Row rowIncr=sheet.createRow(edgeRow++);
                          Cell   cells=rowIncr.createCell(0);
                          cells.setCellValue(element.getText());
                      }
                      System.out.println("--iterate the survey agents---");
                      row= sheet.getRow(82);//forklift
                      cell=row.getCell(0);
                      String addAgent= cell.getStringCellValue();
                      WebElement surveyAgent=driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[1]/li/input"));

                      surveyAgent.click();
                      surveyAgent.sendKeys(addAgent);
                      //surveyAgent.sendKeys(Keys.ARROW_DOWN);
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[2]/li/div")).click();
                   //   surveyAgent.click();
                      surveyAgent.sendKeys(Keys.ENTER);
                      Thread.sleep(1000);

                      //adding survey agent
                      WebElement surveyAddress= driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[2]/div/div[1]/span"));
                      surveyAddress.click();
                       driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[2]/div/div[2]/ul[2]/li/div")).click();
                       surveyAddress.click();
                      Thread.sleep(1000);
                      //submit button of add surveyor
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[3]/button")).click();

                      driver.findElement(By.xpath(cancelButton)).click();
                      Thread.sleep(2000);


                      driver.findElement(By.xpath(cancelButton)).click();
                      Thread.sleep(2000);

                      //print permium on cover
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[8]/div[2]/div/div/label/span")).click();
                      Thread.sleep(2000);
                      JavascriptExecutor js3 = (JavascriptExecutor)driver;
                      js3.executeScript("window.scrollBy(0, 150)", "");

                      //checkbox for agree
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[10]/div/article/div[1]/div/div/div/label/span")).click();
                      Thread.sleep(2000);

                      //submit button
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[10]/div/article/div[2]/div/button")).click();
                      Thread.sleep(2000);

                      //downloading orginal or copies of certificate
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[1]/div/label[1]")).click();
                      Thread.sleep(1000);

                      //no.of copies
                      WebElement noOfCopies=  driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[3]/div/div[2]/select"));

                      noOfCopies.click();
                      noOfCopies.sendKeys(Keys.ARROW_DOWN);
                      noOfCopies.sendKeys(Keys.ENTER);

                      //confirmation button of copies
                      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[4]/button")).click();
                      Thread.sleep(10000);

                      JavascriptExecutor js5 = (JavascriptExecutor)driver;
                      js5.executeScript("window.scrollBy(0, 250)", "");
                      //download button of certificate
                      WebElement download= driver.findElement(By.xpath("//span[normalize-space()='Download']"));
                      download.click();
                      Thread.sleep(1000);


                      //view of certificate
                      WebElement view =  driver.findElement(By.xpath("//span[normalize-space()='View']"));
                      view.click();
                      Thread.sleep(1000);


                      // hold all window handles in array list
                      ArrayList<String> newTb = new ArrayList<String>(driver.getWindowHandles());//switch to new tab
                      driver.switchTo().window(newTb.get(0));
                      Thread.sleep(2000);
                      driver.close();


                      FileOutputStream file = new FileOutputStream("C:\\demo\\GetCertificate.xlsx");
                      workbook.write(file);
                      file.close();


                  }
              }
          }
      }catch (Exception e){
          System.out.println(e);
      }
    }
}