package org.example.example.billing;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.example.getCertificate.Login;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BillingFlow {
    public WebDriver driver;

    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    //XSSFRow row = null;
    Row rows = null;
    Cell cell = null;
    int rowNo=0;
    List<WebElement> elementList=new ArrayList<>();
    String xpath=null;


    private  void fileWriting() throws IOException {
        FileOutputStream outputStream = new FileOutputStream("C:\\demo\\BillingFile.xlsx");
        workbook.write(outputStream);
        outputStream.close();
    }
    private void creatingRowAndSettingCellValue(String cellValue){
        rowNo=sheet.getLastRowNum()+1;
        rows=sheet.createRow(rowNo);
        cell= rows.createCell(0);
        cell.setCellValue(cellValue);
    }

    public void enterIntoBillingModule()  {
        try {
            xpath = "//*[@id=\"navbarResponsive\"]/ul/li[3]/a";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            xpath = "//*[@id=\"navbarResponsive\"]/ul/li[3]/ul/li[1]/a";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void addBillingContractButton()  {
        try{
        xpath="//button[@id='jh-create-entity']";
        Login.getDriver().findElement(By.xpath(xpath)).click();
        Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void fromDate()  {
        try {
            WebElement popUp=Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-billing-my-suffix/div[2]/div/div"));
            if(popUp.isDisplayed()) {
                xpath = "//my-date-picker[@id='field_fromDate']//button[@aria-label='Open Calendar']";
                //my-date-picker[@id='field_toDate']//button[@aria-label='Open Calendar']
                WebElement fromCal = Login.getDriver().findElement(By.xpath(xpath));
                fromCal.click();
                Thread.sleep(1000);
                // xpath="//span[normalize-space()='16']";
                xpath = "//*[@id=\"field_fromDate\"]/div/div[2]/table[2]/tbody/tr[3]/td[4]/div/span";
                Login.getDriver().findElement(By.xpath(xpath)).click();
                Thread.sleep(1000);
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void toDate() {
        try{
        xpath="//my-date-picker[@id='field_toDate']//button[@aria-label='Open Calendar']";

        WebElement toCal=Login.getDriver().findElement(By.xpath(xpath));
        toCal.click();
        Thread.sleep(1000);
        // xpath="//span[normalize-space()='16']";
        xpath="//*[@id=\"field_toDate\"]/div/div[2]/table[1]/tbody/tr/td[3]/div/div[3]/button";
        Login.getDriver().findElement(By.xpath(xpath)).click();
        Thread.sleep(1000);
//*[@id="field_toDate"]/div/div[2]/table[2]/tbody/tr[3]/td[4]/div/span
        xpath="//*[@id=\"field_toDate\"]/div/div[2]/table[2]/tbody/tr[3]/td[4]/div/span";
        Login.getDriver().findElement(By.xpath(xpath)).click();
        Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void client()  {
        try{
        xpath="//span[@class='dropdown-btn']";
        WebElement searchPath=Login.getDriver().findElement(By.xpath(xpath));
        searchPath.click();
        Thread.sleep(1000);
        //create a new workbook and worksheet
        FileInputStream inputStream = new FileInputStream("C:\\demo\\BillingFile.xlsx");

        workbook = new XSSFWorkbook(inputStream);
        sheet = workbook.getSheet("Billing");

       rows = sheet.createRow(rowNo);

        cell = rows.createCell(0);
        cell.setCellValue("Client list");
        //iterate the clients
        xpath="//*[@id=\"main_section\"]/section/div/div/jhi-billing-my-suffix/div[2]/div/div/div[2]/form/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li";
      elementList=Login.getDriver().findElements(By.xpath(xpath));
      //rowNo=sheet.getLastRowNum()+1;
        for(WebElement list:elementList){
       /*    rows=sheet.createRow(rowNo++);
            cell=rows.createCell(0);
            cell.setCellValue(list.getText());*/
            creatingRowAndSettingCellValue(list.getText());
            System.out.println(list.getText());
        }
        fileWriting();
        //send the client name
        xpath="//*[@id=\"main_section\"]/section/div/div/jhi-billing-my-suffix/div[2]/div/div/div[2]/form/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
      rows=sheet.getRow(5);
        WebElement selectClientName=Login.getDriver().findElement(By.xpath(xpath));
        cell=rows.getCell(0);
        String name=cell.getStringCellValue();
        selectClientName.sendKeys(name);
        Thread.sleep(1000);
        Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-billing-my-suffix/div[2]/div/div/div[2]/form/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
        searchPath.click();
        Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void billingCycle() {
        try{
        xpath="//select[@placeholder='Select Billing Cycle']";
        WebElement billingCycle=Login.getDriver().findElement(By.xpath(xpath));
        billingCycle.click();
        Thread.sleep(1000);
        Select select=new Select(billingCycle);
        elementList=select.getOptions();
       // rowNo=sheet.getLastRowNum()+1;
        for(WebElement list:elementList){
           /* rows=sheet.createRow(rowNo++);
            cell=rows.createCell(0);
            cell.setCellValue(list.getText())*/;
            creatingRowAndSettingCellValue(list.getText());
           // System.out.println(list.getText());
        }
        fileWriting();
        rows=sheet.getRow(22);
        cell=rows.getCell(0);
        String payment=cell.getStringCellValue();
        billingCycle.sendKeys(payment);
        Thread.sleep(1000);

        billingCycle.click();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public  void totalTransactions()  {
        try{
           creatingRowAndSettingCellValue("45");
        WebElement transaction=Login.getDriver().findElement(By.xpath("//*[@id=\"field_transactionCount\"]"));
        transaction.click();
            cell=rows.getCell(0);
            String totalTransactions=cell.getStringCellValue();
            fileWriting();
        Thread.sleep(1000);
        transaction.sendKeys(totalTransactions);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void totalUsers(){
        try{
           creatingRowAndSettingCellValue("5");
        WebElement totalUsers=Login.getDriver().findElement(By.xpath("//*[@id=\"field_userCount\"]"));
        totalUsers.click();
            cell=rows.getCell(0);
            String noOfUsers=cell.getStringCellValue();
            fileWriting();
        Thread.sleep(1000);
        totalUsers.sendKeys(noOfUsers);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    public void currencyList(){
        try{
            //select
            WebElement currency=Login.getDriver().findElement(By.xpath("//*[@id=\"field_Currency\"]"));
         Select select=new Select(currency);
         elementList=select.getOptions();
         for(WebElement option:elementList){
             creatingRowAndSettingCellValue(option.getText());
            // System.out.println(option.getText());
         }
         fileWriting();
            currency.click();
            rows=sheet.getRow(44);
            cell=rows.getCell(0);
            String currencyType=cell.getStringCellValue();
            currency.sendKeys(currencyType);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void basicCost() {
        try{
            System.out.println("----basic cost----");
            creatingRowAndSettingCellValue("30");
            fileWriting();
        WebElement cost=Login.getDriver().findElement(By.xpath("//*[@id=\"field_basicCost\"]"));
        cost.click();
            rowNo=sheet.getLastRowNum();
            rows=sheet.getRow(rowNo);
            cell=rows.getCell(0);
            String basicCost=cell.getStringCellValue();

        Thread.sleep(1000);
        cost.sendKeys(basicCost);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void additionalCost(){
        try{
            System.out.println("----additional cost----");
            xpath="//input[@id='field_additionalPerTransaction']";
            WebElement additionalCost=Login.getDriver().findElement(By.xpath(xpath));
            additionalCost.click();
            creatingRowAndSettingCellValue("1");
            fileWriting();
            rowNo=sheet.getLastRowNum();
            rows=sheet.getRow(rowNo);
            cell=rows.getCell(0);
            String additionalCharges=cell.getStringCellValue();
            additionalCost.sendKeys(additionalCharges);
            Thread.sleep(1000);
        }catch (Exception e){
        System.out.println(e.getMessage());
    }
    }

    public void rebate() {
        try{
            System.out.println("----rebate----");
            xpath="//input[@id='field_rebate']";
            WebElement rebate=Login.getDriver().findElement(By.xpath(xpath));
            rebate.click();
            creatingRowAndSettingCellValue("10");
            fileWriting();
            rowNo=sheet.getLastRowNum();
            rows=sheet.getRow(rowNo);
            cell=rows.getCell(0);
            String discount=cell.getStringCellValue();
            rebate.sendKeys(discount);
            Thread.sleep(2000);
            Actions act = new Actions(Login.getDriver());
            act.sendKeys(Keys.PAGE_DOWN).build().perform();
          // act.sendKeys(Keys.PAGE_UP).build().perform(); //for scroll up the pop-up

      }catch (Exception e){
       System.out.println(e.getMessage());
    }
    }

    public void VesselScreeningIncludedInCost(){
        try{
            xpath="//span[normalize-space()='Vessel Screening Included in Cost']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void VesselScreeningFreeTransactions(){
        try{
            System.out.println("----free transactions----");
            xpath="//input[@id='field_vesselScreeningLimit']";
            WebElement screening=Login.getDriver().findElement(By.xpath(xpath));
            screening.click();
            creatingRowAndSettingCellValue("10");
            fileWriting();
            rowNo=sheet.getLastRowNum();
            rows=sheet.getRow(rowNo);
            cell=rows.getCell(0);
            String limit=cell.getStringCellValue();
            screening.sendKeys(limit);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void CostPerCallVesselScreening(){
        try{
            System.out.println("----cost per transactions----");
            xpath="//input[@id='field_vesselScreeningCost']";
            WebElement screening=Login.getDriver().findElement(By.xpath(xpath));
            screening.click();
            creatingRowAndSettingCellValue("10");
            fileWriting();
            rowNo=sheet.getLastRowNum();
            rows=sheet.getRow(rowNo);
            cell=rows.getCell(0);
            String cost=cell.getStringCellValue();
            screening.sendKeys(cost);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void SanctionScreeningCost(){
        try{
            System.out.println("----screening cost----");
            xpath="//input[@id='field_ScreeningCost']";
            WebElement screening=Login.getDriver().findElement(By.xpath(xpath));
            screening.click();
            creatingRowAndSettingCellValue("44");
            fileWriting();
            rowNo=sheet.getLastRowNum();
            rows=sheet.getRow(rowNo);
            cell=rows.getCell(0);
            String cost=cell.getStringCellValue();
            screening.sendKeys(cost);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void provisionSpot(){
        try{
            System.out.println("----provision spot checkbox----");
            xpath="//span[normalize-space()='Do you want provision spot market for this client?']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(2000);
            Actions act = new Actions(Login.getDriver());
            act.sendKeys(Keys.PAGE_DOWN).build().perform();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void flatPrice(){
        try{
            System.out.println("----flat price----");
            xpath="//input[@id='field_flatPrice']";
            WebElement flatPrice=Login.getDriver().findElement(By.xpath(xpath));
            flatPrice.click();
            creatingRowAndSettingCellValue("5");
            fileWriting();
            rowNo=sheet.getLastRowNum();
            rows=sheet.getRow(rowNo);
            cell=rows.getCell(0);
            String price=cell.getStringCellValue();
            flatPrice.sendKeys(price);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void netPremium(){
        try{
            System.out.println("----net premium----");
            xpath="//input[@id='field_PercentageOnNetPremium']";
            WebElement netPremium=Login.getDriver().findElement(By.xpath(xpath));
            netPremium.click();
            creatingRowAndSettingCellValue("2");
            fileWriting();
            rowNo=sheet.getLastRowNum();
            rows=sheet.getRow(rowNo);
            cell=rows.getCell(0);
            String cost=cell.getStringCellValue();
            netPremium.sendKeys(cost);
            Thread.sleep(2000);
          /*JavascriptExecutor js1 = (JavascriptExecutor) Login.getDriver();
            Thread.sleep(2000);
            js1.executeScript("window.scrollBy(0,300)", "");
            Thread.sleep(2000);*/
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void confirm() {
        try {
            System.out.println("----confirm button----");
            xpath = "//button[normalize-space()='Confirm']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            WebElement popUp=Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-billing-my-suffix/div[2]/div/div"));
            if(popUp.isDisplayed()){
                System.out.println("Test failed");
            }else {
                System.out.println("Test has passed");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void cancel() {
        try {

            System.out.println("----cancel button----");
            xpath = "//button[normalize-space()='Cancel']";
           WebElement cancel= Login.getDriver().findElement(By.xpath(xpath));
            cancel.click();
            Thread.sleep(1000);
       /*     WebElement popUp=Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-billing-my-suffix/div[2]/div/div"));

            if(popUp.isDisplayed()){
                System.out.println("Test failed");
            }else {
                System.out.println("Test has passed");
                  Assert.assertTrue(true);
            }*/


        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
