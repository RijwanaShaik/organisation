package org.example.example.getCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.example.workingWithExcel.ExcelFile;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TradeDetails {
    public WebDriver driver;

    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    //XSSFRow row = null;
    Row rows = null;
    Cell cell = null;
    int rowNo=0;
    List<WebElement> elementList=new ArrayList<>();
    String xpath=null;

    public void tradeDetails() throws IOException {
        ExcelFile excelFile=new ExcelFile();
        excelFile.createExcel("TradeDetails","C:\\demo\\TradeDetails.xlsx");
    }

    private  void fileWriting() throws IOException {
        FileOutputStream outputStream = new FileOutputStream("C:\\demo\\TradeDetails.xlsx");
        workbook.write(outputStream);
        outputStream.close();
    }
    private void creatingRowAndSettingCellValue(String cellValue){
        rowNo=sheet.getLastRowNum()+1;
        rows=sheet.createRow(rowNo);
        cell= rows.createCell(0);
        cell.setCellValue(cellValue);
    }
    public void iam(){
        try{
            //create a new workbook and worksheet
            FileInputStream inputStream = new FileInputStream("C:\\demo\\TradeDetails.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("TradeDetails");
            rows = sheet.createRow(rowNo);

            cell = rows.createCell(0);
            cell.setCellValue("select Trader");

           System.out.println("--select seller or buyer");
            xpath="//select[@name='clientType']";
            WebElement select = Login.getDriver().findElement(By.xpath(xpath));
            select.click();
            Select options=new Select(select);
            elementList=options.getOptions();
            for(WebElement option:elementList){
                creatingRowAndSettingCellValue(option.getText());
                System.out.println(option.getText());
            }
            fileWriting();

             rows=sheet.getRow(2); //choose seller or buyer from excel & put the row number
            cell=rows.getCell(0);//choosing last option of i'm
            String iam=cell.getStringCellValue();
            select.sendKeys(iam);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void incoterm(){
        try{
            System.out.println("--select incoterm--");
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[2]/div/select";
            WebElement incoterms = Login.getDriver().findElement(By.xpath(xpath));
            incoterms.click();
            Select options=new Select(incoterms);
            elementList=options.getOptions();
            for(WebElement option:elementList){
                creatingRowAndSettingCellValue(option.getText());
                System.out.println(option.getText());
            }
            fileWriting();
            rows=sheet.getRow(5); //choose incoterm from excel & put the row number
            cell = rows.getCell(0);
            String incoterm = cell.getStringCellValue();
            incoterms.sendKeys(incoterm);

            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
  /*public void incoterm(){
      try{
          System.out.println("--select incoterm--");
          xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[2]/div/select";
          WebElement incoterms = Login.getDriver().findElement(By.xpath(xpath));
          incoterms.click();
          Select options=new Select(incoterms);
          elementList=options.getOptions();
          for(WebElement option:elementList){
              creatingRowAndSettingCellValue(option.getText());
              System.out.println(option.getText());
          }
          fileWriting();

          // Read the incoterm value from the Excel sheet
          String incoterm = "EXW"; // Replace with the actual incoterm value you want to select
          int rowNumber = -1;
          for (int i = 0; i <= sheet.getLastRowNum(); i++) {
              Row row = sheet.getRow(i);
              Cell cell = row.getCell(0);
              String cellValue = cell.getStringCellValue();
              if (cellValue.equalsIgnoreCase(incoterm)) {
                  rowNumber = i;
                  break;
              }
          }
          if (rowNumber == -1) {
              System.out.println("Incoterm not found in the Excel sheet");
              return;
          }

          // Select the incoterm from the dropdown
          options.selectByIndex(rowNumber);
          Thread.sleep(1000);
      }catch (Exception e){
          System.out.println(e.getMessage());
      }
  }*/

    public void next(){
        try{
            xpath="//button[normalize-space()='Next']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//clicked next button and entered into shipping details
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        }
}
