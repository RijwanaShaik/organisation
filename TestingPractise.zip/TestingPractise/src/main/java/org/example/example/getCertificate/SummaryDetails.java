package org.example.example.getCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class SummaryDetails {
    public WebDriver driver;

    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    //XSSFRow row = null;
    Row rows = null;
    Cell cell = null;
    int rowNo=0;
    List<WebElement> elementList=new ArrayList<>();
    String xpath=null;
    public void clickOnContinue() throws InterruptedException {
        //clicking on contiune button after successful scope
        try {

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-quotation-details/section/form/article[2]/div/article/div/div/div[2]/div[3]/div/div[3]/button";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(4000);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    //certificate summary details
    public void cancelPopUP() throws InterruptedException {
        try {
            //cancel pop-up
            String cancelButton = "(//*[text()='Cancel'])[5]";
            Login.getDriver().findElement(By.xpath(cancelButton)).click();
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void addSurveyorDetails() throws InterruptedException {

        try {
            //action button click
            WebElement addSurveyor = Login.getDriver().findElement(By.xpath("//button[@id='button-basic']"));
            addSurveyor.click();
            //add surveyor
            Login.getDriver().findElement(By.xpath("//a[normalize-space()='Add Surveyor']")).click();

            //search bar click of survey agent
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[1]/span")).click();
            Thread.sleep(2000);

            List<WebElement> elements = Login.getDriver().findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[2]/li/div"));
            int edgeRow = 82;
            for (WebElement element : elements) {
                Row rowIncr = sheet.createRow(edgeRow++);
                Cell cells = rowIncr.createCell(0);
                cells.setCellValue(element.getText());
            }
            System.out.println("--iterate the survey agents completed---");
            rows = sheet.getRow(82);
            cell = rows.getCell(0);
            String addAgent = cell.getStringCellValue();
            WebElement surveyAgent = Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[1]/li/input"));

            surveyAgent.click();
            surveyAgent.sendKeys(addAgent);
            //surveyAgent.sendKeys(Keys.ARROW_DOWN);
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[2]/li/div")).click();
            //   surveyAgent.click();
            surveyAgent.sendKeys(Keys.ENTER);
            Thread.sleep(1000);

            //adding survey agent
            WebElement surveyAddress = Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[2]/div/div[1]/span"));
            surveyAddress.click();
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[2]/div/div[2]/ul[2]/li/div")).click();
            surveyAddress.click();
            Thread.sleep(1000);
            //submit button of add surveyor
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[3]/button")).click();
            Thread.sleep(1000);

            cancelPopUP();


        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void additionalPremium() throws InterruptedException {
        //additonal premium
        try {
            System.out.println("Enter additional premium amount");
            rows = sheet.getRow(80);
            cell = rows.getCell(0);
            String amount = String.valueOf(cell.getNumericCellValue());
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[4]/div/div[1]/input")).sendKeys(amount);
            Thread.sleep(2000);

            //confirm button
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[4]/div/div[1]/div/button")).click();
            Thread.sleep(2000);
            cancelPopUP();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void tickOnCheckBoxes() {
        try {
            //print permium on cover
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[8]/div[2]/div/div/label/span")).click();
            Thread.sleep(2000);
            JavascriptExecutor js3 = (JavascriptExecutor) Login.getDriver();
            js3.executeScript("window.scrollBy(0, 150)", "");

            //checkbox for agree
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[10]/div/article/div[1]/div/div/div/label/span")).click();
            Thread.sleep(2000);

            //submit button
            WebElement submit= Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[10]/div/article/div[2]/div/button"));
            submit.click();
            Thread.sleep(2000);



        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void noOfCopies() throws InterruptedException {
        try {
            //downloading orginal or copies of certificate
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[1]/div/label[1]")).click();
            Thread.sleep(1000);

            //no.of copies
            WebElement noOfCopies = Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[3]/div/div[2]/select"));

            noOfCopies.click();
            noOfCopies.sendKeys(Keys.ARROW_DOWN);
            noOfCopies.sendKeys(Keys.ENTER);

            //confirmation button of copies
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[4]/button")).click();
            Thread.sleep(10000);
            System.out.println("zip file is downloaded");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void downloadAndViewCertificate() {
        try {
            System.out.println("downloading certificate");
            JavascriptExecutor js5 = (JavascriptExecutor)Login.getDriver();
            js5.executeScript("window.scrollBy(0, 250)", "");
            //download button of certificate
            WebElement download=Login.getDriver().findElement(By.xpath("//span[normalize-space()='Download']"));
            if(download.isDisplayed()){
                System.out.println("Test has been passsed");
            }else {
                System.out.println("Test failed");
            }

            download.click();
            Thread.sleep(1000);


            //view of certificate
            WebElement view =  Login.getDriver().findElement(By.xpath("//span[normalize-space()='View']"));
            view.click();
            Thread.sleep(1000);


            // hold all window handles in array list
            ArrayList<String> newTb = new ArrayList<String>(Login.getDriver().getWindowHandles());//switch to new tab
            Login.getDriver().switchTo().window(newTb.get(0));
            Thread.sleep(2000);
            Login.getDriver().close();

            FileOutputStream file = new FileOutputStream("C:\\demo\\GetCertificate.xlsx");
            workbook.write(file);
            file.close();
            Login.getDriver().quit();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}
