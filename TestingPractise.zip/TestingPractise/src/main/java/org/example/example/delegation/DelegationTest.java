package org.example.example.delegation;


import org.example.example.getCertificate.Login;
import org.example.example.workingWithExcel.ExcelFile;
import org.testng.annotations.Test;

import java.io.IOException;

public class DelegationTest {
    public void delegationFile() throws IOException {
        ExcelFile excelFile=new ExcelFile();
        excelFile.createExcel("DelegationFile","C:\\demo\\DelegationFile.xlsx");
    }
    @Test
    public static void main(String[] args) throws InterruptedException, IOException {
        DelegationTest delegationTest = new DelegationTest();
        delegationTest.delegationFile();

        Login login = new Login();
        login.getTDISUrl();
        login.loginCredentials();


        Delegation delegation=new Delegation();
        delegation.enteringIntoUnderWriterAndInsurer();
        delegation.clickUnderwriter();
        delegation.selectUnderwriter();
        delegation.scrollUpTheWindowToDown();
        delegation.addDelegationButton();
        delegation.inceptionDate();
        delegation.expiryDate();
        delegation.limit();
        delegation.currencyList();
        delegation.delegationNumber();
        delegation.insuranceCompany();
        delegation.sharePercent();
        delegation.addMoreSeurity();
       // delegation.signature();
        //delegation.save();

    }
}
