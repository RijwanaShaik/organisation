package org.example.example.withoutRowNo;

import org.example.example.getCertificate.GetCertificate;
import org.example.example.getCertificate.Login;
import org.testng.annotations.Test;

import java.io.IOException;

public class userSpecific {



    @Test
    public static void main(String[] args) throws InterruptedException, IOException {

        Login login = new Login();
        login.getTDISUrl();
        login.loginCredentials();

        GetCertificate certificate = new GetCertificate();
       certificate.getCertificate();
        certificate.pageEnterIntoGetCertificate();
        certificate.getCertificateCilck();
        certificate.WritingListOfPolicyHoldersToExcel();
    }
}
