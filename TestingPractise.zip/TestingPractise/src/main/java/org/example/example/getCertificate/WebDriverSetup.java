package org.example.example.getCertificate;

import org.testng.annotations.Test;

import java.io.IOException;

public class WebDriverSetup {

    @Test
    public static void main(String[] args) throws InterruptedException, IOException {

        Login login = new Login();
        login.getTDISUrl();
        login.loginCredentials();

        GetCertificate certificate = new GetCertificate();
        for (int i = 1; i <= 3; i++) {
            certificate.getCertificate();
            certificate.pageEnterIntoGetCertificate();
            certificate.getCertificateCilck();
            certificate.WritingListOfPolicyHoldersToExcel();
        /*certificate.traderDetails();
        certificate.shippingDetails();
        certificate.cargoDetails();
        certificate.clickOnContinue();
        certificate.cancelPopUP();
        certificate.additionalPremium();
        certificate.addSurveyorDetails();
        certificate.tickOnCheckBoxes();
        certificate.noOfCopies();
        certificate.downloadAndViewCertificate();*/
            TradeDetails td = new TradeDetails();
            td.tradeDetails();
            td.iam();
            td.incoterm();
            td.next();
        ShippingDetails sd=new ShippingDetails();
        sd.shippingDetails();
        sd.meansOfConveyance();
        sd.scrollUpWindow();
        sd.next();
        CargoDetails cd=new CargoDetails();
        cd.cargoDetails();
        cd.chooseCargo();
        cd.loadingType();
        cd.subType();
        cd.packingType();
        cd.cargoValue();
        cd.scrollUpWindow();
        cd.next();
        }

    }
}
