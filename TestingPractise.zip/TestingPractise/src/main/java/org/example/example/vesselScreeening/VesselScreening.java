package org.example.example.vesselScreeening;


import org.example.example.getCertificate.Login;
import org.example.example.workingWithExcel.ExcelFile;
import org.testng.annotations.Test;

import java.io.IOException;

public class VesselScreening {


    public void EnterVesselScreeningDetails() throws IOException {
        ExcelFile excelFile=new ExcelFile();
        excelFile.createExcel("VesselScreening","C:\\demo\\VesselScreening.xlsx");
    }
    @Test
    public static void main(String[] args) throws IOException, InterruptedException {
        VesselScreening vesselScreening =new VesselScreening();
        vesselScreening.EnterVesselScreeningDetails();
        Login login=new Login();
        login.getTDISUrl();
        login.loginCredentials();
        TestVessel testVessel=new TestVessel();
        testVessel.getIntoVesselScreeningpage();
        testVessel.enterVesselNoOrVesselName();
        testVessel.selectPolicyHolders();
        testVessel.selectProduct();
        testVessel.selectLoadingType();
        testVessel.submitButton();
        testVessel.backToVesselScreeningPage();
    }
}
