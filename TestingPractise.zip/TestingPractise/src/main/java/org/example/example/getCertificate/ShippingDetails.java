package org.example.example.getCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.example.workingWithExcel.ExcelFile;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ShippingDetails {
    public WebDriver driver;

    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    //XSSFRow row = null;
    Row rows = null;
    Cell cell = null;
    int rowNo=0;
    List<WebElement> elementList=new ArrayList<>();
    String xpath=null;

    public void shippingDetails() throws IOException {
        ExcelFile excelFile=new ExcelFile();
        excelFile.createExcel("ShippingDetails","C:\\demo\\ShippingDetails.xlsx");
    }

    private  void fileWriting() throws IOException {
        FileOutputStream outputStream = new FileOutputStream("C:\\demo\\ShippingDetails.xlsx");
        workbook.write(outputStream);
        outputStream.close();
    }
    private void creatingRowAndSettingCellValue(String cellValue){
        rowNo=sheet.getLastRowNum()+1;
        rows=sheet.createRow(rowNo);
        cell= rows.createCell(0);
        cell.setCellValue(cellValue);
    }
    public void meansOfConveyance(){
        try {

            FileInputStream inputStream = new FileInputStream("C:\\demo\\ShippingDetails.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("ShippingDetails");
            rows = sheet.createRow(rowNo);

            cell = rows.createCell(0);
            cell.setCellValue("Types of transport");

            WebElement selectM = Login.getDriver().findElement(By.tagName("select"));
            Select select1 = new Select(selectM);
            elementList = select1.getOptions();
            for (WebElement option : elementList) {
                creatingRowAndSettingCellValue(option.getText());
                System.out.println(option.getText());
            }
            fileWriting();
            System.out.println("--select your mode of transport--");
            xpath = "//select[@name='meansOfConveynace']";
            WebElement meanOfConveyance = Login.getDriver().findElement(By.xpath(xpath));
            meanOfConveyance.click();
            rows=sheet.getRow(1); //enter the row number from excel
            cell = rows.getCell(0);
            String transportBy = cell.getStringCellValue();

            Thread.sleep(1000);
            meanOfConveyance.sendKeys(transportBy);
            System.out.println("successfully enter the mode of transport");
            if(transportBy.equalsIgnoreCase("Air")||transportBy.equalsIgnoreCase("Rail")){
                fromStation();
                toStation();
                shipmentDate();
            }

            if(transportBy.equalsIgnoreCase("Road")){
               fromRoad();
               toRoad();
               shipmentDateOfRoad();
            }
            if(transportBy.equalsIgnoreCase("Vessel")){
                vesselImo();
                vesselVoyageNo();
               fromPort();
               toPort();
               shipmentDateOfVessel();
            }

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void vesselImo(){
        try {
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[1]/div[2]/div[2]/input";
            WebElement vesselImo=Login.getDriver().findElement(By.xpath(xpath));
            vesselImo.click();
            creatingRowAndSettingCellValue("1000069");//set your vessel imo to reflect in excel
            fileWriting();
            //  rows = sheet.getRow(26); // put row number of your vessel no from excel

            cell = rows.getCell(0);
            String origin = cell.getStringCellValue();
            vesselImo.sendKeys(origin);
            Thread.sleep(2000);

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void vesselVoyageNo(){
        try {
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[1]/div[3]/div/input";
            WebElement vesselVoyageNo=Login.getDriver().findElement(By.xpath(xpath));
            vesselVoyageNo.click();
            creatingRowAndSettingCellValue("56");//set your vessel voyage no to reflect in excel
            fileWriting();
            //  rows = sheet.getRow(26); // put row number of your vessel no from excel

            cell = rows.getCell(0);
            String origin = cell.getStringCellValue();
            vesselVoyageNo.sendKeys(origin);
            Thread.sleep(2000);

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void fromPort(){
        try{
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[1]/div/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();

            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[1]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement fromVessel=Login.getDriver().findElement(By.xpath(xpath));
            fromVessel.click();

            creatingRowAndSettingCellValue("chennai");//set your origin of transport place name to reflect in excel
            fileWriting();
            //  rows = sheet.getRow(26); // put row number of your choosen place from excel

            cell = rows.getCell(0);
            String origin = cell.getStringCellValue();
            fromVessel.sendKeys(origin);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[1]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
            Thread.sleep(2000);

            System.out.println("place of origin is completed");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void toPort(){
        try{
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[2]/div/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();

            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[2]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement toPort=Login.getDriver().findElement(By.xpath(xpath));
            toPort.click();
            creatingRowAndSettingCellValue("aprilia");//set your place of discharge name to reflect in excel
            fileWriting();
            // rows = sheet.getRow(26); // put row number of your chosen place from excel
            cell = rows.getCell(0);
            String discharge = cell.getStringCellValue();
            toPort.sendKeys(discharge);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[2]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
            Thread.sleep(2000);

            System.out.println("place of discharge is completed");

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void shipmentDateOfVessel(){
        try{
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[2]/div/div/my-date-picker/div/div/input";

            WebElement shipmentDate = Login.getDriver().findElement(By.xpath(xpath));
            SimpleDateFormat formDate = new SimpleDateFormat("dd/MM/yyyy");
            String strDate = formDate.format(new Date());
            System.out.println("Enter your date of shipping in dd/MM/yyyy format");
            rowNo=sheet.getLastRowNum()+1;
            rows = sheet.createRow(rowNo);
            cell = rows.createCell(0);
            cell.setCellValue(strDate);
            fileWriting();
            String date = cell.getStringCellValue();
            shipmentDate.sendKeys(date);
            Thread.sleep(2000);
            System.out.println("--shipment date--");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void fromStation(){
        try{

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[1]/div/input";
                    //*[@id="main_section"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[1]/div/input
            WebElement fromStation = Login.getDriver().findElement(By.xpath(xpath));
            fromStation.click();

            creatingRowAndSettingCellValue("Mumbai");//set your origin of transport place name to reflect in excel
            fileWriting();
            //  rows = sheet.getRow(26); // put row number of your choosen place from excel

            cell = rows.getCell(0);
            String origin = cell.getStringCellValue();

            Login.getDriver().findElement(By.xpath("//input[@name='fromStation']")).sendKeys(origin);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ENTER);
            Thread.sleep(2000);
            System.out.println("from airport is completed");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void toStation(){
        try{
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[2]/div/input";
            //*[@id="main_section"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[2]/div/input
            WebElement toStation = Login.getDriver().findElement(By.xpath(xpath));
            toStation.click();
            creatingRowAndSettingCellValue("Afghanistan");//set your place of discharge name to reflect in excel
             fileWriting();
            // rows = sheet.getRow(26); // put row number of your chosen place from excel
            cell = rows.getCell(0);
            String discharge = cell.getStringCellValue();
            Login.getDriver().findElement(By.xpath("//input[@name='toStation']")).sendKeys(discharge);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='toStation']")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='toStation']")).sendKeys(Keys.ENTER);
            Thread.sleep(2000);

            System.out.println("to airport is completed");

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void shipmentDate(){
        try{
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[5]/div[2]/div/div/my-date-picker/div/div/input";
//*[@id="main_section"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[5]/div[2]/div/div/my-date-picker/div/div/input
            WebElement shipmentDate = Login.getDriver().findElement(By.xpath(xpath));
            SimpleDateFormat formDate = new SimpleDateFormat("dd/MM/yyyy");
            String strDate = formDate.format(new Date());
            System.out.println("Enter your date of shipping in dd/MM/yyyy format");
            rowNo=sheet.getLastRowNum()+1;
            rows = sheet.createRow(rowNo);
            cell = rows.createCell(0);
            cell.setCellValue(strDate);
            fileWriting();
            String date = cell.getStringCellValue();
            shipmentDate.sendKeys(date);
            Thread.sleep(2000);
            System.out.println("--shipment date--");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

     public void fromRoad(){
        try{
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[1]/div/input";
             WebElement fromRoad=Login.getDriver().findElement(By.xpath(xpath));
             fromRoad.click();

            creatingRowAndSettingCellValue("india");//set your origin of transport place name to reflect in excel
            fileWriting();
            //  rows = sheet.getRow(26); // put row number of your choosen place from excel

            cell = rows.getCell(0);
            String origin = cell.getStringCellValue();
          Login.getDriver().findElement(By.xpath("//input[@name='placeOfOrigin']")).sendKeys(origin);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='placeOfOrigin']")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='placeOfOrigin']")).sendKeys(Keys.ENTER);
            Thread.sleep(2000);
            System.out.println("place of origin is completed");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
     }
    public void toRoad(){
        try{
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[2]/div/input";
            WebElement toRoad=Login.getDriver().findElement(By.xpath(xpath));
            toRoad.click();
            creatingRowAndSettingCellValue("pakistan");//set your place of discharge name to reflect in excel
            fileWriting();
            // rows = sheet.getRow(26); // put row number of your chosen place from excel
            cell = rows.getCell(0);
            String discharge = cell.getStringCellValue();
            toRoad.sendKeys(discharge);
            Thread.sleep(2000);
            toRoad.sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            toRoad.sendKeys(Keys.ENTER);
            Thread.sleep(2000);

            System.out.println("place of discharge is completed");

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void shipmentDateOfRoad(){
        try{
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div/div/div/my-date-picker/div/div/input";

            WebElement shipmentDate = Login.getDriver().findElement(By.xpath(xpath));
            SimpleDateFormat formDate = new SimpleDateFormat("dd/MM/yyyy");
            String strDate = formDate.format(new Date());
            System.out.println("Enter your date of shipping in dd/MM/yyyy format");
            rowNo=sheet.getLastRowNum()+1;
            rows = sheet.createRow(rowNo);
            cell = rows.createCell(0);
            cell.setCellValue(strDate);
            fileWriting();
            String date = cell.getStringCellValue();
            shipmentDate.sendKeys(date);
            Thread.sleep(2000);
            System.out.println("--shipment date--");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }




    public void scrollUpWindow(){
        try{
            JavascriptExecutor js1 = (JavascriptExecutor) Login.getDriver();
            Thread.sleep(2000);
            js1.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Thread.sleep(2000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void next(){
        try{
            xpath="//button[normalize-space()='Next']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//clicked next button and entered into shipping details
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
