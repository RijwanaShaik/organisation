package org.example.example.tdis.website;

import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class LoginPage {

    @Test
    public  void testLogin() throws InterruptedException {


        System.setProperty("webdriver.chrome.driver","/home/thrymr123/Desktop/chromedriver");

        WebDriver  driver=new ChromeDriver();
        driver.get("https://qa.tdis-marine.com/login");

        driver.manage().window().maximize();
        //find the username and password fields
        WebElement usernameField=driver.findElement(By.id("username"));
        WebElement passwordField=driver.findElement(By.id("password"));
        usernameField.sendKeys("adam@gmail.com");
        passwordField.sendKeys("Adam@123");
        WebElement loginButton=driver.findElement(By.xpath("//*[text()='Login']"));;
        loginButton.click();

        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"field_PolicyManagement\"]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"navbarResponsive\"]/ul/li[4]/ul/li[4]/a/span[2]")).click();
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);

        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"jh-create-entity\"]/span")).click();
        Thread.sleep(1000);
        //get certificate

        if(driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody")).isDisplayed()) {//before clikcing get certificate page

            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody/tr[1]/td[5]/div/button/span")).click(); //clicked the button get certficate and enter into trade details
        }
        Thread.sleep(1000);

        if(driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]")).isDisplayed()) {//filling details page 1
           //trader details
            WebElement select = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[1]/div/select"));
            select.sendKeys("seller");

            Thread.sleep(1000);

            WebElement incoterms = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[2]/div/select"));
            incoterms.sendKeys("CIF");

            Thread.sleep(1000);

            WebElement referenceNo = driver.findElement(By.xpath("//input[@name='clientReferenceNumber']"));
            referenceNo.sendKeys("30");

            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[3]/button")).click();//clicked next button and entered into shipping details
            Thread.sleep(1000);

            //shipping details
            WebElement meansOfConveyance = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[1]/div[1]/div/select"));
           meansOfConveyance.click();
            meansOfConveyance.sendKeys("Air");
            Thread.sleep(1000);

            WebElement fromAriport = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[1]/div/input"));
            fromAriport.click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@name='fromStation']")).sendKeys("Mumbai");
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ENTER);
            Thread.sleep(2000);

            WebElement toAirport = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[2]/div/input"));
            toAirport.click();
            driver.findElement(By.xpath("//input[@name='toStation']")).sendKeys("Afghanistan");
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@name='toStation']")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@name='toStation']")).sendKeys(Keys.ENTER);
            Thread.sleep(2000);


            WebElement shipmentDate = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[5]/div[2]/div/div/my-date-picker/div/div/input"));
                 SimpleDateFormat formDate = new SimpleDateFormat("dd/MM/yyyy");
                 String strDate = formDate.format(new Date());
            shipmentDate.sendKeys(strDate);
            Thread.sleep(2000);

            JavascriptExecutor js1 = (JavascriptExecutor) driver;
            Thread.sleep(2000);
            js1.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)","");
            Thread.sleep(2000);

            driver.findElement(By.xpath("(//button[normalize-space()='Next'])[1]")).click(); //enter into cargo details

            //cargo details
             driver.findElement(By.xpath("//ng-multiselect-dropdown[@name='cargoObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']")).click();//click on search box
             Thread.sleep(1000);
             driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[3]/div")).click(); //cargo

            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[1]/span")).click();//click on search box
            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[5]/div")).click(); //loading type
            Thread.sleep(1000);

            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[1]/span")).click();//click on search box
            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click(); //subtype
            Thread.sleep(1000);

            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[1]/span")).click();//click on search box
            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[1]/div")).click(); //packing type
            Thread.sleep(1000);

            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[2]/div[1]/div/div/div[1]/input")).sendKeys("0,01"); //cargo value
            Thread.sleep(1000);

            JavascriptExecutor js2 = (JavascriptExecutor) driver;
            Thread.sleep(2000);
            js2.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Thread.sleep(2000);

            driver.findElement(By.xpath("(//button[normalize-space()='Next'])[1]")).click();//next


            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-quotation-details/section/form/article[2]/div/article/div/div/div[2]/div[3]/div/div[3]/button")).click();
            Thread.sleep(4000);


            //certificate summary details
            //cancel pop-up
            driver.findElement(By.xpath("(//*[text()='Cancel'])[5]")).click();
            Thread.sleep(2000);
            //additonal premium
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[4]/div/div[1]/input")).sendKeys("0,0000");
              Thread.sleep(2000);
            //confirm button
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[4]/div/div[1]/div/button")).click();
            Thread.sleep(2000);
try {
    //add surveyor
    driver.findElement(By.xpath("//*[@id=\"button-tc\"]/span")).click();
    Thread.sleep(2000);

    //search bar click of survey agent
    driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[1]/span")).click();
    Thread.sleep(2000);

    WebElement surveyAgent = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[2]/li[1]/div"));
    surveyAgent.click();
    driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[1]/span")).click();
    Thread.sleep(1000);

    //search bar click of survey address
    driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[2]/div/div[1]/span")).click();
    Thread.sleep(1000);


    WebElement surveyAddres = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[2]/div/div[2]/ul[2]/li/div"));
    surveyAddres.click();
    Thread.sleep(1000);

    driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/div[1]/div/button")).click();
    Thread.sleep(1000);

    //submit button of surveyor
    driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[3]/button")).click();
    Thread.sleep(1000);
       }catch (Exception e){
              System.out.println(e);
             }

            //cancel pop-up
            driver.findElement(By.xpath("(//*[text()='Cancel'])[5]")).click();
            Thread.sleep(2000);

            //cancel pop-up
            driver.findElement(By.xpath("(//*[text()='Cancel'])[5]")).click();
            Thread.sleep(3000);



            //print permium on cover
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[8]/div[2]/div/div/label/span")).click();
            Thread.sleep(2000);
            JavascriptExecutor js3 = (JavascriptExecutor)driver;
            js3.executeScript("window.scrollBy(0, 150)", "");

            //checkbox for agree
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[10]/div/article/div[1]/div/div/div/label/span")).click();
            Thread.sleep(2000);

            //submit button
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[10]/div/article/div[2]/div/button")).click();
            Thread.sleep(2000);

            //downloading orginal or copies of certificate
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[2]/div/div/div[2]/div/div[1]/div/label[1]")).click();
            Thread.sleep(1000);

            //no.of copies
          WebElement noOfCopies=  driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[2]/div/div/div[2]/div/div[3]/div/div[2]/select"));
          noOfCopies.click();
          noOfCopies.sendKeys(Keys.ARROW_DOWN);
          noOfCopies.sendKeys(Keys.ENTER);

          //confirmation button of copies
            driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[2]/div/div/div[2]/div/div[4]/button")).click();
            Thread.sleep(10000);

            //download button of certificate
          WebElement download= driver.findElement(By.xpath("(//span[normalize-space()='Download'])[1]"));
            JavascriptExecutor js4 = (JavascriptExecutor)driver;
            js4.executeScript("arguments[0].click()",download);
            Thread.sleep(4000);
            JavascriptExecutor js5 = (JavascriptExecutor)driver;
            js5.executeScript("window.scrollBy(0, 250)", "");

            //view of certificate
         WebElement view =  driver.findElement(By.xpath("(//button[@id='cancel-save'])[1]"));
         view.click();
            Thread.sleep(1000);


            // hold all window handles in array list
            ArrayList<String> newTb = new ArrayList<String>(driver.getWindowHandles());//switch to new tab
            driver.switchTo().window(newTb.get(0));
            Thread.sleep(2000);
           driver.close();

        }
    }

}
