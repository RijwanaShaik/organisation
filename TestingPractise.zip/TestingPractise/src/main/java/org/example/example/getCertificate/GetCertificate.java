package org.example.example.getCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.example.workingWithExcel.ExcelFile;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class GetCertificate {
    public WebDriver driver;
    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    XSSFRow row = null;
    Row rows = null;
    Cell cell = null;
    String xpath = null;
    String nextButton = "//button[normalize-space()='Next']";
    List<WebElement> elementList = new ArrayList<>();
    int rowNo = 0;
    public void getCertificate() throws IOException {
        ExcelFile excelFile=new ExcelFile();
        excelFile.createExcel("GetCertificate","C:\\demo\\GetCertificate.xlsx");
    }

    @Test(priority = 1)
    public void pageEnterIntoGetCertificate() throws InterruptedException {
        xpath = "//*[@id=\"field_PolicyManagement\"]";
        Login.getDriver().findElement(By.xpath(xpath)).click();
        Thread.sleep(1000);
        xpath = "//*[@id=\"navbarResponsive\"]/ul/li[4]/ul/li[4]/a/span[2]";
        Login.getDriver().findElement(By.xpath(xpath)).click();
        Login.getDriver().manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
        Thread.sleep(1000);
    }

    @Test(priority = 2)
    public void getCertificateCilck() throws InterruptedException {
        xpath = "//*[@id=\"jh-create-entity\"]/span";
        Login.getDriver().findElement(By.xpath(xpath)).click();
        Thread.sleep(1000);
    }

    @Test(priority = 3)
    public void WritingListOfPolicyHoldersToExcel() throws InterruptedException, IOException {
        try {
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody";
            if (Login.getDriver().findElement(By.xpath(xpath)).isDisplayed()) {//before clikcing get certificate page
                WebElement table = Login.getDriver().findElement(By.tagName("table"));//table

                if (table.isDisplayed()) {
                    xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/thead/tr";
                    int rowNum = Login.getDriver().findElements(By.xpath(xpath)).size();//table rows
                   // System.out.println(rowNum);
                    xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/thead/tr/th";
                    int colNum = Login.getDriver().findElements(By.xpath(xpath)).size();//table columns
                  //  System.out.println("Number of rows =" + rowNum);
                  //  System.out.println("Number of columns =" + colNum);
                    List<WebElement> rowVals = table.findElements(By.tagName("tr"));
                    List<WebElement> headers = table.findElements(By.tagName("th"));

                    //create a new workbook and worksheet
                    FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

                     workbook = new XSSFWorkbook(inputStream);
                    sheet = workbook.getSheet("GetCertificate");

          /*          rows = sheet.createRow(0);
                    for (int i = 0; i < headers.size(); i++) {
                        cell = rows.createCell(i);
                        cell.setCellValue(headers.get(i).getText());
                    }


                    for (WebElement row : rowVals) {
                        rows = sheet.createRow(rowNo++);
                        List<WebElement> colVals = row.findElements(By.tagName("td"));
                        int cellNum = 0;
                        for (WebElement cells : colVals) {
                            cell = rows.createCell(cellNum++);
                            cell.setCellValue(cells.getText());
                        }
                    }

                    Thread.sleep(1000);

                    row = sheet.getRow(1);*/
                    xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody/tr[1]/td[5]/div/button/span";
                    Login.getDriver().findElement(By.xpath(xpath)).click();

                 /*   cell = row.createCell(4);
                    cell.setCellValue("Clicked");*/

                }
               /* FileOutputStream file = new FileOutputStream("C:\\demo\\GetCertificate.xlsx");
                workbook.write(file);
                file.close();*/
            }
        } catch (Exception exception) {
            System.out.println(exception);
        }
    }

    @Test(priority = 4)
    public void traderDetails() throws InterruptedException {
        try {
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form";
            if (Login.getDriver().findElement(By.xpath(xpath)).isDisplayed()) {//filling details page 1
                //trader details
                row = sheet.getRow(7);
                xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[1]/div/select";
                WebElement select = Login.getDriver().findElement(By.xpath(xpath));
                select.click();
                cell = row.getCell(0);
                String iam = cell.getStringCellValue();
                select.sendKeys(iam);
                Thread.sleep(1000);

                row = sheet.getRow(10);

                xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[2]/div/select";
                WebElement incoterms = Login.getDriver().findElement(By.xpath(xpath));
                incoterms.click();
                cell = row.getCell(0);
                String incoterm = cell.getStringCellValue();
                incoterms.sendKeys(incoterm);

                Thread.sleep(1000);


                Login.getDriver().findElement(By.xpath(nextButton)).click();//clicked next button and entered into shipping details
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Test(priority = 5)
    public void shippingDetails() throws InterruptedException {
        //shipping details
        try {
            WebElement selectM = Login.getDriver().findElement(By.tagName("select"));
            Select select1 = new Select(selectM);
            elementList = select1.getOptions();
            rowNo = 23;
            for (WebElement option : elementList) {
                rows = sheet.createRow(rowNo++);
                cell = rows.createCell(0);
                cell.setCellValue(option.getText());
            }


            System.out.println("rows enter into excel");
            row = sheet.getRow(23);
            xpath = "//select[@name='meansOfConveynace']";
            WebElement meanOfConveyance = Login.getDriver().findElement(By.xpath(xpath));
            meanOfConveyance.click();
            cell = row.getCell(0);
            String transportBy = cell.getStringCellValue();
            Thread.sleep(1000);
            meanOfConveyance.sendKeys(transportBy);
            System.out.println("successfully enter the mode of transport");

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[1]/div/input";
            WebElement fromAriport = Login.getDriver().findElement(By.xpath(xpath));
            fromAriport.click();
            row = sheet.getRow(26);
            cell = row.getCell(0);
            String origin = cell.getStringCellValue();

            Login.getDriver().findElement(By.xpath("//input[@name='fromStation']")).sendKeys(origin);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ENTER);
            Thread.sleep(2000);

            System.out.println("from airport is completed");

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[2]/div/input";
            WebElement toAirport = Login.getDriver().findElement(By.xpath(xpath));
            toAirport.click();
            row = sheet.getRow(26);
            cell = row.getCell(1);
            String discharge = cell.getStringCellValue();
            Login.getDriver().findElement(By.xpath("//input[@name='toStation']")).sendKeys(discharge);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='toStation']")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='toStation']")).sendKeys(Keys.ENTER);
            Thread.sleep(2000);

            System.out.println("to airport is completed");

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[5]/div[2]/div/div/my-date-picker/div/div/input";

            WebElement shipmentDate = Login.getDriver().findElement(By.xpath(xpath));
            SimpleDateFormat formDate = new SimpleDateFormat("dd/MM/yyyy");
            String strDate = formDate.format(new Date());
            System.out.println("Enter your date of shipping in dd/MM/yyyy format");
            row = sheet.createRow(27);
            cell = row.createCell(0);
            cell.setCellValue(strDate);
            String date = cell.getStringCellValue();
            shipmentDate.sendKeys(date);
            Thread.sleep(2000);

            JavascriptExecutor js1 = (JavascriptExecutor) Login.getDriver();
            Thread.sleep(2000);
            js1.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Thread.sleep(2000);


            Login.getDriver().findElement(By.xpath(nextButton)).click();//clicked next button and entered into shipping details
            Thread.sleep(1000);
            System.out.println("entering into cargo details");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test(priority = 6)
    public void cargoDetails() throws InterruptedException {
        //cargo details
        try {
            xpath = "//ng-multiselect-dropdown[@name='cargoObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            row = sheet.createRow(27);
            cell = row.createCell(0);
            cell.setCellValue("Goods");

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            elementList = Login.getDriver().findElements(By.xpath(xpath));

            rowNo = 28;
            for (WebElement element : elementList) {
                rows = sheet.createRow(rowNo++);
                Cell cells = rows.createCell(0);
                cells.setCellValue(element.getText());

            }
            row = sheet.getRow(30);//coal
            cell = row.getCell(0);
            String cargo = cell.getStringCellValue();
            //cargos
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement cargoSearch = Login.getDriver().findElement(By.xpath(xpath));
            cargoSearch.click();
            cargoSearch.sendKeys(cargo);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);

            //loadingType
            System.out.println("Choose loading type");
            row = sheet.createRow(44);
            cell = row.createCell(0);
            cell.setCellValue("Loading Type");
            //loading type list
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();//click on search box
            Thread.sleep(1000);

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            elementList = Login.getDriver().findElements(By.xpath(xpath));
            rowNo = 45;
            for (WebElement element : elementList) {
                rows = sheet.createRow(rowNo++);
                Cell cells = rows.createCell(0);
                cells.setCellValue(element.getText());
            }
            row = sheet.getRow(50);//forklift
            cell = row.getCell(0);
            String loadType = cell.getStringCellValue();

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement loadingType = Login.getDriver().findElement(By.xpath(xpath));
            loadingType.sendKeys(loadType);
            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            Login.getDriver().findElement(By.xpath(xpath)).click();


            //subType
            System.out.println("Choose sub type");
            row = sheet.createRow(63);
            cell = row.createCell(0);
            cell.setCellValue("sub type");
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();//click on search box
            Thread.sleep(1000);

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            elementList = Login.getDriver().findElements(By.xpath(xpath));
            rowNo = 64;
            for (WebElement element : elementList) {
                rows = sheet.createRow(rowNo++);
                Cell cells = rows.createCell(0);
                cells.setCellValue(element.getText());
            }
            System.out.println("---subtype---");
            row = sheet.getRow(64);//forklift
            cell = row.getCell(0);
            String loadSubtype = cell.getStringCellValue();

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement subType = Login.getDriver().findElement(By.xpath(xpath));
            subType.sendKeys(loadSubtype);
            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            Login.getDriver().findElement(By.xpath(xpath)).click(); //subtype
            Thread.sleep(1000);

            //packingType
            System.out.println("Choose packing type");
            row = sheet.createRow(65);
            cell = row.createCell(0);
            cell.setCellValue("packing type");
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();//click on search box

            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            elementList = Login.getDriver().findElements(By.xpath(xpath));
            rowNo = 66;
            for (WebElement element : elementList) {
                rows = sheet.createRow(rowNo++);
                cell = rows.createCell(0);
                cell.setCellValue(element.getText());
            }
            System.out.println("---packingtype----");

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement packingType = Login.getDriver().findElement(By.xpath(xpath));
            row = sheet.getRow(76);//rigid boxes
            cell = row.getCell(0);
            String packType = cell.getStringCellValue();
            packingType.sendKeys(packType);
            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[1]/div";
            Login.getDriver().findElement(By.xpath(xpath)).click(); //packing type
            Thread.sleep(1000);

            //cargo value
            System.out.println("Enter cargo value");
            row = sheet.createRow(78);
            cell = row.createCell(0);
            cell.setCellValue("cargo value");

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[2]/div[1]/div/div/div[1]/input";
            WebElement cargoValue = Login.getDriver().findElement(By.xpath(xpath)); //cargo value
            row = sheet.getRow(79);
            cell = row.getCell(0);
            double cargoAmt = cell.getNumericCellValue();
            String cargoAmount = String.valueOf(cargoAmt);
            cargoValue.sendKeys(cargoAmount);
            Thread.sleep(1000);

            //scrolling up window
            JavascriptExecutor js2 = (JavascriptExecutor) Login.getDriver();
            Thread.sleep(2000);
            js2.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Thread.sleep(2000);


            Login.getDriver().findElement(By.xpath(nextButton)).click();//clicked next button and entered into shipping details
            Thread.sleep(1000);
            System.out.println("completed cargo details");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    @Test(priority = 7)

    public void clickOnContinue() throws InterruptedException {
        //clicking on contiune button after successful scope
        try {

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-quotation-details/section/form/article[2]/div/article/div/div/div[2]/div[3]/div/div[3]/button";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(4000);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    @Test(priority = 8)
    //certificate summary details
    public void cancelPopUP() throws InterruptedException {
        try {
            //cancel pop-up
            String cancelButton = "(//*[text()='Cancel'])[5]";
            Login.getDriver().findElement(By.xpath(cancelButton)).click();
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    @Test(priority = 9)
    public void additionalPremium() throws InterruptedException {
        //additonal premium
        try {
            System.out.println("Enter additional premium amount");
            row = sheet.getRow(80);
            cell = row.getCell(0);
            String amount = String.valueOf(cell.getNumericCellValue());
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[4]/div/div[1]/input")).sendKeys(amount);
            Thread.sleep(2000);

            //confirm button
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[4]/div/div[1]/div/button")).click();
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    @Test(priority = 10)
    public void addSurveyorDetails() throws InterruptedException {

        try {
            //action button click
            WebElement addSurveyor = Login.getDriver().findElement(By.xpath("//button[@id='button-basic']"));
            addSurveyor.click();
            //add surveyor
            Login.getDriver().findElement(By.xpath("//a[normalize-space()='Add Surveyor']")).click();

            //search bar click of survey agent
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[1]/span")).click();
            Thread.sleep(2000);

            List<WebElement> elements = Login.getDriver().findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[2]/li/div"));
            int edgeRow = 82;
            for (WebElement element : elements) {
                Row rowIncr = sheet.createRow(edgeRow++);
                Cell cells = rowIncr.createCell(0);
                cells.setCellValue(element.getText());
            }
            System.out.println("--iterate the survey agents completed---");
            row = sheet.getRow(82);
            cell = row.getCell(0);
            String addAgent = cell.getStringCellValue();
            WebElement surveyAgent = Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[1]/li/input"));

            surveyAgent.click();
            surveyAgent.sendKeys(addAgent);
            //surveyAgent.sendKeys(Keys.ARROW_DOWN);
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[2]/li/div")).click();
            //   surveyAgent.click();
            surveyAgent.sendKeys(Keys.ENTER);
            Thread.sleep(1000);

            //adding survey agent
            WebElement surveyAddress = Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[2]/div/div[1]/span"));
            surveyAddress.click();
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[2]/div/div[2]/ul[2]/li/div")).click();
            surveyAddress.click();
            Thread.sleep(1000);
            //submit button of add surveyor
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[3]/button")).click();
            Thread.sleep(1000);

            cancelPopUP();

            cancelPopUP();
             } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test(priority = 11)
    public void tickOnCheckBoxes() {
        try {
            //print permium on cover
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[8]/div[2]/div/div/label/span")).click();
            Thread.sleep(2000);
            JavascriptExecutor js3 = (JavascriptExecutor) Login.getDriver();
            js3.executeScript("window.scrollBy(0, 150)", "");

            //checkbox for agree
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[10]/div/article/div[1]/div/div/div/label/span")).click();
            Thread.sleep(2000);

            //submit button
           WebElement submit= Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[10]/div/article/div[2]/div/button"));
           submit.click();
            Thread.sleep(2000);



        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    @Test(priority = 12)
    public void noOfCopies() throws InterruptedException {
        try {
            //downloading orginal or copies of certificate
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[1]/div/label[1]")).click();
            Thread.sleep(1000);

            //no.of copies
            WebElement noOfCopies = Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[3]/div/div[2]/select"));

            noOfCopies.click();
            noOfCopies.sendKeys(Keys.ARROW_DOWN);
            noOfCopies.sendKeys(Keys.ENTER);

            //confirmation button of copies
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[4]/button")).click();
            Thread.sleep(10000);
            System.out.println("zip file is downloaded");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    @Test(priority = 13)
    public void downloadAndViewCertificate() {
        try {
            System.out.println("downloading certificate");
            JavascriptExecutor js5 = (JavascriptExecutor)Login.getDriver();
            js5.executeScript("window.scrollBy(0, 250)", "");
            //download button of certificate
            WebElement download=Login.getDriver().findElement(By.xpath("//span[normalize-space()='Download']"));
            if(download.isDisplayed()){
                System.out.println("Test has been passsed");
            }else {
                System.out.println("Test failed");
            }

            download.click();
            Thread.sleep(1000);


            //view of certificate
            WebElement view =  Login.getDriver().findElement(By.xpath("//span[normalize-space()='View']"));
            view.click();
            Thread.sleep(1000);


            // hold all window handles in array list
            ArrayList<String> newTb = new ArrayList<String>(Login.getDriver().getWindowHandles());//switch to new tab
            Login.getDriver().switchTo().window(newTb.get(0));
            Thread.sleep(2000);
            Login.getDriver().close();

            FileOutputStream file = new FileOutputStream("C:\\demo\\GetCertificate.xlsx");
            workbook.write(file);
            file.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
