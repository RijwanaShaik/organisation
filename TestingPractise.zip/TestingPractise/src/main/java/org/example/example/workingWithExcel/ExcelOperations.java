package org.example.example.workingWithExcel;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExcelOperations {
    FileInputStream fi;
    FileOutputStream fo;
    XSSFWorkbook workbook;
    XSSFSheet sheet;
    XSSFRow row;
    XSSFCell cell;
    String path=null;
    public ExcelOperations(String path){
        this.path=path;
    }
public ExcelOperations(){}

    public  int getRowCount(String sheetName) throws IOException {
        fi=new FileInputStream(path);
        workbook=new XSSFWorkbook(fi);
        sheet= workbook.getSheet(sheetName);
        int rowCount=sheet.getLastRowNum();
        workbook.close();
        fi.close();
        return rowCount;
    }
    public  int getCellCount(String sheetName,int rowNum) throws IOException {
        fi=new FileInputStream(path);
        workbook=new XSSFWorkbook(fi);
        sheet= workbook.getSheet(sheetName);
        row=sheet.getRow(rowNum);
        int cellCount=row.getLastCellNum();
        workbook.close();
        fi.close();
        return cellCount;
    }
    public String getCellData(String sheetName,int rowNum,int colNo) throws IOException {
        fi=new FileInputStream(path);
        workbook=new XSSFWorkbook(fi);
        row= sheet.getRow(rowNum);
        cell= row.getCell(colNo);
        DataFormatter formatter=new DataFormatter();
        String data;
        try{
            data=formatter.formatCellValue(cell);
        }catch (Exception e){
            data=" ";
        }
        workbook.close();
        fi.close();
        return data;
    }
    public void setCellData(String sheetName,int rowNum,int colNo,String data) throws IOException {
        fi=new FileInputStream(path);
        workbook=new XSSFWorkbook(fi);
        sheet= workbook.getSheet(sheetName);

        row=sheet.getRow(rowNum);
        cell=row.createCell(colNo);
        cell.setCellValue(data);

        fo=new FileOutputStream(path);
        workbook.write(fo);

        workbook.close();
        fi.close();
        fo.close();
    }

}
