package org.example.example.delegation;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.example.example.getCertificate.Login;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Delegation {
    public WebDriver driver;

    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    //XSSFRow row = null;
    Row rows = null;
    Cell cell = null;
    int rowNo=0;
    List<WebElement> elementList=new ArrayList<>();
    String xpath=null;


    private  void fileWriting() throws IOException {
        FileOutputStream outputStream = new FileOutputStream("C:\\demo\\DelegationFile.xlsx");
        workbook.write(outputStream);
        outputStream.close();
    }
    private void creatingRowAndSettingCellValue(String cellValue){
        rowNo=sheet.getLastRowNum()+1;
        rows=sheet.createRow(rowNo);
        cell= rows.createCell(0);
        cell.setCellValue(cellValue);
    }
    public void enteringIntoUnderWriterAndInsurer(){
    try{
        xpath="//img[@alt='Data Management']";
        Login.getDriver().findElement(By.xpath(xpath)).click();//clickable on data management
        Thread.sleep(1000);
        xpath="//a[@routerlink='data-management/insurance-company']//span[@class='sidenav-image']";
        Login.getDriver().findElement(By.xpath(xpath)).click();//clickable on underwriter and insurer module
        Thread.sleep(1000);
        }catch (Exception e){
        System.out.println(e.getMessage());
        }
    }
    public void clickUnderwriter(){
        try {
            xpath="//a[normalize-space()='Underwriters']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void selectUnderwriter(){
        try {
            System.out.println("--selectUnderwriter--");
            xpath="table";
            WebElement table=Login.getDriver().findElement(By.tagName(xpath));
            List<WebElement> rowVal = table.findElements(By.tagName("tr"));
          //  List<WebElement> headers = table.findElements(By.tagName("th"));
            //create a new workbook and worksheet
            FileInputStream inputStream = new FileInputStream("C:\\demo\\DelegationFile.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("DelegationFile");

            rows = sheet.createRow(rowNo);

            cell = rows.createCell(0);
            cell.setCellValue("list");
         /*   for(WebElement row:rowVals){
                creatingRowAndSettingCellValue(row.getText());
                System.out.println(row.getText());
            }*/
        /*    for(WebElement row:rowVal){
                rows=sheet.createRow(rowNo++);
             List<WebElement> headers=row.findElements(By.tagName("th"));
                int cellNum = 0;
            for(WebElement col:headers){
                cell = rows.createCell(cellNum++);
                cell.setCellValue(col.getText());
                System.out.println(col.getText());
            }
            }*/
            WebElement tbody=Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-underwriter-my-suffix/div/div/div[2]/table/tbody"));
            List<WebElement> rowVals = table.findElements(By.tagName("tr"));

            for(WebElement row: rowVals) {
                rows=sheet.createRow(rowNo++);
                List<WebElement> colVals = row.findElements(By.tagName("td"));
                int cellNum = 0;
                for (WebElement col : colVals) {
                    cell = rows.createCell(cellNum++);
                    cell.setCellValue(col.getText());
                    System.out.println(col.getText());
                }
            }
            fileWriting();
            rows = sheet.getRow(1);
           xpath="//*[@id=\"main_section\"]/section/div/div/jhi-underwriter-my-suffix/div/div/div[2]/table/tbody/tr[1]/td[1]/a";
           Login.getDriver().findElement(By.xpath(xpath)).click();
            cell = rows.createCell(0);
            cell.setCellValue("Clicked");
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void scrollUpTheWindowToDown(){
        try {
            JavascriptExecutor js1 = (JavascriptExecutor) Login.getDriver();
            Thread.sleep(2000);
            js1.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Thread.sleep(2000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void addDelegationButton(){
        try{
            System.out.println("--click on add delegation button--");
            xpath="//span[normalize-space()='Add Delegation']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void inceptionDate()  {
        try {
            System.out.println("--inception date--");
                xpath = "//button[@class='btnpicker btnpickerenabled']//span[@class='mydpicon icon-mydpcalendar']";//my-date-picker[@id='field_toDate']//button[@aria-label='Open Calendar']
                WebElement inceptionDate = Login.getDriver().findElement(By.xpath(xpath));
            inceptionDate.click();
                Thread.sleep(1000);
                // xpath="//span[normalize-space()='16']";
                xpath = "//span[@class='markcurrday']";
                Login.getDriver().findElement(By.xpath(xpath)).click();
                Thread.sleep(1000);

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void expiryDate() {
        try{
            System.out.println("--expiry date--");
            xpath="//my-date-picker[@name='expiryDate']//button[@aria-label='Open Calendar']";

            WebElement expiryDate=Login.getDriver().findElement(By.xpath(xpath));
            expiryDate.click();
            Thread.sleep(1000);
            xpath="//button[@aria-label='Next Year']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            xpath="//span[normalize-space()='14']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void limit(){
        try{
            System.out.println("--add limit--");
            xpath="//input[@id='limit']";
           WebElement limit= Login.getDriver().findElement(By.xpath(xpath));
           limit.click();
           creatingRowAndSettingCellValue("40");
           fileWriting();
           cell=rows.getCell(0);
           String value=cell.getStringCellValue();
           limit.sendKeys(value);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void currencyList(){
        try{
            System.out.println("--choose currency list--");
            WebElement currency=Login.getDriver().findElement(By.xpath("//span[contains(text(),'Select Currency')]"));
            currency.click();
            xpath="//*[@id=\"currency\"]/div/div[2]/ul[2]/li";
            elementList=Login.getDriver().findElements(By.xpath(xpath));
            for(WebElement option:elementList){
                creatingRowAndSettingCellValue(option.getText());
                System.out.println(option.getText());
            }
            fileWriting();

            rows=sheet.getRow(20);
            cell=rows.getCell(0);
            String currencyType=cell.getStringCellValue();
            Login.getDriver().findElement(By.xpath("//*[@id=\"currency\"]/div/div[2]/ul[1]/li/input")).sendKeys(currencyType);
            Thread.sleep(1000);
            Login.getDriver().findElement(By.xpath("//*[@id=\"currency\"]/div/div[2]/ul[2]/li/div")).click();

            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void delegationNumber(){
        try {
            System.out.println("--delegation number--");
            xpath="//input[@id='delegationNumber']";
            WebElement delegationNumber=Login.getDriver().findElement(By.xpath(xpath));
            delegationNumber.click();
            creatingRowAndSettingCellValue("84569");
            fileWriting();
            cell=rows.getCell(0);
            String delegationNo=cell.getStringCellValue();
            delegationNumber.sendKeys(delegationNo);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void insuranceCompany(){
        try{
            System.out.println("--choose insurance company--");
           xpath="//*[@id=\"insuranceCompany\"]/div/div[1]/span";

            WebElement selectPath=Login.getDriver().findElement(By.xpath(xpath));
            selectPath.click();
            xpath="//*[@id=\"insuranceCompany\"]/div/div[2]/ul[1]/li/input";

            WebElement searchPath=Login.getDriver().findElement(By.xpath(xpath));
            creatingRowAndSettingCellValue("sams");
            searchPath.sendKeys("samsung");
            xpath="//*[@id=\"insuranceCompany\"]/div/div[2]/ul[2]/li/div";

            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void sharePercent(){
        try {
            System.out.println("--give share percent--");
            xpath="//input[@id='share0']";
            WebElement sharePercent=Login.getDriver().findElement(By.xpath(xpath));
            sharePercent.click();
            sharePercent.sendKeys("2");
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
   public void addMoreSeurity(){//add button
        try {
            xpath="//fa-icon[@ng-reflect-icon-prop='plus']//*[name()='svg']";
            WebElement addButton=Login.getDriver().findElement(By.xpath(xpath));
            addButton.click();
            insuranceCompany();
            sharePercent();

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
   }
   public void signature(){
        try {
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-delegation-my-suffix-update/section/div[1]/div/form/div[6]/div[2]/a";
            Login.getDriver().findElement(By.xpath(xpath)).click();

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
   }
   public void save(){
        try {
            xpath="//*[@id=\"save-entity\"]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
   }
}
