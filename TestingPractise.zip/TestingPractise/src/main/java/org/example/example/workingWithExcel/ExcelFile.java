package org.example.example.workingWithExcel;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;

public class ExcelFile {
    public void createExcel(String name,String path) throws IOException {
        //path="C:\\demo\\GetCertificate.xlsx";
        XSSFWorkbook workbook=new XSSFWorkbook();
        XSSFSheet sheet= workbook.createSheet(name);
        FileOutputStream file=new FileOutputStream(path);
        workbook.write(file);
        file.close();
    }
    public static void main(String[] args) throws IOException {

        XSSFWorkbook workbook=new XSSFWorkbook();
        XSSFSheet sheet= workbook.createSheet("GetCertificate");
        FileOutputStream file=new FileOutputStream("C:\\demo\\GetCertificate.xlsx");
        workbook.write(file);
        file.close();
    }

}
