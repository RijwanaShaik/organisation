package org.example.example.vesselScreeening;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class HardCodeVesselScreening {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","/home/thrymr123/Desktop/chromedriver");

        WebDriver driver=new ChromeDriver();
        driver.get("https://qa.tdis-marine.com/login");

        driver.manage().window().maximize();
        //find the username and password fields
        WebElement usernameField=driver.findElement(By.id("username"));
        WebElement passwordField=driver.findElement(By.id("password"));
        usernameField.sendKeys("adam@gmail.com");
        passwordField.sendKeys("Adam@123");
        WebElement loginButton=driver.findElement(By.xpath("//*[text()='Login']"));;
        loginButton.click();

        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"field_PolicyManagement\"]")).click();
        Thread.sleep(1000);

        driver.findElement(By.xpath("//span[contains(text(),'Vessel Screening')]")).click();

        if(driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening-my-suffix/section")).isDisplayed()){
            Thread.sleep(1000);
            driver.findElement(By.xpath("//span[normalize-space()='Screen Vessel']")).click();
            Thread.sleep(1000);
         WebElement element=driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[1]/div[2]/input"));
         element.click();
         Thread.sleep(1000);
         element.sendKeys("1000435");//1000241or1000069

         WebElement select=driver.findElement(By.xpath("//ng-multiselect-dropdown[@name='client']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']"));
         select.click();
         Thread.sleep(1000);

         List<WebElement> elementList=driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[2]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li"));

         for(WebElement list:elementList){
             System.out.println(list.getText());
            }
      driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[2]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input")).sendKeys("sania");
        driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[2]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li")).click();
        select.click();
        }
       //product
        WebElement product=driver.findElement(By.xpath("//select[@placeholder='Select product']"));
        //*[@id="main_section"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[3]/select

        product.click();
        product.sendKeys(Keys.ARROW_DOWN);
        product.sendKeys(Keys.ENTER);

        WebElement loadingType=driver.findElement(By.xpath("//ng-multiselect-dropdown[@name='loadingTypeObjName']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']"));
        loadingType.click();
        List<WebElement> webElementList=driver.findElements(By.xpath("//ng-multiselect-dropdown[@name='loadingTypeObjName']//ul[@class='item2']"));
        for(WebElement list:webElementList){
            System.out.println(list.getText());
        }
         WebElement selectLT=driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[4]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input"));
        selectLT.click();
        selectLT.sendKeys("forklift");

        driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[4]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();

        driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[3]/div[2]/button")).click();

        driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[3]/div[1]/button")).click();
    }
}
