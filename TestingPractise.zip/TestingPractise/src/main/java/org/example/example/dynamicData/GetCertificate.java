package org.example.example.dynamicData;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class GetCertificate {
    @Test
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","/home/thrymr123/Desktop/chromedriver");

        WebDriver driver=new ChromeDriver();
        driver.get("https://qa.tdis-marine.com/login");

        driver.manage().window().maximize();
        //find the username and password fields
        WebElement usernameField=driver.findElement(By.id("username"));
        WebElement passwordField=driver.findElement(By.id("password"));
        usernameField.sendKeys("adam@gmail.com");
        passwordField.sendKeys("Adam@123");
        WebElement loginButton=driver.findElement(By.xpath("//*[text()='Login']"));;
        loginButton.click();
        String expectedUrl="https://qa.tdis-marine.com/login";
        Assert.assertEquals(driver.getCurrentUrl(),expectedUrl);

        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"field_PolicyManagement\"]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"navbarResponsive\"]/ul/li[4]/ul/li[4]/a/span[2]")).click();
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);

        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"jh-create-entity\"]/span")).click();
        Thread.sleep(1000);

        if(driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody")).isDisplayed()) {//before clikcing get certificate page
            WebElement table=driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table"));//table
            if(table.isDisplayed()) {
                int rowNum = driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody/tr")).size();//table rows
                int colNum = driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody/tr[1]/td")).size();//table columns
                System.out.println("Number of rows ="+rowNum);
                System.out.println("Number of columns ="+colNum);

                List<WebElement> rowVals=table.findElements(By.tagName("tr"));
                List<WebElement> colHeader=rowVals.get(0).findElements(By.tagName("th"));
                System.out.println("Column names");
                for(int i=0;i<colHeader.size();i++){

                    System.out.print(colHeader.get(i).getText()+" ");
                }
                System.out.println(" ");
                //  List<WebElement> colVals=rowVals.get(i).findElements(By.tagName("td"));

                for(int i=1; i<=rowNum; i++){
                    for(int j=1; j<=colNum; j++){
                        System.out.print(driver.findElement(By.
                                xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody/tr[" + i +"]/td[" + j + "]")).getText() + "\t");


                    }
                    System.out.println("");
                }
                Scanner sc=new Scanner(System.in);
                System.out.println("Enter the row number");
                int row=sc.nextInt();
                int col=5;
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody/tr[" + row +"]/td[" + col + "]/div/button/span")).click();
                if(driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form")).isDisplayed()) {//filling details page 1
                    //trader details
                    List<String> selection=new ArrayList<>();
                    selection.add("Seller");
                    selection.add("Buyer");
                    System.out.println("choose seller or Buyer");
                    String value=sc.next();
                    for(int i=0;i<selection.size();i++){
                        if(selection.get(i).equalsIgnoreCase(value)){
                            WebElement select = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[1]/div/select"));
                            select.click();
                            select.sendKeys(selection.get(i));

                        }
                    }

                    Thread.sleep(1000);


                    List<String> incotermList=new ArrayList<>();
                    incotermList.add("CIF");
                    incotermList.add("CFR");
                    incotermList.add("FOB");
                    incotermList.add("DAT");
                    incotermList.add("FAS");
                    incotermList.add("EXW");
                    incotermList.add("FCA");
                    incotermList.add("CPT");
                    incotermList.add("CIP");
                    incotermList.add("DAP");
                    incotermList.add("DPU");
                    incotermList.add("DDP");
                    System.out.println("choose Incoterm from below list");
                    incotermList.forEach(System.out::println);
                    System.out.println("choose incoterm ");
                    String incoterm=sc.next();
                    for(int i=0;i<incotermList.size();i++){
                        if(incotermList.get(i).equalsIgnoreCase(incoterm)){
                            WebElement incoterms = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[2]/div/select"));
                            incoterms.click();
                            incoterms.sendKeys(incotermList.get(i));
                        }
                    }

                    Thread.sleep(1000);

                    System.out.println("Enter reference number");
                    String refValue=sc.next();
                    WebElement referenceNo = driver.findElement(By.xpath("//input[@name='clientReferenceNumber']"));
                    referenceNo.sendKeys(refValue);
                    Thread.sleep(1000);

                    driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[3]/button")).click();//clicked next button and entered into shipping details
                    Thread.sleep(1000);
                }



                //shipping details
                List<String> modeOfTransport=new ArrayList<>();
                modeOfTransport.add("Air");
                modeOfTransport.add("Road");
                modeOfTransport.add("Vessel");
                modeOfTransport.add("Rail");
                System.out.println("Choose modeOfTransport from list");
                modeOfTransport.forEach(System.out::println);
                System.out.println("Choose modeOfTransport");
                String selectTransport=sc.next();
                for(int i=0;i<modeOfTransport.size();i++){
                    if(modeOfTransport.get(i).equalsIgnoreCase(selectTransport)){
                        WebElement meansOfConveyance = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[1]/div[1]/div/select"));
                        meansOfConveyance.click();
                        meansOfConveyance.sendKeys(modeOfTransport.get(i));
                    }
                }

                Thread.sleep(1000);


                WebElement fromAriport = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[1]/div/input"));
                fromAriport.click();
                Thread.sleep(2000);
                System.out.println("Enter from location");
                String fromLocation=sc.next();
                driver.findElement(By.xpath("//input[@name='fromStation']")).sendKeys(fromLocation);
                Thread.sleep(2000);
                driver.findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ARROW_DOWN);
                Thread.sleep(2000);
                driver.findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ENTER);
                Thread.sleep(2000);

                WebElement toAirport = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[2]/div/input"));
                toAirport.click();
                System.out.println("Enter to location");
                String toLocation=sc.next();
                driver.findElement(By.xpath("//input[@name='toStation']")).sendKeys(toLocation);
                Thread.sleep(2000);
                driver.findElement(By.xpath("//input[@name='toStation']")).sendKeys(Keys.ARROW_DOWN);
                Thread.sleep(2000);
                driver.findElement(By.xpath("//input[@name='toStation']")).sendKeys(Keys.ENTER);
                Thread.sleep(2000);


                WebElement shipmentDate = driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[5]/div[2]/div/div/my-date-picker/div/div/input"));
              /*  SimpleDateFormat formDate = new SimpleDateFormat("dd/MM/yyyy");
                String strDate = formDate.format(new Date());*/
                System.out.println("Enter your date of shipping in dd/MM/yyyy format");
                String strDate=sc.next();
                shipmentDate.sendKeys(strDate);
                Thread.sleep(2000);

                JavascriptExecutor js1 = (JavascriptExecutor) driver;
                Thread.sleep(2000);
                js1.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)","");
                Thread.sleep(2000);

                driver.findElement(By.xpath("(//button[normalize-space()='Next'])[1]")).click(); //enter into cargo details

                //cargo details
                driver.findElement(By.xpath("//ng-multiselect-dropdown[@name='cargoObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']")).click();
                Thread.sleep(1000);

                List<WebElement> ele=driver.findElements(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div"));

                for(int i=1;i< ele.size();i++){
                    System.out.println(driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[" + i + "]/div")).getText());
                }
                System.out.println("choose your cargo");
                String cargo=sc.next();
                //cargos
                WebElement cargoSearch=driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input"));
                cargoSearch.click();
                cargoSearch.sendKeys(cargo);
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
                Thread.sleep(1000);
               //loadingType
                System.out.println("Choose loading type");
                String loadType=sc.next();
                //loading type list
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[1]/span")).click();//click on search box
                Thread.sleep(1000);

                WebElement loadingType= driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input"));
                loadingType.sendKeys(loadType);
                Thread.sleep(1000);
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();

                //subType
                System.out.println("Choose sub type");
                String loadSubtype=sc.next();

                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[1]/span")).click();//click on search box
                WebElement subType= driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input"));
                subType.sendKeys(loadSubtype);
                Thread.sleep(1000);
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click(); //subtype
                Thread.sleep(1000);
                //packingType
                System.out.println("Choose packing type");
                String packType=sc.next();

                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[1]/span")).click();//click on search box
                WebElement packingType=driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input"));
                packingType.sendKeys(packType);
                Thread.sleep(1000);
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[1]/div")).click(); //packing type
                Thread.sleep(1000);
                //cargo value
                System.out.println("Enter cargo value");
                String cargoValue=sc.next();
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[2]/div[1]/div/div/div[1]/input")).sendKeys(cargoValue); //cargo value
                Thread.sleep(1000);

                //scrolling up window
                JavascriptExecutor js2 = (JavascriptExecutor) driver;
                Thread.sleep(2000);
                js2.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
                Thread.sleep(2000);

                driver.findElement(By.xpath("(//button[normalize-space()='Next'])[1]")).click();//next

                //clicking on contiune button after successful scope
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-quotation-details/section/form/article[2]/div/article/div/div/div[2]/div[3]/div/div[3]/button")).click();
                Thread.sleep(4000);

                //certificate summary details
                //cancel pop-up
                driver.findElement(By.xpath("(//*[text()='Cancel'])[5]")).click();

                Thread.sleep(2000);
                //additonal premium
                System.out.println("Enter additional premium amount");
                String amount=sc.next();
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[4]/div/div[1]/input")).sendKeys(amount);
                Thread.sleep(2000);
                //confirm button
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/div[4]/div/div[1]/div/button")).click();
                Thread.sleep(2000);


                //add surveyor
                driver.findElement(By.xpath("//*[@id=\"button-tc\"]/span")).click();

                Thread.sleep(2000);

                //search bar click of survey agent
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[1]/span")).click();
                Thread.sleep(2000);

                WebElement surveyAgent=driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[2]/ul[2]/li[1]/div"));
                surveyAgent.click();
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[1]/div/div[1]/span")).click();
                Thread.sleep(1000);

                //search bar click of survey address
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[2]/div/div[1]/span")).click();
                Thread.sleep(1000);

                WebElement surveyAddrress= driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/ng-multiselect-dropdown[2]/div/div[2]/ul[2]/li/div"));
                surveyAddrress.click();
                Thread.sleep(1000);

                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[1]/div[1]/div/button")).click();
                Thread.sleep(1000);

                //submit button of surveyor
                driver.findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[2]/div/form/div/div[3]/button")).click();
                Thread.sleep(1000);
            }
        }

    }

}
