package org.example.example.getCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.example.workingWithExcel.ExcelFile;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CargoDetails {
    public WebDriver driver;

    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    //XSSFRow row = null;
    Row rows = null;
    Cell cell = null;
    int rowNo=0;
    List<WebElement> elementList=new ArrayList<>();
    String xpath=null;

    public void cargoDetails() throws IOException {
        ExcelFile excelFile=new ExcelFile();
        excelFile.createExcel("CargoDetails","C:\\demo\\CargoDetails.xlsx");
    }

    private  void fileWriting() throws IOException {
        FileOutputStream outputStream = new FileOutputStream("C:\\demo\\CargoDetails.xlsx");
        workbook.write(outputStream);
        outputStream.close();
    }
    private void creatingRowAndSettingCellValue(String cellValue){
        rowNo=sheet.getLastRowNum()+1;
        rows=sheet.createRow(rowNo);
        cell= rows.createCell(0);
        cell.setCellValue(cellValue);
    }
    public void chooseCargo(){
        try{
            FileInputStream inputStream = new FileInputStream("C:\\demo\\CargoDetails.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("CargoDetails");
            rows = sheet.createRow(rowNo);

            cell = rows.createCell(0);
            cell.setCellValue("Goods");

            xpath = "//ng-multiselect-dropdown[@name='cargoObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            elementList = Login.getDriver().findElements(By.xpath(xpath));

            for (WebElement element : elementList) {

                creatingRowAndSettingCellValue(element.getText());
            }
            System.out.println("---cargo's list enter into excel--");
            fileWriting();
            rows = sheet.getRow(3);// put row number of your cargo from excel
            cell = rows.getCell(0);
            String cargo = cell.getStringCellValue();
            //cargos
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement cargoSearch = Login.getDriver().findElement(By.xpath(xpath));
            cargoSearch.click();
            cargoSearch.sendKeys(cargo);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            System.out.println("---cargo is entered---");
             xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[2]/div/textarea";
             Login.getDriver().findElement(By.xpath(xpath)).click();
            System.out.println("--other click--");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void loadingType(){
        try{
            //loadingType
            System.out.println("Choose loading type");

            creatingRowAndSettingCellValue("Loading Type");
            //loading type list
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();//click on search box
            Thread.sleep(1000);

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            elementList = Login.getDriver().findElements(By.xpath(xpath));

            for (WebElement element : elementList) {
                creatingRowAndSettingCellValue(element.getText());
            }
            fileWriting();
            rows = sheet.getRow(24);// put row number of your loading type no from excel
            cell = rows.getCell(0);
            String loadType = cell.getStringCellValue();

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement loadingType = Login.getDriver().findElement(By.xpath(xpath));
            loadingType.sendKeys(loadType);
            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            Login.getDriver().findElement(By.xpath(xpath)).click();

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void subType(){
        try{
            //subType
            System.out.println("Choose sub type");
          creatingRowAndSettingCellValue("sub type");
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();//click on search box
            Thread.sleep(1000);

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            elementList = Login.getDriver().findElements(By.xpath(xpath));
            for (WebElement element : elementList) {
               creatingRowAndSettingCellValue(element.getText());
            }
            fileWriting();
            System.out.println("---subtype---");
           // rows = sheet.getRow(43);// put row number of your sub type no from excel
            cell = rows.getCell(0);
            String loadSubtype = cell.getStringCellValue();

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement subType = Login.getDriver().findElement(By.xpath(xpath));
            subType.sendKeys(loadSubtype);
            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            Login.getDriver().findElement(By.xpath(xpath)).click(); //subtype
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void packingType(){
        try{
//packingType
            System.out.println("Choose packing type");
         creatingRowAndSettingCellValue("packing type");
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();//click on search box

            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            elementList = Login.getDriver().findElements(By.xpath(xpath));

            for (WebElement element : elementList) {
             creatingRowAndSettingCellValue(element.getText());
            }
            fileWriting();
            System.out.println("---packingtype----");

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement packingType = Login.getDriver().findElement(By.xpath(xpath));
            rows = sheet.getRow(56);// put row number of your packing type no from excel
            cell = rows.getCell(0);
            String packType = cell.getStringCellValue();
            packingType.sendKeys(packType);
            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[1]/div";
            Login.getDriver().findElement(By.xpath(xpath)).click(); //packing type
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void cargoValue(){
        try{
         //cargo value
            System.out.println("Enter cargo value");
          creatingRowAndSettingCellValue("cargo value");

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[2]/div[1]/div/div/div[1]/input";
            WebElement cargoValue = Login.getDriver().findElement(By.xpath(xpath)); //cargo value
            rowNo=sheet.getLastRowNum()+1;// put your cargo value & it will refelct in excel
            rows=sheet.createRow(rowNo);
            cell=rows.createCell(0);
            cell.setCellValue(1);
            fileWriting();
            cell = rows.getCell(0);
         /*   double cargoAmt = cell.getNumericCellValue();
            String cargoAmount = cell.getStringCellValue();*/
             String cargoAmount= cell.getStringCellValue();
            cargoValue.sendKeys(cargoAmount);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void scrollUpWindow(){
        try{
            JavascriptExecutor js1 = (JavascriptExecutor) Login.getDriver();
            Thread.sleep(2000);
            js1.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Thread.sleep(2000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void next(){
        try{
            xpath="//button[normalize-space()='Next']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//clicked next button and entered into shipping details
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
