package org.example.testing;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SummaryDetails {
    public WebDriver driver;

    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    //XSSFRow row = null;
    Row rows = null;
    Cell cell = null;
    int rowNo=0;
    List<WebElement> elementList=new ArrayList<>();
    String xpath=null;
    public void clickOnContinue() throws InterruptedException {
        //clicking on contiune button after successful scope
        try {

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-quotation-details/section/form/article[2]/div/article/div/div/div[2]/div[3]/div/div[3]/button";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(4000);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    //certificate summary details
    public void cancelPopUP() throws InterruptedException {
        try {
            //cancel pop-up
            String cancelButton = "(//*[text()='Cancel'])[5]";
           Login.getDriver().findElement(By.xpath(cancelButton)).click();
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void addSurveyorDetails() throws InterruptedException {

        try {

            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("GetCertificate");

            WebElement addSurveyor = Login.getDriver().findElement(By.xpath("//button[@id='button-basic']"));
            addSurveyor.click();
            //add surveyor
            Login.getDriver().findElement(By.xpath("//*[@id=\"dropdown-basic\"]/span[3]/li/a")).click();

            //search bar click of survey agent
            xpath="//ng-multiselect-dropdown[@name='surveyAgentObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(2000);


            System.out.println("--iterate the survey agents completed---");
            rows = sheet.getRow(18);
            cell = rows.getCell(0);
            String addAgent = cell.getStringCellValue();
            //li[@class='filter-textbox ng-star-inserted']
            xpath="//input[@placeholder='Select Survey Agent']";
            WebElement surveyAgent = Login.getDriver().findElement(By.xpath(xpath));

            surveyAgent.click();
            surveyAgent.sendKeys(addAgent);
            //surveyAgent.sendKeys(Keys.ARROW_DOWN);
xpath="//ng-multiselect-dropdown[@name='surveyAgentObj']//ul[@class='item2']//li[1]";
            //(//*[@class='multiselect-item-checkbox ng-star-inserted'])[1]//sis
           Login.getDriver().findElement(By.xpath(xpath)).click();
             // surveyAgent.click();
            surveyAgent.sendKeys(Keys.ENTER);
            Thread.sleep(1000);

            //adding survey agent
            xpath="//ng-multiselect-dropdown[@name='surveyAgentAddressObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']";
            WebElement surveyAddress = Login.getDriver().findElement(By.xpath(xpath));
            surveyAddress.click();
            xpath="ng-multiselect-dropdown[name='surveyAgentAddressObj'] div[class='dropdown-list'] div";
           Login.getDriver().findElement(By.cssSelector(xpath)).click();
            surveyAddress.click();
            Thread.sleep(1000);
            //submit button of add surveyor
            xpath="//button[@class='btn btn-blue btn-main pull-right']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);

            cancelPopUP();

            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/button";
           WebElement verifyLimits=Login.getDriver().findElement(By.xpath(xpath));
           if(verifyLimits.isDisplayed()){
               verifyLimits.click();
               Thread.sleep(1000);
               //tick on approved
               xpath="//input[@id='ins0']";

               Login.getDriver().findElement(By.xpath(xpath)).click();
               //save button
               xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[3]/button[2]";
               Login.getDriver().findElement(By.xpath(xpath)).click();
           }else {
               System.out.println("verify limit option is not available on page");
           }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

   /* //for vessel
    public void verifyLimits(){
        try{
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/section/div[3]/div[3]/button";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            //tick on approved
            xpath="//input[@id='ins0']";

            Login.getDriver().findElement(By.xpath(xpath)).click();
            //save button
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[21]/div/div/div[3]/button[2]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }*/
    public void additionalPremium() throws InterruptedException, IOException {
        //additonal premium
        try {

            System.out.println("Enter additional premium amount");
            rows = sheet.getRow(21);
            cell = rows.getCell(0);
            DataFormatter formatter=new DataFormatter();
            String amount = formatter.formatCellValue(cell);

           Login.getDriver().findElement(By.xpath("//*[@class='col-md-5 no-padding-right']/input")).sendKeys(amount); //for all
           Thread.sleep(2000);

            //confirm button

            xpath="//*[@class='margintop-10']";

           WebElement confirmButton= Login.getDriver().findElement(By.xpath(xpath));
            confirmButton.click();
            Thread.sleep(2000);


            //confirmPoPOfVessel
           xpath="//button[@class='btn btn-blue btn-main'][normalize-space()='Confirm']";

            WebElement confirm= Login.getDriver().findElement(By.xpath(xpath));
            if(confirm.isDisplayed()){
                confirm.click();
              //  confirmButton.click();
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void tickOnCheckBoxes() {
        try {
            //print permium on cover
            xpath="//span[normalize-space()='Print premium amount on Certificate/Cover Note']";    //vessel
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(2000);
            JavascriptExecutor js3 = (JavascriptExecutor) Login.getDriver();
            js3.executeScript("window.scrollBy(0, 150)", "");

            //checkbox for agree
            xpath="//span[@class='label-text d-flex text-left']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//for vessel
            Thread.sleep(2000);

            JavascriptExecutor js5 = (JavascriptExecutor) Login.getDriver();
            js5.executeScript("window.scrollBy(0, 250)", "");
            //submit button
            xpath="//button[@type='button'][normalize-space()='Submit']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(2000);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void noOfCopies() throws InterruptedException {
        try {
            //downloading orginal or copies of certificate
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[1]/div/label[1]")).click();
            Thread.sleep(1000);

            //no.of copies
            WebElement noOfCopies = Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[3]/div/div[2]/select"));

            noOfCopies.click();
            noOfCopies.sendKeys(Keys.ARROW_DOWN);
            noOfCopies.sendKeys(Keys.ENTER);

            //confirmation button of copies
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-summary-details/div[1]/div/div/div[2]/div/div[4]/button")).click();
            Thread.sleep(10000);
            System.out.println("zip file is downloaded");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void downloadAndViewCertificate() {
        try {
            System.out.println("downloading certificate");
            JavascriptExecutor js5 = (JavascriptExecutor) Login.getDriver();
            js5.executeScript("window.scrollBy(0, 250)", "");
            //download button of certificate
            WebElement download= Login.getDriver().findElement(By.xpath("//span[normalize-space()='Download']"));
            if(download.isDisplayed()){
                System.out.println("Test has been passed");
                download.click();

            }else {
                System.out.println("Test failed");
            }


            Thread.sleep(1000);


            //view of certificate
            WebElement view =  Login.getDriver().findElement(By.xpath("//span[normalize-space()='View']"));
            view.click();
            Thread.sleep(1000);


            // hold all window handles in array list
            ArrayList<String> newTb = new ArrayList<String>(Login.getDriver().getWindowHandles());//switch to new tab
            Login.getDriver().switchTo().window(newTb.get(0));
            Thread.sleep(2000);
           // Login.getDriver().close();

            FileOutputStream file = new FileOutputStream("C:\\demo\\GetCertificate.xlsx");
            workbook.write(file);
            file.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}
