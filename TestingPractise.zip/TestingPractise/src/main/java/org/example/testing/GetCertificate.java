package org.example.testing;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.example.example.workingWithExcel.ExcelFile;
import org.openqa.selenium.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class GetCertificate {
    public WebDriver driver;
    XSSFWorkbook workbook = null;
    XSSFSheet sheet = null;
    XSSFRow row = null;
    static Row rows = null;
    static Cell cell = null;
    String xpath = null;
    String nextButton = "//button[normalize-space()='Next']";
    List<WebElement> elementList = new ArrayList<>();
    int rowNo = 0;

    public void getCertificate() throws IOException {
        ExcelFile excelFile = new ExcelFile();
        excelFile.createExcel("GetCertificate", "C:\\demo\\GetCertificate.xlsx");
    }

    private  void fileWriting() throws IOException {
        FileOutputStream outputStream = new FileOutputStream("C:\\demo\\GetCertificate.xlsx");
        workbook.write(outputStream);
        outputStream.close();
    }
    public void pageEnterIntoGetCertificate() throws InterruptedException {
        xpath = "//*[@id=\"field_PolicyManagement\"]";
      Login.getDriver().findElement(By.xpath(xpath)).click();
        Thread.sleep(1000);
        xpath = "//*[@id=\"navbarResponsive\"]/ul/li[4]/ul/li[4]/a/span[2]";
        Login.getDriver().findElement(By.xpath(xpath)).click();
      Login.getDriver().manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
        Thread.sleep(1000);
    }


    public void getCertificateCilck() throws InterruptedException {
        xpath = "//*[@id=\"jh-create-entity\"]/span";
        Login.getDriver().findElement(By.xpath(xpath)).click();
        Thread.sleep(1000);
    }

public  void selectUser(){
        try {
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            XSSFWorkbook  workbook = new XSSFWorkbook(inputStream);
            XSSFSheet  sheet = workbook.getSheet("GetCertificate");
            rows = sheet.getRow(1);// put row number of your packing type no from excel
            cell = rows.getCell(2);

            DataFormatter formatter=new DataFormatter();
            int clientNo = Integer.parseInt(formatter.formatCellValue(cell));
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody/tr[" + clientNo +"]/td[5]/div/button/span")).click();


        }catch (Exception e){

        }

}
    public static void main(String[] args) throws IOException, InterruptedException {
        Login login = new Login();
        login.getTDISUrl();
        login.loginCredentials();
        GetCertificate gc=new GetCertificate();

      //  gc.getCertificate();
        FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

        XSSFWorkbook  workbook = new XSSFWorkbook(inputStream);
        XSSFSheet  sheet = workbook.getSheet("GetCertificate");
        rows = sheet.getRow(1);// put row number of your packing type no from excel
        cell = rows.getCell(0);

        DataFormatter formatter=new DataFormatter();
        int noOfCertificates = Integer.parseInt(formatter.formatCellValue(cell));

        for(int i=1;i<=noOfCertificates;i++) {
            gc.pageEnterIntoGetCertificate();
            gc.getCertificateCilck();
            gc.selectUser();
            TradeDetails td = new TradeDetails();

            td.traderDetailsFilling();

            ShippingDetails sd = new ShippingDetails();
            sd.meansOfConveyance();


            CargoDetails cd = new CargoDetails();
            cd.chooseCargo();
            cd.loadingType();
            cd.subType();
            cd.cargoValue();
            cd.scrollUpWindow();
            cd.next();
            SummaryDetails sm = new SummaryDetails();
            sm.clickOnContinue();
            sm.cancelPopUP();
            sm.addSurveyorDetails();
            sm.additionalPremium();
            sm.tickOnCheckBoxes();
            sm.noOfCopies();
            sm.downloadAndViewCertificate();
        }
    }
}