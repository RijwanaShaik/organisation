public class HelloWorld {
    public static void main(String[] args) {

        String a="Sangeetha";
        int age=36;
        String b="hyd";
        float sal=40000;
        System.out.println("employee name: "+a);
        System.out.println("emp age : "+ age);
        System.out.println("emp add : "+b);
        System.out.println("monthly salary : "+sal);
        System.out.println("annual salary : "+sal*12);
    }
}
