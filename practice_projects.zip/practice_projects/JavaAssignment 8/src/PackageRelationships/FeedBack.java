package PackageRelationships;

public class FeedBack {
    int fId;
    String date;
    String feedBack;

    public FeedBack(int fId, String date, String feedBack) {
        this.fId = fId;
        this.date = date;
        this.feedBack = feedBack;
    }

    @Override
    public String toString() {
        return "FeedBack{" +
                "fId=" + fId +
                ", date='" + date + '\'' +
                ", feedBack='" + feedBack + '\'' +
                '}';
    }
}
