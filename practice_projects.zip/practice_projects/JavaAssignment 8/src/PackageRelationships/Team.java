package PackageRelationships;

import java.util.Arrays;

public class Team {
    int tId;
    String tName;
    Member[] members;

    public Team(int tId, String tName, Member[] members) {
        this.tId = tId;
        this.tName = tName;
        this.members = members;
    }

    @Override
    public String toString() {
        return "Team{" +
                "tId=" + tId +
                ", tName='" + tName + '\'' +
                ", members=" + Arrays.toString(members) +
                '}';
    }

    public static void main(String[] args) {
        Team[] teams=new Team[2];

        Member[] members1=new Member[3];

        Assignment[] assignments=new Assignment[1];
        Assignment[] assignment1=new Assignment[1];
        Assignment[] assignment2=new Assignment[1];

        FeedBack[] feedBacks=new FeedBack[1];
        FeedBack[] feedBacks1=new FeedBack[1];
        FeedBack[] feedBacks2=new FeedBack[1];

        feedBacks[0]=new FeedBack(1,"13-09-2022","No Improvement");
        feedBacks1[0]=new FeedBack(2,"20-09-2022","Not Satisfactory");
        feedBacks2[0]=new FeedBack(3,"28-09-2022","not found good");

        assignments[0]=new Assignment(1,"java","12-09-2022",feedBacks);
        assignment1[0]=new Assignment(1,"java","12-09-2022",feedBacks1);
        assignment2[0]=new Assignment(1,"java","12-09-2022",feedBacks2);

        members1[0]=new Member(60,"rahul",assignments);
        members1[1]=new Member(68,"kunal",assignment1);
        members1[2]=new Member(70,"anusha",assignment2);

        Team t1=new Team(100,"java",members1);



        Member [] members2=new Member[2];
        Assignment[] asg1=new Assignment[1];
        Assignment[] asg2=new Assignment[1];
        FeedBack[] feedb1=new FeedBack[1];
        FeedBack[] feedb2=new FeedBack[1];

        feedb1[0]=new FeedBack(1,"20-07-2022","incorrect answers");
        feedb2[0]=new FeedBack(2,"28-07-2022","partially incorrect");

        asg1[0]=new Assignment(1,"core java","18-07-2022",feedb1);
        asg2[0]=new Assignment(1,"core java","18-07-2022",feedb2);

        members2[0]=new Member(40,"shameem",asg1);
        members2[1]=new Member(45,"sanjay",asg2);

        Team t2=new Team(101,"Java1",members2);

        teams[0]=t1;
        teams[1]=t2;

        for ( Team data:teams) {
            System.out.println(data);

        }
    }
}
