package PackageRelationships;

import java.util.Arrays;

public class Member {
    int mId;
    String mName;
    Assignment[] assignments;

    public Member(int mId, String mName, Assignment[] assignments) {
        this.mId = mId;
        this.mName = mName;
        this.assignments = assignments;
    }

    @Override
    public String toString() {
        return "Memeber{" +
                "mId=" + mId +
                ", mName='" + mName + '\'' +
                ", assignments=" + Arrays.toString(assignments) +
                '}';
    }
}
