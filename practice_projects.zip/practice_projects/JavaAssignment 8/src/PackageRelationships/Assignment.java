package PackageRelationships;

import java.util.Arrays;

public class Assignment {
    int aId;
    String aName;
String aDate;
   FeedBack[] feedBacks;

    public Assignment(int aId, String aName, String aDate, FeedBack[] feedBacks) {
        this.aId = aId;
        this.aName = aName;
        this.aDate = aDate;
        this.feedBacks = feedBacks;
    }

    @Override
    public String toString() {
        return "Assignment{" +
                "aId=" + aId +
                ", aName='" + aName + '\'' +
                ", aDate='" + aDate + '\'' +
                ", feedBacks=" + Arrays.toString(feedBacks) +
                '}';
    }
}
