package PackageFileOperations;
//8.Delete directory
import java.io.File;

public class DeleteDirectory {
    public static void main(String[] args) {
        boolean result;
        String directory="D:\\ProjectDirectory";
        File file=new File(directory);
        result=file.delete();
        System.out.println("The Directory is deleted: "+result);

    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/JavaAssignment 8/out/production/JavaAssignment 8 PackageFileOperations.DeletingTempFile
        The Directory is deleted: true
*/
