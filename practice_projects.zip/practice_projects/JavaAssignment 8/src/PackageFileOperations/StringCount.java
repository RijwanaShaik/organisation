package PackageFileOperations;
//    4. Find the String "Lorem Ipsum" repeated count in file. String case should be ignored
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class StringCount {
    public static void main(String[] args) throws Exception {

        File f1=new File("assignment_test_file.txt");

        String[] words=null;
        FileReader fr = new FileReader(f1);
        BufferedReader br = new BufferedReader(fr);
        String s;
        String input="Lorem";
        int count=0;
        while((s=br.readLine())!=null)
        {
            words=s.split(" ");
            for (String word : words)
            {
                if (word.equalsIgnoreCase(input))
                {
                    count++;
                }
            }
        }
        if(count!=0)
        {
            System.out.println("The given word is present for "+count+ " Times in the file");
        }
        else
        {
            System.out.println("The given word is not present in the file");
        }

        fr.close();

    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/JavaAssignment 8/out/production/JavaAssignment 8 PackageFileOperations.StringCount
        The given word is present for 4 Times in the file
*/
