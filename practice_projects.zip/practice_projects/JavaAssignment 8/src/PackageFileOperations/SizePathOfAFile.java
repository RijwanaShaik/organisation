package PackageFileOperations;
//6.Get the size, complete path of the file 'assignment_test_file.txt"
import java.io.File;

public class SizePathOfAFile {
    public static void main(String[] args) {
        File file=new File("assignment_test_file.txt");
        if(file.exists()){
            System.out.println("The size of the file is: "+file.length());
            System.out.println("The complete path of the file is: "+file.getAbsolutePath());

        }else {
            System.out.println("Given file name is not matching");
        }
    }
}


/*The output is:
/home/thrymrthrymr123/Documents/practice_projects/JavaAssignment 8/out/production/JavaAssignment 8 PackageFileOperations.SizePathOfAFile
        The size of the file is: 574
        The complete path of the file is: /home/thrymrthrymr123/Documents/practice_projects/JavaAssignment 8/assignment_test_file.txt*/
