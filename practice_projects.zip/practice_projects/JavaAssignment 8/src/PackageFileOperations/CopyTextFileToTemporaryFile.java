package PackageFileOperations;
//5.Copy the contents of assignment_test_file.txt
import java.io.File;
import java.nio.file.Files;

public class CopyTextFileToTemporaryFile {
    public static void main(String[] args) throws Exception {
        File file1=new File("assignment_test_file.txt");
        File file2=new File("/tmp/temporary-file1504378767159237308.tmp");
        Files.copy(file1.toPath(),file2.toPath());
        System.out.println("copied successfully");
    }
}
