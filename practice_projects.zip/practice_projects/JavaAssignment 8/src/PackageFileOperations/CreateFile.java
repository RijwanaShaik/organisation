package PackageFileOperations;
//Create a new file with the name 'assignment_test_file.txt"
import java.io.File;
import java.io.IOException;

public class CreateFile {
    public static void main(String[] args) {
        File file=new File("assignment_test_file.txt");

        try {
            if(file.createNewFile()){
                System.out.println("The "+file.getName()+ " is created ");
            }else{
                System.out.println("Error,The assignment_test_file already exists");
            }
        }catch (IOException e){
            e.printStackTrace();
        }

    }
}
