package PackageFileOperations;
//3.Read the file assignment_test_file.txt. Print the strings by splitting with delimiter "."
import java.io.FileReader;
import java.util.Scanner;

public class ReadAFileAndSplitingTextByDot {
    public static void main(String[] args) {
        try {
            FileReader fileReader = new FileReader("assignment_test_file.txt");
            Scanner sc = new Scanner(fileReader);
            while (sc.hasNextLine()) {
                String str = sc.nextLine();
                System.out.println("Reading File with text before spliting : " + str + "\n");

                String[] strSplit = str.split("\\.");
                System.out.println("Reading a file and spliting the data based on delimiter: ");
                for (String text : strSplit) {
                    System.out.println(text);
                }
            }
            sc.close();
        } catch (Exception e) {
            System.out.println("Exception occured check the program again");
        }
    }
}
