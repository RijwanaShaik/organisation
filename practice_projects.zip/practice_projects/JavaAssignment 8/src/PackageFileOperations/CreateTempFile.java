package PackageFileOperations;
//5.Create a new temporary file.
import java.io.File;
import java.io.IOException;

public class CreateTempFile {
        public static void main(String[] args) {
            try {
                File f1 = File.createTempFile("temporary-file", ".tmp");
                System.out.println("Temp file is created & path is " + f1.getPath());
            } catch (IOException e) {
                System.out.println("Something went wrong");
            }
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/JavaAssignment 8/out/production/JavaAssignment 8 PackageFileOperations.CreateTempFile
        Temp file is created & path is /tmp/temporary-file6638428118481263637.tmp
*/
