package PackageFileOperations;
//7.Create a Directory (Folder)
import java.io.File;

public class CreateDirectory {
    public static void main(String args[])
    {
        File f = new File("D:\\ProjectDirectory");


        if (f.mkdir() == true) {
            System.out.println("Directory has been created successfully");
        }
        else {
            System.out.println("Directory cannot be created");
        }
    }
}
