package PackageFileOperations;
//8.Delete temporary file
import java.io.File;

public class DeletingTempFile {
    public static void main(String[] args) {
        boolean result;
        String temp="temporary-file.temp";
        File file=new File(temp);
        result=file.delete();
        System.out.println("The temporary is deleted: "+result);
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/JavaAssignment 8/out/production/JavaAssignment 8 PackageFileOperations.DeletingTempFile
        The temporary is deleted: true
*/
