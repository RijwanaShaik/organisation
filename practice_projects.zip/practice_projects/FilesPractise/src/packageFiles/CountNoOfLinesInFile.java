package packageFiles;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class CountNoOfLinesInFile {
    public static void main(String[] args) {
        /*try{
            Path file= Paths.get("D:myfile.txt");
            long count= Files.lines(file).count();
            System.out.println(count);
        }catch (IOException e){
            System.out.println(e);
        }*/
        int count=0;
        try {
            File file = new File("D:myfile.txt");
            Scanner sc = new Scanner(file);
            while(sc.hasNextLine()){
                sc.nextLine();
                count++;
            }
            System.out.println(count);
            sc.close();
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
