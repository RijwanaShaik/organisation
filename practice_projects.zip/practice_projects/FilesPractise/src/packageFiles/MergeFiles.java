package packageFiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;

public class MergeFiles {
    public static void main(String[] args)throws Exception {
        PrintWriter p=new PrintWriter("D:file3.txt");
        BufferedReader br=new BufferedReader(new FileReader("D:myfile.txt"));
        String line= br.readLine();
        // loop to copy each line of
        // file1.txt to  file3.txt
        while (line != null)
        {
            p.println(line);
            line = br.readLine();
        }

        br = new BufferedReader(new FileReader("D:myfile2.txt"));

        line = br.readLine();

        // loop to copy each line of
        // file2.txt to  file3.txt
        while(line != null)
        {
            p.println(line);
            line = br.readLine();
        }

        p.flush();

        // closing resources
        br.close();
        p.close();

        System.out.println("Merged file1.txt and file2.txt into file3.txt");
    }
}
