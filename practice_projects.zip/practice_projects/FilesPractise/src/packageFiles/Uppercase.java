package packageFiles;

import java.io.*;

//import static jdk.jfr.internal.SecuritySupport.newFileReader;

/*public class Uppercase {
    public static void main(String[] args) throws Exception {
        File file1 = new File("initial.txt");
        File file2 = new File("final.txt");
        char CharCounter = 0;
        BufferedReader in = (new BufferedReader(newFileReader(file1)));
        PrintWriter out = (new PrintWriter(new FileWriter(file2)));
        int ch;
        while ((ch = in.read()) != -1)
        {
            if (Character.isLowerCase(ch))
            {
                ch=Character.toUpperCase(ch);// convert assign variable
            }
            out.write(ch);
        }
        in.close();
        out.close();
    }
}*/
class m {

    public static void main(String[] args) throws Exception {


        try{
            FileReader file = new FileReader("D:myfile.txt");
            BufferedReader bufferedReader = new BufferedReader(file);
            StringBuilder existingData= new StringBuilder();
            String line="";

            while((line=bufferedReader.readLine()) !=null)
            {
                existingData.append(line.toUpperCase()).append("\n");
            }
            file.close();
            bufferedReader.close();
            FileWriter fileWriter = new FileWriter("D:myfile.txt");
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(existingData.toString());
            bufferedWriter.close();
            System.out.println(existingData);

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}