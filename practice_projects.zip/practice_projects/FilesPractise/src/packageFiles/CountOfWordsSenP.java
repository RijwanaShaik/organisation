package packageFiles;

import java.io.*;

public class CountOfWordsSenP {
    public static void main(String[] args) {

    }
}
class Test {
    public static void main(String[] args)
            throws IOException {
        File file = new File("D:myfile.txt");
        FileInputStream fileInputStream = new FileInputStream(file);
        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

        String line;
        int wordCount = 0;
        int characterCount = 0;
        int paraCount = 0;
        int whiteSpaceCount = 0;
        int sentenceCount = 0;

        while ((line = bufferedReader.readLine()) != null) {
            if (line.equals("")) {
                paraCount += 1;
            } else {
                characterCount += line.length();
                String words[] = line.split("\\s+");
                wordCount += words.length;
                whiteSpaceCount += wordCount - 1;
                String sentence[] = line.split("[!?.:]+");
                sentenceCount += sentence.length;
            }
        }
        if (sentenceCount >= 1) {
            paraCount++;
        }
        System.out.println("Total word count = " + wordCount);
        System.out.println("Total number of sentences = " + sentenceCount);
        System.out.println("Total number of characters = " + characterCount);
        System.out.println("Number of paragraphs = " + paraCount);
        System.out.println("Total number of whitespaces = " + whiteSpaceCount);
    }
}
class FileWordCount
{
    public static void main(String[] args) throws IOException
    {
        File f1=new File("D:myfile.txt"); //Creation of File Descriptor for input file
        String[] words=null;    //Intialize the word Array
        int wc=0;     //Intialize word count to zero
        FileReader fr = new FileReader(f1);    //Creation of File Reader object
        BufferedReader br = new BufferedReader(fr);    //Creation of BufferedReader object
        String s;
        while((s=br.readLine())!=null)    //Reading Content from the file
        {
            words=s.split(" ");   //Split the word using space
            wc=wc+words.length;   //increase the word count for each word
        }
        fr.close();
        System.out.println("Number of words in the file:" +wc);    //Print the word count
      //another method
        /*String line;
        int count = 0;

        //Opens a file in read mode
        FileReader file = new FileReader("data.txt ");
        BufferedReader br = new BufferedReader(file);

        //Gets each line till end of file is reached
        while((line = br.readLine()) != null) {
            //Splits each line into words
            String words[] = line.split("");
            //Counts each word
            count = count + words.length;

        }

        System.out.println("Number of words present in given file: " + count);
        br.close();*/
    }
}