package Relationships;

import java.util.Arrays;

public class Team {
    int tId;
    String tName;
Memeber[] memebers;

    public Team(int tId, String tName, Memeber[] memebers) {
        this.tId = tId;
        this.tName = tName;
        this.memebers = memebers;
    }

    @Override
    public String toString() {
        return "Team{" +
                "tId=" + tId +
                ", tName='" + tName + '\'' +
                ", memebers=" + Arrays.toString(memebers) +
                '}';
    }
}
