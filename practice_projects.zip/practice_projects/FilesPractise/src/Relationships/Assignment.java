package Relationships;

import java.util.Arrays;

public class Assignment {
int aId;
String aName;
String[] IncorrectFeedback;

    public Assignment(int aId, String aName, String[] incorrectFeedback) {
        this.aId = aId;
        this.aName = aName;
        IncorrectFeedback = incorrectFeedback;
    }

    @Override
    public String toString() {
        return "Assignment{" +
                "aId=" + aId +
                ", aName='" + aName + '\'' +
                ", IncorrectFeedback=" + Arrays.toString(IncorrectFeedback) +
                '}';
    }
}
