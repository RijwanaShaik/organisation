package packageExercises;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class CompareFile {
    public static void main(String[] args) {
        File file1 = new File("D:myfile.txt");
        File file2 = new File("D:myfile2.txt");
        if (file1.compareTo(file2) == 0) {
            System.out.println("Both the paths are lexicographically equal");
        } else {
            System.out.println("Both the paths are lexicographically not equal");
        }
    }
}
