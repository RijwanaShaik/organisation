package packageExercises;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ReadNthLine {
    public static void main( String args[] ) {
        int n = 0; // The line number
        try{
            String line = Files.readAllLines(Paths.get("D:file3.txt")).get(n);
            System.out.println(line);
        }
        catch(IOException e){
            System.out.println(e);
        }
        /*int n = 40; // The line number
        String line;
        try (BufferedReader br = new BufferedReader(new FileReader("file.txt"))) {
            for (int i = 0; i < n; i++)
                br.readLine();
            line = br.readLine();
            System.out.println(line);
        }
        catch(IOException e){
            System.out.println(e);
        }*/
    }
}
