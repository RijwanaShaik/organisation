package packageExercises;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadFirstThreeLines {
    public static void main(String [] args) throws IOException
    {
        // int counter=0;String str;
        String fileName = "D:file3.txt";

        String line = null;

        BufferedReader bufferedReader =
                new BufferedReader(new FileReader(fileName));

        int i = 0;
        try {
            //print first 2 lines or all if file has less than 2 lines
            while(((line = bufferedReader.readLine()) != null) && i < 2) {
                System.out.println(line);
                i++;
            }
        }
        finally {
            bufferedReader.close();
        }

    }
}
