package packageExercises;

import java.io.File;
import java.util.Date;

public class LastModfiedTimeOfAFile {
    public static void main(String[] args) {
        File f=new File("D:file3.txt");
        Date d=new Date(f.lastModified());
        System.out.println(d);
    }
}
