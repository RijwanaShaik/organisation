package packageExercises;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class SplitLinesInAFile {
    public static void main(String[] args) throws IOException {

        // Open this file.
        BufferedReader reader = new BufferedReader(new FileReader("D:file3.txt"));

        // Read lines from file.
        while (true) {
            String line = reader.readLine();
            if (line == null) {
                break;
            }
            // Split line on comma.
            String[] parts = line.split(",");
            for (String part : parts) {
                System.out.println(part);
            }
            System.out.println();
        }

        reader.close();
    }
}
