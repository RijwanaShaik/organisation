package packageExercises;

import java.io.File;

public class WhetherPathNameIsDirectorOrFile {
    public static void main(String[] args) {
        File my_file_dir = new File("D:myfile.txt");
        //is directory or not
        if (my_file_dir.isDirectory())
        {
            System.out.println(my_file_dir.getAbsolutePath() + " is a directory.\n");
        }
        else
        {
            System.out.println(my_file_dir.getAbsolutePath() + " is not a directory.\n");
        }
        //is file or not
        if (my_file_dir.isFile())
        {
            System.out.println(my_file_dir.getAbsolutePath() + " is a file.\n");
        }
        else
        {
            System.out.println(my_file_dir.getAbsolutePath() + " is not a file.\n");
        }
//can write or not
    if (my_file_dir.canWrite())
    {
        System.out.println(my_file_dir.getAbsolutePath() + " can write.\n");
    }
         else
    {
        System.out.println(my_file_dir.getAbsolutePath() + " cannot write.\n");
    }
         //can read or not
         if (my_file_dir.canRead())
    {
        System.out.println(my_file_dir.getAbsolutePath() + " can read.\n");
    }
         else
    {
        System.out.println(my_file_dir.getAbsolutePath() + " cannot read.\n");
    }
         //is file exists or not
 if (my_file_dir.exists())
    {
        System.out.println("The directory or file exists.\n");
    }
         else
    {
        System.out.println("The directory or file does not exist.\n");
    }
    }

}
