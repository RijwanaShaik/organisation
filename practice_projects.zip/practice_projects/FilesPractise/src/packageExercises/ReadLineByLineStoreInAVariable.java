package packageExercises;
//Write a java program to read a file line by line and store it into a variable
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadLineByLineStoreInAVariable {
    public static void main(String[] args) {
        try {
            BufferedReader in = new BufferedReader(new FileReader("D:myfile.txt"));
            String str=" ";
String str1=" ";
            while ((str=in.readLine()) != null) {
                if(str==null)
                    break;
                str1+=str;
                System.out.println(str1);
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}
