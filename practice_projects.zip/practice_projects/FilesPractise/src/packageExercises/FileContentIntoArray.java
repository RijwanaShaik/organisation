package packageExercises;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileContentIntoArray {
    public static void main(String[] args) throws IOException {
        // list that holds strings of a file
        List<String> listOfStrings
                = new ArrayList<String>();

        // load data from file
        BufferedReader bf = new BufferedReader(
                new FileReader("D:file3.txt"));

        // read entire line as string
        String line = bf.readLine();

        // checking for end of file
        while (line != null) {
            listOfStrings.add(line);
            line = bf.readLine();
        }

        // closing bufferreader object
        bf.close();

        // storing the data in arraylist to array
        String[] array
                = listOfStrings.toArray(new String[0]);

        // printing each line of file
        // which is stored in array
        for (String str : array) {
            System.out.println(str);
        }
    }
}
//using scanner -other method
/*
// arraylist to store strings
List<String> listOfStrings
        = new ArrayList<String>();

    // load content of file based on specific delimiter
    Scanner sc = new Scanner(new FileReader("file.txt"))
            .useDelimiter(",\\s*");
    String str;

// checking end of file
        while (sc.hasNext()) {
                str = sc.next();

                // adding each string to arraylist
                listOfStrings.add(str);
                }

                // convert any arraylist to array
                String[] array
                = listOfStrings.toArray(new String[0]);

                // print each string in array
                for (String eachString : array) {
                System.out.println(eachString);
                }*/


    //readAllLines method
/*
List<String> listOfStrings
        = new ArrayList<String>();

// load the data from file
        listOfStrings
                = Files.readAllLines(Paths.get("file.txt"));

                // convert arraylist to array
                String[] array
                = listOfStrings.toArray(new String[0]);

                // print each line of string in array
                for (String eachString : array) {
                System.out.println(eachString);
                }*/


//using filereader

    /*// list that holds strings of a file
    List<String> listOfStrings
            = new ArrayList<String>();

    // load data from file
    FileReader fr = new FileReader("file.txt");

    // Created a string to store each character
    // to form word
    String s = new String();
    char ch;

// checking for EOF
        while (fr.ready()) {
                ch = (char)fr.read();

                // Used to specify the delimiters
                if (ch == '\n' || ch == ' ' || ch == ',') {

                // Storing each string in arraylist
                listOfStrings.add(s.toString());

                // clearing content in string
                s = new String();
                }
                else {
                // appending each character to string if the
                // current character is not delimiter
                s += ch;
                }
                }
                if (s.length() > 0) {

                // appending last line of strings to list
                listOfStrings.add(s.toString());
                }
                // storing the data in arraylist to array
                String[] array
                = listOfStrings.toArray(new String[0]);

                // printing each line of file which is stored in
                // array
                for (String str : array) {
                System.out.println(str);
                }*/