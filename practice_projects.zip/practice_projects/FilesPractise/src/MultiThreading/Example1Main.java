package MultiThreading;

public class Example1Main {
    public static void main(String[] args) {
        int n = 6; 	// Number of threads
        for (int i = 0; i < n; i++) {
            Thread obj
                    = new Thread(new Example1());
            obj.start();
        }
    }
}
