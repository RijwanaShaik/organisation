package MultiThreading;

public class Example2 implements Runnable{
    private Thread t;
    private String threadName;

    Example2( String name) {
        threadName = name;
        System.out.println("Created " +  threadName );
    }

    @Override
    public void run() {
        System.out.println("Currently Running " +  threadName );
        try {
            for(int i = 4; i > 0; i--) {
                System.out.println("Thread is: " + threadName + ", " + i);
                // Let the thread sleep for a while.
                Thread.sleep(50);
            }
        } catch (InterruptedException e) {
            System.out.println("Thread is " +  threadName + " interrupted.");
        }
        System.out.println("Thread is " +  threadName + " exiting!!!");
    }
    public void start () {
        System.out.println("Starting now " +  threadName );
        if (t == null) {
            t = new Thread (this, threadName);
            t.start ();
        }
    }
}
