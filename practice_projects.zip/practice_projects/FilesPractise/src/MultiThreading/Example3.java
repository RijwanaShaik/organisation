package MultiThreading;

public class Example3 {
}
class AnimalRunnable implements Runnable{


    @Override
    public void run() {
for (int x=1;x<4;x++){
    System.out.println("Run by "+Thread.currentThread().getName());
    try{
        Thread.sleep(1000);
    }catch (InterruptedException ex){
        ex.printStackTrace();
    }
}
        System.out.println("Thread state of: "+Thread.currentThread().getName()+" - "+Thread.currentThread().getState());
        System.out.println("Exit of thread: "+Thread.currentThread().getName());
    }
}
class AnimalMultiThreadDemo{
    public static void main(String[] args) throws Exception {
        AnimalRunnable anr=new AnimalRunnable();
        Thread cat=new Thread(anr);
        cat.setName("Cat");
        Thread dog=new Thread(anr);
        dog.setName("Dog");
        Thread cow=new Thread(anr);
        cow.setName("Cow");
        System.out.println("Thread state of cat before calling start: "+cat.getState());
        cat.start();
        dog.start();
        cow.start();
        System.out.println("Thread state of cat in main method before sleep: "+cat.getState());
        System.out.println("Thread state of dog in main method before sleep: "+dog.getState());
        System.out.println("Thread state of cow in main method before sleep: "+cow.getState());
Thread.sleep(1000);
        System.out.println("Thread state of cat in main method after sleep: "+cat.getState());
        System.out.println("Thread state of dog in main method after sleep: "+dog.getState());
        System.out.println("Thread state of cow in main method after sleep: "+cow.getState());


    }
}