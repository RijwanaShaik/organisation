package MultiThreading;

public class Example2Main {
    public static void main(String[] args) {
        Example2 obj1=new Example2("Thread1");
        obj1.start();
        Example2 obj2=new Example2("Thread2");
        obj2.start();
    }
}
