package CustomExceptionsDemo;

import java.util.Scanner;

public class VoterList {
    public static void main(String[] args) {
        int age=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter age: ");
        age=sc.nextInt();
                try {
                    RegisterClass.checkAge(age);
                    System.out.println("you are registering in the voterList");
                    System.out.println("Registration completed");
                }catch (NotEligilbleException e){
                    e.printStackTrace();
                 //   System.out.println(e.getMessage());
                }
    }
}
