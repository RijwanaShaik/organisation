package CustomExceptionsDemo;

public class Promotion {
    private static void checkEligibility(int experience,int age)throws CheckEligibilityPromotion{
        if(experience<12 && age<50){
            throw new CheckEligibilityPromotion("Employee is not eligible for promotion");
        }else {
            System.out.println("Eligible to promotion");
        }
    }

    public static void main(String[] args) {
        Promotion obj = new Promotion();
        try {
            obj.checkEligibility(10, 45);

        } catch (CheckEligibilityPromotion e) {
            System.out.println(e.getMessage());
            System.out.println(e.getCause());
            System.out.println(e.getStackTrace());
            System.out.println(e.fillInStackTrace());
            System.out.println(e.getSuppressed());
            System.out.println(e.getLocalizedMessage());
        }
    }
}
