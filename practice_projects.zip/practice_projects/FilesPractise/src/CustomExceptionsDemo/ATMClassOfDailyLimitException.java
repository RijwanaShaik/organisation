package CustomExceptionsDemo;

import java.util.Scanner;

public class ATMClassOfDailyLimitException {
    public static void main(String[] args) throws DailyLimitException {
        System.out.println("Please Enter withdraw money");
        Scanner sc=new Scanner(System.in);
        int amount=sc.nextInt();
       // try {
            if (amount > 10000) {
                throw new DailyLimitException("You are trying to withdraw more than the daily limit,please check before you withdraw...");
            } else {
                System.out.println("you withdrawn your money successfully....Enjoy the day...!!");
            }
      //  }catch (DailyLimitException e){
        //    System.out.println(e);
       // }
    }
}
