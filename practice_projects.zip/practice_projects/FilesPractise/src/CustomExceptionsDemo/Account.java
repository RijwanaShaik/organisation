package CustomExceptionsDemo;

import java.util.Scanner;

public class Account {
    static  double current_balance=1000;

    public static void main(String[] args) throws MinimumAccountBalance {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter amount to withdrawal");
        int n=sc.nextInt();
        try {
            if(current_balance<n){
                throw new MinimumAccountBalance("Insufficient balance! your current balance is: "+current_balance);
            }
            else {
                double balance= current_balance-n;
                System.out.println("please take the money: "+n+"\n"+" Now your current balance is "+balance);
            }
        }catch (MinimumAccountBalance mab){
            //mab.printStackTrace();
            System.out.println(mab);
        }
    }
}
//case-I:
   /* Enter amount to withdrawal
2000
        Insufficient balance! your current balance is: 1000.0
        at CustomExceptionsDemo.Account.main(Account.java:14)*/
//case-II:
   /*Enter amount to withdrawal
800
        please take the money: 800
        Now your current balance is 200.0
*/