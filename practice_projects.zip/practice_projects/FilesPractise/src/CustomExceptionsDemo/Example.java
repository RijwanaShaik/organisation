package CustomExceptionsDemo;

public class Example {
}
class MyCustomException extends RuntimeException {

    public MyCustomException(String message) {
        super(message);
    }
}
class Test {

    public static void main(String[] args) {
        Test test = new Test();
        try {
            test.reserveSeats(8);
        } catch (MyCustomException e) {
            System.out.println("Exception occurred with message: " + e.getMessage());
        }
    }

    private void reserveSeats(int numberOfSeats) {
        if (numberOfSeats > 5) {
            throw new IllegalArgumentException("No more than 5 seats can be reserved.");
        } else {
            System.out.println("Reservation successful!");
        }
    }
}