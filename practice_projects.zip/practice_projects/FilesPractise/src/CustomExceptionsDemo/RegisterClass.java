package CustomExceptionsDemo;

public class RegisterClass {
    public static void checkAge(int age) throws NotEligilbleException{
        if(age<=18){
            throw new NotEligilbleException("your current age is not eligible for voting");
        }
    }
}
