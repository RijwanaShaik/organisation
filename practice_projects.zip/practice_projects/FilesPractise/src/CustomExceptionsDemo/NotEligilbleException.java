package CustomExceptionsDemo;

public class NotEligilbleException extends Exception{
    public NotEligilbleException(){
        super();
    }
    public NotEligilbleException(String msg){
        super(msg);
    }
}
