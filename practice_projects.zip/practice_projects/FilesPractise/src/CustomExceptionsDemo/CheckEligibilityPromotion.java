package CustomExceptionsDemo;

public class CheckEligibilityPromotion extends Exception{
    CheckEligibilityPromotion(){
        super();
    }
    CheckEligibilityPromotion(String msg){
        super(msg);
    }

}
