package CustomExceptionsDemo;

public class EmployeeException extends Exception {
    public EmployeeException(String str)
    {
        super(str);
    }
}
