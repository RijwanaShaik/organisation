package CustomExceptionsDemo;

public class DailyLimitException extends Exception{
    DailyLimitException(String str){
        super(str);
    }

}
