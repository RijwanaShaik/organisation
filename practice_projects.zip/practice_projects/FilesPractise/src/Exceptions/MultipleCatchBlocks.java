package Exceptions;

public class MultipleCatchBlocks {
    public int[] arr = new int[10];

    public void writeList() {

        try {
            arr[10] = 11;
        }

        catch (NumberFormatException e1) {
            System.out.println("NumberFormatException => " + e1.getMessage());
        }

        catch (IndexOutOfBoundsException e2) {
            System.out.println("IndexOutOfBoundsException => " + e2.getMessage());
        }

    }

    public static void main(String[] args) {
        MultipleCatchBlocks list = new MultipleCatchBlocks();
        list.writeList();
    }
}
class MultiCatch{
    public static void main(String[] args) {
        try{
            int  a[]=new int[2];
            a[6] =15/0;
        }catch (ArithmeticException e){
            System.out.println("Arithmetic Exception Handled");
        }catch (ArrayIndexOutOfBoundsException e1){
            System.out.println("Array index out of bound!");
        }
    }
}