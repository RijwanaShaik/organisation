package Exceptions;

import java.util.Scanner;

public class ThrowExample {
     void validate(int number){
        if(number <=0){
            throw  new ArithmeticException("Invalid Input");
        }else {
            System.out.println("Division is possible");
        }
    }
    public static void main(String[] args) {
        ThrowExample ob=new ThrowExample();
        ob.validate(0);
        System.out.println("Execution is possible for remaining code");
    }
}
class Main {
    static void checkAge(int age) {
        if (age < 18) {
            throw new ArithmeticException("Access denied - You must be at least 18 years old.");

        } else {
            System.out.println("Access granted - You are old enough!");
        }
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the age");
        int b=sc.nextInt();

        checkAge(b);
    }
}