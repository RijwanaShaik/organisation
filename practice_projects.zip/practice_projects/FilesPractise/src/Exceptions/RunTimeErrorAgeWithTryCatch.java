package Exceptions;

import java.util.Scanner;

public class RunTimeErrorAgeWithTryCatch {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter your age ");
        int age=in.nextInt();
        if(age>18) {
            System.out.println("you are authorized to view the page");
        }
        else {
            System.out.println("you are not authorized to view page");
        }
    }
}
