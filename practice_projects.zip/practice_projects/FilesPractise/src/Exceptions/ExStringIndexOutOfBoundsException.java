package Exceptions;

public class ExStringIndexOutOfBoundsException {
    public static void main(String[] args) {
        try{
            String str="begginersbook";
            System.out.println(str.length());
            char c=str.charAt(40);
            System.out.println(c);
        }catch (StringIndexOutOfBoundsException e){
            System.out.println("String index out of bounds exception.");
        }
    }
}
class Main4 {
    public static void main(String[] args) {
        String string = "Java Programming Language ";
        try {
            String str1 = string.substring(0, 13);
            System.out.println("str1 : " + str1);
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println(e.toString());
        }
        try {
            String str2 = string.substring(14, 36);
            System.out.println("str2 : " + str2);
            System.out.println(str2);
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println(e.toString());
        }
    }
}
/*
class strex{
    public static void main(String[] args) {
        try{
            String st="java";
            //char a=st.charAt(10);
         //   System.out.println(a);
            System.out.println(st.substring(0,10));
        }catch (StringIndexOutOfBoundsException str){
            System.out.println(str);
        }
    }
}*/
