package Exceptions;

public class TryCatchFinallyArthematic {
    public static void main(String[] args) {
        try {
            // code that generates exception
            int divideByZero = 5 / 0;
            System.out.println(divideByZero);
        }

        catch (ArithmeticException e) {
            System.out.println("ArithmeticException => " + e.getMessage());
        }

        finally {
            try{
                String str=null;
int val= Integer.parseInt(str);
                System.out.println(val);
            }catch (NumberFormatException nfe){
                System.out.println(nfe);
            }
            System.out.println("This is the finally block");
        }
    }
}
