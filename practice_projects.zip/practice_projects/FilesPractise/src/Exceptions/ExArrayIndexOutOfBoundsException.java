package Exceptions;

public class ExArrayIndexOutOfBoundsException {
    public static void main(String[] args) {
        try{
            int a[]=new int[10];
            a[11]=9;
        }catch (ArrayIndexOutOfBoundsException e){
            System.out.println("ArrayIndexoutof bounds exception occured");
            System.out.println("System Message"+e);
        }
    }
}
