package Exceptions;

public class ExceptionArthematic {
    public static void main(String[] args) {
        int x,y,z;
        try{
            x=5;
            y=0;
            z=x/y;
            System.out.println(z);
            System.out.println("The output for z cannot be executed.");
        }catch (ArithmeticException e){
            System.out.println("Expression throws divide by 0 exceptions");
        }
    }
}
/*
class Arex{
    public static void main(String[] args) {
        try{
            System.out.println(2/0);
        }catch (ArithmeticException ae){
            System.out.println(ae);
        }
    }
}*/
