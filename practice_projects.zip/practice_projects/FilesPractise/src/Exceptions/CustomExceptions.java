package Exceptions;

public class CustomExceptions {
    public static void main(String[] args) {

    }
}
class MyNewException extends Exception{
    String s1;
    MyNewException(String s2){
        s1=s2;
    }
    public String toString(){
        return ("MyNewException defines: "+s1);
    }

    public static void main(String[] args) {
        try {
            throw new MyNewException("E-R-R-O-R");
        }
        catch (MyNewException e1){
            System.out.println(e1);
        }
    }
}