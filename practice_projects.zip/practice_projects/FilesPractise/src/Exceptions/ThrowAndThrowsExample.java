package Exceptions;

import java.io.IOException;

public class ThrowAndThrowsExample {
    public static void main(String[] args) {

    }
}
class Demo{
    void myMethod()throws IOException {
        //throw exception using throw keyword
        throw new IOException("IO Exception occurred");
    }
}
class JavaExample{
    //declared IOException using throws keyword
    public static void main(String args[])throws IOException{
        Demo obj = new Demo();
        obj.myMethod();

        System.out.println("Rest of the program");
    }
}