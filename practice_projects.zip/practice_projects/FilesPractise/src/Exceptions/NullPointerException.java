package Exceptions;

public class NullPointerException {
    public static void main(String[] args) {
        try {
            String str=null;
            System.out.println(str.length());
        }catch (java.lang.NullPointerException e){
            System.out.println("NullPointerException..");
        }
    }
}
/*
class Nullex{
    public static void main(String[] args) {
        try{
            String st=null;
            System.out.println(st.length());
        }catch (NullPointerException ne){
            System.out.println(ne);
        }
    }
        }*/
