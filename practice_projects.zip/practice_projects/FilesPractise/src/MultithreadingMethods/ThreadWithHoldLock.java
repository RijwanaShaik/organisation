package MultithreadingMethods;

public class ThreadWithHoldLock implements Runnable {
    @Override
    public void run() {
        System.out.println("Currently executing thread is: "+Thread.currentThread().getName());
        System.out.println("Does thread hols lock? "+Thread.holdsLock(this));
        synchronized (this){
            System.out.println("does thread holds lock? "+Thread.holdsLock(this));
        }
    }

    public static void main(String[] args) {
        ThreadWithHoldLock t=new ThreadWithHoldLock();
        Thread t1=new Thread(t);
        t1.start();
    }
}
