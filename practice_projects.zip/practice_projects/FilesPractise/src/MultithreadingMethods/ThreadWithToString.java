package MultithreadingMethods;

public class ThreadWithToString implements Runnable{
    Thread t;
    ThreadWithToString()
    {
        t = new Thread(this);
        // this will call run() function
        t.start();
    }
    public void run()
    {
        // returns a string representation of this thread
        System.out.println(t.toString());
    }
    public static void main(String[] args)
    {
        new ThreadWithToString();
    }
}
