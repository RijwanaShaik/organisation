package MultithreadingMethods;

public class ThreadWithCheckAccess extends Thread{
    public void run(){
        System.out.println(Thread.currentThread().getName());
    }

    public static void main(String[] args) {
        ThreadWithCheckAccess t1=new ThreadWithCheckAccess();
        ThreadWithCheckAccess t2=new ThreadWithCheckAccess();
        t1.start();
        t2.start();
        t1.checkAccess();
        System.out.println(t1.getName()+" has access");
        t2.checkAccess();
        System.out.println(t2.getName()+" has access");
    }
}
