package MultithreadingMethods;

public class ThreadWithGetPriority extends Thread{
    public void run(){
        System.out.println("running thread name is: "+Thread.currentThread().getName());
    }

    public static void main(String[] args) {
        ThreadWithGetPriority t1=new ThreadWithGetPriority();
        ThreadWithGetPriority t2=new ThreadWithGetPriority();
        System.out.println("t1 thread priority: "+t1.getPriority());
        System.out.println("t2 thread priority: "+t2.getPriority());
t1.start();
t2.start();
    }
}
