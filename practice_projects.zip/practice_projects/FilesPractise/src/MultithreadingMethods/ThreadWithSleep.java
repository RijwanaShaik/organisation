package MultithreadingMethods;

public class ThreadWithSleep  extends Thread{
    public void run(){
        for (int i=1;i<5;i++){
            try {
                Thread.sleep(500);//try with -500
            }catch (InterruptedException e){
                System.out.println(e);
            }
            System.out.println(i);
        }
    }

    public static void main(String[] args) {
        ThreadWithSleep t1=new ThreadWithSleep();
        ThreadWithSleep t2=new ThreadWithSleep();
        t1.start();
        t2.start();
    }
}
