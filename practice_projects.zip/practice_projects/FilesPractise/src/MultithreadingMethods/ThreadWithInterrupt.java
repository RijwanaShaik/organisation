package MultithreadingMethods;
//In this program, after interrupting the thread, we throw a new exception so it will stop working.
public class ThreadWithInterrupt extends Thread{
    public void run(){
        try {
            Thread.sleep(1000);
            System.out.println("Javatpoint");
            }catch (InterruptedException ie){
            throw new RuntimeException("Thread interrupted..."+ie);
        }
    }

    public static void main(String[] args) {
        ThreadWithInterrupt t=new ThreadWithInterrupt();
        t.start();
        try {
            t.interrupt();
            }catch (Exception e){
            System.out.println("Exception handled "+e);
        }
    }
}
//In this example, after interrupting the thread, we handle the exception, so it will break out from the sleeping state but will not stop working.
class ThreadWithInterrupt2 extends Thread{
    public void run(){
        try {
            Thread.sleep(1000);
            System.out.println("Javatpoint");
        }catch (InterruptedException ie){
            System.out.println("Exception handled "+ie);
        }
        System.out.println("thread is running...");
    }

    public static void main(String[] args) {
        ThreadWithInterrupt2 t=new ThreadWithInterrupt2();
        ThreadWithInterrupt2 t2=new ThreadWithInterrupt2();

        t.start();
            t.interrupt();

    }
}