package MultithreadingMethods;

public class ThreadWithNotifyAll {
}
class Notify4 extends Thread
{
    public void run()
    {
        synchronized(this)
        {
            System.out.println("Starting of " + Thread.currentThread().getName());
            try {
                this.wait();
            }
            catch (InterruptedException e) {
                e.printStackTrace();}
            System.out.println(Thread.currentThread().getName() + "...notified");
        }
    }
}
class Notify5 extends Thread {
    Notify4 notify4;
    Notify5(Notify4 notify4)
    {
        this.notify4 = notify4;
    }
    public void run()
    {
        synchronized(this.notify4)
        {
            System.out.println("Starting of " + Thread.currentThread().getName());
            try {
                this.notify4.wait();
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName() + "...notified");
        }
    }
}
class Notify6 extends Thread
{
    Notify4 notify4;
    Notify6(Notify4 notify4)
    {
        this.notify4 = notify4;
    }
    public void run()
    {
        synchronized(this.notify4)
        {
            System.out.println("Starting of " + Thread.currentThread().getName());
            // call the notifyAll() method
            this.notify4.notifyAll();
            System.out.println(Thread.currentThread().getName() + "...notified");
        }
    }
}
class JavaNotifyAllExp
{
    public static void main(String[] args) throws InterruptedException
    {
        Notify4 notify4 = new Notify4();
        Notify5 notify5 = new Notify5(notify4);
        Notify6 notify6 = new Notify6(notify4);

        // creating the threads
        Thread t1 = new Thread(notify4, "Thread-1");
        Thread t2 = new Thread(notify5, "Thread-2");
        Thread t3 = new Thread(notify6, "Thread-3");

        // call run() method
        t1.start();
        t2.start();
        Thread.sleep(100);
        t3.start();
    }
}