package MultithreadingMethods;

public class practise {
}
class TotalEarnings extends Thread{
    int total=0;
    public void run(){
        synchronized (this){

            for(int i=1;i<=10;i++) {
                total = total + 100;
            }
            this.notify();

        }
    }
}
class Moviebookapp{
    public static void main(String[] args) throws InterruptedException {
            TotalEarnings t = new TotalEarnings();
            t.start();

      synchronized (t) {
          System.out.println("Main thread going to wait until other thread wake ups it");
          t.wait();

          System.out.println("Main thread got notified");
          System.out.println(t.total);

        }
        //System.out.println(t.total);

    }
}
class ext implements Runnable{
    public void run(){
        System.out.println(Thread.currentThread());
    }
}
class extMain{
    public static void main(String[] args) {
        for(int i=0;i<=5;i++){
           // ext obj=new ext();
            Thread t=new Thread(new ext());
        t.start();}
    }
}