package MultithreadingMethods;

public class ThreadWithGetState implements Runnable{
    @Override
    public void run() {
        Thread.State state=Thread.currentThread().getState();
        System.out.println("Running thread name: "+Thread.currentThread().getName());
        System.out.println("State of thread: "+ state);
    }

    public static void main(String[] args) {
        ThreadWithGetState t=new ThreadWithGetState();
        Thread t1=new Thread(t);
        Thread t2=new Thread(t);
        t1.start();
        t2.start();
    }
}
