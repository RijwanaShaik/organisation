package MultithreadingMethods;

public class ThreadWithDaemon extends Thread{
    public void run(){
        if(Thread.currentThread().isDaemon()){
            System.out.println("Daemon thread work");
        }
        else {
            System.out.println("user thread work");
        }
    }

    public static void main(String[] args) {
        ThreadWithDaemon t1=new ThreadWithDaemon();
        ThreadWithDaemon t2=new ThreadWithDaemon();
        ThreadWithDaemon t3=new ThreadWithDaemon();
//setDaemon must be invoked before the start method
        t1.setDaemon(true);
        t1.start();
        t2.setDaemon(true);
        t2.start();
        t3.start();
    }
}
