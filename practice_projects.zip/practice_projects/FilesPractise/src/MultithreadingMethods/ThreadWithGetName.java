package MultithreadingMethods;

public class ThreadWithGetName extends Thread{
    public void run(){
        System.out.println("thread is running");
    }

    public static void main(String[] args) {
        ThreadWithGetName t1=new ThreadWithGetName();
        System.out.println("Name of t1: "+t1.getName());
        t1.start();
    }
}
