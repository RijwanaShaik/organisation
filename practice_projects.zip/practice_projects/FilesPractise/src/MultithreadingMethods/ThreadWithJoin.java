package MultithreadingMethods;

public class ThreadWithJoin extends Thread{
    public void run(){
        for(int i=1;i<=4;i++){
            try {
                Thread.sleep(500);
            }catch (Exception e){
                System.out.println(e);
            }
            System.out.println(i);
        }
    }

    public static void main(String[] args) {
        //creating three threads
        ThreadWithJoin t1=new ThreadWithJoin();
        ThreadWithJoin t2=new ThreadWithJoin();
        ThreadWithJoin t3=new ThreadWithJoin();
        //thread t1 starts
        t1.start();
        //starts second thread when first thrsead t1 is died.
        try{
            t1.join();
        }catch (Exception e){
            System.out.println(e);
        }
        //start t2 and t3 thread
        t2.start();
        t3.start();
    }
}
//in the above example 1,when t1 completes its task then t2 and t3 starts execution.
//In the below example 2, when t1 is completes its task for 1500 miliseconds(3 times) then t2 and t3 starts executing.
class ThreadWithJoin2 extends Thread {
    public void run() {
        for (int i = 1; i <= 4; i++) {
            try {
                Thread.sleep(500);
            } catch (Exception e) {
                System.out.println(e);
            }
            System.out.println(i);
        }
    }

    public static void main(String[] args) {
        //creating three threads
        ThreadWithJoin t1 = new ThreadWithJoin();
        ThreadWithJoin t2 = new ThreadWithJoin();
        ThreadWithJoin t3 = new ThreadWithJoin();
        //thread t1 starts
        t1.start();
        //starts second thread when first thread t1 is died.
        try {
            t1.join(1500);
        } catch (Exception e) {
            System.out.println(e);
        }
        //start t2 and t3 thread
        t2.start();
        t3.start();
    }
}