package MultithreadingMethods;

public class ThreadWithStart extends Thread{
    public void run(){
        System.out.println("Thread is running....");
    }

    public static void main(String[] args) {
        ThreadWithStart thread1=new ThreadWithStart();
       thread1.start();
        //thread1.run();//when class extends with thread class the run method call with start() method instead of its actuall name
    }
}
