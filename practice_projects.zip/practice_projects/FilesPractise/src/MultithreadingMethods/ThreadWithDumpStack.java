package MultithreadingMethods;

public class ThreadWithDumpStack {
    public static void main(String[] args) {
        Thread t=Thread.currentThread();
        t.setName("My thread dumpstack");
        t.setPriority(6);
        System.out.println("Current thread: "+t);
        int count=Thread.activeCount();
        System.out.println("currently active threads: "+count);
        Thread.dumpStack();
    }
}
