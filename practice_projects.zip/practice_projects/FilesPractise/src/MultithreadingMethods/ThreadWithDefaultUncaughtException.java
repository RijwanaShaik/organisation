package MultithreadingMethods;

public class ThreadWithDefaultUncaughtException implements Runnable {
    public void run()
    {
        // prints thread name
        System.out.println("Currently running thread is: " + Thread.currentThread().getName());
    }
    public static void main(String[] args)
    {
        ThreadWithDefaultUncaughtException g1 = new ThreadWithDefaultUncaughtException();
        Thread t1 = new Thread(g1);
        Thread t2 = new Thread(g1);
        // this will call run() function
        t1.start();
        t2.start();

        // returns the default handler
        Thread.UncaughtExceptionHandler handler = Thread
                .getDefaultUncaughtExceptionHandler();
        System.out.println(handler);
    }
}
//setdefaultexception
class JavaSetDefaultExceptioneExp implements Runnable {
    public void run() {
        throw new RuntimeException();
    }

    public static void main(String[] args) {
        Thread thread = new Thread(new JavaSetDefaultExceptioneExp());
        thread.setDefaultUncaughtExceptionHandler(new Thread.
                UncaughtExceptionHandler() {
            public void uncaughtException(Thread thread, Throwable e) {
                System.out.println("Exception caught: " + e);
            }
        });
        // call run() function
        thread.start();
    }
}