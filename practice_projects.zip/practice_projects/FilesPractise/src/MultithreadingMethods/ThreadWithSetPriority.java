package MultithreadingMethods;

public class ThreadWithSetPriority extends Thread{
    public void run(){
        System.out.println("running thread name is: "+Thread.currentThread().getName());
        //we can write thread.currenthread().getpriority()
    }

    public static void main(String[] args) {
        ThreadWithGetPriority t1=new ThreadWithGetPriority();
        ThreadWithGetPriority t2=new ThreadWithGetPriority();
        ThreadWithGetPriority t3=new ThreadWithGetPriority();


        t1.setPriority(Thread.MAX_PRIORITY);
       // t1.setPriority(4);//we can set values in the range of 1 to 10.this is called user defined priority
        //priority greater than 10 gives exception
        t2.setPriority(Thread.NORM_PRIORITY);
        t3.setPriority(Thread.MIN_PRIORITY);
        t1.start();
        t2.start();
        t3.start();
      //  System.out.println(t1.getPriority());
        System.out.println("t1 thread max priority: "+t1.getPriority());
         System.out.println("t2 thread norm priority: "+t2.getPriority());
        System.out.println("t3 thread min priority: "+t3.getPriority());

    }
}
class ExP implements Runnable{
    public void run(){
        System.out.println(Thread.currentThread());
    }

    public static void main(String[] args) {
        ExP t=new ExP();
        Thread t1=new Thread(t,"Thread 1");
        Thread t2=new Thread(t,"Thread 2");
        Thread t3=new Thread(t,"Thread 3");
        t1.setPriority(3);
        t2.setPriority(8);
        t3.setPriority(6);
        t1.start();
        t2.start();
        t3.start();
    }
}
class test extends Thread{
    public static void main(String[] args) {
        test t=new test();
        t.start();
    }
}
class test2 extends Thread{
    public void run(){
        System.out.println("overriding the method");
    }

    public static void main(String[] args) {
        test2 t=new test2();
        t.start();
    }
}