package MultithreadingMethods;

public class ThreadWithContextClassLoader implements Runnable {
    public void run()
    {
        System.out.println("Thread is running");
        // returns the context ClassLoader for currently running thread
        ClassLoader loader = Thread.currentThread().getContextClassLoader();

        // sets the context ClassLoader for currently running thread
        Thread.currentThread().setContextClassLoader(loader);
        System.out.println("Context ClassLoader = " + loader);
    }
    public static void main(String args[])
    {
        ThreadWithContextClassLoader g1 = new ThreadWithContextClassLoader();
        Thread t1 = new Thread(g1);
        // call run() method
        t1.start();
    }
}
//getClassLoader
class JavaGetClassLoaderExp implements Runnable {
    public void run() {
        System.out.println("Thread is running");
    }

    public static void main(String args[]) {
        JavaGetClassLoaderExp g1 = new JavaGetClassLoaderExp();
        Thread t1 = new Thread(g1);
        // call run() method
        t1.start();

        // returns the context ClassLoader for thread t1
        ClassLoader loader = t1.getContextClassLoader();
        // sets the context ClassLoader for thread t1
        t1.setContextClassLoader(loader);
        System.out.println("Context ClassLoader = " + loader);
        System.out.println("Parent = " + loader.getParent());
        System.out.println("Class = " + loader.getClass());
    }
}