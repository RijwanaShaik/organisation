package MultithreadingMethods;

public class ThreadWithRun implements Runnable{
    @Override
    public void run() {
        System.out.println("Thread is running....");
    }

    public static void main(String[] args) {
        ThreadWithRun r1=new ThreadWithRun();
        Thread thread1=new Thread(r1);//the class extend with runnable interface,so thread constructor is passed with runnable object
        thread1.start();
    }
}
