package MultithreadingMethods;

public class ThreadWithSetName extends Thread{
    public void run(){
        System.out.println("running...");
    }
    public static void main(String[] args) {
        ThreadWithSetName t1=new ThreadWithSetName();
        ThreadWithSetName t2=new ThreadWithSetName();
        t1.start();
        t2.start();
        t1.setName("Setting name to thread");
        t2.setName("javatpoint");
        System.out.println("After changin name of t1: "+t1.getName());
        System.out.println("After changin name of t2: "+t2.getName());
    }
}
