package MultithreadingMethods;

public class ThreadWithCurrent extends Thread{
    public void run(){
        System.out.println(Thread.currentThread().getName());
        System.out.println(Thread.currentThread().getId());
    }

    public static void main(String[] args) {
        ThreadWithCurrent t1=new ThreadWithCurrent();
ThreadWithCurrent t2=new ThreadWithCurrent();
t1.start();
t2.start();
    }
}
