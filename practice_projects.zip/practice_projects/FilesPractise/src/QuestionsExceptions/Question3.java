package QuestionsExceptions;
//A program accepts two integers as command line arguments. It displays all prime
//numbers between these two. Using assertions, validate the input for the following
//criteria: Both should be positive integers. The second should be larger than the first.
public class Question3 {
}
class primeint
{
    public static void main(String args[])
    {
        int num;
        int flag=0;
        int a=Integer.parseInt(args[0]);
        int b=Integer.parseInt(args[1]);
        assert((a>0 && b>0) && (b>a)) : "INVALID INPUT";
        num=a;
        System.out.println("Prime no's between "+a+" & "+b+" are :");

        while(num<=b)
        {
            flag=1;
            int temp,j;
            temp=num/2;
            for(j=2;j<=temp;j++)//num<b;)
                if((num%j)==0)
                    flag=0;
            if(flag==1)
            {
                System.out.println(num);
            }
            num++;
        }
    }
}