package QuestionsExceptions;

import java.util.Scanner;

//Define class MyDate with members day, month, year. Define default and parameterized constructors. Accept values from the command line and create a dateobject. Throw user defined exceptions – “InvalidDayException” or“InvalidMonthException” if the day and month are invalid. If the date is valid,display message “Valid date”.
public class Question2 {
}

/*class MyDate
{

    int day,month,year;

    MyDate()
    {

        System.out.println("\nNo Date Initialised...");

    }

    MyDate(int d,int m,int y)
    {

        day=d;
        month=m;
        year=y;

    }

    boolean checkmonth()
    {

        if(month<1 || month >12)
            return false;

        else
            return true;

    }

    boolean checkday()
    {

        boolean state;

        if(day<1 || day>31 )
            state=false;

        else
        {

            switch (month)
            {

                case 1:

                case 3:

                case 5:

                case 7:

                case 8:

                case 10:

                case 12:
                    if(day > 31)
                    {

                        state= false;

                    }

                    else
                        state= true;break;

                case 4:

                case 6:

                case 9:

                case 11:
                    if(day > 30)
                    {

                        state= false;

                    }

                    else
                        state= true;break;

                case 2:
                    if(year % 4 != 0 && day > 28)
                    {

                        state= false;

                    }

                    else
                        return true;

                    if(day > 29)
                    {

                        state= false;

                    }

                default:
                    state= false;

            }

        }

        return state;
    }

}

class InvalidDayException extends Exception
{

    public InvalidDayException(String s)
    {

        super(s);

    }

}

class InvalidMonthException extends Exception
{

    public InvalidMonthException(String s)
    {

        super(s);

    }

}

class ass4b1
{

    public static void main(String args[])
    {
MyDate obj=new MyDate(33,10,2000);
       // obj.day
        int d1,m1,y1;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the date,month,year");
        d1=sc.nextInt();
        m1=sc.nextInt();
        y1=sc.nextInt();
        System.out.println();
       *//* if(args.length != 3)
        {

            System.out.println("\nUse command line argument as:");
            System.out.println("dd mm yyyy\n");

        }

        else
        {

            d1=Integer.parseInt(args[0]);

            y1=Integer.parseInt(args[2]);

            m1=Integer.parseInt(args[1]);

            MyDate a =new MyDate(d1,m1,y1);
*//*
            try
            {

                if(! obj.checkmonth())
                    throw new InvalidMonthException("Month is  Invalid");

                if(! obj.checkday())
                    throw new InvalidDayException("Day is  Invalid");

                System.out.println("\n Valid Date;");

            }

            catch(InvalidMonthException e)
            {

                System.out.println(e);

            }

            catch(InvalidDayException e)
            {

                System.out.println(e);

            }

        //}

    }

}*/

/*
class InvalidDayException extends Exception
{
    public String toString()
    {
        return "Invalid Date given";
    }
}

class InvalidMonthException extends Exception
{
    public String toString()
    {
        return "Invalid Month given";
    }
}

class MyDate
{int date;
    int month;
    int year;
public MyDate(){}
    public MyDate(int date, int month, int year) {
        this.date = date;
        this.month = month;
        this.year = year;
    }
    public void CheckMonth(int month) throws InvalidMonthException {
        if (month > 12) {
            throw new InvalidMonthException();
        } else {
            System.out.println("month is valid");
        }
    }
    public void CheckDate(int date) throws InvalidDayException {
        if (date > 31) {
            throw new InvalidDayException();
        } else {
            System.out.println("day is valid");
        }
    }

    public static void main(String[]args) throws InvalidDayException,InvalidMonthException
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the date");
        int dd= sc.nextInt();
        System.out.println("Enter the month");
        int mm=sc.nextInt();
        System.out.println("Enter the year");
        int yy= sc.nextInt();
        try
        {
            MyDate obj=new MyDate();
obj.CheckDate(dd);
obj.CheckMonth(mm);

        } catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
*/
    /*Enter the date
        21
        Enter the month
        13
        Enter the year
        2000
        day is valid
        Invalid Month given
*/
   /* Enter the date
        32
        Enter the month
        12
        Enter the year
        2000
        Invalid Date given
*/
    class InvalidDayException extends Exception
    {
        InvalidDayException(String str){
            super(str);
        }
    }

class InvalidMonthException extends Exception
{
    InvalidMonthException(String str1 ){
        super(str1);
    }
}
class LeapYearException extends Exception{
    LeapYearException (String s){
        super(s);
    }
}
class MyDate {
    int day=0;
    int mon=0;
    int year;

    public MyDate() {
    }

    public MyDate(int day, int mon, int year) {
        this.day = day;
        this.mon = mon;
        this.year = year;
    }


    void checkValidDay(int d) throws InvalidDayException {
        if(d < 0 || d > 31){
            throw new InvalidDayException("Invalid day please enter a valid day ");
        }
        else {
            System.out.println("Valid day ");
        }
    }
    void checkValidMonth(int m) throws InvalidMonthException {
        if(m < 0 || m >12 ){
            throw new InvalidMonthException("Invalid Month please enter a valid Month");
        }
        else {
            System.out.println("Valid month ");
        }
    }
    void checkLeapYear(int y) throws LeapYearException {
        if(y % 4==0 && y % 100==0 && y % 400==0 ){
            System.out.println("It is leap year ");
        }
        else {
            throw new LeapYearException("Leap year exception");
        }
    }
    public static void main(String[]args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the day :");
        int date= sc.nextInt();
        System.out.println("Enter the month :");
        int month=sc.nextInt();
        System.out.println("Enter the year :");
        int yy= sc.nextInt();

        try {
            MyDate ob=new MyDate();
            ob.checkValidDay(date);
            ob.checkValidMonth(month);
            ob.checkLeapYear(yy);
        }
        catch (Exception e){
            System.out.println(e);
        }
    }
}
