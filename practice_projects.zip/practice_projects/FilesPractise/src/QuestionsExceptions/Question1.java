package QuestionsExceptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//Create a class Student with attributes roll no, name, age and course. Initialize values
//through parameterized constructor. If age of student is not in between 15 and 21 then
//generate user-defined exception â€œAgeNotWithinRangeExceptionâ€. If name contains
//numbers or special symbols raise exception â€œNameNotValidExceptionâ€. Define the two
//exception classes.
public class Question1 {
}
/*
class AgeNotWithinRangeException extends Exception
{
    AgeNotWithinRangeException(String s)
    {
        super(s);
    }
}
class NameNotValidException extends Exception
{
    NameNotValidException(String s)
    {
        super(s);
    }

}

class student
{
    int rno;
    String name;
    int age;
    String course;

    student(int rno,String name,int age,String course)
    {

        this.rno=rno;
        this.name=name;
        this.age=age;
        this.course=course;


    }

    void display()
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("rollno :"+rno+"\n name:"+name+"\n age:"+age+"\n course:"+course+"\n");
    }
}

class studentdemo
{
    public static void main(String args[])throws IOException
    {
        student s1;
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        s1= new student(1,"dam",89,"science");
        s1.display();
        System.out.print("Enter the roll number:");
        int rno=Integer.parseInt(br.readLine());
        try
        {
            System.out.println("Enter the student name:");
            String name=br.readLine();
            for(int i=0;i<name.length();i++)
                if(Character.isDigit(name.charAt(i)))
                    throw new NameNotValidException("Name Not Valid");
        }
        catch( NameNotValidException e)
        {
            System.out.println(e);
        }

        try
        {
            System.out.println("Enter the age of student:");
            int age=Integer.parseInt(br.readLine());


            if(age<15 || age>20)
                throw new AgeNotWithinRangeException("AgeNot within the range");
        }
        catch(AgeNotWithinRangeException e)
        {
            System.out.println(e);
        }

        System.out.println("Enter the course:");
        String course=br.readLine();
    }
}*/
class AgeNotWithInRangeException extends Exception
{
    public String toString()
    {
        return("Age is not between 15 and 21 ");
    }
}
class NameNotValidException extends Exception
{
    public String validname()
    {
        return("Name is not Valid … Please ReEnter the Name");
    }
}
class Student
{
    int roll,age;
    String name,course;
    Student()
    {
        roll=0;
        name=null;
        age=0;
        course=null;
    }
    Student(int r,String n,int a,String c)
    {
        roll=r;
        course=c;
        int l,temp=0;
        l=n.length();
        for(int i=0;i<l;i++)
        {
            char ch;
            ch=n.charAt(i);
            if(ch<'A' || ch>'Z' && ch<'a' || ch>'z')
            temp=1;
        }
        /*———-Checking Name——————–*/
        try
        {
            if(temp==1)
                throw new NameNotValidException();
            else
                name=n;
        }
        catch(NameNotValidException e2)
        {
            System.out.println(e2);
        }
        /*———-Checking Age——————–*/
        try
        {
            if(a>=15 && a<=21)
                age=a;
            else
                throw new AgeNotWithInRangeException();
        }
        catch(AgeNotWithInRangeException e1)
        {
            System.out.println(e1);
        }
    }
    void display()
    {
        System.out.println("roll Name Age Course");
      System.out.println("————————————————-");
        System.out.println(roll+name+age+course);
    }
}

class StudentDemo
{
    public static void main(String args[])throws IOException
    {

        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int r,a;
        String n,c;

        System.out.println("Enter roll,name,age,course");

        r=Integer.parseInt(br.readLine());
        n=br.readLine();
        a=Integer.parseInt(br.readLine());
        c=br.readLine();
        Student s=new Student(r,n,a,c);
        s.display();
    }
}