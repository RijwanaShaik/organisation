package QuestionsExceptions;
// Write a program which accept two integers and an arithmetic operator from the
//command line and performs the operation. Fire the following user defined exceptions:
//i. If the no of arguments are less than 3 then fire â€œIllegalNumberOfArgumentsâ€
//ii. If the operator is not an Arithmetic operator, throw â€œInvalidOperatorExceptionâ€.
//iii. If result is â€“ve, then throw â€œNegativeResultExceptionâ
public class Question4 {
}
class NegativeNumberException extends Exception
{
    NegativeNumberException(int n)
    {
        System.out.println("Negative input:"+n);
    }
}

class ExceptionTest
{
    public static void main(String[]args)
    {
        int num,i,sum=0;
        try
        {
            num=Integer.parseInt(args[0]);
            if(num<0)
                throw new NegativeNumberException(num);
            for(i=0;i<num;i++)
                sum=sum+i;
        }
        catch(NumberFormatException e)
        {
            System.out.println("Invalid Format:");
        }
        catch(NegativeNumberException e)
        {   }
        finally
        {
            System.out.println("The sum is:"+sum);
        }
    }
}

//The throws keyword is used to declare which exceptions can be thrown from a method, while the throw keyword is used to explicitly throw an exception within a method or block of code. The throws keyword is used in a method signature and declares which exceptions can be thrown from a method.