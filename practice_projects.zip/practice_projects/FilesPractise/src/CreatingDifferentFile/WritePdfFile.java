package CreatingDifferentFile;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WritePdfFile {
    public static void main(String[] args) {
        File f= new File("D:file.pdf");
        try {
            FileWriter fw =new  FileWriter(f);
            if(f.exists()) {
                fw.write("NewLine in a pdf");
                System.out.println("successfully data is inserted");
            }
            fw.close();
        }catch (IOException e){
            System.out.println(e);
        }
    }
}
