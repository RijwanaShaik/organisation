package CreatingDifferentFile;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadFile {
    public static void main(String[] args) {
        File f=new File("D:file.pdf");
        try{
            FileReader fr=new FileReader(f);
           /* System.out.println(f.getPath());
            System.out.println(f.getAbsoluteFile());
            System.out.println(f.getAbsolutePath());*/
           // System.out.println(f.getFreeSpace());
            Scanner sc=new Scanner(fr);
            String str="";
            while (sc.hasNextLine()){
                str=sc.nextLine();
                System.out.println(str);
                fr.read();
                fr.close();
            }

        }catch (IOException e){
            System.out.println("error");
        }
    }
}
