package CreatingDifferentFile;

import java.io.File;
import java.io.IOException;

public class PdfFile {
    public static void main(String[] args) {
        File f=new File("D:file.pdf");
        try {
            if (f.createNewFile()) {
                System.out.println("created successfully");
            }else{
                System.out.println("already exists");
            }
        }catch (IOException e){
            System.out.println(e);
        }
    }
}
//import java.io.*;

/*
class CreateDirectory {

    public static void main(String args[])
    {
        // specify an abstract pathname in the File object
        File f = new File("D:\\Educative");

        // check if the directory can be created
        // using the specified path name
        if (f.mkdir() == true) {
            System.out.println("Directory has been created successfully");
        }
        else {
            System.out.println("Directory cannot be created");
        }
    }
}

import java.io.File;
        import org.apache.commons.io.FileUtils;

class DelteDirectory {

    public static void main(String[] args)
    {
        // store file path
        String filepath = "C:\\GFG";
        File file = new File(filepath);

        // call deleteDirectory method to delete directory
        // recursively
        FileUtils.deleteDirectory(file);

        // delete GFG folder
        file.delete();
    }
}

import java.io.File;

class DeleteDirectory {

    // function to delete subdirectories and files
    public static void deleteDirectory(File file)
    {
        // store all the paths of files and folders present
        // inside directory
        for (File subfile : file.listFiles()) {

            // if it is a subfolder,e.g Rohan and Ritik,
            // recursiley call function to empty subfolder
            if (subfile.isDirectory()) {
                deleteDirectory(subfile);
            }

            // delete files and empty subfolders
            subfile.delete();
        }
    }

    public static void main(String[] args)
    {
        // store file path
        String filepath = "C:\\GFG";
        File file = new File(filepath);

        // call deleteDirectory function to delete
        // subdirectory and files
        deleteDirectory(file);

        // delete main GFG folder
        file.delete();
    }
}

//}*/
