package ThreadPractise;

public class Example15 extends Thread{
    Example15(String threadName,ThreadGroup tg){
        super(tg,threadName);
        start();
    }
    public void run(){
        System.out.println(Thread.currentThread().getName());
    }
}
class ExMain15{
    public static void main(String[] args) {
        try{
            ThreadGroup group=new ThreadGroup("Parent thread");
            Example15 t1 = new Example15("Child Thread1", group);
            Example15 t2 = new Example15("Child Thread2", group);
            Example15 t3 = new Example15("Child Thread3", group);

            System.out.println("Total active threads: " + group.activeCount());
        }catch (Exception e){
            System.out.println(e);
        }
    }
}