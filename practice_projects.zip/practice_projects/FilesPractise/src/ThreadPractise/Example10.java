package ThreadPractise;
//java program to check thread is alive or not
public class Example10 implements Runnable{
    @Override
    public void run() {
        System.out.println("Thread: "+Thread.currentThread().getId());
    }
}
class ExMain10{
    public static void main(String[] args) {
        Thread t=new Thread(new Example10());
        System.out.println("Thread before start method: "+t.isAlive());
        t.start();
        System.out.println("Thread after start method: "+t.isAlive());

    }
}
