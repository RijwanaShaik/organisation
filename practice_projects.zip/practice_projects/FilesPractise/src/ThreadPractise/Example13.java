package ThreadPractise;
//java program to interrupt the execution of a thread
public class Example13 implements Runnable{
    @Override
    public void run() {
try{
    Thread.sleep(1000);
    System.out.println("Include help");
}catch (Exception e){
    System.out.println(e);
}
        System.out.println("Thread is running");
    }
}
class ExMain13{
    public static void main(String[] args) {
        Thread t=new Thread(new Example13());
        t.start();
        t.interrupt();
    }
}