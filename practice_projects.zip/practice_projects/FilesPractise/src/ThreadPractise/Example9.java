package ThreadPractise;
//java program to get information of the current executing thread
public class Example9 implements Runnable {
    @Override
    public void run() {
        System.out.println("Thread: "+Thread.currentThread().getState());
    }
}
class ExMain9{
    public static void main(String[] args) {
        Thread t1 = new Thread(new Example9());
        Thread t2 = new Thread(new Example9());
        Thread t3 = new Thread(new Example9());

       /* t1.setName("First Thread");
        t2.setName("Second Thread");
        t3.setName("Third Thread");

        t1.setPriority(1);
        t2.setPriority(2);
        t3.setPriority(3);*/
//to get thread state we are writing .getstate() in run method and commented the setname and priority
        t1.start();
        t2.start();
        t3.start();
    }
}
