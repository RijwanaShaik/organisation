package ThreadPractise;
//java program to set and print thread name
public class Example3 {
    public static void main(String[] args) {
        String threadName;
        Thread t1=new Thread("Thread1");
        Thread t2=new Thread("Thread2");
        t1.start();
        t2.start();
        threadName=t1.getName();
        System.out.println(threadName);
        threadName=t2.getName();
        System.out.println(threadName);
    }
}
