package ThreadPractise;
//java program to create a thread by implementing a runnable interaface
public class MultiThreading implements Runnable{
    public void run(){
        System.out.println("thread1");
    }

    public static void main(String[] args) {
        MultiThreading m1=new MultiThreading();
        Thread t=new Thread(m1);
        t.start();
        System.out.println("Outside the thread");
    }
}
class tt extends Thread{
    public void run(){

    }
}
class ttMain{
    public static void main(String[] args) {
        Thread t=new Thread(new tt());
        t.start();
     //   Thread t1=Thread.currentThread();
       // System.out.println(t1);
       // System.out.println(t1.isAlive());
    }
}