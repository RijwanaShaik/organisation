package ThreadPractise;
//java program to set a thread name using setName() method
public class Example7 implements Runnable{
    @Override
    public void run() {
        System.out.println("Thread: "+Thread.currentThread().getId()+" is running");
    }
}
class ExMain7{
    public static void main(String[] args) {
        Thread t1=new Thread( new Example7());
        t1.setName("setting the name of thread");
        System.out.println(t1.getName());
        t1.start();
    }
}
