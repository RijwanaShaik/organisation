package ThreadPractise;
//java program to create multiple threads
public class Example5 implements Runnable{
    @Override
    public void run() {
int i=0;
for(i=1;i<=3;i++){
    System.out.println("Thread "+Thread.currentThread().getId()+" is running");
}
    }
}
class ExMain5{
    public static void main(String[] args) {
        Thread t1=new Thread(new Example5());
        Thread t2=new Thread(new Example5());
        Thread t3=new Thread(new Example5());
        t1.start();
       t2.start();
        t3.start();
    }
}
