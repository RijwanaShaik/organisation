package ThreadPractise;
//java program to sleep a thread
public class Example6 implements Runnable{
    @Override
    public void run() {
try{
    for(int i=1;i<=3;i++){
        System.out.println("Thread "+Thread.currentThread().getId()+ " is running");
        Thread.sleep(1000);
    }
}catch (Exception e){
}
    }
}
class ExMain6{
    public static void main(String[] args) {
        Thread t1=new Thread( new Example6());
        Thread t2=new Thread( new Example6());
        Thread t3=new Thread( new Example6());

        t1.start();
        t2.start();
        t3.start();

    }
}
