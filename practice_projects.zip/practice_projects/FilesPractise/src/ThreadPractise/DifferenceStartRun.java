package ThreadPractise;

public class DifferenceStartRun implements Runnable{
    @Override
    public void run() {
        System.out.println("This method is executed by: "+Thread.currentThread().getName());
    }

    public static void main(String[] args) {
        Thread t=new Thread(new DifferenceStartRun());
       // t.start();
        t.run();
    }
}
