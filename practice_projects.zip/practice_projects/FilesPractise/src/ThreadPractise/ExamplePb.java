package ThreadPractise;

import java.util.Scanner;

//java program for life cycle of a thread
public class ExamplePb implements Runnable{
    Thread t;
    ExamplePb()
    {
        t = new Thread(this);
        System.out.println("Thread is in new state");
        t.start();
    }
    @Override
    public void run() {
        System.out.println("Thread is in runnable state");
        Scanner s = new Scanner(System.in);
        System.out.println("Thread entering blocked state");
        System.out.print("Enter a string: ");
        String str = s.next();
        for(int i = 1; i <= 3; i++)
        {
            try
            {
                System.out.println("Thread suspended");
                t.sleep(1000);
                System.out.println("Thread is running");
            }
            catch(InterruptedException e)
            {
                System.out.println("Thread interrupted");
            }
            System.out.println("Thread terminated");
            t.stop();
        }
    }
}
class ExMainpb{
    public static void main(String[] args) {
        new ExamplePb();
    }
}
//other example
class A1 extends Thread
{
    public void run ()
    {
        System.out.println ("Thread A");
        System.out.println ("i in Thread A ");
        for (int i = 1; i <= 5; i++)
        {
            System.out.println ("i = " + i);
            try
            {
                Thread.sleep (1000);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace ();
            }
        }
        System.out.println ("Thread A Completed.");
    }
}
class B extends Thread
{
    public void run ()
    {
        System.out.println ("Thread B");
        System.out.println ("i in Thread B ");
        for (int i = 1; i <= 5; i++)
        {
            System.out.println ("i = " + i);
        }
        System.out.println ("Thread B Completed.");
    }
}
 class ThreadLifeCycleDemo
{
    public static void main (String[]args)
    {
        // life cycle of Thread
        // Thread's New State
        A1 threadA = new A1 ();
        B threadB = new B ();
        // Both the above threads are in runnable state

        // Running state of thread A & B
        threadA.start ();

        // Move control to another thread
        threadA.yield ();
        // Blocked State of thread B
        try
        {
            threadA.sleep (1000);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace ();
        }
        threadB.start ();
        System.out.println ("Main Thread End");
    }
}
//other example
class thread implements Runnable {
    public void run()
    {
        // moving thread2 to timed waiting state
        try {
            Thread.sleep(1500);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(
                "State of thread1 while it called join() method on thread2 -"
                        + Test.thread1.getState());
        try {
            Thread.sleep(200);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class Test implements Runnable {
    public static Thread thread1;
    public static Test obj;

    public static void main(String[] args)
    {
        obj = new Test();
        thread1 = new Thread(obj);

        // thread1 created and is currently in the NEW
        // state.
        System.out.println(
                "State of thread1 after creating it - "
                        + thread1.getState());
        thread1.start();

        // thread1 moved to Runnable state
        System.out.println(
                "State of thread1 after calling .start() method on it - "
                        + thread1.getState());
    }

    public void run()
    {
        thread myThread = new thread();
        Thread thread2 = new Thread(myThread);

        // thread1 created and is currently in the NEW
        // state.
        System.out.println(
                "State of thread2 after creating it - "
                        + thread2.getState());
        thread2.start();

        // thread2 moved to Runnable state
        System.out.println(
                "State of thread2 after calling .start() method on it - "
                        + thread2.getState());

        // moving thread1 to timed waiting state
        try {
            // moving thread1 to timed waiting state
            Thread.sleep(200);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(
                "State of thread2 after calling .sleep() method on it - "
                        + thread2.getState());

        try {
            // waiting for thread2 to die
            thread2.join();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(
                "State of thread2 when it has finished it's execution - "
                        + thread2.getState());
    }
}
//other example
class MyThread implements Runnable
{
    Thread t;
    MyThread(String name)
    {
        t = new Thread(this, name);
        System.out.println("Child thread: " + t);
        System.out.println("State: " + t.getState());
        t.start();
    }

    @Override
    public void run()
    {
        System.out.println("State: " + t.getState());
        try
        {
            for(int i = 1; i <= 3; i++)
            {
                System.out.println(t.getName() + ": " + i);
                Thread.sleep(2000);
            }
        }
        catch(InterruptedException e)
        {
            System.out.println(t.getName() + " is interrupted!");
        }
        System.out.println(t.getName() + " is terminated");
    }
}

 class Driver
{
    public static void main(String[] args)
    {
        MyThread thread1 = new MyThread("First Thread");
        try
        {
            System.out.println("Main thread is waiting...");
            thread1.t.sleep(1000);
            System.out.println("State: " + thread1.t.getState());
            thread1.t.join();
            System.out.println("State: " + thread1.t.getState());
        }
        catch(InterruptedException e)
        {
            System.out.println("Main thread is interrupted!");
        }
        System.out.println("Main thread terminated");
    }
}

