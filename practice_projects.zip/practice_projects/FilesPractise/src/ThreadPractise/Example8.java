package ThreadPractise;
//java program to get & set thread priority
public class Example8 implements Runnable{

    @Override
    public void run() {
        System.out.println("Thread: "+Thread.currentThread().getId()+" is running");
    }
}
class ExMain8{
    public static void main(String[] args) {
        Thread t1=new Thread(new Example8());
        Thread t2=new Thread(new Example8());
        Thread t3=new Thread(new Example8());

        System.out.println(t1.getPriority());//default value is 5
        t1.start();
        t2.setPriority(4);
        t3.setPriority(8);
        System.out.println(t2.getPriority());
        System.out.println(t3.getPriority());
        t2.start();
        t3.start();
    }
}
