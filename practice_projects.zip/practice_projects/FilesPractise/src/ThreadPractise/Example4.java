package ThreadPractise;
//java program to print the thread Id of a thread
public class Example4 implements Runnable{
    @Override
    public void run() {
        System.out.println("Thread Id: "+Thread.currentThread().getId());
    }
}
class ExMain{
    public static void main(String[] args) {
        Thread t=new Thread(new Example4());
        t.start();
    }
}
