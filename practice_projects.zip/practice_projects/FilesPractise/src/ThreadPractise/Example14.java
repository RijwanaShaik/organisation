package ThreadPractise;


//java program to create a group of  a thread
public class Example14 extends Thread{
    Example14(String threadName,ThreadGroup tg){
        super(tg, threadName);
        start();
    }
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+" is running");
    }
}
class ExMain14 {
    public static void main(String[] args) {
        try {
            ThreadGroup group = new ThreadGroup("Parent thread");

            Example14 t1 = new Example14("Child Thread1", group);
            Example14 t2 = new Example14("Child Thread2", group);
            Example14 t3 = new Example14("Child Thread3", group);

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}