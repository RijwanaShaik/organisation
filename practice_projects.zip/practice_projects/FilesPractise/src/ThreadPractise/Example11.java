package ThreadPractise;
//java program to suspend,resume,stop a thread
//suspend,stop are same
public class Example11 implements Runnable{
    @Override
    public void run() {
        try{
            Thread.sleep(500);//its our choice to write sleep method
            System.out.println(Thread.currentThread().getName());

        }catch (Exception e){

        }
    }
}
class ExMain11{
    public static void main(String[] args) {
        Thread t1 = new Thread(new Example11());
        Thread t2 = new Thread(new Example11());
        Thread t3 = new Thread(new Example11());

        t1.start();//thread 0
        t2.start();//thread 1
        t2.suspend();//after suspend the t2.start get stopped
        t3.start();//thread 2
      t2.resume();//after resume  the t2.start its execution
//we are resuming the t2 last so, thread 1 comes in last line in output
    }
}
