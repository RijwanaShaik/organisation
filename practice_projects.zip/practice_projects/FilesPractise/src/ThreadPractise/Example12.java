package ThreadPractise;
//java program to demonstrate the thread.join() method
public class Example12 implements Runnable{
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " is alive: " + Thread.currentThread().isAlive());

    }
}
class ExMain12{
    public static void main(String[] args) {
        Thread t = new Thread(new Example12());
        t.start();
        try {
            t.join(500);
            System.out.println(t.getName() + " is alive: " + t.isAlive());

        } catch (Exception e) {

        }
    }
}