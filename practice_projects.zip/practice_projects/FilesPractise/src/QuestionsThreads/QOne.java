package QuestionsThreads;
//Write a program that create 2 threads – each displaying a message (Pass the message
//as a parameter to the constructor). The threads should display the messages continuously
//till the user presses ctrl-c. Also display the thread information as it is running.
public class QOne {
}
class MyThread extends Thread
{
    String str;
    public MyThread(String s)
    {
        str=s;
    }
    public void run()
    {
        while(true)
        {   System.out.println((Thread.currentThread()).getName()+" "+"Message: "+str);
            System.out.println((Thread.currentThread()).getName()+" "+"Priority:  "+(Thread.currentThread()).getPriority());

            try
            {
                Thread.sleep(1000);
            }
            catch(InterruptedException ie)
            {
                System.out.println(ie.toString());
            }
        }
    }
}
class ThreadSetA1
{
    public static void main(String args[])
    {
        MyThread t1= new MyThread("ON");
        MyThread t2= new MyThread("OFF");
        System.out.println("Details of the Threads in running state....");
        t1.start();
        t2.start();
    }
}
//other way
class Thread1 extends Thread {
    String msg = "";

    Thread1(String msg) {
        this.msg = msg;
    }

    public void run() {
        try {
            while (true) {
                System.out.println(msg);
                Thread.sleep(300);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

class Thread2 extends Thread
{
    String msg = "";
    Thread2(String msg)
    {
        this.msg = msg;
    }
    public void run()
    {
        try
        {
            while (true)
            {
                System.out.println(msg);
                Thread.sleep(400);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
class ThreadDemo
{
    public static void main(String[] args)
    {
        Thread1 t1 = new Thread1("Running Thread1....");
        Thread1 t2 = new Thread1("Running Thread2....");
        t1.start();
        t2.start();
    }
}

//ANOTHER WAY
class Ass_seta1 extends Thread
{
    String msg="";
    Ass_seta1(String msg)
    {
        this.msg=msg;
    }
    public void run()
    {
        try
        { while(true)
        {
            System.out.println(msg);
            Thread.sleep(200);
        }
        }
        catch(Exception e){}
    }
}
 class seta1 {
    public static void main(String a[]) {
        Ass_seta1 t1 = new Ass_seta1("Hello............");
        t1.start();
    }
}