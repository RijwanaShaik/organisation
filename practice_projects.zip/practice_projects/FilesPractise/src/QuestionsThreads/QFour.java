package QuestionsThreads;
//Write a Java program to create five threads with different priorities. Send two threads of the highest priority to sleep
//state. Check the aliveness of the threads and mark which thread is long lasting
public class QFour {
}
class ThreadClass implements Runnable
{
    long click=0;
    Thread t;
    private volatile boolean running =true;
    public ThreadClass(int p)
    {
        t=new Thread(this);
        t.setPriority(p);
    }
    public void run()
    {
        while(running)
        {
            click++;
        }
    }
    public void stop()
    {
        running =false;
    }
    public void start()
    {
        t.start();
    }
}
class Demo {
    public static void main(String args[])
    {
        Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
        ThreadClass hi1=new ThreadClass(Thread.NORM_PRIORITY + 2);
        ThreadClass hi2=new ThreadClass(Thread.NORM_PRIORITY -2);
        ThreadClass hi3=new ThreadClass(Thread.NORM_PRIORITY + 3);
        ThreadClass hi4=new ThreadClass(Thread.NORM_PRIORITY - 3);
        ThreadClass hi5=new ThreadClass(Thread.NORM_PRIORITY +4);
        hi1.start();
        hi2.start();
        hi3.start();
        hi4.start();
        hi5.start();
        System.out.println("thread one is alive:" +hi1.t.isAlive());
        System.out.println("thread two is alive:" +hi2.t.isAlive());
        System.out.println("thread three is alive:" +hi3.t.isAlive());
        System.out.println("thread four is alive:" +hi4.t.isAlive());
        System.out.println("thread four is alive:" +hi5.t.isAlive());
        try
        { hi5.t.sleep(1000);
            hi3.t.sleep(1000);
        }
        catch(InterruptedException e){
            System.out.println("main thread interrupted");
        }
        hi1.stop();
        hi2.stop();
        hi3.stop();
        hi4.stop();
        hi5.stop();
        try
        {
            System.out.println("waiting for threads to finish");
            hi1.t.join();
            hi2.t.join();
            hi3.t.join();
            hi4.t.join();
            hi5.t.join();
        }
        catch(InterruptedException e)
        {
            System.out.println("main thread interrupted");
        }
        System.out.println("priority of thread1:" +hi1.t.getPriority());
        System.out.println("priority of thread2:" +hi2.t.getPriority());
        System.out.println("priority of thread3:" +hi3.t.getPriority());
        System.out.println("priority of thread4:" +hi4.t.getPriority());
        System.out.println("priority of thread5:" +hi5.t.getPriority());
        System.out.println("thread one is alive:" +hi1.t.isAlive());
        System.out.println("thread two is alive:" +hi2.t.isAlive());
        System.out.println("thread three is alive:" +hi3.t.isAlive());
        System.out.println("thread four is alive:" +hi4.t.isAlive());
        System.out.println("thread five is alive:" +hi5.t.isAlive());
        System.out.println("main thread exiting");
    }
}
class FiveThreads implements Runnable
{
    public static void main(String args[]) throws InterruptedException
    {
        Thread T1=new Thread();
        Thread T2=new Thread();
        Thread T3=new Thread();
        Thread T4=new Thread();
        Thread T5=new Thread();
        T1.setPriority(7);
        T2.setPriority(2);
        T3.setPriority(10);
        T4.setPriority(5);
        T5.setPriority(8);
        T1.sleep(1500);
        if (T1.isAlive())
            System.out.println("Thread 1 is alive");
        else
            System.out.println("Thread 1 is not alive");
        T2.start();
        if (T2.isAlive())
            System.out.println("Thread 2 is alive");
        else
            System.out.println("Thread 2 is not alive");
        T3.sleep(1000);
        if (T3.isAlive())
            System.out.println("Thread 3 is alive");
else
        System.out.println("Thread 3 is not alive");
        T4.start();
        if (T4.isAlive())
            System.out.println("Thread 4 is alive");
        else
            System.out.println("Thread 4 is not alive");
        T5.start();
        if (T5.isAlive())
            System.out.println("Thread 5 is alive");
        else
            System.out.println("Thread 5 is not alive");
    }

    @Override
    public void run() {

    }
}