package QuestionsThreads;

public class QFive {
}
class even extends Thread
{
    Thread t=null; even()
{
    t=new Thread(this); start();
}
    public void run()
    {
        try
        {
            for(int i=2;i<50;i+=2) System.out.print(i+" "); Thread.sleep(100);
        }
        catch(Exception e)
        {System.out.println("thread interepted");}
    }
}
class odd extends Thread
{
    Thread t=null; odd()
{
    t=new Thread(this); start();
}
    public void run()
    {
        try
        {
            for(int i=1;i<50;i+=2) System.out.print(i+" "); Thread.sleep(100);
        }
        catch(Exception e)
        {System.out.println("thread interepted");}
    }
}
class Generate {
    public static void main(String arg[]) {
        even e = new even();
        odd o = new odd();
        try {
            e.start();

        } catch (Exception ex) {
            System.out.println(ex);
        }
        try {
            o.start();

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
//other way
class GFG {

    // Starting counter
    int counter = 1;

    static int N;

    // Function to print odd numbers
    public void printOddNumber()
    {
        synchronized (this)
        {
            // Print number till the N
            while (counter < N) {

                // If count is even then print
                while (counter % 2 == 0) {

                    // Exception handle
                    try {
                        wait();
                    }
                    catch (
                            InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                // Print the number
                System.out.print(counter + " ");

                // Increment counter
                counter++;

                // Notify to second thread
                notify();
            }
        }
    }

    // Function to print even numbers
    public void printEvenNumber()
    {
        synchronized (this)
        {
            // Print number till the N
            while (counter < N) {

                // If count is odd then print
                while (counter % 2 == 1) {

                    // Exception handle
                    try {
                        wait();
                    }
                    catch (
                            InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                // Print the number
                System.out.print(
                        counter + " ");

                // Increment counter
                counter++;

                // Notify to 2nd thread
                notify();
            }
        }
    }

    // Driver Code
    public static void main(String[] args)
    {
        // Given Number N
        N = 10;

        // Create an object of class
        GFG mt = new GFG();

        // Create thread t1
        Thread t1 = new Thread(new Runnable() {
            public void run()
            {
                mt.printEvenNumber();
            }
        });

        // Create thread t2
        Thread t2 = new Thread(new Runnable() {
            public void run()
            {
                mt.printOddNumber();
            }
        });

        // Start both threads
        t1.start();
        t2.start();
    }
}
//other way

class OddEvenPrintMain {

    boolean odd;
    int count = 1;
    int MAX = 20;

    public void printOdd() {
        synchronized (this) {
            while (count < MAX) {
                System.out.println("Checking odd loop");

                while (!odd) {
                    try {
                        System.out.println("Odd waiting : " + count);
                        wait();
                        System.out.println("Notified odd :" + count);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
                System.out.println("Odd Thread :" + count);
                count++;
                odd = false;
                notify();
            }
        }
    }

    public void printEven() {

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }
        synchronized (this) {
            while (count < MAX) {
                System.out.println("Checking even loop");

                while (odd) {
                    try {
                        System.out.println("Even waiting: " + count);
                        wait();
                        System.out.println("Notified even:" + count);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("Even thread :" + count);
                count++;
                odd = true;
                notify();

            }
        }
    }

    public static void main(String[] args) {

        OddEvenPrintMain oep = new OddEvenPrintMain();
        oep.odd = true;
        Thread t1 = new Thread(new Runnable() {

            @Override
            public void run() {
                oep.printEven();

            }
        });
        Thread t2 = new Thread(new Runnable() {

            @Override
            public void run() {
                oep.printOdd();

            }
        });

        t1.start();
        t2.start();

        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
 //using reamider
 class OddEvenRunnable implements Runnable{

     public int PRINT_NUMBERS_UPTO=10;
     static int  number=1;
     int remainder;
     static Object lock=new Object();

     OddEvenRunnable(int remainder)
     {
         this.remainder=remainder;
     }

     @Override
     public void run() {
         while (number < PRINT_NUMBERS_UPTO) {
             synchronized (lock) {
                 while (number % 2 != remainder) { // wait for numbers other than remainder
                     try {
                         lock.wait();
                     } catch (InterruptedException e) {
                         e.printStackTrace();
                     }
                 }
                 System.out.println(Thread.currentThread().getName() + " " + number);
                 number++;
                 lock.notifyAll();
             }
         }
     }
 }

class PrintOddEvenMain {
    public static void main(String[] args) {

        OddEvenRunnable oddRunnable=new OddEvenRunnable(1);
        OddEvenRunnable evenRunnable=new OddEvenRunnable(0);

        Thread t1=new Thread(oddRunnable,"Odd");
        Thread t2=new Thread(evenRunnable,"Even");

        t1.start();
        t2.start();

    }
}