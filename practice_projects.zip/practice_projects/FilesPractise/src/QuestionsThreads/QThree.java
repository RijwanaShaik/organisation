package QuestionsThreads;
//Define a thread called “PrintText_Thread” for printing text on command prompt for
// n number of times. Create three threads and run them. Pass the text and n as
//parameters to the thread constructor. Example:
// i. First thread prints “I am in FY” 10 times
// ii. Second thread prints “I am in SY” 20 times
// iii. Third thread prints “I am in TY” 30 times
public class QThree {
}
class NThread extends Thread {

    String msg;
    int n;
    public NThread() {
        // TODO Auto-generated constructor stub
    }
    public NThread(int n,String a) {
        // TODO Auto-generated constructor stub
        this.n=n;
        msg=a;
    }
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        NThread n1=new NThread(10, "I am in FY");
        n1.start();
        n1=new NThread(20, "I am in SY");
        n1.start();
        n1=new NThread(30, "I am in TY");
        n1.start();
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        int i=1;
        while(i<=n){
            System.out.println(i+msg);
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            i++;
        }
    }

}
//another way
class Ass_seta3 extends Thread
{
    String msg="";
    int  n;
    Ass_seta3(String msg,int n)
    {
        this.msg=msg;
        this.n=n;
    }
    public void run()
    {
        try
        { for(int i=1;i<=n;i++)
        {
            System.out.println(msg+" "+i+" times");
        }
        }
        catch(Exception e){}
    }
}
 class seta3
{
    public static void main(String a[])
    {
        int n=Integer.parseInt(a[0]);
        Ass_seta3 t1=new Ass_seta3("I am in FY",n);
        t1.start();
        Ass_seta3 t2=new Ass_seta3("I am in SY",n+10);
        t2.start();
        Ass_seta3 t3=new Ass_seta3("I am in TY",n+20);
        t3.start();
    }
}
