package PackageRevision;

public class ExamplesScientecheasy {
}
//Multiple threads on single object
class MultipleThread implements Runnable
{
    String task;
    MultipleThread(String task)
    {
        this.task = task;
    }
    public void run()
    {
        for(int i = 1; i <= 5; i++)
        {
            System.out.println(task+ ":" +i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public static void main(String[] args)
    {
        Thread nThread = Thread.currentThread();
        System.out.println("Name of thread: " +nThread);

// Multiple child threads acting on single object.
        MultipleThread mt = new MultipleThread("Hello Java");
        Thread t1 = new Thread(mt);
        Thread t2 = new Thread(mt);
        Thread t3 = new Thread(mt);
        t1.start();
        t2.start();
        t3.start();

        int count = Thread.activeCount();
        System.out.println("No of active threads: " +count);
    }
}
//multiple threads on two different objects

class MyThread1 implements Runnable
{
    public void run() // Entry point of Thread1
    {
        for(int i = 0; i < 5; i++)
        {
            System.out.println("First Child Thread: " +i);
        }
        System.out.println("\t First child existed");
    }
}
class MyThread2 implements Runnable
{
    public void run() // Entry point of Thread2
    {
        for(int i = 0; i < 5; i++)
        {
            System.out.println("Second Child Thread: " +i);
        }
        System.out.println("Second child existed");
    }
}
class MyClass {
    public static void main(String[] args)
    {
        MyThread1 th1 = new MyThread1();
        Thread t1 = new Thread(th1);
        t1.start(); // Execution of first thread is started.

        MyThread2 th2 = new MyThread2();
        Thread t2 = new Thread(th2);
        t2.start(); // Execution of second thread is started.

        int j = 0;
        while(j < 4)
        {
            System.out.println("Main Thread: " +j);
            j = j + 1;
        }
        System.out.println("\t Main thread existing");
    }
}
//deadlock in java
 class X
{
    void display1(X obj2)
    {
        System.out.println("Thread1 waiting for thread2 to release lock");
        synchronized(obj2) {
            System.out.println("Deadlock occurred");
        }
    }
    void display2(X obj1)
    {
        System.out.println("Thread2 waiting for thread1 to release lock");
        synchronized(obj1){
            System.out.println("Deadlock occurred");
        }
    }
}
 class Thread1 extends Thread
{
    X obj1, obj2;
    Thread1(X obj1, X obj2)
    {
        this.obj1 = obj1;
        this.obj2 = obj2;
    }
    public void run()
    {
        synchronized(obj1){
            try {
                Thread.sleep(1000);
            }
            catch(InterruptedException ie) {
                System.out.println(ie);
            }
            obj2.display2(obj2);
        }
    }
}
class Thread2 extends Thread
{
    X obj1, obj2;
    Thread2(X obj1, X obj2)
    {
        this.obj1 = obj1;
        this.obj2 = obj2;
    }
    public void run()
    {
        synchronized(obj2){
            try {
                Thread.sleep(1000);
            }
            catch(InterruptedException ie) {
                System.out.println(ie);
            }
            obj1.display1(obj1);
        }
    }
}
 class Deadlock {
    public static void main(String[] args)
    {
        X obj1 = new X();
        X obj2 = new X();

        Thread1 t1 = new Thread1(obj1, obj2);
        Thread2 t2 = new Thread2(obj1, obj2);
        t1.start();
        t2.start();
    }
}
//how to sleep current thread in java

class A implements Runnable
{
    public void run()
    {
        System.out.println("Hello");
        try
        {
            Thread.sleep(2000); // Pausing running thread for 2 sec.
        }
        catch(InterruptedException ie){
            System.out.println(ie.getMessage());
        }
        System.out.println("Java");
        System.out.println(Thread.currentThread());
    }
    void m1()
    {
        System.out.println("m1 method");
    }
    public static void main(String[] args)
    {
        A a = new A();
        Thread t = new Thread(a, "Child Thread");
        t.start();
        System.out.println("Number of active threads: " +Thread.activeCount());
        a.m1();
    }
}
//Context Switching between Multiple Threads using sleep() Method
class B implements Runnable
{
    public void run()
    {
        for(int i = 1; i <= 3; i++)
        {
            try
            {
                Thread.sleep(500);
            }
            catch (InterruptedException ie)
            {
                ie.printStackTrace();
            }
            System.out.println(Thread.currentThread() + " I: " +i);
        }
    }
    public static void main(String[] args)
    {
        B a1 = new B();
        Thread t1 = new Thread(a1, "First Child Thread");

        B a2 = new B();
        Thread t2 = new Thread(a2, "Second Child Thread");

        t1.start();
        t2.start();
    }
}
