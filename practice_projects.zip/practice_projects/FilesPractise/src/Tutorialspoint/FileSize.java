package Tutorialspoint;

import java.io.File;

public class FileSize {
    public static long getFileSize(String filename) {
        File file = new File(filename);
        if (!file.exists() || !file.isFile()) {
            System.out.println("File doesn\'t exist");
            return -1;
        }
        return file.length();
    }
    public static void main(String[] args) {
        long size = getFileSize("D:samplefile.txt");
        System.out.println("Filesize in bytes: " + size);
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.FileSize
        Filesize in bytes: 21
*/
class FileSizeExample {
    public static void main(String[] args) {
        File file = new File("D:samplefile.txt");
        if(file.exists()) {
            double bytes = file.length();
            double kilobytes = (bytes / 1024);
            double megabytes = (kilobytes / 1024);
            double gigabytes = (megabytes / 1024);
            double terabytes = (gigabytes / 1024);
            double petabytes = (terabytes / 1024);
            double exabytes = (petabytes / 1024);
            double zettabytes = (exabytes / 1024);
            double yottabytes = (zettabytes / 1024);

            System.out.println("bytes : " + bytes);
            System.out.println("kilobytes : " + kilobytes);
            System.out.println("megabytes : " + megabytes);
            System.out.println("gigabytes : " + gigabytes);
            System.out.println("terabytes : " + terabytes);
            System.out.println("petabytes : " + petabytes);
            System.out.println("exabytes : " + exabytes);
            System.out.println("zettabytes : " + zettabytes);
            System.out.println("yottabytes : " + yottabytes);
        } else {
            System.out.println("File does not exists!");
        }
    }
}/*/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.FileSizeExample
        bytes : 21.0
        kilobytes : 0.0205078125
        megabytes : 2.002716064453125E-5
        gigabytes : 1.955777406692505E-8
        terabytes : 1.9099388737231493E-11
        petabytes : 1.865174681370263E-14
        exabytes : 1.8214596497756474E-17
        zettabytes : 1.7787691892340307E-20
        yottabytes : 1.737079286361358E-23

        Process finished with exit code 0*/
