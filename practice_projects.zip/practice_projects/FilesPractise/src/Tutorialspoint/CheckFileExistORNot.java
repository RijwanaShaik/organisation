package Tutorialspoint;

import java.io.File;

public class CheckFileExistORNot {
    public static void main(String[] args) {
        File file=new File("D:myfile.txt");
        System.out.println(file.exists());
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.CheckFileExistORNot
        true*/
