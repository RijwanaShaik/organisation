package Tutorialspoint;

import java.io.File;
import java.io.IOException;

public class ReadOnlyFile {
    public static void main(String[] args) {
        File file = new File("D:samplefile.txt");
        System.out.println(file.setReadOnly());
        System.out.println(file.canWrite());
    }
}

//other method
/*class FileReadAttribute {
    public static void main(String[] args) throws IOException {
        File file = new File("c:/file.txt");
        file.setReadOnly();

        if(file.canWrite()) {
            System.out.println("This file is writable");
        } else {
            System.out.println("This file is read only");
        }
        file.setWritable(true);
        if(file.canWrite()) {
            System.out.println("This file is writable");
        } else {
            System.out.println("This file is read only");
        }
    }
}*/
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.ReadOnlyFile
        true
        false*/
