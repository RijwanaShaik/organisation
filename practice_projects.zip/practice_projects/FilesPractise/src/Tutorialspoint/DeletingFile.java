package Tutorialspoint;

import java.io.File;

public class DeletingFile {
    public static void main(String[] args) {
        try {
            File file = new File("D:myfile2.txt");
            if(file.delete()) {
                System.out.println(file.getName() + " is deleted!");
            } else {
                System.out.println("Delete operation is failed.");
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
/*
class Main {
    public static void main(String[] args) {
        try {
            BufferedWriter out = new BufferedWriter (new FileWriter("filename"));
            out.write("aString1\n");
            out.close();
            boolean success = (new File("filename")).delete();

            if (success) {
                System.out.println("The file has been successfully deleted");
            }
            BufferedReader in = new BufferedReader(new FileReader("filename"));
            String str;

            while ((str = in.readLine()) != null) {
                System.out.println(str);
            }
            in.close();
        }catch (IOException e) {
            System.out.println("exception occoured"+ e);
            System.out.println("
                    File does not exist or you are trying to read a file that has been deleted");
        }
    }
}*/
