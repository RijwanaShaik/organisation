package Tutorialspoint;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

public class ReadFileLineByLine {
    public static void main(String[] args) {
        try {

            // Creates a FileInputStream
            FileInputStream file = new FileInputStream("D:myfile.txt");

            // Creates a BufferedInputStream
            BufferedInputStream input = new BufferedInputStream(file);

            // Reads first byte from file
            int i = input .read();

            while (i != -1) {
                System.out.print((char) i);

                // Reads next byte from the file
                i = input.read();
            }
            input.close();
        }
        catch (Exception e) {
            e.getStackTrace();
        }
    }
}
//java program to read file using buffer reader
/*
class Main {
    public static void main(String[] args) {

        // Creates an array of character
        char[] array = new char[100];

        try {
            // Creates a FileReader
            FileReader file = new FileReader("input.txt");

            // Creates a BufferedReader
            BufferedReader input = new BufferedReader(file);

            // Reads characters
            input.read(array);
            System.out.println("Data in the file: ");
            System.out.println(array);

            // Closes the reader
            input.close();
        }

        catch(Exception e) {
            e.getStackTrace();
        }
    }
}*/
//java program to read file using scanner

/*
class Main {
    public static void main(String[] args) {

        try {
            // create a new file object
            File file = new File("input.txt");

            // create an object of Scanner
            // associated with the file
            Scanner sc = new Scanner(file);

            // read each line from file and print it
            System.out.println("Reading File Using Scanner:");
            while(sc.hasNextLine()) {
                System.out.println(sc.nextLine());
            }

            // close scanner
            sc.close();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}*/
