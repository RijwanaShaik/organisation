package Tutorialspoint;

import java.io.File;

public class CompareFiles {
    public static void main(String[] args) {
        File f1=new File("D:FileCopyOfExistedFile.txt");
        File f2=new File("D:FileOperationExample.txt");
       if(f1.compareTo(f2)==0){
           System.out.println("both are same! ");
       }else{
           System.out.println("both are not same");
       }
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.CompareFiles
        File f1=new File("D:myfile.txt");
        File f2=new File("D:FileOperationExample.txt");
        both are not same*/
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.CompareFiles
        File f1=new File("D:FileCopyOfExistedFile.txt");
        File f2=new File("D:FileOperationExample.txt");
        both are not same
*/
