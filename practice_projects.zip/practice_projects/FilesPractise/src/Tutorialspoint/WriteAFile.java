package Tutorialspoint;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteAFile {
    public static void main(String[] args) {
      /*  try {
            BufferedWriter w=new BufferedWriter(new FileWriter("D:myfile.txt"));
            w.write("aString");
            w.close();
            System.out.println("File is filled with text");
        }catch (IOException e){
            System.out.println(e);
        }*/
        //otherway
        try {
            String str="I'm writing in a file";
            File file=new File("D:myfile.txt");
            if(!file.exists()){
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(str);
            bw.close();

            System.out.println("Done");

        }catch (IOException e){
            System.out.println(e);
        }
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.WriteAFile
        File is filled with text
*/
//2 nd output
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.WriteAFile
        Done*/
