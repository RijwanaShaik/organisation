package Tutorialspoint;

import java.io.*;

public class CreatingFile {
    public static void main(String[] args) {
        try {
            File file=new File("D:myfile.txt");
            if(file.createNewFile()){
                System.out.println("Success! ");
            }else{
                System.out.println("Error ,file already exists");
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
