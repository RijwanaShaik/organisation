package Tutorialspoint;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadAFile {
    public static void main(String[] args) {
        try {
            BufferedReader in = new BufferedReader(new FileReader("D:myfile.txt"));
            String str;

            while ((str = in.readLine()) != null) {
                System.out.println(str);
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.ReadAFile
        I'm writing in a file
*/
/*
class CharacterStreamRead
{
    public static void main(String args[])throws Exception
    {
        FileReader fr=new FileReader("G:\\Internship\\File Handling\\NewFile.txt");
        int i;
        while((i=fr.read())!=-1)
            System.out.print((char)i);
        fr.close();
    }
}*/
/*
class ByteStreamRead
{
    public static void main(String[] args) {
        try  {
            InputStream fread = new FileInputStream("G:\\Internship\\File Handling\\NewFile.txt");
            Reader freader = new InputStreamReader(fread);
            int data = freader.read();
            while (data != -1) {
                System.out.print((char) data);
                data = freader.read();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}*/
