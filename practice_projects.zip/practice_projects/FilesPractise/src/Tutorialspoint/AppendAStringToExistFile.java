package Tutorialspoint;

import java.io.*;

public class AppendAStringToExistFile {
    public static void main(String[] args) {
        try {
            String data = " appending string";
            File f1 = new File("D:myfile.txt");
            if(!f1.exists()) {
                f1.createNewFile();
            }
            FileWriter fileWritter = new FileWriter(f1.getName(),true);
            BufferedWriter bw = new BufferedWriter(fileWritter);
            bw.write(data);
            bw.close();
            System.out.println("Done");

        } catch(IOException e){
            e.printStackTrace();
        }
        try {
            BufferedReader in = new BufferedReader(new FileReader("D:myfile.txt"));
            String str;

            while ((str = in.readLine()) != null) {
                System.out.println(str);
            }
            in.close();

        }catch (IOException e){
            System.out.println(e);
        }
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.AppendAStringToExistFile
        Done
        I'm writing in a file  appending string
        appending string
*/
class AppendFile {

    public static void main(String[] args) {

        String path = System.getProperty("user.dir") + "\\src\\test.txt";
        String text = "Added text";

        try {
            FileWriter fw = new FileWriter(path, true);
            fw.write(text);
            fw.close();
        }
        catch(IOException e) {
        }
        //other method
       /* String path = System.getProperty("user.dir") + "\\src\\test.txt";
        String text = "Added text";

        try {
            Files.write(Paths.get(path), text.getBytes(), StandardOpenOption.APPEND);
        } catch (IOException e) {
        }*/
    }
}