package Tutorialspoint;

import java.io.*;
import java.nio.file.Files;
import java.util.Scanner;

public class CopyingFile {
    public static void main(String[] args) throws Exception {
        File file1=new File("D:myfile2.txt");
        File file2=new File("D:myfile.txt");
        Files.copy(file1.toPath(),file2.toPath());
        System.out.println("copied successfully");
    }
}
class Main {
    public static void main(String[] args) throws Exception {
        BufferedWriter out1 = new BufferedWriter(new FileWriter("D:myfile2.txt"));
        out1.write("string to be copied\n");
        out1.close();
        InputStream in = new FileInputStream(new File("D:myfile2.txt"));
        OutputStream out = new FileOutputStream(new File("D:myfile.txt"));
        byte[] buf = new byte[1024];
        int len;

        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();
        BufferedReader in1 = new BufferedReader(new FileReader("D:myfile.txt"));
        String str;

        while ((str = in1.readLine()) != null) {
            System.out.println(str);
        }
        in.close();
    }
}
/*
public class CopyExample {
    public static void main(String[] args) {
        FileInputStream ins = null;
        FileOutputStream outs = null;
        try {
            File infile = new File("C:\\Users\\TutorialsPoint7\\Desktop\\abc.txt");
            File outfile = new File("C:\\Users\\TutorialsPoint7\\Desktop\\bbc.txt");
            ins = new FileInputStream(infile);
            outs = new FileOutputStream(outfile);
            byte[] buffer = new byte[1024];
            int length;

            while ((length = ins.read(buffer)) > 0) {
                outs.write(buffer, 0, length);
            }
            ins.close();
            outs.close();
            System.out.println("File copied successfully!!");
        } catch(IOException ioe) {
            ioe.printStackTrace();
        }
    }
}*/
class CopyFromFileaToFileb {

    public static void copyContent(File a, File b)
            throws Exception
    {
        FileInputStream in = new FileInputStream(a);
        FileOutputStream out = new FileOutputStream(b);

        try {

            int n;

            // read() function to read the
            // byte of data
            while ((n = in.read()) != -1) {
                // write() function to write
                // the byte of data
                out.write(n);
            }
        }
        finally {
            if (in != null) {

                // close() function to close the
                // stream
                in.close();
            }
            // close() function to close
            // the stream
            if (out != null) {
                out.close();
            }
        }
        System.out.println("File Copied");
    }

    public static void main(String[] args) throws Exception
    {
        Scanner sc = new Scanner(System.in);

        // get the source file name
        System.out.println(
                "Enter the source filename from where you have to read/copy :");
        String a = sc.nextLine();

        // source file
        File x = new File(a);

        // get the destination file name
        System.out.println(
                "Enter the destination filename where you have to write/paste :");
        String b = sc.nextLine();

        // destination file
        File y = new File(b);

        // method called to copy the
        // contents from x to y
        copyContent(x, y);
    }
}