package Tutorialspoint;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ChangingTheLastModficationTime {
    public static void main(String[] args) throws Exception{
        File fileToChange = new File ("D:samplefile.txt");
        fileToChange.createNewFile();
        Date filetime = new Date (fileToChange.lastModified());
        System.out.println(filetime.toString());
        System.out.println (fileToChange.setLastModified (System.currentTimeMillis()));
        filetime = new Date (fileToChange.lastModified());
        System.out.println(filetime.toString());
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.ChangingTheLastModficationTime
        Thu Oct 27 11:24:49 IST 2022
        true
        Thu Oct 27 11:24:57 IST 2022
*/
class GetFileLastModifiedExample2 {
    public static void main(String[] args) {
        File f1 = new File("D:samplefile.txt");
        System.out.println("Before Format : " + f1.lastModified());
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        System.out.println("After Format : " + sdf.format(f1.lastModified()));
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.GetFileLastModifiedExample2
        Before Format : 1666850097590
        After Format : 10/27/2022 11:24:57
*/
