package Tutorialspoint;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreateTempFile {
    public static void main(String[] args) throws Exception{
        File temp = File.createTempFile ("pattern", ".suffix");
        temp.deleteOnExit();
        BufferedWriter out = new BufferedWriter (new FileWriter(temp));
        out.write("aString");
        System.out.println("temporary file created:");
        //System.out.println(temp.getName());
        out.close();
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.CreateTempFile
        temporary file created:
*/
class CreateTempFileExample {
    public static void main(String[] args) {
        try {
            File f1 = File.createTempFile("temp-file-name", ".tmp");
            System.out.println("Temp file : " + f1.getAbsolutePath());
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
}