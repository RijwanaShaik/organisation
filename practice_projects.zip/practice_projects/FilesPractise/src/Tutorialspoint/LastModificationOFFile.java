package Tutorialspoint;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LastModificationOFFile {
    public static void main(String[] args) {
        File file = new File("D:myfile.txt");
        Long lastModified = file.lastModified();
        Date date = new Date(lastModified);
        System.out.println(date);
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise Tutorialspoint.LastModificationOFFile
        Thu Oct 27 10:57:05 IST 2022
*/
class GetFileLastModifiedExample {
    public static void main(String[] args) {
        File file = new File("D:samplefile.txt");
        System.out.println("Before Format : " + file.lastModified());
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        System.out.println("After Format : " + sdf.format(file.lastModified()));
    }
}