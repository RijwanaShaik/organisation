package J9;

import ExercisesOnExceptions.InvalidAmountException;

public class q5 {
}
class AgeNotWithInRange extends Exception{
    int code=0;
    public  AgeNotWithInRange(String msg,int code){
        super(msg);
        this.code=code;
    }

    @Override
    public String toString() {
        return "AgeNotWithInRange: "+" Message "+ this.getMessage()+ " code=" + code ;
    }
}
class NameNotValidException extends Exception{
    int code=0;
    public  NameNotValidException(String msg,int code){
        super(msg);
        this.code=code;
    }
    public String toString() {
        return "NameNotValidException: "+" Message "+ this.getMessage()+ " code=" + code ;
    }

}
class Stu{
    int rollNo;
    String name;
    int age;
    String course;
public void AgeNotBetweenRange() throws AgeNotWithInRange{
    if(age<15||age>21){
        throw new AgeNotWithInRange("Given age is not between 15 and 21 ",400);
    }else {
        System.out.println("Age is valid");
    }
}
    public void NameNotValid() throws NameNotValidException{
        if(name.contains("!") || name.equals(2)){
            throw new NameNotValidException("Name is not valid as it contains special characters",402);
        }else {
            System.out.println("Name is valid");
        }
    }
    public Stu(int rollNo, String name, int age, String course) {
        this.rollNo = rollNo;
        this.name = name;
        this.age = age;
        this.course = course;
    }

    @Override
    public String toString() {
        return "Stu{" +
                "rollNo=" + rollNo +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", course='" + course + '\'' +
                '}';
    }

    public static void main(String[] args) {
        Stu obj=new Stu(101,"r!jwana2",14,"Maths");
        System.out.println(obj);
try{
    obj.AgeNotBetweenRange();
}catch (AgeNotWithInRange ar){
    System.out.println(ar);
}try{
    obj.NameNotValid();
        }catch (NameNotValidException ne){
            System.out.println(ne);
        }
    }
}