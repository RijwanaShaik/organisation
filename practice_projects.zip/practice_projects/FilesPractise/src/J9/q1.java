package J9;

import java.util.Scanner;

public class q1 {
}
class MtC{
    public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);

       try{
           System.out.println("Enter the string ");
           String str=sc.next();
           System.out.println(str.length());
          // System.out.println(str.charAt(10));
           int strFormat= Integer.parseInt(str);
           System.out.println(strFormat);
       }catch (NullPointerException se){
           System.out.println(se);
       }
       catch (NumberFormatException nf){
           System.out.println(nf);
       }
    }
}
class mm{
    public static void main(String[] args) {
        int arr[]={10,20,0,3,4};
        String str[]={"hello","java"};
        try {
            Scanner sc = new Scanner(System.in);

            System.out.println("Enter the value dividend");
           int a = sc.nextInt();
           // String firstindex=sc.next();
            System.out.println("Enter the value divisor");
            int b = sc.nextInt();
           // String firstindex2=sc.next();
          //  System.out.println(firstindex.length());
          //  System.out.println(firstindex2.length());
            double result = arr[a] / arr[b];
            System.out.println("Select the string position");

           // System.out.println(result);
        }catch (ArrayIndexOutOfBoundsException ai) {
            System.out.println(ai);
        }catch (ArithmeticException ae){
            System.out.println(ae);
        }
    }
}