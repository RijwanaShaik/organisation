package J9;

import java.util.Scanner;

public class q7 {
}
interface Noficiation{
    void CreateNotification();
   void SendNotification();
}
class EmailNotification implements Noficiation{

    @Override
    public void CreateNotification() {
        System.out.println("EmailNotification created");
    }

    @Override
    public void SendNotification() {
        System.out.println("EmailNotification is sending");
    }
    void display(){
        CreateNotification();
        SendNotification();
    }
}
class SMSNotification implements Noficiation{
    @Override
    public void CreateNotification() {
        System.out.println("SMSNotification created");
    }

    @Override
    public void SendNotification() {
        System.out.println("SMSNotification is sending");
    }
    void display(){
        CreateNotification();
        SendNotification();
    }
}
class DesktopNotification implements Noficiation{
    @Override
    public void CreateNotification() {
        System.out.println("DesktopNotification created");
    }

    @Override
    public void SendNotification() {
        System.out.println("DesktopNotification is sending");
    }
    void display(){
        CreateNotification();
        SendNotification();
    }
}
class NotificationDemo{

    public static void main(String[] args) {

        EmailNotification em=new EmailNotification();
        /*em.CreateNotification();
        em.SendNotification();*/

        SMSNotification sm=new SMSNotification();
       /* sm.CreateNotification();
        sm.SendNotification();*/
        DesktopNotification dm=new DesktopNotification();
       /* dm.CreateNotification();
        dm.SendNotification();*/
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the notification type");


    }
}
class CommandEx{
    public static void main(String[] args) {
        try {
            int num1=Integer.parseInt(args[0]);
            int num2=Integer.parseInt(args[1]);

            int sum=num1+num2;
            System.out.println("The sum of two numbers are "+sum);
        }
        catch (ArithmeticException e){
            System.out.println(e);
        }
    }
}
class Example1 {
    public static void main(String[] args) {
        try {
            int[] a = new int[2];
            a[3] = Integer.parseInt(args[0]);

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e);
        }
    }
}