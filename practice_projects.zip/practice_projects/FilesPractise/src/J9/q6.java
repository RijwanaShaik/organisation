package J9;

public class q6 {
}
class MoreThanOneObjectCreationNotAllowed extends Exception{
public MoreThanOneObjectCreationNotAllowed(String msg){
    super(msg);
}

}
/*
class NotMoreException extends Exception
{
    NotMoreException()
    {
        super("Create no more object");
    }
}
*/

/*
class Test6
{
    static int a=0;
    Test6() throws NotMoreException
    {
        if (a == 0)
        {
            a++;
        }

        else
            throw new NotMoreException();
    }
*/

class Creation{
   static int cnt=0;
    Creation()throws MoreThanOneObjectCreationNotAllowed{
        if(cnt==0){
            cnt++;
            System.out.println("Object is created");
        }else {
            throw new MoreThanOneObjectCreationNotAllowed("Your are not allowed to create more than one object");
        }
    }

    /*public static void main(String[] args) {
        try {
            Creation obj = new Creation();
Creation newObject=new Creation();
        } catch (MoreThanOneObjectCreationNotAllowed mobj) {
            System.out.println(mobj);
        }
    }*/
}
class Testing{
    public static void main(String[] args) {
        try {
            Creation obj = new Creation();
            Creation newObject = new Creation();
        } catch (MoreThanOneObjectCreationNotAllowed mobj) {
            System.out.println(mobj);
        }
    }
}
/*
class Demo {
    public static void main(String[] args)
    {

        try
        {
            Test6 t1 = new Test6();
            Test6 t2 = new Test6();
            //Test6 t3 = new Test6();
        }
        catch (NotMoreException ex)
        {
            System.out.println(ex);
        }
    }
}*/
