package J9;

public class q2 {
}
