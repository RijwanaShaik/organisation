package Geeks;
import java.io.*;

/*
public class CopyingFileUsingStreams {
    public static void main(String[] args) {
        // Creating object of File class
        // Passing files from directory of local machine
        File file = new File(
                "/Users/mayanksolanki/Desktop/demo.rtf");
        File oFile = new File(
                "/Users/mayanksolanki/Desktop/outputdemo.rtf");

        // Now creating object of FileInputStream
        // Here they are variables
        FileInputStream fis = null;
        FileOutputStream fos = null;

        try {
            // Now we make them as objects of both classes
            // and passed reference of file in directory
            fis = new FileInputStream(file);
            fos = new FileOutputStream(oFile);
        }

        // Catch block to handle exceptions
        catch (FileNotFoundException e) {

            // Display message if exception occurs
            // File Not Found or Path is Incorrect
            System.out.println(e.printStackTrace());
        }

        try {

            // Now let us check how many bytes are available
            // inside content of file
            fis.available();
        }

        catch (Exception e) {
            e.printStackTrace();
        }

        // Using while loop to
        // write over outputdemo file
        int i = 0;
        while (i = fis.read() != -1) {
            fos.write(i);
        }

        // It will execute no matter what
        // to close connections which is
        // always good practice
        finally
        {

            // Closing the file connections

            // For input stream
            if (fis != null😉{
            fis.clsoe();
        }

            // For output stream
            if (fos != null) {
                fos.close();
            }
        }
    }
}

*/

class GFG {

    // Main driver method
    public static void main(String args[])
            throws FileNotFoundException, IOException
    {

        // If file doesnot exist FileInputStream throws
        // FileNotFoundException and read() write() throws
        // IOException if I/O error occurs
        FileInputStream fis = new FileInputStream(args[0]);

        // Assuming that the file exists and
        // need not to be checked
        FileOutputStream fos
                = new FileOutputStream(args[1]);

        int b;
        while ((b = fis.read()) != -1)
            fos.write(b);

        // read() method will read only next int so we used
        // while loop here in order to read upto end of file
        // and keep writing the read int into dest file
        fis.close();
        fos.close();
    }
}