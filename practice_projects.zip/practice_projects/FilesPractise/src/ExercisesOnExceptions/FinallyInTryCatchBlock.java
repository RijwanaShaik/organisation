package ExercisesOnExceptions;

public class FinallyInTryCatchBlock {
    public static void main(String[] args) {
        try{
            int a=9/0;
            System.out.println(a);
        }finally {
            System.out.println("The program is executed");
        }/*catch (ArithmeticException ae){
            System.out.println(ae);
        }*/
    }
}
