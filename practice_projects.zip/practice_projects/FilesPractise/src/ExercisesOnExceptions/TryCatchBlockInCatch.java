package ExercisesOnExceptions;

public class TryCatchBlockInCatch {
    public static void main(String[] args) {
        try{
            int[] arr={10,3,0,4};
            System.out.println(arr[0]/arr[2]);
        }catch (ArithmeticException ae){
            System.out.println(ae);
            try{
                String str=null;
                int val= Integer.parseInt(str);
                System.out.println(val);
            }catch (NumberFormatException nfe){
                System.out.println(nfe);
            }
        }
    }
}
