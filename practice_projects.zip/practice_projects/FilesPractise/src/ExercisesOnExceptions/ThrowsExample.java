package ExercisesOnExceptions;

public class ThrowsExample {
    int division(int a, int b) throws ArithmeticException{
        int result = a/b;
        return result;
    }
    public static void main(String args[]){
        ThrowsExample obj = new ThrowsExample();
      try{
            System.out.println(obj.division(15,0));
        }
        catch(ArithmeticException e){
            System.out.println("Division cannot be done using ZERO");
        }

    }
}
