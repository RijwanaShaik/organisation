package ExercisesOnExceptions;

public class IDNotValid extends Exception{
    public IDNotValid(String s) {
        super(s);
    }
}
class Demo
{
    static void find(int array[], int id) throws IDNotValid
    {
        boolean stdFlag = false;
        for (int i = 0; i < array.length; i++) {
            if(id == array[i])
                stdFlag = true;
        }
        if(!stdFlag)
        {
            throw new IDNotValid("ID is not Valid!");
        }
        else
        {
            System.out.println("ID is Valid!");
        }
    }
    public static void main(String[] args)
    {
        try
        {
            find(new int[]{101, 102, 103, 104, 105, 106, }, 108);
        }
        catch(IDNotValid e)
        {
            System.out.println(e);
        }
    }
}