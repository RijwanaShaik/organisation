package ExercisesOnExceptions;

import java.util.Scanner;

public class ThrowExample {
static  void checkEligibility(int marks){
    if(marks<600){
        throw new ArithmeticException("student is not eligible for scholarship");
    }else {
        System.out.println("you are eligible to scholarship ");
    }
}
    public static void main(String[] args) {
        System.out.println("Welcome to the registration process");
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your  marks");
       int a=sc.nextInt();
        checkEligibility(a);
        System.out.println("Have a nice day..");
    }
}
