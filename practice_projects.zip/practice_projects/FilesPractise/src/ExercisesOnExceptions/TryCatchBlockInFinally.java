package ExercisesOnExceptions;

public class TryCatchBlockInFinally {
    public static void main(String[] args) {
        try {
            // code that generates exception
            int divideByZero = 5 / 0;
        }

        catch (ArithmeticException e) {
            System.out.println("ArithmeticException => " + e.getMessage());
        }

        finally {
            try{
                String str=null;
                System.out.println(str.length());
            }catch (NullPointerException npe){
                System.out.println(npe);
            }
            System.out.println("This is the finally block");
        }

    }
}
