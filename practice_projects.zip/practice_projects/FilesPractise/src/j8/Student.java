package j8;

import java.util.Scanner;

public class Student {
    private String name;
    private String id;
    private int score;

    public Student(String initName, String initID, int initScore){
        this.name = initName;
        this.id = initID;
        this.score = initScore;
    }

    // declare getters such as these two
    public String getName() {
        return this.name;
    }

    public int getScore() {
        return this.score;
    }
    public static void main(String[] args) {
        Scanner s1 = new Scanner(System.in);
        // get number of students
        System.out.println("Enter the number of students:");
        int numberOfStudents = s1.nextInt();
        // initialize array of students
        Student[] array = new Student[numberOfStudents];
        for(int i = 0; i < numberOfStudents; i++) {
            // get name of the student
            System.out.println("Enter the student name:");
            String name = s1.nextLine();
            // get id of student
            System.out.println("Enter the student id:");
            String id = s1.nextLine();
            // get score of student
            System.out.println("Enter the student score:");
            int score = s1.nextInt();
            array[i] = new Student(name, id, score);
        }
        // now you have students input
        // it's time to find your student
        // set the lowest and highest student to first student
        Student min = array[0];
        Student max = array[0];
        /*for(int i = 1; i < numberOfStudents; i++) {
            if(min.getScore() > array[i]) {
                min = array[i];
            } else if(max.getScore() < array[i]) {
                max = array[i];
            }
        }*/
        System.out.println("the highest scoring student: "+max.getName());
        System.out.println("the lowest scoring student: "+min.getName());
    }
}
