package j8;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class CreateTempFile {
    public static void main(String[] args) {
        try {
            File f1 = File.createTempFile("temporary-file", ".tmp");
            File f2=new File("assignment_test_file.txt");
            System.out.println("Temp file : " + f1.getAbsolutePath());
            if (f1.createNewFile()){
                Files.copy(f2.toPath(),f1.toPath());
                System.out.println("copied successfully");
            }
            else{
                System.out.println("not copied");
            }
        } catch (
                IOException e) {
            e.printStackTrace();
        }
    }
}

