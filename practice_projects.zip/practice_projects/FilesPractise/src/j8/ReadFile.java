package j8;

import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class ReadFile {

    public static void main(String[] args) {
        try {
            FileReader fileReader=new FileReader("assignment_test_file.txt");
            Scanner sc=new Scanner(fileReader);
            while(sc.hasNextLine()){
                String str=sc.nextLine();
                System.out.println("Reading File with text before spliting : "+str+"\n");

                String[] strSplit=str.split("\\.");
                System.out.println("Reading a file and spliting the data based on delimiter: ");
                for(String text:strSplit){
                    System.out.println(text);
                }
                File f=new File("temporay-file.temp");
                System.out.println(f.getPath());
            }
            sc.close();
        }catch (Exception e){
            System.out.println("Exception occured check the program again");
        }
        System.out.println();
    }
}
    /*File f=new File("D:file.pdf");
        try{
                FileReader fr=new FileReader(f);
           *//* System.out.println(f.getPath());
            System.out.println(f.getAbsoluteFile());
            System.out.println(f.getAbsolutePath());*//*
                // System.out.println(f.getFreeSpace());
                Scanner sc=new Scanner(fr);
                String str="";
                while (sc.hasNextLine()){
                str=sc.nextLine();
                System.out.println(str);
                fr.read();
                fr.close();
                }

                }catch (IOException e){
                System.out.println("error");
                }*/