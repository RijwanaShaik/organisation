package j8;

import java.io.*;
import java.util.Scanner;

public class StringCount {
    public static void main(String[] args) throws Exception {

           File f1=new File("assignment_test_file.txt");

       /* String[] words=null;
        FileReader fr = new FileReader(f1);
        BufferedReader br = new BufferedReader(fr);
        String s;
        String input="Lorem";
        int count=0;
        while((s=br.readLine())!=null)
        {
           words=s.split("");
            for (String word : words)
            {
                if (word.equals(input))
                {
                    count++;    //If Present increase the count by one
                }
            }

        }
        if(count!=0)
        {
            System.out.println("The given word is present for "+count+ " Times in the file");
        }

        fr.close();
*//*
        Scanner sc1 = new Scanner(System.in);
        System.out.println("Enter the word to be found");
        String word = sc1.next();
        boolean flag = false;
        int count = 0;
        System.out.println("Contents of the line");
        //Reading the contents of the file
        Scanner sc2 = new Scanner(new FileInputStream("assignment_test_file.txt"));
        while(sc2.hasNextLine()) {
            String line = sc2.nextLine();
            System.out.println(line);
            if(line.indexOf(word)!=-1) {
                flag = true;
                count = count+1;
            }
        }
        if(flag) {
            System.out.println("File contains the specified word");
            System.out.println("Number of occurrences is: "+count);
        } else {
            System.out.println("File does not contain the specified word");
        }*/
    }
}
class Strcount{
    public static void main(String[] args) throws Exception {
      //  FileReader f1=new FileReader("assignment_test_file.txt");
        try{
            FileReader f1=new FileReader("assignment_test_file.txt");
            Scanner sc=new Scanner(f1);
          //  System.out.println("Enter the string");
            String str="";

            int count=0;
            while (sc.hasNextLine()){
                str=sc.nextLine();
                //System.out.println(str);
                if(f1.equals(str)){
                     count=count+1;
                    System.out.println("The word present"+count);
                }
              //  f1.read();
                f1.close();
            }

        }catch (IOException e){
            System.out.println("error");
        }
    }
}
class FileSearch {
    public static void main(String[] args) {
        // Testing only
        File f = new File("assignment_test_file.txt");
        String search = "Lorem Ipsum";
        System.out.printf("Result of searching for %s in %s was %b\n", search, f.getName(), FileSearch.find(f, search));
    }

    public static boolean find(File f, String searchString) {
        boolean result = false;
        Scanner in = null;
        try {
            in = new Scanner(new FileReader(f));
            while(in.hasNextLine() && !result) {
                result = in.nextLine().indexOf(searchString) >= 0;

            }
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        finally {
            try { in.close() ; } catch(Exception e) { /* ignore */ }
        }
        return result;
    }
}