package j8;

import java.io.File;

public class DeletingDirectory {
    public static void main(String[] args) {
boolean result;
String directory="D:\\Educative";
File file=new File(directory);
result=file.delete();
        System.out.println("The Directory is deleted: "+result);
    }
}
   /* public static void deleteDirectory(File file)
    {
        // store all the paths of files and folders present
        // inside directory
        for (File subfile : file.listFiles()) {

            // if it is a subfolder,e.g Rohan and Ritik,
            // recursiley call function to empty subfolder
            if (subfile.isDirectory()) {
                deleteDirectory(subfile);
            }

            // delete files and empty subfolders
            subfile.delete();
        }
    }

    public static void main(String[] args)
    {
        // store file path
        String filepath = "D:\\Educative";
        File file = new File(filepath);

        // call deleteDirectory function to delete
        // subdirectory and files
        deleteDirectory(file);

        // delete main GFG folder
        file.delete();
    }*/
//}


/*public class DeleteDirectory {
    public static void main(String[] args) {
       *//* boolean result;
        String directory="D:\\ProjectDirectory";
        File file=new File(directory);
        result=file.delete();
        System.out.println("The Directory is deleted: "+result);*//*
        try {
            // create a new file object
            File directory = new File("Directory");

            // delete the directory
            boolean result = directory.delete();

            if(result) {
                System.out.println("Directory Deleted");
            }
            else {
                System.out.println("Directory not Found");
            }

        } catch (Exception e) {
            e.getStackTrace();
        }

    }
}*/
/*
/home/thrymrthrymr123/Documents/practice_projects/JavaAssignment 8/out/production/JavaAssignment 8 PackageFileOperations.DeletingTempFile
        The Directory is deleted: true
*/
