package j8;

import java.io.File;

public class SizePathOfAFile {
    public static void main(String[] args) {
        File file=new File("assignment_test_file.txt");
        if(file.exists()){
            System.out.println(file.length());
            System.out.println(file.getAbsolutePath());
            System.out.println(file.getAbsoluteFile());
            System.out.println(file.getPath());
        }else {
            System.out.println("Given file name is not matching");
        }
    }
}
