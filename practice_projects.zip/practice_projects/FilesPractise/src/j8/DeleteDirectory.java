package j8;

import java.io.File;
import java.nio.file.SecureDirectoryStream;

public class DeleteDirectory {
        public static void main(String[] args)
        {
            // store file path
            String filepath = "D:\\Educative";
            File file = new File(filepath);

            // call deleteDirectory method to delete directory
            // recursively
           // SecureDirectoryStream<File> FileUtils;
            //FileUtils.deleteDirectory(file);

            // delete GFG folder
            file.delete();
        }

}
