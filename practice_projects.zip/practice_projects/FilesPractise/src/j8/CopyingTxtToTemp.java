package j8;

import java.io.File;
import java.nio.file.Files;

public class CopyingTxtToTemp {
    public static void main(String[] args) throws Exception {
        File file1=new File("assignment_test_file.txt");
        File file2=new File("temporary-file.temp");
        Files.copy(file1.toPath(),file2.toPath());
        System.out.println("copied successfully");
    }
}
class ss{
    public static void main(String[] args) throws Exception{
        File file1=new File("assignment_test_file.txt");
        File f1 = File.createTempFile("temporary1-file", ".tmp");
Files.copy(f1.toPath(),file1.toPath());
        System.out.println("copied Sucessfully");

    }
}