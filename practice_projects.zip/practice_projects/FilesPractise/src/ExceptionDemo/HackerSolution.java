package ExceptionDemo;

import java.util.InputMismatchException;
import java.util.Scanner;

//You will be given two integers  and  as input, you have to compute .
// If  and  are not  bit signed integers or if  is zero, exception will occur and you have to report it. Read sample Input/Output to know what to report in case of exceptions.
public class HackerSolution {
    public static void main(String[] args) {
        try{
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter the x,y values");
            int x=sc.nextInt(),y=sc.nextInt();
            System.out.println(x/y);
        }catch (InputMismatchException e){
            System.out.println(e.getClass().getName());
        }catch (ArithmeticException e){
            System.out.println(e);
        }
    }
}
    /*Enter the x,y values
        10
        Hello
        java.util.InputMismatchException
*/
    /*Enter the x,y values
        10
        0
        java.lang.ArithmeticException: / by zero
*/
   /* Enter the x,y values
        23.323
        java.util.InputMismatchException
*/