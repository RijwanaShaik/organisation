package ExceptionDemo;

public class SingleTryCatch {
    public static void main(String[] args) {
        try{
            int a=10;
            int b=0;
            int z=a/b;
            System.out.println(z);
        }catch (ArithmeticException e){
            System.out.println("ArithmeticExsception "+e.getMessage());

        }
    }
}
