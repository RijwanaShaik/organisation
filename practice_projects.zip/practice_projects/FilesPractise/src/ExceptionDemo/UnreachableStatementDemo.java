package ExceptionDemo;

public class UnreachableStatementDemo {
    public static void main(String[] args) {
        try {
            throw new Exception("Custom exception");
          //  System.out.println("An exception was thrown");

        } catch (Exception e) {
            System.out.println(e.getMessage() + " was caught");
        }
    }
}
