package ExceptionDemo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TryWithResourceAndFinally {
    public static void main(String[] args) {
        BufferedReader br = null;
        String line;

        try {
            System.out.println("Entering try block");
            br = new BufferedReader(new FileReader("D:myfile.txt"));
            while ((line = br.readLine()) != null) {
                System.out.println("Line =>"+line);
            }
        } catch (IOException e) {
            System.out.println("IOException in try block =>" + e.getMessage());
        } finally {
            System.out.println("Entering finally block");
            try {
                if (br != null) {
                    br.close();
                }

            } catch (IOException e) {
                System.out.println("IOException in finally block =>"+e.getMessage());
            }

        }
    }
}
//The try-with-resources statement does automatic resource management.
// We need not explicitly close the resources as JVM automatically closes them. This makes the code more readable and easier to write.

class experiment{
    public static void main(String[] args) {
        try{
            System.out.println(50/0);
        }finally {
            System.out.println("we can use finally block with only try block");
        }
    }
}
