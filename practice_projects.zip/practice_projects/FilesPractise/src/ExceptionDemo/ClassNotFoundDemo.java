package ExceptionDemo;

public class ClassNotFoundDemo {
    public static void main(String[] args) {
        try{
            Class.forName("SingleTryCatch");
        }catch (ClassNotFoundException e){
            System.out.println(e);
       }
        System.out.println("program finished");
    }
}
class UserDefinedCustomException extends Exception {
   // ErrorCode code = ErrorCode.DEFAULT_ERROR;
  //  String errorMessage = "";
    int code=0;
    public UserDefinedCustomException(String errorMessage, int code) {
        super(errorMessage);
        this.code = code;
    }

    public UserDefinedCustomException(String errorMessage) {
        super(errorMessage);
    }


    @Override
    public String toString(){
        return "Message : "+this.getMessage()+" \n Error Cause : "+this.code;
    }
}

/**
 * Custom Exception Demo
 */
class CustomExceptionDemo2 {

    public void callDefaultExceptionCode() throws UserDefinedCustomException {
        throw new UserDefinedCustomException("Custom Exception Default ");
    }

    public void callBadRequestExceptionCode() throws UserDefinedCustomException {
        throw new UserDefinedCustomException("Custom Exception Bad Request ",300);
    }

    public void callLogicExceptionCode() throws UserDefinedCustomException{
        throw new UserDefinedCustomException("Custom Exception Logic Failure  ",404);
    }

    public static void main(String[] args){
        CustomExceptionDemo2 demo = new CustomExceptionDemo2();
        try{
            demo.callDefaultExceptionCode();
        }catch(UserDefinedCustomException ex){
            System.out.println(ex);
        }
        try{
            demo.callBadRequestExceptionCode();
        }catch(UserDefinedCustomException ex){
            System.out.println(ex);
        }
        try{
            demo.callLogicExceptionCode();
        }catch(UserDefinedCustomException ex){
            System.out.println(ex);
        }

    }
}