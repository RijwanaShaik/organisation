package ExceptionDemo;

public class UnreachableStatementDemo1 {
    public static void main(String[] args) {
        try{
            int i=Integer.parseInt("abc");

        }catch (NumberFormatException nf){
            System.out.println(nf);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
