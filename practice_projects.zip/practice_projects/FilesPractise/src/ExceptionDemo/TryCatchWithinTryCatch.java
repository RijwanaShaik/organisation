package ExceptionDemo;

public class TryCatchWithinTryCatch {
    public static void main(String[] args) {

            try{
                int arr[]={7,0,12,8};
                try{
                    int x=arr[2]/arr[1];
                }catch (ArithmeticException e){
                    System.out.println("Divide by Zero Exception");
                }

                arr[4]=3;
            }catch (ArrayIndexOutOfBoundsException e1){

                System.out.println("Array index is out of bound");
            }
    }
}
