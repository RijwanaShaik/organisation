package ExceptionDemo;

public class SingleTryMultipleCatch {
    public static void main(String[] args) {
        try{
            int[] arr=new int[2];
            arr[4]=30/0;
            System.out.println("output in the try block");
        }catch (ArithmeticException e){
            System.out.println("ArithmaticException occured "+e.getMessage());
        }catch (ArrayIndexOutOfBoundsException ab){
            System.out.println("ArrayIndexoutboundsexception occurs");
        }catch (Exception exception){
            System.out.println("something went wrong");
        }
    }
}
