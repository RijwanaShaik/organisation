package ExceptionDemo;

import java.util.Scanner;

public class HackerSolution2 {
    public static int power(int n,int p) throws Exception{
        if(n<0||p<0){
            throw new Exception("n or p should not be negative");
        }else if(n==0 && p==0){
            throw new Exception("n and p should not be zero");
        }
        else {
            return ((int)Math.pow(n,p));
        }
    }
    public static void main(String[] args) {

    }
}
//
class solution {
    public static final HackerSolution2 my_calculator = new HackerSolution2();
    public static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        while (in .hasNextInt()) {
            int n = in .nextInt();
            int p = in .nextInt();
            HackerSolution2 my_calculator = new HackerSolution2();
            try {
                System.out.println(my_calculator.power(n, p));
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }
}
/*3 5
        243
        2 4
        16
        0 0
        java.lang.Exception: n and p should not be zero
        -1 -2
        java.lang.Exception: n or p should not be negative
        -1 3
        java.lang.Exception: n or p should not be negative
*/