package PackageException;
//6.Write a Java program which creates only one object for a class .
// If user attempts to create morethan one object, Raise an Exception. (UsingException Handling)
public class ObjectCreation {
    static int cnt=0;
   ObjectCreation()throws MoreThanOneObjectCreationNotAllowed{
        if(cnt==0){
            cnt++;
            System.out.println("Object is created");
        }else {
            throw new MoreThanOneObjectCreationNotAllowed("Your are not allowed to create more than one object");
        }
    }

    public static void main(String[] args) {
        try {
            ObjectCreation obj = new ObjectCreation();
            ObjectCreation newObject = new ObjectCreation();
        } catch (MoreThanOneObjectCreationNotAllowed mobj) {
            System.out.println(mobj);
        }
    }
}
