package PackageException;

import java.util.Scanner;
//3.Write a program to illustrate the throw keyword in Java.Give a proper example
public class Throw {
    static  void checkEligibility(int marks){
        if(marks<600){
            throw new ArithmeticException("student is not eligible for scholarship");
        }else {
            System.out.println("you are eligible to scholarship ");
        }
    }
    public static void main(String[] args) {
        System.out.println("Welcome to the registration process");
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your  marks");
        int a=sc.nextInt();
        checkEligibility(a);
        System.out.println("Have a nice day..");
    }
}
