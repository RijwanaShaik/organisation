package PackageException;
//4.Write a program to demonstrate Try-catch-finally & try-finally
public class TryFinally {
    public static void main(String[] args) {
        try{
            int x, y, z;
            x = 5;
            y = 0;
            z = x / y;
            System.out.println(z);
        }finally {
            System.out.println("we can use finally block with only try block");
        }
    }
}
