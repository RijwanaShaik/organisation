package PackageException;

public class AgeNotWithInRange extends Exception{
    int code=0;
    public  AgeNotWithInRange(String msg,int code){
        super(msg);
        this.code=code;
    }

    @Override
    public String toString() {
        return "AgeNotWithInRange: "+" Message "+ this.getMessage()+ " code=" + code ;
    }
}
