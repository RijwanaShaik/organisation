package PackageException;
//5.Create a class Student with attributes roll no, name, age and course.
// Initialize values through parameterized constructor.
// If age of student is not in between 15 and 21 then generate user-defined exception "AgeNotWithinRangeException" with error code 400.
// If name contains numbers or special symbols raise exception "NameNotValidException"with error code 402. Define the two exception classes.
public class Student {
    int rollNo;
    String name;
    int age;
    String course;
    public void AgeNotBetweenRange() throws AgeNotWithInRange{
        if(age<15||age>21){
            throw new AgeNotWithInRange("Given age is not between 15 and 21 ",400);
        }else {
            System.out.println("Age is valid");
        }
    }
    public void NameNotValid() throws NameNotValidException{
        if(name.contains("!")){
            throw new NameNotValidException("Name is not valid as it contains special characters",402);
        }else {
            System.out.println("Name is valid");
        }
    }
    public Student(int rollNo, String name, int age, String course) {
        this.rollNo = rollNo;
        this.name = name;
        this.age = age;
        this.course = course;
    }

    @Override
    public String toString() {
        return "Stu{" +
                "rollNo=" + rollNo +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", course='" + course + '\'' +
                '}';
    }

    public static void main(String[] args) {
        Student obj=new Student(101,"r!jwana",14,"Maths");
        System.out.println(obj);
        try{
            obj.AgeNotBetweenRange();
        }catch (AgeNotWithInRange ar){
            System.out.println(ar);
        }try{
            obj.NameNotValid();
        }catch (NameNotValidException ne){
            System.out.println(ne);
        }
    }
}
