package PackageException;

import java.util.Scanner;
//1.Write a Java program to illustrate multiple catch block using command line argument. Give a proper example
public class MultipleCatchBlocks {
    public void writeList(int first,int second) {

       int arr[]={10,20,0,40,4};
        try {
           double result= arr[first]/arr[second];
            System.out.println(result);
        }
        catch (ArithmeticException ae){
         System.out.println("Arthimetic exception occured"+ae.getMessage());
        }
        catch (NumberFormatException nfe) {
            System.out.println("NumberFormatException => " + nfe.getMessage());
        }

        catch (ArrayIndexOutOfBoundsException abe) {
            System.out.println("ArrayIndexOutOfBoundsException => " + abe.getMessage());
        }

    }

    public static void main(String[] args) {
        MultipleCatchBlocks list = new MultipleCatchBlocks();
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the first value");
        int first=sc.nextInt();
        System.out.println("Enter the second value");
        int second=sc.nextInt();
        list.writeList(first,second);
    }
}
//In first output we are dividing the 20/0 so the result exception is catched by arthimatic exception
    /*Enter the first value
1
        Enter the second value
        2
        Arthimetic exception occured/ by zero
*/
//In second output we are dividing the 20/array out of index  so the result exception is catched by ArrayIndexoutOfBount exception

   /* Enter the first value
1
        Enter the second value
        8
        ArrayIndexOutOfBoundsException => Index 8 out of bounds for length 5
*/