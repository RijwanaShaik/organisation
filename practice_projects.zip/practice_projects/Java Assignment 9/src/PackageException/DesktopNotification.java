package PackageException;

public class DesktopNotification implements Noficiation{
    @Override
    public void createNotification() {
        System.out.println("DesktopNotification created");
    }

    @Override
    public void sendNotification() {

        System.out.println("DesktopNotification is sending");
    }

}
