package PackageException;

public class SMSNotification implements Noficiation{
    @Override
    public void createNotification() {
        System.out.println("SMSNotification created");
    }

    @Override
    public void sendNotification() {

        System.out.println("SMSNotification is sending");
    }
}
