package PackageException;

public class EmailNotification implements Noficiation{

    @Override
    public void createNotification() {
        System.out.println("EmailNotification created");
    }

    @Override
    public void sendNotification() {

        System.out.println("EmailNotification is sending");
    }

}
