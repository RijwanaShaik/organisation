package PackageException;
//2.Write a program to illustrate the throws keyword in Java.Give a proper example
public class ThrowsExample {
    int division(int a, int b) throws ArithmeticException{
        int result = a/b;
        return result;
    }
    public static void main(String args[]){
        ThrowsExample obj = new ThrowsExample();
        try{
            System.out.println(obj.division(15,0));
        }
        catch(ArithmeticException e){
            System.out.println("Division cannot be done using ZERO");
        }

    }
}
//throws keyword as method signature and is used to provide information to the caller about the exception to  handle it.