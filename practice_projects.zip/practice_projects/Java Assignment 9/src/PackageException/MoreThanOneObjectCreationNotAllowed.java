package PackageException;

public class MoreThanOneObjectCreationNotAllowed extends Exception{
    public MoreThanOneObjectCreationNotAllowed(String msg){
        super(msg);
    }

}
