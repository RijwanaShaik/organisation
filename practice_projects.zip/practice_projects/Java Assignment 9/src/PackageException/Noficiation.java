package PackageException;

public interface Noficiation {
    void createNotification();
    void sendNotification();
}
