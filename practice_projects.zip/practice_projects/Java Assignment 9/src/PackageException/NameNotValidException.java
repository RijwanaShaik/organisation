package PackageException;

public class NameNotValidException extends Exception{
    int code=0;
    public  NameNotValidException(String msg,int code){
        super(msg);
        this.code=code;
    }
    public String toString() {
        return "NameNotValidException: "+" Message "+ this.getMessage()+ " code=" + code ;
    }
}
