package PackageException;

import java.util.Scanner;
//7.Create an Interface “Notification” with abstract methods createNotification(), sendNotification(). EmailNotification, SMSNotification, DesktopNotification classes should have contracts with Notification Interface and implement the abstract methods accordingly. Create a NotificationDemo class for the main method to execute the createNotification, sendNotification of different classes based on user input. Input should be recorded from command line args
public class NotificationDemo {
    public static void main(String args[]) {
        Noficiation em = null;

        Scanner sc=new Scanner(System.in);
        String st=sc.next();
        if(st.equalsIgnoreCase("Email")){
            em=new EmailNotification();
          //  em.createNotification();
        }else if(st.equalsIgnoreCase("SMS")){
            em=new SMSNotification();
        }else if(st.equalsIgnoreCase("Desktop")){
            em=new DesktopNotification();
        }
        em.createNotification();
        em.sendNotification();

    }
}
/*
class Employee {
    int id;
    String name;
    // String designation;
//    float salary;

    public Employee(int id, String name) {
        this.id = id;
        this.name = name;
        //  this.designation = designation;
        //  this.salary = salary;
    }

Employee(){

}
    @Override
    public String toString() {
        return
                "id=" + id +
                        ", name='" + name;
    }

    public static void menu() {

        // Printing statements displaying menu on console
        System.out.println("MENU");
        System.out.println("1: enter id ,name");
        System.out.println("2: do you want add more data Yes or No");

        System.out.print("Enter your selection : ");
    }

    public static void main(String[] args) {
        int size = 10;
        Employee[] emp = new Employee[size];
        int count = 0;
        Scanner sc = new Scanner(System.in);
        int option = 0;
        do {
            menu();
            option = sc.nextInt();
            switch (option) {
                case 1:
                    System.out.print("Enter the id");
                    int id = sc.nextInt();
                    System.out.println("Enter the name");
                    String name = sc.next();
                    Employee obj = new Employee(id, name);
                    System.out.println(obj);

                    break;
                case 2:
                    String result = "";
                    if (sc.equals("yes")) {
                        //   System.out.println((case 1));

                    } else {
                        System.out.println("you cann't enter data");
                    }
                    break;
                default:
                    System.out.println("");
            }
        }
        while (option != 3);


for(int i=0;i< emp.length;i++)

    {
        emp[i]=new Employee();
       // System.out.println();
    }
for(Employee e:emp){
    System.out.println(e.id+e.name);
}

}
    }


class Employ{
    int id;
    String name;

    public Employ(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Employ{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

    public static void main(String[] args) {
        int size=3;
        Employ[] emparray= new Employ[size];
        int count=0;
        Scanner sc=new Scanner(System.in);

        */
/*System.out.println("Enter id");
        int id=sc.nextInt();
        System.out.println("Enter name");
        String name=sc.next();*//*

      //  System.out.println(id+" "+name);
      //  Employ[] obj= new Employ[em.length];
        for(int i=0;i<size;i++){
            Employ emp=new Employ(sc.nextInt(),sc.next());
            emparray[i]=emp;
           // System.out.println(emp);

        }

        System.out.println("Employee details are");
        for(int i=0;i<size;i++){
            System.out.println(emparray[i]);
        }
        Employ[] temp=new Employ[size];
        emparray=temp;
        temp=null;
for(int i=0;i<emparray.length;i++){
    System.out.println(emparray[i]);
}
        System.out.println(emparray.length);
        if(count>=(size-2)){
           size=size+5;

        }
    }
}*/
