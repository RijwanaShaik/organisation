package Arrays;

import java.util.Arrays;
import java.util.Scanner;

public class SortingArray {
    public static void main(String[] args) {
        int arr[] = {50, 25, 30, 55, 15};
        String[] str={"rahul","geeks","tutorial"};
      // Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
      //  Arrays.sort(str);
        System.out.println(Arrays.toString(str));
        //converting string array to string
        String st=Arrays.toString(str);
       // System.out.println(st);
        //to get array in ascending order
       for(int i=0;i< arr.length-1;i++) {
           if (arr[i] >arr[i+1]) {//if(arr[i]<arr[i+1] descending order
              int temp=arr[i];
              arr[i]=arr[i+1];
               arr[i+1]=temp;
               i=-1;
           }
       }
           for(int i=0;i<arr.length;i++) {

               System.out.println(arr[i] + " ");

           }

    }
}
class SortingArrayByScanner{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of array");
        int size= sc.nextInt();
        String arr[]=new String[size];
        System.out.println("Enter string array elements");
        for(int i=0;i<arr.length;i++){
            arr[i]=sc.next();
        }
        System.out.println("Enter the key");
        String key=sc.next();
       // String result=key;
        for(int i=0;i<arr.length;i++) {
            if (arr[i].contains(key)) {
                System.out.println("founded");
            }
        }
        System.out.println(Arrays.toString(arr));

    }
}