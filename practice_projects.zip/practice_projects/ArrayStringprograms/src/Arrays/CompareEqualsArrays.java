package Arrays;

import java.util.Arrays;

public class CompareEqualsArrays {
    public static void main(String[] args) {
        int arr[]={10,20,30};
int arr1[]={20,30,40};
int arr2[]=arr1;
//== operator
if(arr==arr1){
    System.out.println("both are equals");
}
else {
    System.out.println("not equal");
}
//equals
        if(arr.equals(arr1)){
            System.out.println("both are equals");
        }
        else {
            System.out.println("not equal");
        }
        //Arrays.equals method
        if(Arrays.equals(arr1,arr2)){
            System.out.println("both are equals");
        }
        else {
            System.out.println("not equal");
        }
        //for multidemnision or 2-d Arrays.deepEquals(arr1,arr2) methods are useful
    }
}
