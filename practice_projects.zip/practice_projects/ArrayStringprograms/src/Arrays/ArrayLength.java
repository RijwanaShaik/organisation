package Arrays;

import java.util.Arrays;

public class ArrayLength {
    public static void main(String[] args) {
        int arr[]={10,20,30};
        System.out.println(arr.length);//to know the array length
        //to get arr values use for loop
        System.out.println("Array elements are");
        for(int i=0;i< arr.length;i++){
            System.out.println(arr[i]);
        }
        //using for each loop
        for(int i:arr){
            System.out.println(i);
        }
        //using predefined method
        System.out.println(Arrays.toString(arr));

        String[] str={"rahul","geeks","tutorial"};
        System.out.println(str.length);//to know string length
        //to get string elements use for loop
        String[] st=new String[]{"rahul","gee"};//string array object

        for(int i=0;i< st.length;i++){
           System.out.print(st[i]);
        }
        //using for each
        for(String i:str){
            System.out.println(i);
        }
        //using predefined method
        System.out.println(Arrays.toString(str));
    }
}
//array length of 2-d
 class TestArray{

    public static void main(String[] args) {

        // 2d array
        int[][] a = {{10,20},{30,40},{50,60}};
String[][] b={{"ab","bc"},{"dc","ef"}};//string array
        // display size of array
        System.out.println("2D array size = "+ a.length);
        System.out.println("First row size = "+ a[0].length);
        System.out.println("Second row size = "+ a[1].length);

        // display array using length property
        System.out.println("Array elements:");
        for(int i=0; i < a.length; i++){
            for (int j=0; j < a[i].length; j++) {
                System.out.print(a[i][j]+"\t");
            }
            System.out.println();
        }
        //using for each loop
        for(int i[]:a){
            for(int j:i){
                System.out.println(j);

            }
        }
        //using direct/predefined method
        System.out.println("using predefined method"+Arrays.deepToString(a));
        //to get string arrays
        System.out.println("Array string elements:");
        for(int i=0; i < b.length; i++){
            for (int j=0; j < b[i].length; j++) {
                System.out.print(b[i][j]+"\t");
            }
            System.out.println();
        }
    }
}