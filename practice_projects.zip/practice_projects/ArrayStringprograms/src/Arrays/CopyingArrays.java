package Arrays;

import java.util.Arrays;
//firts create other arrayof 1-D
//copying of arrays can be done by =,System.arraycopy(),Arrays.copyOf()
//Arrays.copyOfRange(),name of array.clone():-e.gint[] arrcopy=arr.clone()

public class CopyingArrays {
    public static void main(String[] args) {
        int arr[]={10,20,30};
        int[] arr2=arr;//copying array using assignment(=) operator;
        System.out.println(Arrays.toString(arr2));

        // create new array with similar type and size
        int newArr[] = new int[arr.length];

        // copy array using System.arraycopy
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        System.out.println(Arrays.toString(newArr));
        //copy using loop
        for(int i=0;i<arr.length;i++){
            newArr[i]=arr[i];
        }
        System.out.println(Arrays.toString(newArr));
//using Arrays.copyOf()Method
        int[] arr3={1,2,3,4};
        int[] newArr2=Arrays.copyOf(arr3,arr3.length);
        //using Arrays.copyOfRange()Method
        int[] newArr3=Arrays.copyOfRange(arr3,0,arr3.length);

        System.out.println(Arrays.toString(newArr2));
        System.out.println(Arrays.toString(newArr3));

    }
}
class CopyingArrayString{
    public static void main(String[] args) {
        String str[]={"java","world"};
        //copying array using System.arraycopy()
        String[] newArr=new String[str.length];
        System.arraycopy(str,0,newArr,0,str.length);
        //copy using Arrays.copuOf()
        // String[] newArr = Arrays.copyOf(str, str.length);

        // copy using clone()
        // String[] newArr = str.clone();
        System.out.println("Original Array = " + Arrays.toString(str));
        System.out.println("Copied Array = " + Arrays.toString(newArr));

       }
    }