package Shorts;

public class PrintingTables2to10 {
    public static void main(String[] args) {
        /*for(int i=1;i<=10;i++){
            for(int j=1;j<=10;j++){
                System.out.printf(" %2d ",(i*j));
            }
            System.out.println();
        }*/
        int num=0;
        while (num < 130){
            if( num % 2==1){
                System.out.println(num);
            }
            num++;
        }
    }
}
