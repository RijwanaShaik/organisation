package Shorts;

public class NumberSeries {
    public static void main(String[] args) {
        int n=10;
        int x=0;
        int y=0;

        /*for(int i=1;i<=n;i++){
            x=n-i+1;
            for(int j=1;j<=n;j++){
                System.out.printf(" %2d ",x);
                x=x+n;
            }
            System.out.println();
        }*/
        /*for (int i=1;i<=n;i++){
            x=i;
            y=n-i+1;
            for (int j=1;j<=n;j++){
                if(j%2==1){
                    System.out.printf(" %2d ",x);
                }else {
                    System.out.printf(" %2d ",y);
                }
                x=x+n;
                y=y+n;
            }
            System.out.println();
        }*/
        /*for(int i=1;i<=n;i++){
            for (int j=1;j<=n;j++){
                System.out.printf(" %2d ",(2*(i+j))-3);
            }
            System.out.println();
        }*/
       /* for(int i=1;i<=n;i++){
            for (int j=1;j<=n;j++){
                System.out.printf(" %2d ",x);//the x starts with 0,becasue you given x=0;change and see the result
                x+=2;
            }
            System.out.println();
        }*/
       /* for(int i=1;i<=10;i++){
            for(int j=1;j<=10;j++){//make here j<=i
                System.out.print(j+" ");//print i
            }
            System.out.println();
        }*/
        /*for(int i=10;i>=1;i--){
            for (int j=1;j<=10;j++)
                System.out.print(i+" ");//try to print with j
            }
            System.out.println();
        }*/
        int z=1;
        int c=8;
        for(int i=1;i<=c;i++){
            for (int j=1;j<=c;j++){
                System.out.printf(" %2d",z);
                z+=2;
            }
            System.out.println();
        }
        //other method
        int num=0;
        while (num < 130){
            if( num % 2==1){
                System.out.println(num);
            }
            num++;
        }
       /* for(int i=1;i<=10;i++) {
            x=i;
            for (int j = 1; j <= 10; j++) {
                System.out.printf(" %2d",x);
                x+=n;
            }
            System.out.println();
        }*/
    }
}
