package PackageDateAndCalendar;
//    5. Perform following actions sequentially
//        a. Take a. date String (Your choice of format)
//        b. convert String to date object
//        c. date to calendar object
//        d. Increase day by 1
//        e. convert calendar object to date object
//        f. date to string(Your choice of format)
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ActionsSequentially {

    public static void main(String[] args) throws Exception{
        String str= "2010/05/20 11:30:00";
        System.out.println("Original String is : "+str);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/d hh:mm:ss");

        Date date = sdf.parse(str);
        System.out.println("String converted to Date : "+date);

        // Converting Date to calendar
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        System.out.println("Date converted to Calendar : "+calendar.getTime());

        // Increasing 1 day
        calendar.add(Calendar.DAY_OF_MONTH,1);
        System.out.println("Increasing 1 day :"+calendar.getTime());

        // Calendar to Date
        Date date1=calendar.getTime();
        System.out.println("Calendar to date :"+date1);

        // Date to string
        SimpleDateFormat sdf1=new SimpleDateFormat("dd-MM-yyy");
        String strDate=sdf1.format(date1);
        System.out.println("Date to String :"+strDate);

    }
}
