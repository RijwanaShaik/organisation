package PackageDateAndCalendar;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

//2.Take 2 different date objects and find the date which comes first
public class DatesWhichComesFirst {
    public static void main(String[] args)  {

        LocalDate date1 = LocalDate.of(2022, 03, 20);
        LocalDate date2 = LocalDate.of(2021, 05, 28);
        if (date1.isBefore(date2)) {

            System.out.println("Date1 comes isBefore Date2");
        }
        else if (date1.isAfter(date2)) {
            System.out.println("Date1 comes After Date2");
        }
    }

}

class FindingFirstOccuranceDate {
    public static  void main(String[] args) {
        Calendar firstDate = new GregorianCalendar(2022, Calendar.DECEMBER, 24);
        Calendar secondDate = new GregorianCalendar(2022, Calendar.DECEMBER, 27);
        Date date1 = firstDate.getTime();
        Date date2 = secondDate.getTime();
        if(date1.before(date2)){
            System.out.println(date1);
        }else {
            System.out.println(date2);
        }


    }
}


