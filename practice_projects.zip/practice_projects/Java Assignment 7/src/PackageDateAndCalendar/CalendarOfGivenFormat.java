package PackageDateAndCalendar;
//4.Take a calendar object and set the date with following values
// Y-2017, M- 8 , D-25,H - 16, m - 50, s - 16, ms- 000
import java.util.Calendar;

public class CalendarOfGivenFormat {
    public static void main(String[] args) {
        Calendar cal=Calendar.getInstance();
        cal.set(2017,8,25,16,50,16);
        cal.set(Calendar.MILLISECOND,0);
        System.out.println(cal.getTime());
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/Java Assignment 7/out/production/Java Assignment 7 PackageDateAndCalendar.CalendarOfGivenFormat
        Mon Sep 25 16:50:16 IST 2017
*/
