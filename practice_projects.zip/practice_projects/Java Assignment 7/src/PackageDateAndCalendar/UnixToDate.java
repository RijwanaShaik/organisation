package PackageDateAndCalendar;
//1.Convert Unix long date to Date object and print the date acquired from long value in Sat 22 Oct 7:00 am.
//Example long value 1666410176977
import java.text.SimpleDateFormat;
import java.util.Date;

public class UnixToDate {
    public static void main(String[] args) {
        Date date=new Date(1666410176977l);
        SimpleDateFormat sdf=new SimpleDateFormat("E dd MMM hh:mm a ");
        System.out.println(" Unix long Date isin the form of :"+sdf.format(date));
    }
}
