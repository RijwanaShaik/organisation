package PackageStrings;

import java.util.Arrays;
import java.util.Formatter;

//    4. Create a class Address(hno,landmark,streetName, city, state, country, pincode). Create an object of address by initializing all the variables. Get the formatted address similar to following
//        a. Address(2-110B, Near Cross Road temple, Ram Nagar Colony, Gachibowli, Telangana, India,522654)
//        b. Formmated address string(single string) should be - H:No 2-110B,Ram Nagar Colony,Gachibowli,Telangana,India. Pin:522654, landmark:Near Cross Road temple
public class Address {
String hNo;
String landmark;
String streetName;
String city;
String state;
String country;
int pincode;

    public Address(String hNo, String landmark, String streetName, String city, String state, String country, int pincode) {
        this.hNo = hNo;
        this.landmark = landmark;
        this.streetName = streetName;
        this.city = city;
        this.state = state;
        this.country = country;
        this.pincode = pincode;
    }

    @Override
    public String toString() {
        return "FormattedAddressString " +
                "H:No= " + hNo +
                ", " + streetName +
                ", " + city +
                ", " + state +
                ", " + country +
                ". pin: " + pincode +
                ", landmark: " + landmark;
    }

    public static void main(String[] args) {
        Address ad=new Address("2-110B","Near Cross Road temple", "Ram Nagar Colony", "Gachibowli", "Telangana", "India",522654);
/*
String[] formmatedString={("H:No "+ad.hNo),(ad.streetName),(ad.city),(ad.state),(ad.country),("Pin: "+ad.pincode),("landmark: "+ad.landmark)};
        System.out.println(Arrays.toString(formmatedString));
*/
        System.out.println(ad);
    }
}
