package PackageStrings;
//3.Find the first non-repeated character from a String
import java.util.Scanner;

public class FirstNonRepeatChar {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter string");
        String string=sc.nextLine();
        System.out.println("The given string is: "+string);
        for (int i = 0; i < string.length(); i++) {
            boolean result = true;
            for (int j = 0; j < string.length(); j++) {
                if (i != j && string.charAt(i) == string.charAt(j)) {
                    result = false;
                    break;
                }
            }
            if (result) {
                System.out.println("The first non repeated character in String is: " + string.charAt(i));
                break;
            }
        }
    }
}

/*
/home/thrymrthrymr123/Documents/practice_projects/Java Assignment 7/out/production/Java Assignment 7 PackageStrings.FirstNonRepeatChar
        Enter string
        hiphop
        The given string is: hiphop
        The first non repeated character in String is: i
*/

