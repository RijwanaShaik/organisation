package PackageStrings;

import java.util.Arrays;

//    5. Take 2 String arrays of same length. Get the final array which concatenates the first array first element with second array last element and the same for further elements
//        a. eg: ["Hello", "Hi", "Hey"], ["Team", "Everyone", "Java"]. O/p: ["Hello Java", "Hi Everyone", "Hey Team"]
public class StringConcat {
    public static void main(String[] args) {
        String[] s1={"Hello", "Hi", "Hey"};
        String[] s2={"Team", "Everyone", "Java"};

        int length=s1.length;
        String result[]=new String[length];
        int j=length-1;
        for(int i=0;i<length;i++){
            result[i]=s1[i].concat("\s"+s2[j]);
            j--;
        }
        System.out.println(Arrays.toString(result));
    }
}
