package PackageStrings;
//    1. Find if the given two strings are having same characters(order of characters & Count of characters doesn't matter)
//        a. eg: abcd , baccd - Bothe the strings having same character
//        b. eg: abcd, abcdf - Strings do not have same characters
public class StringWithSameChar {
    boolean StringContainChar(String string1, String string2){
        for(char ch : string1.toCharArray()){
            if(string2.indexOf(ch) < 0 )
                return false;
        }
        for(char ch : string2.toCharArray()){
            if(string1.indexOf(ch) < 0 )
                return false;
        }
        return true;
    }
    public static void main(String[] args) {

        StringWithSameChar stringObj=new StringWithSameChar();

        System.out.println(stringObj.StringContainChar("abcd","baccd"));
        System.out.println(stringObj.StringContainChar("abcd","abcdf"));
    }
}
