package PackageStrings;
//    2. Read 2 string inputs, find the first string contains the second String
//        a. eg: Str1 = "Hello World Java", Str2 = "rld" - Str1 contains str2
import java.util.Scanner;

public class StringOneContainSecondString {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter string1: ");
        String string1 = sc.nextLine();

        System.out.println("Enter string2: ");
        String string2 = sc.nextLine();

        if (string1.contains(string2)) {
            System.out.println("String1 contains string2");
        } else {
            System.out.println("String1 and string2 are different");
        }
    }
}


/*
/home/thrymrthrymr123/Documents/practice_projects/Java Assignment 7/out/production/Java Assignment 7 PackageStrings.StringOneContainSecondString
        Enter string1:
        Hello World Java
        Enter string2:
        rld
        String1 contains string2*/
