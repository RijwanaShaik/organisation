import java.util.Arrays;

//2.Create your Own Integer ArrayList for following methods
    // add
// addAll
//remove
//retainAll
//size
//isEmpty
//indexOf
public class ArrayListClass {
        int size=10;
        int  arr[]=new int[10];
        int index=-1;
        public void incrementSize(){
            size +=2;
            int [] temp = new int[size];
            for(int i=0;i < arr.length;i++){
                temp[i] = arr[i];
            }
        }
        public void add(int n){
            index++;

            if(index==(size*0.7)){
                incrementSize();
            }
            arr[index]=n;
        }
        public void addAll(int[] elements) {
            for (int i=0;i<elements.length;i++) {
                arr[index] = elements[i];
                index++;
                if (index ==(size* 0.7)) {
                    incrementSize();
                }

            }
        }
        public void remove(int n){
            for(int i=0;i<arr.length;i++) {
                if (arr[i]==n) {
                    index--;
                    while (arr[i]!=0){
                        arr[i]=arr[i+1];
                        i++;
                    }
                    break;
                }
            }
        }
        public boolean isEmpty () {
            if (index == -1) {
                return true;
            }
            return false;
        }
        public int size(){
            return index+1;
        }
        public int indexOf(int n){
            int indexOf=0;
            for(int i=0;i<arr.length;i++){
                if(arr[i]==n){
                    indexOf=i;
                    break;
                }
                else indexOf=-1;
            }
            return indexOf;
        }
        public int[] retainAll(int[] arr1) {
            int k = 0;
            int[] arr2 = new int[arr1.length];
            for (int i = 0; i < arr.length; i++) {
                for (int j = 0; i < arr1.length; i++) {

                    if (arr[i] == arr1[j]) {
                        arr2[k] = arr1[j];
                        k++;
                    }
                }
            }
            arr=arr2;
            return arr;
        }
        public static void main(String[] args) {
            ArrayListClass obj= new ArrayListClass();
            obj.add(30);
            obj.add(40);
            obj.add(60);
            System.out.println(Arrays.toString(obj.arr));
            int[] arr1={45,65,80};
            obj.addAll(arr1);
            System.out.println(Arrays.toString(obj.arr));
            obj.remove(30);
            System.out.println(Arrays.toString(obj.arr));
            System.out.println(obj.isEmpty());
            System.out.println(obj.size());
            System.out.println(obj.indexOf(45));
            obj.retainAll(arr1);
            System.out.println(Arrays.toString(obj.arr));
        }
    }
