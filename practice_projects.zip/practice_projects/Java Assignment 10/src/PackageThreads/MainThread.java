package PackageThreads;
//4. Create 3 threads for sending SMS, Email, Whatsapp message. Execute threads parallelly
public class MainThread {
    public static void main(String[] args) {
        //Executing 3 threads parallel
        SMS s1 = new SMS();
        Email e = new Email();
        WhatsApp w = new WhatsApp();
        s1.start();
        e.start();
        w.start();
    }
}
