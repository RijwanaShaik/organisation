package PackageThreads;

public class WhatsApp extends Thread{
    @Override
    public void run() {
        System.out.println("Sending Whatsapp Messsage "+Thread.currentThread().getName());
    }
}
