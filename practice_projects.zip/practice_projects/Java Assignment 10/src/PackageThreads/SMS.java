package PackageThreads;

public class SMS extends Thread{
    @Override
    public void run() {
        System.out.println("Sending Sms  "+Thread.currentThread().getName());
    }
}
