package PackageThreads;

public class Email extends Thread{
    @Override
    public void run() {
        System.out.println("Sending Email Message "+Thread.currentThread().getName());
    }
}
