package ExamplesOfDataSturcture;

//arrays example
public class StudentArray {
    String name;
    long mobileNumber;
    int score;
    int id;
    String address;

    public StudentArray(String name, long mobileNumber, int score, int id, String address) {
        this.name = name;
        this.mobileNumber = mobileNumber;
        this.score = score;
        this.id = id;
        this.address = address;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", mobileNumber=" + mobileNumber +
                ", score=" + score +
                ", id=" + id +
                ", address='" + address + '\'' +
                '}';
    }

    public static void main(String[] args) {
        StudentArray[] student = new StudentArray[10];
        student[0] = new StudentArray("Amar", 8841526378l, 68, 1, "Main road , Kurnool");
        student[1] = new StudentArray("kunal", 8596147390l, 45, 2, "120-B,opposite to temple , Kurnool");
        student[2] = new StudentArray("Shameem", 6648519625l, 72, 3, "10/a,Trends near to bus stand , Nandyal");
        student[3] = new StudentArray("Koushik", 7489561585l, 34, 4, "16-10/c,near to rama theater , Allagadda");
        student[4] = new StudentArray("Anusha", 8591523654l, 80, 5, "101-B,Saket road , Hyderabad");
        student[5] = new StudentArray("Ram", 8461789512l, 47, 6, "24-10/a,ECIL , Hyderabad");
        student[6] = new StudentArray("Prakash", 7014485269l, 63, 7, "23-10/b,anupama apartment , Kurnool");
        student[7] = new StudentArray("Rohit", 8854819625l, 59, 8, "14-10/c,opposite to Govt Hospital , Nandyal");
        student[8] = new StudentArray("Ankur", 6301478521l, 82, 9, "16/c,sai baba nagar , Nandyal");
        student[9] = new StudentArray("Sohal", 8865187235l, 65, 10, "13/a,benz circle, Vijayawada");

        for (int i = 0; i < student.length; i++) {
            System.out.println(student[i]);

        }

    }
}
