package ExamplesOfDataSturcture;
//3.Give proper usecases and examples for Arrays & Linkedlist data structures
public class ArrayAndLinkedList {
}

//                               Arrays
//An array is a linear data structure that collects elements of the same data type and stores them in contiguous and adjacent memory locations.
// Arrays work on an index system starting from 0 to (n-1), where n is the size of the array.
//ex:Let's suppose a class consists of ten students, and the class has to publish their results.
// If you had declared all ten variables individually, it would be challenging to manipulate and maintain the data.

//If more students were to join, it would become more difficult to declare all the variables and keep track of it. To overcome this problem, arrays came into the picture.




//                              LinkedList
//Defination:
     // This is a data structure that stores elements in a non-contiguous location. It is a linear data structure.
   //Each data item is called a ‘Node’ and each node has a data part and an address part. The address part stores the link to the next node in the LinkedList

//Types of LinkedList are

//Single linked list:A singly linked list is made up of nodes where each node has two parts:
     //The first part contains the actual data of the node
     //The second part contains a link that points to the next node of the list that is the address of the next node.
     //ex: we use undo button (Ctrl+x) in keyboard that's the best example we can't use the same button for redo we have Ctrl+y for that.


//double linkedlist:It is made up of nodes where each node has three parts:
      //The first part contains a link that points to the previous node of the list.
     //The second part contains the actual data of the node
     //The third part contains a link that points to the next node of the list that is the address of the next node.
     //Ex:web browser,music player

//circular linkedlist:It contains a node,like double linked list but,head node conncected to tail node,it means head node contain address of tail node in previous address  and tail node contain next node address as head node address.
      //In the simple linked list, all the nodes will point to their next element and tail will point to null.
      // The circular linked list is the collection of nodes in which tail node also point back to head node.
       //ex:A ludo game has to come back give turn to first player after 4th player so it has to be circular.


//Circular doubly linked list: is a more complexed type of data structure in which a node contain pointers to its previous node as well as the next node.
       // Circular doubly linked list doesn't contain NULL in any of the node. The last node of the list contains the address of the first node of the list.
       // The first node of the list also contain address of the last node in its previous pointer.
      //ex:In our keyboard we have alt+tab key this is circular linked list it goes back on to first tab after last tab and we can go back also.




//         Arrays                                                                 LinkedList
//Arrays stored in sequential order                                       LinkedList stored in random order
//Array is size is fixed.                                                 LinkedList size can grow dynamically
//In Array insertion and deletion operations are slow                     LinkedList insertion and deletion opertions are fast
//In array shifts occurs during manipulations                             LinkedList shifts are not occured and links get de-Attach and attach to previous &next nodes
//                                                                        In java,linkedlist mostly use double linkedlist data structure.
//   arrays are faster in storing & accessing the data                    LinkedList fast in manipulations.

//ex.book-authors ,one book has one author if the permissions is given     ex.book-buyers,one book can buy by many buyers,we can't put any condition
//only to that author,no one can write or publish that book again                  it has no fixed size means the buyers number can be changed at any time,the size can be growable
//so,the author is fixed here,cann't be changed.