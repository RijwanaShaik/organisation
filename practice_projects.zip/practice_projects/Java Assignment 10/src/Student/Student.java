package Student;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

//1.Create list of Students
public class Student  {
    int id;
    String name;
    int rollNo;
    int mobileNumber;

    int englishMarks;
    int sciencesMarks;
    int computerMarks;
    int age;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Student(int id, String name, int rollNo, int mobileNumber, int englishMarks, int sciencesMarks, int computerMarks, int age) {
        this.id = id;
        this.name = name;
        this.rollNo = rollNo;
        this.mobileNumber = mobileNumber;
        this.englishMarks = englishMarks;
        this.sciencesMarks = sciencesMarks;
        this.computerMarks = computerMarks;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", rollNo=" + rollNo +
                ", mobileNumber=" + mobileNumber +
                ", englishMarks=" + englishMarks +
                ", sciencesMarks=" + sciencesMarks +
                ", computerMarks=" + computerMarks +
                ", age=" + age +
                '}';
    }

    public static void main(String[] args) {
        List<Student> studentList=new ArrayList<Student>();
        studentList.add(new Student(1, "Anusha",12, 857865090,80,78,88,30));
        studentList.add(new Student(2, "Sahil",8, 786598320,90,65, 55,20));
        studentList.add(new Student(3, "Rahul",10, 786593028,56,45,66,37));
        studentList.add(new Student(4, "Kunal",6, 857865090,70,88,85,32));
        studentList.add(new Student(5, "Shammem",13, 780389309,82,59,77,33));
        studentList.add(new Student(6, "Rashi",14, 765490387,60,85,85,29));
        studentList.add(new Student(7, "Nikhila",50, 630875692,69,66,80,44));
        System.out.println(studentList);
    }
}
