package Student;

import java.util.ArrayList;
import java.util.List;
//2.Add null values in odd positions of list
public class AddNull {
        public static void main(String[] args) {
            List<Student> studentList=new ArrayList<Student>();
            studentList.add(new Student(1, "Anusha",12, 857865090,80,78,88,30));
            studentList.add(new Student(2, "Sahil",8, 786598320,90,65, 55,20));
            studentList.add(new Student(3, "Rahul",10, 786593028,56,45,66,37));
            studentList.add(new Student(4, "Kunal",6, 857865090,70,88,85,32));
            studentList.add(new Student(5, "Shammem",13, 780389309,82,59,77,33));
            studentList.add(new Student(6, "Rashi",14, 765490387,60,85,85,29));
            studentList.add(new Student(7, "Nikhila",50, 630875692,69,66,80,44));

            for(int i=0;i<studentList.size();i++){
                if(i%2==0){
                    studentList.set(i,null);
                }
            }
            System.out.println(studentList);
        }
    }


