package PackageSynchronization;
//example of synchronization block.Execution of this class is done in class TestThread
public class PrintDemo extends Thread{

    public void printCount() {
        try {
            for(int i = 5; i > 0; i--) {
                System.out.println("Counter --- " + i );
            }
        } catch (Exception e) {
            System.out.println("Thread " + Thread.currentThread().getName()+" interrupted.");
        }
    }
    public void run() {
        synchronized(this) {
            printCount();
        }
        System.out.println("Thread " + Thread.currentThread().getName() + " exiting.");
    }
}
//Here is the same example which prints counter value in sequence and every time we run it, it produces the same result.
// We have put synchronized keyword over a block so that counter increment code is now locked as per the object during method execution.
// We're using current object as lock which we're passing in the synchronized block as parameter