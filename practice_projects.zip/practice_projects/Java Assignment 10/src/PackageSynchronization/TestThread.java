package PackageSynchronization;
//This the main class of printDemo class
public class TestThread {
    public static void main(String args[]) {
        PrintDemo PD = new PrintDemo();
        Thread t1 = new Thread(PD );
        Thread t2 = new Thread(PD );
        t1.start();
        t2.start();
        // wait for threads to end
        try {
            t1.join();
            t2.join();
        } catch ( Exception e) {
            System.out.println("Interrupted");
        }
    }
}


//Synchronized block is used to synchronize a critical block of code instead of whole method.
//When a thread enters into synchronized block, it acquires lock and once it completes its task and exits from the synchronized block, it releases the lock.
//Synchronized block is preferred over synchronized method because in case synchronized block only critical block of code is locked not whole method, hence performance will be better in this case.




















