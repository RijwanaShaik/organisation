package PackageSynchronization;
//customer class contain synchornization methods.here i'm executing customer class methods in SychronizationMethod
public class SynchronizationMethod {
    public static void main(String args[]) {
        final Customer c = new Customer();
        new Thread() {
            public void run() {
                c.withdraw(15000);
            }
        }.start();
        new Thread() {
            public void run() {
                c.deposit(10000);
            }
        }.start();
    }
    }
//Synchronization is the capability of controlling access of multi-threads to any shared resources.
// It is better for when we want only one thread to access the shared resource at a time.
//In the above scenario,second thread has to wait until the work of first thread completed
