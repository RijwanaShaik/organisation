package Questions;


import RelationshipClasses.EmpDevice;
import RelationshipClasses.Status;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
//2.Find the counts of each device type that are not in use among all organizations in descending order
public class CountOfEachDevice {
    public static void main(String[] args) {
        EmpDevice obj=new EmpDevice();
        List<EmpDevice> empDeviceList=new ArrayList<EmpDevice>(obj.data());
        Predicate<EmpDevice> p3= a->a.status.equals(Status.NOTASSIGNED);
        Map<String,Long> count= empDeviceList.stream().filter(p3).collect(Collectors.groupingBy(p->p.employee.organisation.name+" "+p.device.name,Collectors.counting()));
        System.out.println(count);

    }
}
