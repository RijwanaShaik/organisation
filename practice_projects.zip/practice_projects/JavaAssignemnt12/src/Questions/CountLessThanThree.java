package Questions;

import RelationshipClasses.*;

import java.util.function.Predicate;

//    1. An employee from ORG1 requires a new desktop. Find the requested device availability in this organization's inventory.
//    Also, Print "DESKTOP shortage in inventory" only If the available desktops count <= 3. Here you should consider the devices which are not in use or not assigned to any employee currently

public class CountLessThanThree {
    public static void main(String[] args) {
        EmpDevice obj=new EmpDevice();
        Predicate<Device> predicate=device -> device.name.equals(Type.DESKTOP)&&device.status.equals(DeviceStatus.AVAILABLE);
        if(obj.deviceList1().stream().filter(predicate).count()<=3){
            System.out.println("Desktop shortage in inventory");
        }else {
            System.out.println("No Shortage of deskotp");
        }
    }
}
