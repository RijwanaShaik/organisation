package Questions;

import RelationshipClasses.EmpDevice;
import RelationshipClasses.Status;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import static java.time.temporal.ChronoUnit.DAYS;
//4. Find all devices assigned to an employee where the device assigned status is 'RETURNED' and the date difference between the device assigned & returned id < 4 days.

public class DateDifference {
    public static void main(String[] args) {
        EmpDevice obj=new EmpDevice();
        List<EmpDevice> empDeviceList=new ArrayList<EmpDevice>(obj.data());
        Predicate<EmpDevice> p1= a->a.status.equals(Status.RETURNED);
        Predicate<EmpDevice> p2=a-> DAYS.between(a.assignedDate,a.returnedDate)<4;
        empDeviceList.stream().filter(p1.and(p2)).forEach(e-> System.out.println(e.device.name+" "+e.employee.name+" "+e.employee.organisation.name));
    }
}
