package Questions;

import RelationshipClasses.EmpDevice;

import java.util.ArrayList;
import java.util.List;
//3.Find a device and employee details who got assigned to a particular device. eg: find the device and assigned employee details of device code "TH-DESK-001"
public class DeviceEmpDetails {
    public static void main(String[] args) {
        EmpDevice obj=new EmpDevice();
        List<EmpDevice> empDeviceList=new ArrayList<EmpDevice>(obj.data());
        empDeviceList.stream().filter(a -> a.device.id.equalsIgnoreCase("TH-DESK-001")).map(a -> a.device.name + " id " + a.employee.id + " name " + a.employee.name).forEach(System.out::println);

    }
}
