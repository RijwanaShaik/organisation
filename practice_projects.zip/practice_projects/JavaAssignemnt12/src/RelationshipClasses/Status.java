package RelationshipClasses;

public enum Status {
    ASSIGNED,RETURNED,NOTASSIGNED

}
