package RelationshipClasses;

public class Organisation {
   public int id;
    public String name;

    public Organisation(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Organisation{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
