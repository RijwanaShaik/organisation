package RelationshipClasses;

public class Device {
    public String id;
    public Type name;
   public DeviceStatus status;
    public Organisation organisation;

    public Device(String id, Type name, DeviceStatus status, Organisation organisation) {
        this.id = id;
        this.name = name;
        this.status = status;
        this.organisation = organisation;
    }

    @Override
    public String toString() {
        return "Device{" +
                "id='" + id + '\'' +
                ", name=" + name +
                ", status=" + status +
                ", organisation=" + organisation +
                '}';
    }
}
