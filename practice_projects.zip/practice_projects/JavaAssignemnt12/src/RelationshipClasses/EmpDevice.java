package RelationshipClasses;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EmpDevice {
    public Employee employee;
    public Device device;
    public Status status;
    public LocalDate assignedDate;
    public LocalDate returnedDate;
    public EmpDevice(Employee employee, Device Device, Status status, LocalDate assignedDate, LocalDate returnedDate) {
        this.employee = employee;
        this.device = Device;
        this.status = status;
        this.assignedDate = assignedDate;
        this.returnedDate = returnedDate;
    }

    public EmpDevice() {
    }

    @Override
    public String toString() {
        return "EmpDevice{" +
                "employee=" + employee +
                ", Device=" + device +
                ", status='" + status + '\'' +
                ", assignedDate='" + assignedDate + '\'' +
                ", returnedDate='" + returnedDate + '\'' +
                '}';
    }

    public List<Organisation> organisationList(){
        return List.of(new Organisation(300,"ORG1"),new Organisation(3002,"ORG2"));
    }
    public List<Employee> employeeList() {
        return List.of(new Employee(1, "raj", organisationList().get(0)),

                new Employee(2, "rahul", organisationList().get(1)),
                new Employee(3, "anshu", organisationList().get(0)));
    }

    public List<Device> deviceList1() {
        return List.of(new Device("TH-DESK-001", Type.DESKTOP, DeviceStatus.NOTAVAILABLE,organisationList().get(0)),
                new Device("TH-KB-001", Type.KEYBOARD,DeviceStatus.NOTAVAILABLE, organisationList().get(0)),
                new Device("TH-MS-001", Type.MOUSE,DeviceStatus.NOTAVAILABLE, organisationList().get(0)),
                new Device("TH-CPU-001", Type.CPU, DeviceStatus.NOTAVAILABLE,organisationList().get(0)),


                new Device("TH-DESK-002", Type.DESKTOP,DeviceStatus.AVAILABLE, organisationList().get(1)),
                new Device("TH-KB-002", Type.KEYBOARD,DeviceStatus.NOTAVAILABLE, organisationList().get(1)),
                new Device("TH-MS-002", Type.MOUSE, DeviceStatus.NOTAVAILABLE,organisationList().get(1)),
                new Device("TH-CPU-002", Type.CPU, DeviceStatus.NOTAVAILABLE,organisationList().get(1)),


                new Device("TH-DESK-003", Type.DESKTOP,DeviceStatus.AVAILABLE ,organisationList().get(0)),
                new Device("TH-KB-003", Type.KEYBOARD,DeviceStatus.AVAILABLE, organisationList().get(0)),
                new Device("TH-MS-003", Type.MOUSE, DeviceStatus.AVAILABLE,organisationList().get(0)),
                new Device("TH-CPU-003", Type.CPU,DeviceStatus.AVAILABLE, organisationList().get(0)),

                new Device("TH-CPU-004", Type.CPU,DeviceStatus.AVAILABLE ,organisationList().get(0)),

                new Device("TH-Desk-004", Type.DESKTOP,DeviceStatus.NOTAVAILABLE, organisationList().get(0)));

    }
    public List<EmpDevice> data(){
        return List.of(new EmpDevice(employeeList().get(0), deviceList1().get(0),Status.ASSIGNED , LocalDate.of(2022,11,20) , null),
                new EmpDevice(employeeList().get(0), deviceList1().get(1), Status.ASSIGNED, LocalDate.of(2022,11,20) , null),
                new EmpDevice(employeeList().get(0), deviceList1().get(2), Status.ASSIGNED, LocalDate.of(2022,11,20) , null),
                new EmpDevice(employeeList().get(0), deviceList1().get(3), Status.ASSIGNED, LocalDate.of(2022,11,20), null),

                new EmpDevice(employeeList().get(1),deviceList1().get(4), Status.RETURNED, LocalDate.of(2022,11,22) , LocalDate.of(2022,11,25)),
                new EmpDevice(employeeList().get(1), deviceList1().get(5), Status.ASSIGNED, LocalDate.of(2022,11,22) , null),
                new EmpDevice(employeeList().get(1), deviceList1().get(6), Status.ASSIGNED,  LocalDate.of(2022,11,22) , null),
                new EmpDevice(employeeList().get(1), deviceList1().get(7), Status.ASSIGNED,LocalDate.of(2022,11,22) , null),

                new EmpDevice(employeeList().get(2), deviceList1().get(8), Status.NOTASSIGNED, null, null),
                new EmpDevice(employeeList().get(2), deviceList1().get(9), Status.NOTASSIGNED, null, null),
                new EmpDevice(employeeList().get(2), deviceList1().get(10), Status.NOTASSIGNED, null, null),
                new EmpDevice(employeeList().get(2), deviceList1().get(11), Status.NOTASSIGNED, null, null),
                new EmpDevice(employeeList().get(2), deviceList1().get(12), Status.NOTASSIGNED, null, null),
                new EmpDevice(employeeList().get(1), deviceList1().get(13), Status.ASSIGNED, LocalDate.of(2022,11,27), null)

        );
    }

    public static void main(String[] args) {
        EmpDevice obj=new EmpDevice();
        List<EmpDevice> empDeviceList=new ArrayList<EmpDevice>(obj.data());
        System.out.println(empDeviceList);

    }
}

