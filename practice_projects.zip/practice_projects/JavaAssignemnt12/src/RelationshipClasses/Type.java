package RelationshipClasses;

public enum Type {
    DESKTOP,KEYBOARD,MOUSE,CPU

}
