package RelationshipClasses;

public enum DeviceStatus {
    AVAILABLE,NOTAVAILABLE
}
