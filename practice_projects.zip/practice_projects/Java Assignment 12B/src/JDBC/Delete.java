package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

//        5.Delete employees if the email is 'test@gmail.com'
public class Delete {
    public static void main(String[] args)  throws ClassNotFoundException, SQLException {
   /*     Class.forName("org.postgresql.Driver");
        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "thrymr@123");*/
        Connection con=DBConnection.getConnection();
        Statement st = con.createStatement();
        int delete = st.executeUpdate("delete from employee2 where email='test@gmail.com'");
        System.out.println(delete+" deleted");
        con.close();
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/Java Assignment 12B/out/production/Java Assignment 12B:/home/thrymrthrymr123/Downloads/postgresql-42.2.27.jre7.jar JDBC.Delete
        1 deleted*/
