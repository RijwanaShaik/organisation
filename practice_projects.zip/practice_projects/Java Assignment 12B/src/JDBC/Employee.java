package JDBC;


import java.sql.Connection;
import java.sql.DriverManager;

public class Employee {
    int id;
    String name;
    float salary;
    String email;

    public Employee(){}
    public Employee(int id, String name, float salary, String email) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.email = email;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", salary=" + salary +
                ", email='" + email + '\'' +
                '}';
    }

    public static void main(String[] args) {


    }
}
class ConnectionSingleton {
    static ConnectionSingleton obj = new ConnectionSingleton();

    private ConnectionSingleton() {

    }

    public Connection connect() {
        Connection conn = null;
        try {
            String url = "jdbc:postgresql://localhost/siva";
            String user = "postgres";
            String password = "thrymr@123";
            conn = DriverManager.getConnection(url, user, password);

            if (conn != null) {
                System.out.println("Connected to the PostgresSQL server successfully.");
            } else {
                System.out.println("Failed to make connection!");
            }


        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return conn;

    }

    public static ConnectionSingleton getInstance() {
        return obj;
    }

    public static void main(String[] args) {
        ConnectionSingleton ob= ConnectionSingleton.getInstance();
    }
}





