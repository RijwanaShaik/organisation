package JDBC;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


//  6.Find all employees whose email contains @thrymr.net (SQL query)
//a.Convert result set to Employee objects
//  b.      Display all employee details
public class FindAllEmployee {
    public static void main(String[] args) {
 /*       String driver = "org.postgresql.Driver";
        final String DB_URL = "jdbc:postgresql://localhost:5432/postgres";
        final String USER = "postgres";
        final String PASS = "thrymr@123";
        final String QUERY = "SELECT * FROM employee where email like '%@thrymr.net'" ;*/
        List<Employee2> employeeList=new ArrayList<>();
        Employee2 emp=null;
Connection conn=DBConnection.getConnection();
        try{

            /*  Class.forName(driver);
        Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);*/

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM employee2 where email like '%@thrymr.net'");

            while (rs.next()) {

                emp=new Employee2(rs.getInt("id"),rs.getString("name"),rs.getInt("salary"),rs.getString("email"));
                employeeList.add(emp);

            }
        }
          catch (SQLException e){
            e.printStackTrace();
        }
        try {
            FileOutputStream fileOut =
                    new FileOutputStream("D:Employeefile.txt");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(employeeList);
            out.close();
            fileOut.close();
            System.out.printf("Serialized data is saved in /tmp/employee.ser");
        } catch (IOException i) {
            i.printStackTrace();
        }
        for(Employee2 e:employeeList){
            System.out.println(e);
        }
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/Java Assignment 12B/out/production/Java Assignment 12B:/home/thrymrthrymr123/Downloads/postgresql-42.2.27.jre7.jar JDBC.FindAll
        Employee{id=12, name='kunal', salary=5000.0, email='kunal@thrymr.net'}
        Employee{id=15, name='Ishrat', salary=8000.0, email='ishu@thrymr.net'}
        Employee{id=13, name='TRAINING_UPDATE_NAME', salary=4000.0, email='rahul@thrymr.net'}
        */
