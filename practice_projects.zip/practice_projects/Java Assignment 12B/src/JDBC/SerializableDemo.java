package JDBC;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class SerializableDemo {
        public static void main(String[] args) {
            Employee2 e1 = new Employee2(1,"raj",8000,"raj123@gmail.com");
            Employee2 e2 = new Employee2(2,"sudeep",6000,"suddep@gmail.com");
            List<Employee2> employeeList = new ArrayList<>();
            employeeList.add(e1);
            employeeList.add(e2);


            try {
                FileOutputStream fileOut = new FileOutputStream("D:Employeefile.txt");
                ObjectOutputStream out =new ObjectOutputStream(fileOut);
                out.writeObject(employeeList);
                out.close();
                fileOut.close();
                System.out.println("Data saved ");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


