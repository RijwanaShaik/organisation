package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateEmployee {
    public static void main(String[] args) throws SQLException {

       // Class.forName("org.postgresql.Driver");
      // Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "thrymr@123");
Connection con=DBConnection.getConnection();
        Statement st = con.createStatement();
        int r = st.executeUpdate("create table Employee2(id int primary key,name varchar(20),salary float,email varchar(20))");
        System.out.println(r+" Table created");

        con.close();
    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/Java Assignment 12B/out/production/Java Assignment 12B:/home/thrymrthrymr123/Downloads/postgresql-42.2.27.jre7.jar JDBC.CreateEmployee
        0 Table created
postgres=# select*from employee;
        id | name | salary | email
        ----+------+--------+-------
        (0 rows)*/
