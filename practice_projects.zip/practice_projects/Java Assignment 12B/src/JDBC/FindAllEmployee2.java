package JDBC;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FindAllEmployee2 {
    public static void main(String[] args) {
        List<Employee2> employee2List = new ArrayList<>();
      //  Employee2 emp = null;
        Connection con = DBConnection.getConnection();
        PreparedStatement ps;
        try {
            Statement st = con.createStatement();
            ps=con.prepareStatement("SELECT * FROM employee2 where email like '%@thrymr.net'");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {


                employee2List.add( new Employee2(rs.getInt("id"), rs.getString("name"), rs.getFloat("salary"), rs.getString("email")));
            }
            FileOutputStream fileOut =
                    new FileOutputStream("D:Employeefile.txt");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(employee2List);
            FileInputStream si = new FileInputStream("D:Employeefile.txt");
            ObjectInputStream oi = new ObjectInputStream(si);
            List<Employee2> std = (List<Employee2>)  oi.readObject();
            System.out.println(std);
            out.close();
            fileOut.close();

        } catch (SQLException s) {
            System.out.println(s);
        }catch (IOException i){
            System.out.println(i);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
       /* for(Employee2 employee2:employee2List){
            System.out.println(employee2);
        }*/
    }
}