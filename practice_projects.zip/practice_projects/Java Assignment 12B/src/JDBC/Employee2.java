package JDBC;

import java.io.Serializable;

public class Employee2 implements Serializable {
    int id;
    String name;
    float salary;
    String email;

    public Employee2(int id, String name, float salary, String email) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.email = email;
    }

    @Override
    public String toString() {
        return "Employee2{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", salary=" + salary +
                ", email='" + email + '\'' +
                '}';
    }
}
