package JDBC;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

//        3.Insert multiple employee data(Single query)
public class InsertData {
    public static void main(String[] args)  throws  SQLException {
       /* Class.forName("org.postgresql.Driver");
        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "thrymr@123");*/
        Connection con=DBConnection.getConnection();
        Statement st = con.createStatement();
        int insert = st.executeUpdate("insert into employee2 values(12,'kunal',5000,'kunal@thrymr.net')," +
                "(13,'rahul',4000,'rahul@thrymr.net')," +
                "(14,'anshu',6000,'test@gmail.com'),(15,'Ishrat',8000,'ishu@thrymr.net')");
        System.out.println(insert+" inserted");


        con.close();
    }
}
/*/home/thrymrthrymr123/Documents/practice_projects/Java Assignment 12B/out/production/Java Assignment 12B:/home/thrymrthrymr123/Downloads/postgresql-42.2.27.jre7.jar JDBC.InsertData
        4 inserted
  postgres=# select*from employee;
 id |  name  | salary |      email
----+--------+--------+------------------
 12 | kunal  |   5000 | kunal@thrymr.net
 13 | rahul  |   4000 | rahul@thrymr.net
 14 | anshu  |   6000 | test@gmail.com
 15 | Ishrat |   8000 | ishu@thrymr.net
(4 rows)

 */
