package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    static Connection connection = null;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                Class.forName("org.postgresql.Driver");
                connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "thrymr@123");
            } catch (Exception e) {
                e.printStackTrace();
                connection = null;
            }
        }
        return connection;
    }

    public static void main(String[] args) {

    }
}