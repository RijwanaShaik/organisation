package Practise;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCConnection {


    public Connection getconnection() {
        String driver = "org.postgresql.Driver";
        final String DB_URL = "jdbc:postgresql://localhost:5432/postgres";
        final String USER = "postgres";
        final String PASS = "thrymr@123";

        Connection conn = null;
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);


            if (conn != null) {
                System.out.println("Connected to the PostgresSQL server successfully.");
            } else {
                System.out.println("Failed to make connection!");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return conn;
    }
}
