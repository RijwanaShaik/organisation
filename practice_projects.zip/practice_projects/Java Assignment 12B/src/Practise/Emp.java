package Practise;

public class Emp {
    int id;
    String name;
    float salary;
    String email;

}
