package ListExamples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StringListToStringArray {
    public static void main(String[] args) {
        //string list to string array
        List<String> list=new ArrayList<String>();
        list.add("Geeks");
        list.add("for");
        list.add("Geeks");
        list.add("Practise");

        /*String[] arr=new String[list.size()];
        //converting list to array using get() method
        for(int i=0;i<list.size();i++){
            arr[i]=list.get(i);
        }
        //printing elements of array on console
        for(String a:arr) {
            System.out.print(a+" ");
        }*/
        //using toArray()method
    //  String[] arr=list.toArray(new String[0]);
        //using streams via scope resolutions
      String[] arr=list.stream().toArray(String[]::new);
      for(String x:arr){
          System.out.print(x+" ");
      }
      //converting string array to list
      List strarrTolist=new ArrayList<>(Arrays.asList(arr));
        System.out.println("\nconverting string array to list : "+strarrTolist);


    }
}
