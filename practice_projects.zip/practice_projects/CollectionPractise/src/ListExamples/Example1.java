package ListExamples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Example1 {
    public static void main(String[] args) {
        List<Integer> al=new ArrayList<>();
        for(int i=1;i<=5;i++)
            al.add(i);
            System.out.println(al);
          //  al.remove(3);
            System.out.println(al);
            for (int i=0;i<al.size();i++)
                System.out.print(al.get(i)+" ");

    }
}
class ex{
    public static void main(String[] args) {
        List<Integer> list=new ArrayList<Integer>();
        List<Integer> list1=new ArrayList<Integer>();
        List<Integer> list3=new ArrayList<Integer>();

        list.add(32);
        list.add(34);
        System.out.println(list);
        System.out.println("original size of list1: "+list.size());
        System.out.println(list.isEmpty());
        System.out.println(list.containsAll(list3));
        list1.add(65);
        list1.add(87);
        list.addAll(list1);

        System.out.println("original list1: "+list1);
        list1.remove(1);
        System.out.println("After removing the element from list1, the list1 contains: "+list1);

        list3.add(98);
        list3.add(78);
        list1.addAll(1,list3);
        System.out.println(list1);
        System.out.println("finding index of 78 in list1: "+list1.indexOf(78));
        System.out.println(list3.size());
        System.out.println("after adding elements to list1,now the size becomes: "+list1.size());
    }
}
class ListMethods{
    public static void main(String[] args) {
        List<String> listString=new ArrayList<String>();
        listString.add("A");
        listString.add("B");
        listString.add("z");
        listString.add("I");
        System.out.println("before sorting: "+listString);
        List<String> listString2=new ArrayList<String>();
        listString2.add("C");
        listString2.add("D");
        Collections.sort(listString);
        System.out.println("after sorting: "+listString);
        Collections.copy(listString,listString2);
        System.out.println(listString2);
    }
}