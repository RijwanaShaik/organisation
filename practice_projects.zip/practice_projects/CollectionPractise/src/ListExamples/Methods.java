package ListExamples;

import java.util.*;
import java.util.stream.Collectors;

public class Methods {
    public static void main(String[] args) {
        List<String> strlist=new ArrayList<String>();
        strlist.add("Java");
        strlist.add("Ruby");
        System.out.println("size of list: "+strlist.size());
        strlist.add("python");
        strlist.add("c++");
        System.out.println("Size of a list after adding more elements: "+strlist.size());
        strlist.clear();
        System.out.println("List after calling clear() method: "+strlist);
        //contains method demo
        if(strlist.contains("C")==true)
            System.out.println("Given list contains string 'C'");
        else if(strlist.contains("Java")==true)
            System.out.println("Given list contains string 'Java' but not string 'C'");

        //containsAll method demo
        List<String> myList = new ArrayList<String>();
        myList.add("Ruby");
        myList.add("Python");
        if(strlist.containsAll(myList)==true)
            System.out.println("List contains strings 'Ruby' and 'Python'");

        //define lists
        List<Integer> first_list= new LinkedList<>();
        List<Integer> second_list = new LinkedList<>();
        List<Integer> third_list = new LinkedList<>();
        //initialize lists with values
        for (int i=0;i<11;i++){
            first_list.add(i);
            second_list.add(i);
            third_list.add(i*i);
        }

        System.out.println("First list: " + first_list);
        System.out.println("Second list: " + second_list);
        System.out.println("Third list: " + third_list);

//use equals method to check equality with each list to other
        if (first_list.equals(second_list) == true)
            System.out.println("\nfirst_list and second_list are equal.\n");
        else
            System.out.println("first_list and second_list are not equal.\n");

        if(first_list.equals(third_list))
            System.out.println("first_list and third_list are equal.\n");
        else
            System.out.println("first_list and third_list are not equal.\n");
        if(second_list.equals(third_list))
            System.out.println("second_list and third_list are equal.\n");
        else
            System.out.println("second_list and third_list are not equal.\n");

                  List<String> listA=new ArrayList<String>();
                  listA.add("java");
                  listA.add("Python");
        System.out.println("Element at 0 index: "+listA.get(0));
        System.out.println("Element at 1 index: "+listA.get(1));
listA.set(1,"Ruby");
        System.out.println("Element at index1 changed to: "+listA.get(1));
        //hashcode
        int hash=listA.hashCode();
        System.out.println("Hashcode for list: "+hash);
        //copy method
      List<String> listCopy=new ArrayList<String>();
        listCopy.addAll(myList);
        System.out.println(listCopy);

        listCopy.addAll(listA);
        System.out.println(listCopy);
        //using indexof,lastindex of "Ruby" in a list
        System.out.println(listCopy.indexOf("Ruby"));
        System.out.println(listCopy.lastIndexOf("Ruby"));
        //remove and remove all
        listCopy.remove(1);
        System.out.println("After removing the element at index 1: "+listCopy);
        System.out.println("Elemetns of mylist are: "+myList);
        listCopy.removeAll(myList);

        System.out.println("After removing the mylist elements from list copy: "+listCopy);
        strlist.add("Python");
        strlist.add("Java");
        strlist.add("HTML");
        strlist.add("Ruby");
        System.out.println("After adding elements to strlist: "+strlist);
        strlist.retainAll(myList);
        System.out.println("retaining only myList elements in strlist: "+strlist);
        //sublist
        List<String> list=new ArrayList<String>();
        list.add("java");
        list.add("Tutorials");
        list.add("Collection");
        list.add("Framework");
        list.add("Series");
        System.out.println("the original list: "+list);
        List<String> sublist=new ArrayList<String>();
        sublist=list.subList(2,4);
        System.out.println("The sublist of list: "+sublist);
//sort list
        Collections.sort(list);
        System.out.println("The sorted list: "+list);
        /*Collections.reverse(list);//to sort integer list in reverse order
        System.out.println(list);*/  //list.sort((o1,o2) -> {return(o2-o1);});
        /*for (int i=0,j=list.size()-1;i<j;i++){
            String temp=list.remove(j);
            list.add(i,temp);
        }
        System.out.println(list);*/
//the sorted list is stored in revList in reverse order of the list.
        List<String> revList=new ArrayList<String>();
        for (int i=list.size()-1;i>=0;i--){
            String element=list.get(i);
            revList.add(element);
        }
        System.out.println("reverse order of the sorted list: "+revList);
//create an array from the list using toArray method
        String strArray[]=new String[list.size()];
        strArray=list.toArray(strArray);
        System.out.println("Printing element of strArray: "+Arrays.toString(strArray));
        // create list
        List<String> colorsList = new ArrayList<String>(7);

        // add colors to colorsList
        colorsList.add("Violet");
        colorsList.add("Indigo");
        colorsList.add("Blue");
        colorsList.add("Green");
        colorsList.add("Yellow");
        colorsList.add("Orange");
        colorsList.add("Red");
        System.out.println("ColorList using iterator:");
        //define iterator for colorsList
        Iterator<String> iterator = colorsList.iterator();
        //iterate through colorsList using iterator and print each item
        while(iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }
            //listIterator
            List<String> nameList = new LinkedList<>();
            nameList.add("Java");
            nameList.add("C++");
            nameList.add("Python");
            // get listIterator for the list
            ListIterator<String> namesIterator = nameList.listIterator();

            // Traverse list using listiterator and print each item
            System.out.println("\nContents of list using listIterator:");
            while(namesIterator.hasNext()){
                System.out.print(namesIterator.next() + " ");

            }
            //arrays.asList with elements as argument
            List<String> st=Arrays.asList("java","java","Ruby","Python","Ruby");
            //Arrays.asList() :- in closed brackets we can passs string array,we can also pass class objects with arguments as new car("benz",20);
        System.out.println("\n"+st);
        //to get distinct values of a list
        List<String> distinctSt=st.stream().distinct().collect(Collectors.toList());
        System.out.println(distinctSt);
        //other way to get distinct value of a list
        List<String > newList=new ArrayList<String>();
        for(String element:st){
            //check if elementis present in newlist,else add it
            if(!newList.contains(element)){
                newList.add(element);
            }
        }
        System.out.println(newList);
        }
      }
