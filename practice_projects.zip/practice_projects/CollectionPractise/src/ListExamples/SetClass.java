package ListExamples;

import java.util.*;

enum course{java, Python, Clanguage};
//set interface with its class
public class SetClass {
    public static void main(String[] args) {
        Set<String> s1=new HashSet<>();
        s1.add("A");
        s1.add("B");
        s1.add("C");
        s1.add("A");
        s1.add("R");
        s1.add("Z");
        s1.add("S");
        System.out.println(s1);//hashset doesn't follow insertion order

        Set<course> se= EnumSet.of(course.java,course.Clanguage,course.Python);
        System.out.println(se);

        Set<String> s2=new LinkedHashSet<>();
        s2.add("A");
        s2.add("B");
        s2.add("C");
        s2.add("A");
        s2.add("R");
        s2.add("Z");
        s2.add("S");
        System.out.println(s2);//linkedhash set follow insertion order

        Set<String> s3=new TreeSet<>();
        s3.add("A");
        s3.add("B");
        s3.add("C");
        s3.add("A");
        s3.add("R");
        s3.add("Z");
        s3.add("S");
        System.out.println(s3);//Treeset follows sorted order
        TreeSet<Integer> s4=new TreeSet<>();
        s4.add(20);
        s4.add(34);
        s4.add(50);
        s4.add(55);
        s4.add(66);

        System.out.println(s4);
        TreeSet<Integer> s5=new TreeSet<>((TreeSet)s4.headSet(50));
        System.out.println(s5);
    }
}
