package ListExamples;

import java.util.ArrayList;
import java.util.List;

public class  IntListToIntArray {
    public static void main(String[] args) {
        List<Integer> list=new ArrayList<Integer>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
       /* int[] arr = list.stream().mapToInt(i->i).toArray();
        for (int val : arr) {
            System.out.println(val);
        }   */
        /*int[] arr=new int[list.size()];
        int index=0;
        for(Integer value:list){
            arr[index++]=value;
            System.out.println(value);
        }
        System.out.println("Elements of int array: ");
        for (Integer i:arr){
            System.out.println(i);
        }*/
        Integer[] intArray=new Integer[list.size()];
        intArray=list.toArray(intArray);
        for(Integer i:intArray){
            System.out.println(i);
        }
    }

}
