package ListExamples;

import java.util.*;

public class MethodsOfLinkedList {
    public static void main(String[] args) {
        LinkedList<String> str = new LinkedList<String>();
        str.add("Ajay");
        str.add("Vijay");
        str.add(1, "Sonoo");
        str.remove("Ajay");
        str.remove(1);
        System.out.println(str);
        LinkedList<String> str1 = new LinkedList<String>();
        str1.add("Virat");
        str1.addFirst("Dhoni");
        str1.addLast("Yuvraj");
        System.out.println(str1);
        //adding second list(str1) to first list(str)
        str.addAll(str1);
        System.out.println(str);
        System.out.println(str.getLast());
        System.out.println(str1.getFirst());
        System.out.println(str.removeLast());
        System.out.println(str.removeFirst());
        System.out.println(str);
        LinkedList<String> str3 = new LinkedList<String>();
        str3.addAll(str);
        str3.addAll(str1);
        System.out.println(str3);
        str3.removeFirstOccurrence("Virat");
        System.out.println(str3);
        str3.add(1, "Sachin");
        System.out.println(str3);
        str3.removeLastOccurrence("Dhoni");
        System.out.println("after removing last occurence of dhoni the str3 list is: "+str3);
        //iterating list in reverse order
       /* Iterator it=str3.descendingIterator();
        while (it.hasNext()){
            System.out.println(it.next());
        }*/
        //reversing the list using listiterator with has previous method
        ListIterator<String> lt=str3.listIterator(str3.size());
        while(lt.hasPrevious()){
            System.out.println(lt.previous());
        }
        //reversing the list using for loop
        for(int i= str3.size()-1;i>=0;i--){
            System.out.println(str3.get(i));
        }
        //Iterating over LinkedList using for each loop
        /*for (String st : str3) {
            System.out.println(st);
        }*/
      /*  //Iterating over linkedlist using get() method and for loop
        for(int i=0;i<str3.size();i++){
            System.out.print(str3.get(i)+" ");
                        System.out.print("Element at index "+"i"+str3.get(i)+" ");//to display the elements and their positions
        }*/
       /* //to iterate elements starting at specified position
        Iterator p=str3.listIterator(1);
        //print list from second position
        while(p.hasNext()){
            System.out.println(p.next());
        }*/
    }
}
class LinkedListToArray {
    public static void main(String[] args) {


        List<Integer> numbersList = new LinkedList<Integer>();
        numbersList.add(1);
        numbersList.add(2);
        numbersList.add(3);
        numbersList.add(4);
        numbersList.add(5);
        Integer[] numbers = new Integer[numbersList.size()];

        numbers = numbersList.toArray(numbers);
        System.out.println(Arrays.toString(numbers));
       /* List<Integer> test=new LinkedList<>();
        for(Integer t:numbers){
            test.add(t);
        }
        System.out.println(test);*/
    }
}
class ArrayToLinkedList{
    public static void main(String[] args) {
        Integer[] numbers = {1,2,3,4,5};
        List<Integer> numbersList = new LinkedList<Integer>();
        for(Integer s : numbers){
            numbersList.add(s);
        }
        System.out.println(numbersList);
    }
}
class QueueMethods{
    public static void main(String[] args) {
        LinkedList<String> strmethod=new LinkedList<String>();
        strmethod.add("First");
        strmethod.add("Second");
        strmethod.add("Third");
        strmethod.add("last");
        System.out.println(strmethod);
        //access the first element
        String str1=strmethod.peek();
        System.out.println(str1);
        //access and remove the first element
String str2=strmethod.poll();
        System.out.println(str2);
        System.out.println(strmethod);
        //add element at the end
        strmethod.offer("Fifth");
        System.out.println(strmethod);
        System.out.println();
    }
}

class CollectionQueue{
    public static void main(String[] args) {
        Queue<Integer> pq=new PriorityQueue<Integer>();
        pq.add(10);
        pq.add(20);
        pq.add(15);
        System.out.println(pq);
        System.out.println(pq.peek());
        System.out.println(pq.poll());
        System.out.println(pq);
        System.out.println(pq.peek());
    }
}