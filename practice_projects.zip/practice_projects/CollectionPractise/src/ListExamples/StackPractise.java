package ListExamples;

import java.util.Stack;

public class StackPractise {
    /*int[] numbers = new int[10];
    int top = -1;

    public boolean push(int number){
        // Check if array has empty slots to insert new value
        // yes > increment top & insert element  > Return success
        // No >  Return failed
        if (!isFull()) {
            top++;
            arr[top] = pushedElement;
            System.out.println("Pushed element:" + pushedElement);
        } else {
            System.out.println("Stack is full !");
        }

    }

    public boolean pop(){
        // check if array has atleast one element
        // if yes > remove  numbers[top], return success
        // if no > return failure
        if (top == -1) {
            System.out.println("Stack Underflow !!");
            return false;
        }
        else   {

            System.out.println("\nItem popped: " + stack_arry[top--]);
            return true;
        }
    }

    public boolean isEmpty(){
        // I don't tell you steps even here. Put your thoughts
       // return (top < 0);
        return size()==0;

    }

    public int top(){
        // I don't tell you steps even here. Put your thoughts
        if(isEmpty())
            return null;
        return array[top];
    }
    }

    public int size(){
        // I don't tell you steps even here. Put your thoughts
return top+1;
    }

    public static void main(String[] args) {

        StackPractise stackDemo = new StackPractise();
        boolean pushStatus = stackDemo.push(10);
        boolean popStatus =  stackDemo.pop();
        int topValue = stackDemo.top();
        boolean isStackEmpty = stackDemo.isEmpty()
        int stackSize =stackDemo.size()

    }
*/
}
class s{
    int a[]=new int[10];
    int top=-1;
    public boolean isEmpty(){
        return (top<0);
    }
    public int size(){

        return top+1;
    }
    public int top() {
        if (!isEmpty()) {
            System.out.println(a[top]);
        }
        return a[top];
    }
}
class Sd {
    public static void main(String args[])
    {
        // Creating an empty Stack
        Stack<Integer> stack = new Stack<Integer>();

        // Use add() method to add elements
        stack.push(10);
        stack.push(15);
        stack.push(30);
        stack.push(20);
        stack.push(5);

        // Displaying the Stack
        System.out.println("Initial Stack: " + stack);

        // Removing elements using pop() method
        System.out.println("Popped element: "
                + stack.pop());
        System.out.println("Popped element: "
                + stack.pop());

        // Displaying the Stack after pop operation
        System.out.println("Stack after pop operation "
                + stack);
    }
}