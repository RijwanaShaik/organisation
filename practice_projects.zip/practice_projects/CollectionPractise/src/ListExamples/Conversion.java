package ListExamples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Conversion {
    public static void main(String[] args) {
        //converting list to array of string
        List<String> itemList = new ArrayList<String>();
        itemList.add("item1");
        itemList.add("item2");
        itemList.add("item3");

        String[] itemsArray = new String[itemList.size()];
        itemsArray = itemList.toArray(itemsArray);

        for(String s : itemsArray)
            System.out.println(s);
        //normal forloop
        for(int i=0;i<itemsArray.length;i++){
            System.out.println(itemsArray[i]);
        }
        //converting string array to list
        String[] stringArray = {"item 1", "item 2", "item 3", "item 4"};
        List<String> stringList = new ArrayList(Arrays.asList(stringArray));

        for (String listItem : stringList) {
            System.out.println(listItem);
        }

        //converting list to array of integers
        List<Integer> intList = new ArrayList<Integer>();
        intList.add(10);
        intList.add(20);
        intList.add(30);

        Integer[] intArray = new Integer[intList.size()];
        intArray = intList.toArray(intArray);

        for(Integer i : intArray)
            System.out.println(i);
    }
}
class LinkedListConversion{
    public static void main(String[] args) {
        //Creating and populating LinkedList
        LinkedList<String> linkedlist = new LinkedList<String>();
        linkedlist.add("Harry");
        linkedlist.add("Maddy");
        linkedlist.add("Chetan");
        linkedlist.add("Chauhan");
        linkedlist.add("Singh");

        //Converting LinkedList to Array
        String[] array = linkedlist.toArray(new String[linkedlist.size()]);

        //Displaying Array content
        System.out.println("Array Elements:");
        for (int i = 0; i < array.length; i++)
        {
            System.out.println(array[i]);
        }
LinkedList<String> cstr=new LinkedList<>((LinkedList)linkedlist.clone());
        System.out.println("copying one linked list to other"+cstr);
        List<String> al=new ArrayList<>(linkedlist);
        System.out.println("Converting LinkedList to ArrayList");
        for(String i:al){
            System.out.println(i);
        }
        //converting array to linkedlist
        String[] str={"A","B","E","T","H"};
        List<String> strl=new LinkedList<>(Arrays.asList(str));
        System.out.println(strl);
    }
}
class LinkedListComparision{
    public static void main(String[] args) {
        LinkedList<String> c1= new LinkedList<String>();
        c1.add("Red");
        c1.add("Green");
        c1.add("Black");
        c1.add("White");
        c1.add("Pink");

        LinkedList<String> c2= new LinkedList<String>();
        c2.add("Red");
        c2.add("Green");
        c2.add("Black");
        c2.add("Orange");

        //comparison output in linked list
        LinkedList<String> c3 = new LinkedList<String>();
        for (String e : c1)
            c3.add(c2.contains(e) ? "Yes" : "No");
        System.out.println(c3);
    }
}