package ListExamples;

import java.util.Iterator;
import java.util.Stack;

public class StackMethods {
    public static void main(String[] args) {
        Stack<Integer> obj=new Stack<Integer>();
        obj.push(30);
        obj.push(40);
        obj.push(50);
        obj.push(60);
        obj.pop();
       obj.pop();
        Iterator iterator=obj.iterator();
        while (iterator.hasNext()){
            System.out.print(iterator.next()+" ");
        }
        Object[] str=obj.toArray();
        System.out.println("\nThe Array contents: ");
        for(int j=0;j<str.length;j++)
            System.out.print(str[j]+" ");
        //declare a stack object
        Stack<Integer> stack = new Stack<>();
        //print initial stack
        System.out.println("\nInitial stack : "  + stack);
        //isEmpty ()
        System.out.println("Is stack Empty? : "  + stack.isEmpty());
        //push () operation
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        //print non-empty stack
        System.out.println("Stack after push operation: "  + stack);
        //pop () operation
        System.out.println("Element popped out:"  + stack.pop());
        System.out.println("Stack after Pop Operation : "  + stack);
        //search () operation
        System.out.println("Element 10 found at position: "  + stack.search(10));
        System.out.println("Is Stack empty? : "  + stack.isEmpty());
    }
}
