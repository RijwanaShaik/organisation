package ListExamples;

import java.util.ArrayList;
import java.util.List;

//Java Program for copying one ArrayList to another
public class CopyingArrayListtypes {
    public static void main(String[] args) {
        // creation of ArrayList of Integers
        ArrayList<Integer> gfg = new ArrayList<>();

        // adding elements to  first ArrayList
        gfg.add(10);
        gfg.add(21);
        gfg.add(22);
        gfg.add(35);

       /*//1.first using the assignment operator(=)
        // Assigning the first reference to second
        ArrayList<Integer> gfg2 = gfg;

        // Iterating over  second ArrayList
        System.out.println(
                "-----Iterating over the second ArrayList----");
        for (Integer value : gfg2) {
            System.out.println(value);
        }
        // here we changed the third element to 23
        // we changed in second list and you can
        // see the same change in the first Arraylist
        gfg2.set(2, 23);
        System.out.println("third element of first list ="
                + gfg.get(2));
        System.out.println("third element of second list ="
                + gfg2.get(2));*/


   /*  //2. passing in the constructor
        ArrayList<Integer> gfg2 = new ArrayList<>(gfg);

        // Iterating over  second ArrayList
        System.out.println(
                "-----Iterating over the second ArrayList----");
        for (Integer value : gfg2) {
            System.out.println(value);
        }

        // here we changed the third element to 23
        // we changed in second list and you can
        // here we will not see the same change in the first
        gfg2.set(2, 23);

        System.out.println("third element of first list ="
                + gfg.get(2));
        System.out.println("third element of second list ="
                + gfg2.get(2));*/

        // 3.Adding one by one using add() method
        ArrayList<Integer> gfg2 = new ArrayList<>();

        // adding element to the second ArrayList
        // by iterating over one by one
        for (Integer value : gfg) {
            gfg2.add(value);
        }

        // Iterating over  second ArrayList
        System.out.println(
                "-----Iterating over the second ArrayList----");

        for (Integer value : gfg2) {
            System.out.println(value);
        }

        // here we changed the third element to 23
        // we changed in second list
        // here we will not see the same change in the first
        gfg2.set(2, 23);

        System.out.println("third element of first list ="
                + gfg.get(2));
        System.out.println("third element of second list ="
                + gfg2.get(2));

        //4.Using addAll() method

        ArrayList<String> AL1 = new ArrayList<>();
        AL1.add("geeks");
        AL1.add("forgeeks");
        AL1.add("learning");
        AL1.add("platform");

        ArrayList<String> AL2 = new ArrayList<>();
        AL2.addAll(AL1);
        System.out.println("Original ArrayList : " + AL1);
        System.out.println("Copied ArrayList : " + AL2);


//5.using List.copyOf();
        ArrayList<String> al1=new ArrayList<>();
        al1.add("java");
        al1.add("is a");
        al1.add("platform independent language");
        ArrayList<String> al2=new ArrayList<>(List.copyOf(al1));
        System.out.println("Original ArrayList : " + al1);
        System.out.println("Copied Arraylist : " + al2);

/*
        //using clone()method
ArrayList<String> al3=new ArrayList<>();
al3=(ArrayList)al1.clone() ;
*/
        ArrayList<String> al3=(ArrayList)al1.clone() ;

        System.out.println("Original ArrayList : " + al1);
        System.out.println("Copied Arraylist : " + al3);

    }
}
