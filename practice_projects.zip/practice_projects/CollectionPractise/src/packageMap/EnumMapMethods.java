package packageMap;

import java.util.EnumMap;

enum Size{
    SMALL,MEDIUM,LARGE,EXTRALARGE
}
public class EnumMapMethods {
    public static void main(String[] args) {
        EnumMap<Size,Integer> sizes1=new EnumMap<Size, Integer>(Size.class);
        sizes1.put(Size.SMALL,28);
        sizes1.put(Size.MEDIUM,32);
        System.out.println("EnumMap1: "+sizes1);
        EnumMap<Size,Integer> sizes2=new EnumMap<Size,Integer>(Size.class);
        sizes2.putAll(sizes1);
        sizes2.put(Size.LARGE,36);
        System.out.println("EnumMap2: "+sizes2);
        int value=sizes1.get(Size.MEDIUM);
        System.out.println(value);
        int value1=sizes2.remove(Size.LARGE);
        System.out.println(value1);
        sizes1.replace(Size.MEDIUM,30);
        System.out.println(sizes1);
        sizes1.replaceAll((key,oldValue)->oldValue+3);
        System.out.println(sizes1);
    }
}
