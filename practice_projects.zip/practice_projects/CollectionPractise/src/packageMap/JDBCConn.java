package packageMap;

import java.sql.*;

public class JDBCConn {
    public static void main(String[] args) {


        String driver = "org.postgresql.Driver";
        final String DB_URL = "jdbc:postgresql://localhost:5432/postgres";
        final String USER = "postgres";
        final String PASS = "thrymr@123";
        final String QUERY = "SELECT * FROM employee";


        try {
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(QUERY);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int salary = rs.getInt("salary");
                System.out.println("ID = " + id + "  NAME = " + name + " salary = " + salary);

            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
class JDBCProgram {
    public static void main(String[] args) throws SQLException {
        Driver driver = new org.postgresql.Driver();
       DriverManager.registerDriver(driver);
//Class.forName("org.postgresql.Driver");
        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "thrymr@123");
        Statement st = con.createStatement();
        int a= st.executeUpdate("insert into javatable values(3,'rahul')");
        System.out.println(a+" Record inserted");
        int b= st.executeUpdate("update javatable set name='sohal' where id=2");
        System.out.println(b+" updated");
         con.close();
    }
}
