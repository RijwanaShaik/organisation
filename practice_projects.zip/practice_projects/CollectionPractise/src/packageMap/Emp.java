package packageMap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Emp {
    int id;
    String name;
    int age;
    String gender;
    String department;
    double salary;

    public Emp(int id, String name, int age, String gender, String department, double salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Emp{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                ", department='" + department + '\'' +
                ", salary=" + salary +
                '}';
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Map<Integer, Emp> map = new HashMap<>();
        map.put(0, new Emp(1, "Kunal", 22, "Male", "Engineering", 15000));
        map.put(1, new Emp(2, "Ajay", 23, "Male", "Engineering", 16000));
        map.put(2, new Emp(3, "Yamini", 22, "Female", "Testing", 15000));
        map.put(3, new Emp(4, "Ram", 28, "Male", "Engineering", 18000));
        map.put(4, new Emp(5, "Reshma", 32, "Female", "Hr", 35000));
        map.put(5, new Emp(6, "Sowjanya", 30, "Female", "Testing", 25000));
        map.put(6, new Emp(7, "Shameem", 25, "Female", "Engineering", 55000));
        map.put(7, new Emp(8, "Sohal", 24, "Male", "Hr", 85000));


        System.out.println("Enter key");
        /*int key = scan.nextInt();
        for (Map.Entry value : map.entrySet()) {
            if (value.getKey().equals(key)) {
                Emp object = (Emp) value.getValue();
                System.out.println(value.getKey() + "\t" + object.getId() + "\t" + object.getName() + "\t" + object.getAge() + "\t" + object.getGender() +
                        "\t" + object.getDepartment() + "\t" + object.getSalary());
            }

        }*/
       /* for(Integer val:map.keySet()){
            System.out.println(val);
        }
        for(Map.Entry<Integer,Emp> value:map.entrySet()){
            System.out.println(value);
        }
        Iterator it=map.entrySet().iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);*/
        Map<Integer, Emp> map1 = new HashMap();
        map1.put(0, new Emp(1, "Kouashik", 22, "Male", "Engineering", 15000));
        map1.put(1, new Emp(2, "vijay", 23, "Male", "Engineering", 16000));
        map1.put(2, new Emp(3, "Yamu", 22, "Female", "Testing", 15000));
        map1.put(3, new Emp(4, "Raj", 28, "Male", "Engineering", 18000));
       /* map1.put(4, new Emp(5, "Reshma", 32, "Female", "Hr", 35000));
        map1.put(5, new Emp(6, "Sowjanya", 30, "Female", "Testing", 25000));
        map1.put(6, new Emp(7, "Shameem", 25, "Female", "Engineering", 55000));
        map1.put(7, new Emp(8, "Sohal", 24, "Male", "Hr", 85000));*/
      /*  map.forEach(
                (key, value) -> map1.merge(key, value, (v1, v2) -> v1.equals(v2)?v1:v2 )
        );*/
        /*for(Map.Entry val: map.entrySet()){
            System.out.println(val);
       }*/
       /* for(Map.Entry<Integer, Emp> entry: map.entrySet()){ map1.merge(entry.getKey(), entry.getValue(), (v1, v2) -> v1); }
        System.out.println(map1);*/
       /* map1.forEach((key, value) -> map.merge(key, value, (v1, v2) -> v2));
        System.out.println(map);*/
        map.forEach((key, value) -> map1.merge(key, value, (v1, v2) -> v2));
        System.out.println(map1);
    }

}
