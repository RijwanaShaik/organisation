package packageMap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapExamples {
    public static void main(String[] args) {
        Map<String,Integer> numbers=new HashMap<>();
        numbers.put("one",1);
        numbers.put("two",2);
        System.out.println(numbers);
        System.out.println(numbers.keySet());
        System.out.println(numbers.values());
        System.out.println(numbers.entrySet());
        Map<String,Integer> numbers1=new TreeMap<>();
numbers1.put("Second",2);
numbers1.put("First",1);
        System.out.println(numbers1);
        numbers1.replace("First",11);
        numbers1.replace("Second",12);
        System.out.println("New Map "+numbers1);
        int removedValue=numbers1.remove("First");
        System.out.println("Removed Value: "+removedValue);
        Map<String,Integer> numbers2=new LinkedHashMap<>();

    }
}
