package packageMap;

import java.util.HashMap;
import java.util.Map;

public class HashMapMethods {
    public static void main(String[] args) {
        HashMap<Integer, String> languages = new HashMap<>();
        System.out.println(languages);
        //put() method to add elements
        languages.put(1, "Java");
        languages.put(2, "Python");
        languages.put(3, "JavaScript");
        System.out.println("HashMap after put(): " + languages);
        //get() method to get value
        String values=languages.get(1);
        System.out.println("Value at index 1: "+values);
        //getOrDefault() method
        String value1=languages.getOrDefault(2,"Not Found");
        String value2=languages.getOrDefault(4,"Not Found");
        System.out.println("Value for key1: "+value1);
        System.out.println("Value for key2: "+value2);
        //putIfAbsent();
        languages.putIfAbsent(2,"Java");//key already present in languages
        languages.putIfAbsent(4,"Swift");//key not present in languages
        System.out.println("Updated languages: "+languages);
        System.out.println("Keys: "+languages.keySet());
        System.out.println("Values: "+languages.values());
        System.out.println("Key value mappings: "+languages.entrySet());
        System.out.println("before replace method orginial map is: "+languages);
        //replace()
        languages.replace(2,"c++");
        System.out.println("after using replace(): "+languages);
        //replaceAll()
languages.replaceAll((key,value)->value.toUpperCase());
        System.out.println("after using replaceAll(): "+languages);

        // create copy of languages
        HashMap<String, Integer> cloneLanguages = (HashMap<String, Integer>)languages.clone();
        System.out.println("Cloned HashMap: " + cloneLanguages);
                       //or
        // print the return value of clone()
        System.out.println("Return value of clone(): " + languages.clone());
        //we can also get square if map integer,integer by
        //languages.replaceAll((key,value)->key*key);
        HashMap<Integer, String> languages2 = new HashMap<>();
         languages2.put(5,"JavaScript");
         languages2.putAll(languages);
        System.out.println(languages2);
        // iterate through keys only
        System.out.print("Keys: ");
        for (Integer key : languages.keySet()) {
            System.out.print(key);
            System.out.print(", ");
        }

        // iterate through values only
        System.out.print("\nValues: ");
        for (String value : languages.values()) {
            System.out.print(value);
            System.out.print(", ");
        }

        // iterate through key/value entries
        System.out.print("\nEntries: ");
        for (Map.Entry<Integer, String> entry : languages.entrySet()) {
            //for(Map.Entry m:languages.entrySet()){

            System.out.print(entry);
            System.out.print(", ");
        }
        HashMap<String, Integer> prices = new HashMap<>();
        prices.put("Shoes", 200);
        prices.put("Bag", 300);
        prices.put("Pant", 150);
        System.out.println("HashMap: " + prices);

        // recompute the value of Shoes with 10% discount
        int newPrice = prices.compute("Shoes", (key, value) -> value - value * 10/100);
        System.out.println("Discounted Price of Shoes: " + newPrice);

        System.out.println("Updated HashMap: " + prices);
        // compute the value of Shirt
        int shirtPrice = prices.computeIfAbsent("Shirt", key -> 280);
        System.out.println("Price of Shirt: " + shirtPrice);
        System.out.println("Updated HashMap: " + prices);

        // mapping for Shoes is already present
        // new value for Shoes is not computed
        int shoePrice = prices.computeIfAbsent("Shoes", (key) -> 280);
        System.out.println("Price of Shoes: " + shoePrice);
        System.out.println("Updated HashMap: " + prices);

        // recompute the value of Shoes with 10% VAT
        int shoesPrice = prices.computeIfPresent("Shoes", (key, value) -> value + value * 10/100);
        System.out.println("Price of Shoes after VAT: " + shoesPrice);

        System.out.println("Updated HashMap: " + prices);
        //merge method
        int returnedValue = prices.merge("Shirt", 100, (oldValue, newValue) -> oldValue + newValue);
        System.out.println("Price of Shirt: " + returnedValue);

        System.out.println("Updated HashMap: " + prices);

        HashMap<String, String> countries = new HashMap<>();
        countries.put("Washington", "America");
        countries.put("Canberra", "Australia");
        countries.put("Madrid", "Spain");
        System.out.println("HashMap: " + countries);

        // merge mapping for key Washington
        String returnedValue1 = countries.merge("Washington", "USA", (oldValue, newValue) -> oldValue + "/" + newValue);
        System.out.println("Washington: " + returnedValue1);

        System.out.println("Updated HashMap: " + countries);


        HashMap<String, Integer> prices1 = new HashMap<>();
        prices1.put("Pant", 230);
        prices1.put("Shoes", 350);
        System.out.println("HashMap 1: " + prices1);

        HashMap<String, Integer> prices2 = new HashMap<>();
        prices2.put("Shirt", 150);
        prices2.put("Shoes", 320);
        System.out.println("HashMap 2: " + prices2);

        // forEach() access each entries of prices2
        // merge() inserts each entry from prices2 to prices1
        prices2.forEach((key, value) -> prices1.merge(key, value, (oldValue, newValue) -> {

            // return the smaller value
            if (oldValue < newValue) {
                return oldValue;
            }
            else {
                return newValue;
            }
        }));

        System.out.println("Merged HashMap: " + prices1);
    }

}
