package Practise;

import java.util.*;
import java.util.stream.Collectors;

public class Food {
    private final String name;
    private final boolean vegetarian;
    private final int calories;
    private final Type type;

    public Food(String name, boolean vegetarian, int calories, Type type) {
        this.name = name;
        this.vegetarian = vegetarian;
        this.calories = calories;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public boolean isVegetarian() {
        return vegetarian;
    }

    public int getCalories() {
        return calories;
    }

    public Type getType() {
        return type;
    }

    @Override
    public String toString() {
        return name;
    }

    public static final List<Food> menu =
            Arrays.asList(new Food("pork", false, 1800, Type.MEAT),
                    new Food("beef", false, 7100, Type.MEAT),
                    new Food("chicken", false, 1400, Type.MEAT),
                    new Food("french fries", true, 1530, Type.OTHER),
                    new Food("rice", true, 3510, Type.OTHER),
                    new Food("season fruit", true, 1120, Type.OTHER),
                    new Food("pizza", true, 5150, Type.OTHER),
                    new Food("prawns", false, 1400, Type.FISH),
                    new Food("salmon", false, 4150, Type.FISH));


    public static void main(String[] args) {
        String n = Food.menu.stream().map(Food::getName).collect(Collectors.joining(","));
        System.out.println(n);
        //how to get highest value for each group
        Map<Type, Optional<Food>> o =
                Food.menu.stream().collect(
                        Collectors.groupingBy(Food::getType,
                                Collectors.reducing((Food d1, Food d2) -> d1.getCalories() > d2.getCalories() ? d1 : d2)));

        System.out.println(o);
        Map<Type, Food> maxValue =
                Food.menu.stream().collect(
                        Collectors.groupingBy(Food::getType,
                                Collectors.collectingAndThen(
                                        Collectors.reducing((Food d1, Food d2) -> d1.getCalories() > d2.getCalories() ? d1 : d2),
                                        Optional::get)));

        System.out.println(maxValue);
        //how to group and count
        Map<Type, Long> t = Food.menu.stream().collect(Collectors.groupingBy(Food::getType, Collectors.counting()));

        System.out.println(t);
        Food.menu.stream().filter(p -> p.type == Type.MEAT).forEach(System.out::println);
    }
}