package Practise;

import java.security.KeyStore;
import java.util.*;
import java.util.stream.Collectors;

public class SortHashMapByKeys {
    public static void main(String[] args) {
        Map<String,Integer> studentMap=new HashMap<String,Integer>();
        studentMap.put("Jyous", 87);
        studentMap.put("Klusener", 82);
        studentMap.put("Xiangh", 91);
        studentMap.put("Lisa", 89);
        studentMap.put("Narayan", 95);
        studentMap.put("Arunkumar", 86);
        //Sorting HashMap according to natural order of keys using TreeMap without Comparator :
       /* Map<String, Integer> sortedStudentMap = new TreeMap<>(studentMap);

        System.out.println("Before Sorting : ");

        System.out.println(studentMap);

        System.out.println("After Sorting : ");

        System.out.println(sortedStudentMap);*/
        //to get hashmap by keys in natural order
        Map<String,Integer> s1=studentMap.entrySet().stream().sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,(e1,e2)->e2,LinkedHashMap::new));
        System.out.println(s1);
        //to get reverse order by using streams
        Map<String, Integer> s2
                = studentMap.entrySet()
                .stream()
                .sorted(Collections.reverseOrder(Map.Entry.comparingByKey()))

                //  OR
                // .sorted(Entry.comparingByKey(Comparator.reverseOrder()))

                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));
        System.out.println(s2);
        //The following program sorts HashMap in natural reverse order of keys by passing Collections.reverseOrder() to TreeMap.
       /* Map<String, Integer> sortedStudentMap = new TreeMap<>(Collections.reverseOrder());

        sortedStudentMap.putAll(studentMap);

        System.out.println("Before Sorting : ");

        System.out.println(studentMap);

        System.out.println("After Sorting : ");

        System.out.println(sortedStudentMap);*/


//Sorting HashMap by keys using TreeMap with customized Comparator :
//
//In the below example, HashMap with strings as keys is sorted in increasing order of length of keys by passing customized Comparator to TreeMap
        Map<String, Integer> sortedStudentMap = new TreeMap<>(new Comparator<String>()
        {
            @Override
            public int compare(String o1, String o2)
            {
                return o1.length() - o2.length();//to get reverse order of string length just change the places of o1,o2 as o2,o1
            }
        });

        sortedStudentMap.putAll(studentMap);

        System.out.println("Before Sorting : ");

        System.out.println(studentMap);

        System.out.println("After Sorting : ");

        System.out.println(sortedStudentMap);
        //to get reverseorder of length
        Map<String, Integer> sortedStudentMap2 = new TreeMap<>(Collections.reverseOrder(new Comparator<String>()
    {
         @Override
       public int compare(String o1, String o2)
         {
             return o1.length() - o2.length();
         }
     }));
//by using streams to get natural order and reverse order with compartor
        Map<String, Integer> s3
                = studentMap.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByKey((o1, o2) -> o1.length() - o2.length()))//natural order
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));



        System.out.println(s3);

        Map<String, Integer> s4
                = studentMap.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByKey((o1, o2) -> o2.length() - o1.length()))

                //  OR
                //  .sorted(Collections.reverseOrder(Entry.comparingByKey((o1, o2) -> o1.length() - o2.length())))

                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));

        System.out.println(s4);




    }
}
