package Practise;

public enum Type {
     MEAT, OTHER, FISH
}
