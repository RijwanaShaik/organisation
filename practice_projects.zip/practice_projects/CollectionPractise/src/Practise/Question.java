package Practise;

import java.text.ParseException;
import java.util.*;

public class Question {
}
class Employee {
    String name;
    String email;
    Double salary;
    int contactNumber;
   // Date doj;
    boolean status;

    public Employee(String name, String email, Double salary, int contactNumber,  boolean status) {
        this.name = name;
        this.email = email;
        this.salary = salary;
        this.contactNumber = contactNumber;
        //  this.doj = doj;
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public int getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(int contactNumber) {
        this.contactNumber = contactNumber;
    }

    /*public Date getDoj() {
        return doj;
    }

    public void setDoj(Date doj) {
        this.doj = doj;
    }*/

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Employee{" + "name='" + name + '\'' + ", email='" + email + '\'' + ", salary=" + salary + ", contactNumber=" + contactNumber +
                ", status=" + status + '}';
    }

    public static void main(String[] args) throws ParseException {
        List<Employee> employeeList1 = new ArrayList<Employee>();
        employeeList1.add(new Employee("raj", "raj@123.com", 30000d, 768997499, true));
        employeeList1.add(new Employee("sony", "sony@123.com", 20000d, 768997499, true));
        employeeList1.add(new Employee("virat", "virat@123.com", 40000d, 768997499, false));
        //Employee[] empArray=employeeList.toArray(new Employee[employeeList.size()]);
       /*for(int i=0;i<empArray.length;i++){
           if(empArray[i].status==false)

           System.out.println(empArray[i]);
       }*/
       /* for(Employee e:employeeList){
            if(e.status==false){
                employeeList.remove(e);
            }
        }*/
        //  System.out.println(employeeList);
        /*Iterator<Employee> it = employeeList1.iterator();
        while (it.hasNext()) {
            Employee e = it.next();
            ;
            if (e.getStatus() == false) {
                it.remove();
            }
        }
        //  employeeList1.removeIf(n ->n.name=="sony");
        System.out.println(employeeList1);
        System.out.println(employeeList1.size());*/
        List<Employee> employeeList2 = new ArrayList<Employee>();
        employeeList2.add(new Employee("raj", "raj@123.com", 30000d, 768997499, true));
        employeeList2.add(new Employee("sony", "sony@123.com", 20000d, 768997499, true));
        employeeList2.add(new Employee("virat", "virat@123.com", 40000d, 768997499, false));
        employeeList2.addAll(employeeList1);
        System.out.println(employeeList2);
        System.out.println(employeeList2.size());
        //System.out.println(employeeList2.get(employeeList2.indexOf("sony")));
        System.out.println(employeeList2.indexOf("virat"));
/*public Employee getEmployee(String name){
    for(Employee e:employeeList2){
        if(e.name.equals(e.getName())){
            return e.getName();
        }
        return null;
    }
        }*/
       //  employeeList1.stream().sorted((a1,a2)->a1.salary > a2.salary?1:-1).forEach(System.out::println);
      //  employeeList1.stream().sorted(Comparator.comparing(Employee::getName).thenComparing(Employee::getContactNumber)).collect(Collectors.toList()).forEach(System.out::println);

 /*public int compareTo(Employee employeeList2){
     return this.salary.compareTo(employeeList2.getSalary());
        }
        Employee emp= Collections.min(employeeList2);
    }*/
        Collections.sort(employeeList1,(o1, o2) -> (int)(o1.getSalary()-o2.getSalary()));
        System.out.println(employeeList1);
        Optional<Employee> maxsal=employeeList1.stream().max(Comparator.comparing(Employee::getSalary));
        System.out.println(maxsal.get());
        employeeList1.stream().forEach(s-> System.out.println(s.name));
    }
}