package Practise;

import java.util.HashMap;
import java.util.Map;

public class EmpTest {
    int id;
    String name;
    String role;

    public EmpTest(int id, String name, String role) {
        this.id = id;
        this.name = name;
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "EmpTest{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", role='" + role + '\'' +
                '}';
    }

    public static void main(String[] args) {
        EmpTest e1=new EmpTest(11,"raj","HR");
        EmpTest e2=new EmpTest(12,"ram","techincal");
        EmpTest e3=new EmpTest(10,"lavanya","UI");
        Map<Integer,EmpTest> empTestMap=new HashMap<Integer, EmpTest>();
        empTestMap.put(0,e1);
        empTestMap.put(1,e2);
        empTestMap.put(2,e3);
        for(Map.Entry<Integer,EmpTest> val:empTestMap.entrySet()){
            System.out.println(val.getValue().name+" "+val.getValue().role);
        }
        empTestMap.remove(2);

        System.out.println(empTestMap);
        for(Map.Entry<Integer,EmpTest> val:empTestMap.entrySet()){

        }
    }
}
