public class Main {
    int id;
    String name;

    public Main(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return
                "id= " + id +
                "name= " + name
                ;
    }

    public static void main(String[] args) {
        Main obj=new Main(2,"rijwana");
        System.out.println(obj);

    }
}
