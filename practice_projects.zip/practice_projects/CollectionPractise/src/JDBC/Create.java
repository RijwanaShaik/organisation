package JDBC;

import java.sql.*;

public class Create {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Class.forName("org.postgresql.Driver");
        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "thrymr@123");
        Statement st = con.createStatement();
        int r = st.executeUpdate("create table student(id int,name varchar(20),age int)");
        System.out.println(r+" Table created");

        con.close();
    }
}
