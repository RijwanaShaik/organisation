package JDBC;


import java.sql.*;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

public class JDBCClass {
    public static void main(String[] args) {


       /* String driver = "org.postgresql.Driver";
        final String DB_URL = "jdbc:postgresql://localhost:5432/postgres";
        final String USER = "postgres";
        final String PASS = "thrymr@123";*/
        final String QUERY = "SELECT * FROM customer";
       List<Customer> customerList=new ArrayList<Customer>() ;

       Customer c=null;
        JDBCConnection obj=new JDBCConnection();



            /*Class.forName(driver);
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);*/
            Connection conn=obj.getconnection();
            try {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(QUERY);

                while (rs.next()) {
                    int id = rs.getInt("id");
                    String name = rs.getString("name");
                    int contact_no = rs.getInt("contact_no");
                  //  System.out.println("ID = " + id + "  NAME = " + name + " contact_no = " + contact_no);
                    customerList.add(new Customer(id,name,contact_no));
                    c=new Customer(id,name,contact_no);
                    System.out.println(c);
                }
            }catch (SQLException e){
                  e.printStackTrace();
            }
        System.out.println(customerList.size());

    }
}
