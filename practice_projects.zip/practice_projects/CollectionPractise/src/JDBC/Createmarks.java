package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Createmarks {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Class.forName("org.postgresql.Driver");
        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "thrymr@123");
        Statement st = con.createStatement();
        int r = st.executeUpdate("create table marks(subject varchar(20),marks int,s_Id int,foreign key(s_Id) references student(id))");
        System.out.println(r+" Table created");

        con.close();
    }
}
