package JDBC;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;

public class CommitRollBack {
    public static void main(String[] args) throws SQLException,ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "thrymr@123");
        con.setAutoCommit(false);
        //Insert the record
        String sql = "INSERT INTO Employee (empid, empname) VALUES (?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);
        //Used to take user input
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {

            while (true) {
                System.out.print("Enter employee Id: ");
                String s1 = br.readLine();
                int empid = Integer.parseInt(s1);

                System.out.print("Enter employee name: ");
                String name = br.readLine();

                ps.setInt(1, empid);
                ps.setString(2, name);
                ps.executeUpdate();
                System.out.println("commit/rollback");
                String answer = br.readLine();
                if (answer.equals("commit")) {
                    con.commit();
                }
                if (answer.equals("rollback")) {
                    con.rollback();
                }
                System.out.println("Want to add more records y/n");
                String ans = br.readLine();
                if (ans.equals("n")) {
                    break;
                }
            }
        }catch (Exception e){
            System.out.println(e);
        }
        con.commit();
        System.out.println("record successfully saved");
        con.close();//before closing connection commit() is called

    }
}
