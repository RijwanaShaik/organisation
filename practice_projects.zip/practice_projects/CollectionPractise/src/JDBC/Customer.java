package JDBC;

public class Customer {
    int id;
    String name;
    int contact;

    public Customer(int id, String name, int contact) {
        this.id = id;
        this.name = name;
        this.contact = contact;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", contact=" + contact +
                '}';
    }
}
