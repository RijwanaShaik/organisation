package JDBC;

import java.sql.*;

public class Insert {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Class.forName("org.postgresql.Driver");
        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "thrymr@123");
        Statement st = con.createStatement();
        int insert = st.executeUpdate("insert into student values(12,'rahul',22)");
        System.out.println(insert+" inserted");
        int update=st.executeUpdate("update student set age=20 where id=1");
        System.out.println(update+" one record updated");
        con.close();
    }
}
class Insert2{
    public static void main(String[] args) {

        String driver = "org.postgresql.Driver";
        final String DB_URL = "jdbc:postgresql://localhost:5432/postgres";
        final String USER = "postgres";
        final String PASS = "thrymr@123";
        final String QUERY = "insert into account values(2,'raj',3456),(3,'karthik',4567)";


        try {
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(QUERY);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int account_no = rs.getInt("account_no");
                System.out.println("ID = " + id + "  NAME = " + name + " account_no = " + account_no);

            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    }
