package RegularExpressions;

public class Hotel {
    int id;
    String name;
    String location;
}
