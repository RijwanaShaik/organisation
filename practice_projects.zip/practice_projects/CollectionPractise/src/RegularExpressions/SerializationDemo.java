package RegularExpressions;

import java.io.*;


public class SerializationDemo {
    public static void main(String[] args) {

        Employee employee1=new Employee(1,"raj",5000,"raj@123");
      try{
            FileOutputStream fileOut =
                   new FileOutputStream("D:Employeefile.txt");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(employee1);
            FileInputStream si = new FileInputStream("D:Employeefile.txt");
            ObjectInputStream oi = new ObjectInputStream(si);
            System.out.println(employee1);
            out.close();
            fileOut.close();

        } catch (IOException i){
            System.out.println(i);
        }

}
}
