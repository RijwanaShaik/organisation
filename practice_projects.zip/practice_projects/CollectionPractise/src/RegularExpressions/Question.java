package RegularExpressions;

public class Question {
}
// 'p' followed by anything, ending in 'q'.==>"p.*?q"
//check a word contains the character 'g' in a given string.==>
// a word containing 'g', not at the start or end of the word.==>
//a string starts with a specific number.==>"^5.*$"