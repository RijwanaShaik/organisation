package RegularExpressions;

public class OnlyNumber {
    public static void main(String[] args) {
        String str="1234";
        String regEx="^[0-9]+$";
        System.out.println(str.matches(regEx));
    }
}
