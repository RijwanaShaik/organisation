package RegularExpressions;

public class SmallCapsNumber {
    public static void main(String[] args) {
        String str="GeeksForGeeks123";
        String regEx="^[A-Za-z0-9]+$";//[A-Za-z0-9]==\\w
        if(str.matches(regEx)) {
            System.out.println("Matched string");
        }
        else {
            System.out.println("Unmatched string...");
        }
    }
}
