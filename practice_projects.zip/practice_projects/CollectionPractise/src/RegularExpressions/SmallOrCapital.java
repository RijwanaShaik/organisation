package RegularExpressions;

public class SmallOrCapital {
    public static void main(String[] args) {
        String str="GeeksForGeeks";
        String regEx="^[A-Za-z]+$";
        if(str.matches(regEx)) {
            System.out.println("Matched string");
        }
        else {
            System.out.println("Unmatched string...");
        }
    }
}
