package RegularExpressions;

import java.util.Scanner;

public class DateOfBirth {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a date of birth");
        String input=sc.nextLine();
        String regEx="(0?[1-9]|[12][0-9]|3[01])-(0?[1-9]|1[0-2])-\\d{4}";//dd-MM-yyyy
        if(input.matches(regEx)){
            System.out.println("your date of birth is valid");
        }else {
            System.out.println("your date of birth is invalid!");
        }
    }
}
