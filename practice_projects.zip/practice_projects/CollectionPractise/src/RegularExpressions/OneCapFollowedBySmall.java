package RegularExpressions;

public class OneCapFollowedBySmall {
    public static String validate(String text){
        if(text.matches("^[A-Z][a-z]+$")){
            return "String contain one capital letter followed by one or more small letters";
        }else return "Not matched!";
    }
    public static void main(String[] args) {
        System.out.println(validate("Java"));
        System.out.println(validate("java"));
        System.out.println(validate("javA"));
        System.out.println(validate("JAva"));
        System.out.println(validate("Ja"));
        System.out.println(validate("aJ"));
    }
}
