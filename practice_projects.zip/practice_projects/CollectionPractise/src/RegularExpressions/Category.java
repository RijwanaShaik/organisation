package RegularExpressions;

public enum Category {
    CAKES,PASTERY,SOUPS,PAVBHAJI
}
