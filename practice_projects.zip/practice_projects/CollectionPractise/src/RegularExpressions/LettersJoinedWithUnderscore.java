package RegularExpressions;

public class LettersJoinedWithUnderscore {
    public static String validate(String text){
        if(text.matches("^[a-z]+_[a-z]+$")){
            return "Found a match!";
        }else return "Not matched!";
    }
    public static void main(String[] args) {
        System.out.println(validate("java_example"));
        System.out.println(validate("Java_example"));
        System.out.println(validate("java_Example"));
        System.out.println(validate("Java_Example"));	    }
}
