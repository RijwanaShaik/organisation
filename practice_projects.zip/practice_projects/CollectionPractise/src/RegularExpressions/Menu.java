package RegularExpressions;

public class Menu {
    int id;
    String itemName;
    Category category;

    double cost;
    Hotel hotel;
}
