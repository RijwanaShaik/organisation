public class Example {
}
/*
public class Employee {
    private int id;
    private String name;
    private String position;
    private double salary;

    public Employee() {
    }

    public Employee(int id, String name, double salary, String position) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.position = position;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, position, salary);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Employee other = (Employee) obj;
        return id == other.id && Objects.equals(name, other.name) && Objects.equals(position, other.position) && Double.doubleToLongBits(salary) == Double.doubleToLongBits(other.salary);
    }

}

public class BatchProcessing {

    private final String[] EMPLOYEES = new String[]{"Zuck","Mike","Larry","Musk","Steve"};
    private final String[] DESIGNATIONS = new String[]{"CFO","CSO","CTO","CEO","CMO"};
    private final String[] ADDRESSES = new String[]{"China","York","Diego","Carolina","India"};

    private Connection connection;

    public void getConnection(){
        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:db", "SA", "");
            connection.setAutoCommit(false);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }

    public void createTables(){
        try {
            connection.createStatement().executeUpdate("create table EMPLOYEE (ID VARCHAR(36), NAME VARCHAR(45), DESIGNATION VARCHAR(15))");
            connection.createStatement().executeUpdate("create table EMP_ADDRESS (ID VARCHAR(36), EMP_ID VARCHAR(36), ADDRESS VARCHAR(45))");
            System.out.println("Tables Created!!!");
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        }
    }

    public void useStatement(){
        try {
            String insertEmployeeSQL = "INSERT INTO EMPLOYEE(ID, NAME, DESIGNATION) VALUES ('%s','%s','%s');";
            String insertEmployeeAddrSQL = "INSERT INTO EMP_ADDRESS(ID, EMP_ID, ADDRESS) VALUES ('%s','%s','%s');";
            Statement statement = connection.createStatement();
            for(int i = 0; i < EMPLOYEES.length; i++){
                String employeeId = UUID.randomUUID().toString();
                statement.addBatch(String.format(insertEmployeeSQL, employeeId, EMPLOYEES[i],DESIGNATIONS[i]));
                statement.addBatch(String.format(insertEmployeeAddrSQL, UUID.randomUUID().toString(),employeeId,ADDRESSES[i]));
            }
            statement.executeBatch();
            connection.commit();
        } catch (Exception e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                System.out.println("Error during rollback");
                System.out.println(ex.getMessage());
            }
            e.printStackTrace(System.out);
        }
    }

    public void usePreparedStatement(){
        try {
            String insertEmployeeSQL = "INSERT INTO EMPLOYEE(ID, NAME, DESIGNATION) VALUES (?,?,?);";
            String insertEmployeeAddrSQL = "INSERT INTO EMP_ADDRESS(ID, EMP_ID, ADDRESS) VALUES (?,?,?);";
            PreparedStatement employeeStmt = connection.prepareStatement(insertEmployeeSQL);
            PreparedStatement empAddressStmt = connection.prepareStatement(insertEmployeeAddrSQL);
            for(int i = 0; i < EMPLOYEES.length; i++){
                String employeeId = UUID.randomUUID().toString();
                employeeStmt.setString(1,employeeId);
                employeeStmt.setString(2,EMPLOYEES[i]);
                employeeStmt.setString(3,DESIGNATIONS[i]);
                employeeStmt.addBatch();

                empAddressStmt.setString(1,UUID.randomUUID().toString());
                empAddressStmt.setString(2,employeeId);
                empAddressStmt.setString(3,ADDRESSES[i]);
                empAddressStmt.addBatch();
            }
            employeeStmt.executeBatch();
            empAddressStmt.executeBatch();
            connection.commit();
        } catch (Exception e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                System.out.println("Error during rollback");
                System.out.println(ex.getMessage());
            }
            e.printStackTrace(System.out);
        }
    }

    public static void main(String[] args) {
        BatchProcessing batchProcessing = new BatchProcessing();
        batchProcessing.getConnection();
        batchProcessing.createTables();
        batchProcessing.useStatement();
        batchProcessing.usePreparedStatement();
    }
}
//joins

class ArticleWithAuthor {

    private String title;

    private String authorFirstName;

    private String authorLastName;

    public ArticleWithAuthor(String title, String authorFirstName, String authorLastName) {
        this.title = title;
        this.authorFirstName = authorFirstName;
        this.authorLastName = authorLastName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthorFirstName() {
        return authorFirstName;
    }

    public void setAuthorFirstName(String authorFirstName) {
        this.authorFirstName = authorFirstName;
    }

    public String getAuthorLastName() {
        return authorLastName;
    }

    public void setAuthorLastName(String authorLastName) {
        this.authorLastName = authorLastName;
    }

}
class ArticleWithAuthorDAO {

    private static final String QUERY_TEMPLATE = "SELECT ARTICLE.TITLE, AUTHOR.LAST_NAME, AUTHOR.FIRST_NAME FROM ARTICLE %s AUTHOR ON AUTHOR.id=ARTICLE.AUTHOR_ID";
    private final Connection connection;

    ArticleWithAuthorDAO(Connection connection) {
        this.connection = connection;
    }

    List<ArticleWithAuthor> articleInnerJoinAuthor() {
        String query = String.format(QUERY_TEMPLATE, "INNER JOIN");
        return executeQuery(query);
    }

    List<ArticleWithAuthor> articleLeftJoinAuthor() {
        String query = String.format(QUERY_TEMPLATE, "LEFT JOIN");
        return executeQuery(query);
    }

    List<ArticleWithAuthor> articleRightJoinAuthor() {
        String query = String.format(QUERY_TEMPLATE, "RIGHT JOIN");
        return executeQuery(query);
    }

    List<ArticleWithAuthor> articleFullJoinAuthor() {
        String query = String.format(QUERY_TEMPLATE, "FULL JOIN");
        return executeQuery(query);
    }

    private List<ArticleWithAuthor> executeQuery(String query) {
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            return mapToList(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private List<ArticleWithAuthor> mapToList(ResultSet resultSet) throws SQLException {
        List<ArticleWithAuthor> list = new ArrayList<>();
        while (resultSet.next()) {
            ArticleWithAuthor articleWithAuthor = new ArticleWithAuthor(
                    resultSet.getString("TITLE"),
                    resultSet.getString("FIRST_NAME"),
                    resultSet.getString("LAST_NAME")
            );
            list.add(articleWithAuthor);
        }
        return list;
    }
}
//metadatabase
public class DatabaseConfig {
    private static final Logger LOG = Logger.getLogger(DatabaseConfig.class);

    private Connection connection;

    public DatabaseConfig() {
        try {
            Class.forName("org.h2.Driver");
            String url = "jdbc:h2:mem:testdb";
            connection = DriverManager.getConnection(url, "sa", "");
        } catch (ClassNotFoundException | SQLException e) {
            LOG.error(e);
        }
    }

    public Connection getConnection() {
        return connection;
    }

    public void init() {
        createTables();
        createViews();
    }

    private void createTables() {
        try {
            connection.createStatement().executeUpdate("create table CUSTOMER (ID int primary key auto_increment, NAME VARCHAR(45))");
            connection.createStatement().executeUpdate("create table CUST_ADDRESS (ID VARCHAR(36), CUST_ID int, ADDRESS VARCHAR(45), FOREIGN KEY (CUST_ID) REFERENCES CUSTOMER(ID))");
        } catch (SQLException e) {
            LOG.error(e);
        }
    }

    private void createViews() {
        try {
            connection.createStatement().executeUpdate("CREATE VIEW CUSTOMER_VIEW AS SELECT * FROM CUSTOMER");
        } catch (SQLException e) {
            LOG.error(e);
        }
    }
}

public class MetadataExtractor {
    private final DatabaseMetaData databaseMetaData;

    public MetadataExtractor(Connection connection) throws SQLException {
        this.databaseMetaData = connection.getMetaData();
        DatabaseMetaData databaseMetaData = connection.getMetaData();
    }

    public void extractTableInfo() throws SQLException {
        try (ResultSet resultSet = databaseMetaData.getTables(null, null, "CUST%", new String[] { "TABLE" })) {
            while (resultSet.next()) {
                // Print the names of existing tables
                System.out.println(resultSet.getString("TABLE_NAME"));
                System.out.println(resultSet.getString("REMARKS"));
            }
        }
    }

    public void extractSystemTables() throws SQLException {
        try (ResultSet resultSet = databaseMetaData.getTables(null, null, null, new String[] { "SYSTEM TABLE" })) {
            while (resultSet.next()) {
                // Print the names of system tables
                System.out.println(resultSet.getString("TABLE_NAME"));
            }
        }
    }

    public void extractViews() throws SQLException {
        try(ResultSet resultSet = databaseMetaData.getTables(null, null, null, new String[] { "VIEW" })) {
            while (resultSet.next()) {
                // Print the names of existing views
                System.out.println(resultSet.getString("TABLE_NAME"));
            }
        }
    }

    public void extractColumnInfo(String tableName) throws SQLException {
        try(ResultSet columns = databaseMetaData.getColumns(null, null, tableName, null)) {
            while (columns.next()) {
                String columnName = columns.getString("COLUMN_NAME");
                String columnSize = columns.getString("COLUMN_SIZE");
                String datatype = columns.getString("DATA_TYPE");
                String isNullable = columns.getString("IS_NULLABLE");
                String isAutoIncrement = columns.getString("IS_AUTOINCREMENT");
                System.out.println(String.format("ColumnName: %s, columnSize: %s, datatype: %s, isColumnNullable: %s, isAutoIncrementEnabled: %s", columnName, columnSize, datatype, isNullable, isAutoIncrement));
            }
        }
    }

    public void extractPrimaryKeys(String tableName) throws SQLException {
        try(ResultSet primaryKeys = databaseMetaData.getPrimaryKeys(null, null, tableName)) {
            while (primaryKeys.next()) {
                String primaryKeyColumnName = primaryKeys.getString("COLUMN_NAME");
                String primaryKeyName = primaryKeys.getString("PK_NAME");
                System.out.println(String.format("columnName:%s, pkName:%s", primaryKeyColumnName, primaryKeyName));
            }
        }
    }

    public void extractForeignKeys(String tableName) throws SQLException {
        try(ResultSet foreignKeys = databaseMetaData.getImportedKeys(null, null, tableName)) {
            while (foreignKeys.next()) {
                String pkTableName = foreignKeys.getString("PKTABLE_NAME");
                String fkTableName = foreignKeys.getString("FKTABLE_NAME");
                String pkColumnName = foreignKeys.getString("PKCOLUMN_NAME");
                String fkColumnName = foreignKeys.getString("FKCOLUMN_NAME");
                System.out.println(String.format("pkTableName:%s, fkTableName:%s, pkColumnName:%s, fkColumnName:%s", pkTableName, fkTableName, pkColumnName, fkColumnName));
            }
        }
    }

    public void extractDatabaseInfo() throws SQLException {
        String productName = databaseMetaData.getDatabaseProductName();
        String productVersion = databaseMetaData.getDatabaseProductVersion();

        String driverName = databaseMetaData.getDriverName();
        String driverVersion = databaseMetaData.getDriverVersion();

        System.out.println(String.format("Product name:%s, Product version:%s", productName, productVersion));
        System.out.println(String.format("Driver name:%s, Driver Version:%s", driverName, driverVersion));
    }

    public void extractUserName() throws SQLException {
        String userName = databaseMetaData.getUserName();
        System.out.println(userName);
        try(ResultSet schemas = databaseMetaData.getSchemas()) {
            while (schemas.next()) {
                String table_schem = schemas.getString("TABLE_SCHEM");
                String table_catalog = schemas.getString("TABLE_CATALOG");
                System.out.println(String.format("Table_schema:%s, Table_catalog:%s", table_schem, table_catalog));
            }
        }
    }

    public void extractSupportedFeatures() throws SQLException {
        System.out.println("Supports scrollable & Updatable Result Set: " + databaseMetaData.supportsResultSetConcurrency(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE));
        System.out.println("Supports Full Outer Joins: " + databaseMetaData.supportsFullOuterJoins());
        System.out.println("Supports Stored Procedures: " + databaseMetaData.supportsStoredProcedures());
        System.out.println("Supports Subqueries in 'EXISTS': " + databaseMetaData.supportsSubqueriesInExists());
        System.out.println("Supports Transactions: " + databaseMetaData.supportsTransactions());
        System.out.println("Supports Core SQL Grammar: " + databaseMetaData.supportsCoreSQLGrammar());
        System.out.println("Supports Batch Updates: " + databaseMetaData.supportsBatchUpdates());
        System.out.println("Supports Column Aliasing: " + databaseMetaData.supportsColumnAliasing());
        System.out.println("Supports Savepoints: " + databaseMetaData.supportsSavepoints());
        System.out.println("Supports Union All: " + databaseMetaData.supportsUnionAll());
        System.out.println("Supports Union: " + databaseMetaData.supportsUnion());
    }
}


public class JdbcMetadataApplication {

    private static final Logger LOG = Logger.getLogger(JdbcMetadataApplication.class);

    public static void main(String[] args) {
        DatabaseConfig databaseConfig = new DatabaseConfig();
        databaseConfig.init();
        try {
            MetadataExtractor metadataExtractor = new MetadataExtractor(databaseConfig.getConnection());
            metadataExtractor.extractTableInfo();
            metadataExtractor.extractSystemTables();
            metadataExtractor.extractViews();
            String tableName = "CUSTOMER";
            metadataExtractor.extractColumnInfo(tableName);
            metadataExtractor.extractPrimaryKeys(tableName);
            metadataExtractor.extractForeignKeys("CUST_ADDRESS");
            metadataExtractor.extractDatabaseInfo();
            metadataExtractor.extractUserName();
            metadataExtractor.extractSupportedFeatures();
        } catch (SQLException e) {
            LOG.error("Error while executing SQL statements", e);
        }
    }
}

//statement vs preparedstatement


public class DatasourceFactory {

    private Connection connection;

    public Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("org.h2.Driver");
        connection = DriverManager.getConnection("jdbc:h2:mem:db_basic", "SA", "");
        connection.setAutoCommit(false);
        return connection;
    }

    public boolean createTables() throws SQLException {
        String query = "create table if not exists PERSONS (ID INT, NAME VARCHAR(45))";
        return connection.createStatement().executeUpdate(query) == 0;
    }

}


public class PersonEntity {
    private int id;
    private String name;

    public PersonEntity(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        PersonEntity that = (PersonEntity) o;
        return id == that.id && Objects.equals(name, that.name);
    }

    @Override public int hashCode() {
        return Objects.hash(id, name);
    }
}

public class StatementPersonDao {

    private final Connection connection;

    public StatementPersonDao(Connection connection) {
        this.connection = connection;
    }

    public Optional<PersonEntity> getById(int id) throws SQLException {
        String query = "SELECT id, name, FROM persons WHERE id = '" + id + "'";

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);

        if (resultSet.first()) {
            PersonEntity result = new PersonEntity(resultSet.getInt("id"),
                    resultSet.getString("name"));
            return Optional.of(result);
        } else {
            return Optional.empty();
        }
    }

    public void insert(PersonEntity personEntity) throws SQLException {
        String query = "INSERT INTO persons(id, name) VALUES(" + personEntity.getId() + ", '"
                + personEntity.getName() + "')";

        Statement statement = connection.createStatement();
        statement.executeUpdate(query);
    }

    public void insert(List<PersonEntity> personEntities) throws SQLException {
        for (PersonEntity personEntity : personEntities) {
            insert(personEntity);
        }
    }

    public void update(PersonEntity personEntity) throws SQLException {

        String query = "UPDATE persons SET name = '" + personEntity.getName() + "' WHERE id = "
                + personEntity.getId();

        Statement statement = connection.createStatement();
        statement.executeUpdate(query);

    }

    public void deleteById(int id) throws SQLException {
        String query = "DELETE FROM persons WHERE id = " + id;
        Statement statement = connection.createStatement();
        statement.executeUpdate(query);
    }

    public List<PersonEntity> getAll() throws SQLException {
        String query = "SELECT id, name, FROM persons";

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        List<PersonEntity> result = new ArrayList<>();
        while (resultSet.next()) {
            result.add(new PersonEntity(resultSet.getInt("id"), resultSet.getString("name")));
        }
        return result;
    }
}

public class PreparedStatementPersonDao {

    private final Connection connection;

    public PreparedStatementPersonDao(Connection connection) {
        this.connection = connection;
    }

    public Optional<PersonEntity> getById(int id) throws SQLException {
        String query = "SELECT id, name FROM persons WHERE id = ?";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, id);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.first()) {

            PersonEntity result = new PersonEntity(resultSet.getInt("id"),
                    resultSet.getString("name"));

            return Optional.of(result);
        } else {
            return Optional.empty();
        }

    }

    public void insert(PersonEntity personEntity) throws SQLException {

        String query = "INSERT INTO persons(id, name) VALUES( ?, ?)";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, personEntity.getId());
        preparedStatement.setString(2, personEntity.getName());
        preparedStatement.executeUpdate();

    }

    public void insert(List<PersonEntity> personEntities) throws SQLException {
        String query = "INSERT INTO persons(id, name) VALUES( ?, ?)";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        for (PersonEntity personEntity : personEntities) {
            preparedStatement.setInt(1, personEntity.getId());
            preparedStatement.setString(2, personEntity.getName());
            preparedStatement.addBatch();
        }
        preparedStatement.executeBatch();

    }

    public void update(PersonEntity personEntity) throws SQLException {
        String query = "UPDATE persons SET name = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, personEntity.getName());
        preparedStatement.setInt(2, personEntity.getId());
        preparedStatement.executeUpdate();
    }

    public void deleteById(int id) throws SQLException {
        String query = "DELETE FROM persons WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, id);
        preparedStatement.executeUpdate();
    }

    public List<PersonEntity> getAll() throws SQLException {
        String query = "SELECT id, name FROM persons";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();
        List<PersonEntity> result = new ArrayList<>();
        while (resultSet.next()) {
            result.add(new PersonEntity(resultSet.getInt("id"), resultSet.getString("name")));
        }
        return result;
    }
}*/
