package Practise1;

import java.util.ArrayList;
import java.util.List;

public class StudentInformationManagementSystem {
    public static void main(String[] args) {
        List<String> arr=new ArrayList<String>();

        arr.add("sjkdjflkd");
        arr.add("ram");
        arr.add("rahul");
        arr.add("Kunal");
        System.out.println(arr);
        arr.remove(1);
        //arr.add(5,"raj");
        System.out.println(arr);
        for(String str:arr){
            System.out.println(arr);
        }
        System.out.println(arr.get(1));
        arr.set(2,"sohal");
        System.out.println(arr.get(2));
    }
}
