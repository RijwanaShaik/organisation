package Practise1;

import java.util.LinkedList;

public class LinkedListMethods {

        // This program demonstrates that all methods in LinkedList
        LinkedList<String> software = new LinkedList<String>();

        public void insertion()   // This method is for to insert elements into LinkedList
        {
            this.software.add("Thrymr");
            this.software.add("infosys");
            this.software.add("Wipro");

            System.out.println(software);
        }

        public void addFirstMethod()    // This method is for to addFirst()
        {
            this.software.addFirst("Thrymr Software");
            System.out.println("----------------------------");
            System.out.println("After adding first element");
            System.out.println(software);
        }

        public void addLastMethod()   // This method is for to addLast()
        {
            this.software.addLast("Thrymr Hyd");
            System.out.println("---------------------------");
            System.out.println("After adding element at last:");
            System.out.println(software);
        }

        public void getFirstMethod()    // This method is for to get first element
        {
            System.out.println("------------------------------------");
            System.out.println("getting first element using getFirst()");
            System.out.println(software.getFirst());
        }

        public void getLastMethod()   // This method is for to get last element in Linked List
        {
            System.out.println("---------------------------");
            System.out.println("getting last element using getLast():");
            System.out.println(software.getLast());
        }

        public void removeFirstMethod()   // This method is for to remove first element
        {
            System.out.println("----------------------------");
            System.out.println("Remove first element using removeFirst()");
            software.removeFirst();
            System.out.println(software);
        }

        public void removeLastMethod()  // This method is for to remove last  element
        {
            System.out.println("---------------------------");
            System.out.println("Remove last element using removeLast()");
            software.removeLast();
            System.out.println(software);
        }

        public static void main(String[] args) {
            System.out.println("This is an Example program that demonstrates that all methods in LinkedList");
            System.out.println("_____________________________________________________________________________");
            LinkedListMethods linkedList = new LinkedListMethods();
            linkedList.insertion();
            linkedList.addFirstMethod();
            linkedList.addLastMethod();
            linkedList.getFirstMethod();
            linkedList.getLastMethod();
            linkedList.removeFirstMethod();
            linkedList.removeLastMethod();
        }
    }

