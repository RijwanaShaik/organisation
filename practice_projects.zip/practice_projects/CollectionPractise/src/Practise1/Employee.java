package Practise1;

import java.util.Scanner;

public class Employee {
    int id;
    String name;
    String designation;
    float salary;

    public Employee(int id, String name, String designation, float salary) {
        this.id = id;
        this.name = name;
        this.designation = designation;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", designation='" + designation + '\'' +
                ", salary=" + salary +
                '}';
    }

    public static void main(String[] args) {
        int size=10;
        Employee[] emp=new Employee[size];
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the id");
        //id=sc.nextInt();
    }
}
    /*public static void main(String[] args) {
        int arraySize = 10;
      //  Employee emps[] = new Emp[arraySize];

        int count = 0; // input employee count
     //   Scanner sc = new Scanner();
        // Enter emp Id, name
        //count++;
        // Yes or No

        // Create a Employee object and store it into emps array

        if( count >= (arraySize-4)){
            // Here is the logic to increment the emps array
            // Move the actual Employee data to temporary array
            // reinitialize the emps array with new size
            arraySize = arraySize+5;
          //  emps[] = new Emp[arraySize];
            // Copy temp array data to emps
            // Then allow new Employee data to emps

        }
 */

/*
class IncreaseArraySize {
    public static void main(String[] args) {
        int arr[] = new int[5];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = 5;
        }
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println(" ");
        System.out.println("Before increasing Size of an array :" + arr.length);


        int arr2[] = new int[10];

        arr = arr2;
        arr2 = null;
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println("");
        System.out.println("After increasing Size of an array : " + arr.length);
    }
}*/
