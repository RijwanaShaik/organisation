package Practise1;

public class StackDemo {
    int  arr[]=new int[10];
    int top=-1;
    public boolean push(int n){
        if(top==-1||arr.length>=top){

                top++;
           arr[top]=n;
         System .out .println(n);
            return true;
        }
        return false ;

    }
    public boolean pop(){
        if(!isEmpty()){
            int i= arr[top--];
           System .out.println (i);
            return true ;
        }
        return false ;

    }
    public boolean isEmpty (){

        return (top<0);
    }
    public int size(){
        top=top+1;
        return top;
    }
    public int topM(){
        if(top<0){
            return top;
        }return arr[top];

    }
    public static void main(String[] args) {
        StackDemo stackDemo = new StackDemo();
        boolean pushStatus =stackDemo.push(10);
        stackDemo.push(20);
        stackDemo.push(30);
       boolean popStatus =  stackDemo.pop();
        int topValue = stackDemo.topM();
        boolean isStackEmpty = stackDemo.isEmpty();
        int stackSize =stackDemo.size();
        System.out.println("-------****--------- ");

        System.out.println("Push() "+pushStatus);
        System.out.println("pop() "+popStatus);
        System .out .println ("top() "+topValue );
        System.out.println("isEmpty() "+isStackEmpty);
        System.out.println("size "+stackSize);

    }
}
