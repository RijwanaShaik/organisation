package Practise1;

import java.util.LinkedList;

public class Demo {
    public static void main(String[] args) {
       LinkedList<String> str=new LinkedList<String>();
       str.add("Hello");
       str.add("World");
       str.add("Message");
       str.add("from");
       str.add("GeeksforGeeks");
        System.out.println(str);
        System.out.println(str.getFirst());
        System.out.println(str.getLast());
        str.addFirst("Hi");
        System.out.println(str+" -added hi element at first position of linked list ");
        str.addLast("website");
        System.out.println(str+" -added webiste elemetn at last position of linked list ");
        System.out.println(str.removeFirst());
        System.out.println(str.removeLast());
       // System.out.println(str);
    //    LinkedList<String> str1=new LinkedList<String>();
      String  str1= String.valueOf(str.clone());
        System.out.println(str1);
        /*Object ob=str.clone();
        System.out.println("using clone() "+ob);*/

    }
}
