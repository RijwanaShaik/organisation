package JDBCPractise;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class createtb {
    public static void main(String[] args) {
        String driver = "org.postgresql.Driver";
        final String DB_URL = "jdbc:postgresql://localhost:5432/postgres";
        final String USER = "postgres";
        final String PASS = "thrymr@123";
        final String QUERY = "create table dummy2(id int,name varchar(20),salary float,email varchar(20))";


        try {
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(QUERY);
            System.out.println(rs);
            /*while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int salary = rs.getInt("salary");
                System.out.println("ID = " + id + "  NAME = " + name + " salary = " + salary);

            }*/
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    }

