package JDBCPractise;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class AccountStoringApplication {
    public static void main(String[] args)  throws ClassNotFoundException, SQLException {
        Class.forName("org.postgresql.Driver");
        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "thrymr@123");
        Statement st = con.createStatement();
        int insert = st.executeUpdate("insert into account values(14,'koushik',3456)");
        System.out.println(insert+" inserted");
        int insert2 = st.executeUpdate("insert into account values(13,'rahul',3339)");
        System.out.println(insert2+" inserted");

        con.close();
    }
}
