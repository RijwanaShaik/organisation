package java10;

public class ExecutingParllelThreads {
    public static void main(String[] args) {
SMS s1=new SMS();
Email e=new Email();
Whatsapp w=new Whatsapp();
s1.start();
e.start();
w.start();
    }
}
