package java10;

public class Synchronisation {
}
class ExampleWithoutSyn implements Runnable
{
    int tickets = 3;
    static int i = 1, j = 2, k = 3;
    public void bookticket (String name, int wantedtickets)
    {
        if (wantedtickets <= tickets)
        {
            System.out.println (wantedtickets + " booked to " + name);
            tickets = tickets - wantedtickets;
        }
        else
        {
            System.out.println ("No tickets to book");
        }
    }
    public void run ()
    {
        String name = Thread.currentThread ().getName ();
        if (name.equals ("t1"))
        {
            bookticket (name, i);
        }
        else if (name.equals ("t2"))
        {
            bookticket (name, j);
        }
        else
        {
            bookticket (name, k);
        }
    }
    public static void main (String[]args)
    {
        ExampleWithoutSyn s = new ExampleWithoutSyn ();
        Thread t1 = new Thread (s);
        Thread t2 = new Thread (s);
        Thread t3 = new Thread (s);
        t1.setName ("t1");
        t2.setName ("t2");
        t3.setName ("t3");
        t1.start ();
        t2.start ();
        t3.start ();
    }
}
/*the tickets available are 3 ,while multiple threads accessing the booking ticket method,it shows no tickets to book ,even there is one ticket
/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise packSynchronization.ExampleWithoutSyn
        1 booked to t1
        2 booked to t2
        No tickets to book*/
class ExampleWithSynBlock implements Runnable{
    int token=1;
    @Override
    public void run() {
        synchronized (this){
            Thread t=Thread.currentThread();
            String name=t.getName();
            System.out.println(token+".......allocated to"+name);
            token++;
        }
    }
}
class SynBlock{
    public static void main(String[] args) {
        ExampleWithSynBlock a=new ExampleWithSynBlock();
        Thread t1=new Thread(a);
        Thread t2=new Thread(a);
        Thread t3=new Thread(a);
        t1.setName("t1");
        t2.setName("t2");
        t3.setName("t3");
        t1.start();
        t2.start();
        t3.start();
    }
}
//with synchornization block the tickets are correctly allocated to accesing people
/*/home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise packSynchronization.SynBlock
        1.......allocated tot1
        2.......allocated tot3
        3.......allocated tot2*/
class ExampleWithSynMethod implements Runnable
{
    int tickets = 3;
    static int i = 1, j = 2, k = 3;
    synchronized void bookticket (String name, int wantedtickets)
    {
        if (wantedtickets <= tickets)
        {
            System.out.println (wantedtickets + " booked to " + name);
            tickets = tickets - wantedtickets;
        }
        else
        {
            System.out.println ("No tickets to book");
        }
    }
    public void run ()
    {
        String name = Thread.currentThread ().getName ();
        if (name.equals ("t1"))
        {
            bookticket (name, i);
        }
        else if (name.equals ("t2"))
        {
            bookticket (name, j);
        }
        else
        {
            bookticket (name, k);
        }
    }
    public static void main (String[]args)
    {
        ExampleWithSynMethod s = new ExampleWithSynMethod();
        Thread t1 = new Thread (s);
        Thread t2 = new Thread (s);
        Thread t3 = new Thread (s);
        t1.setName ("t1");
        t2.setName ("t2");
        t3.setName ("t3");
        t1.start ();
        t2.start ();
        t3.start ();
    }
}
/*
//home/thrymrthrymr123/Documents/practice_projects/FilesPractise/out/production/FilesPractise packSynchronization.ExampleWithSynMethod
1 booked to t1
2 booked to t2
No tickets to book

*/
class Customer{
    int amount=10000;

    synchronized void withdraw(int amount){
        System.out.println("going to withdraw...");

        if(this.amount<amount){
            System.out.println("Less balance; waiting for deposit...");
            try{wait();}catch(Exception e){}
        }
        this.amount-=amount;
        System.out.println("withdraw completed...");
    }

    synchronized void deposit(int amount){
        System.out.println("going to deposit...");
        this.amount+=amount;
        System.out.println("deposit completed... ");
        notify();
    }
}

class Test{
    public static void main(String args[]){
        final Customer c=new Customer();
        new Thread(){
            public void run(){
                c.withdraw(15000);}
        }.start();
        new Thread(){
            public void run(){c.deposit(10000);}
        }.start();

    }}
//the synchronization concept mostly used in shared resources,while multiple people accessing the same resource
//In the above scenario,second thread has to wait until the work of first thread completed
//Synchronization is the capability of controlling access of multi-threads to any shared resources. It is better for when we want only one thread to access the shared resource at a time.