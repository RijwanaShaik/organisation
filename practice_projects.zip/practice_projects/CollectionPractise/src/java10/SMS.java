package java10;

public class SMS extends Thread{
    @Override
    public void run() {
        System.out.println("Sending Sms message"+Thread.currentThread().getName());
    }
}
