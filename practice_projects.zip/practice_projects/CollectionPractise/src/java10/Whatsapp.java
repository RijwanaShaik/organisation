package java10;

public class Whatsapp extends Thread{
    @Override
    public void run() {
        System.out.println("Sending Whatsapp Messsage"+Thread.currentThread().getName());
    }
}
