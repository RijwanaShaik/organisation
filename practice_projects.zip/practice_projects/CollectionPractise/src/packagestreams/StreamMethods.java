package packagestreams;
//geeks for geeks
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class StreamMethods {
    public static void main(String[] args) {
        List<Integer> number= Arrays.asList(2,3,4,5);
        List<Integer> square=number.stream().map(x->x*x).collect(Collectors.toList());
       System.out.println(square);
        List<String> names = Arrays.asList("Reflection","Collection","Stream");
        // demonstration of filter method
        List<String> result = names.stream().filter(s ->s.startsWith("S")).collect(Collectors.toList());
       System.out.println(result);
        //demonstration of sorted method
        List<String> show=names.stream().sorted().collect(Collectors.toList());
       System.out.println(show);
        //create a list of integers
        List<Integer> numbers=Arrays.asList(2,3,4,5);
        //collect method returns a set
        Set<Integer> squareSet=numbers.stream().map(x->x*x).collect(Collectors.toSet());
        System.out.println(squareSet);
        //demonstration of forEach method
       number.stream().map(x->x*x).forEach(y-> System.out.println(y));
        //demonstration of reduce method
        int even=number.stream().filter(x->x%2==0).reduce(0,(ans,i)->ans+i);
       System.out.println(even);
       List<Integer> list=Arrays.asList(1,1,2,3,3,4,5,5);
        System.out.println("The distinct elements are: ");
        list.stream().distinct().forEach(System.out::println);//same syntax for string list
        //to find duplicate elements in a list
        Set<Integer> set=new HashSet<>();
        System.out.println("The duplicate elements present in a list are");
        list.stream().filter(n->!set.add(n)).forEach(System.out::println);
        //storing the count of distinct elements in the lsit using stream.distinct() method
        long Count=list.stream().distinct().count();
        System.out.println("The count of distinct elements is: "+Count);
List<Integer> listskip=Arrays.asList(1,2,3,4,5,6,7,8,9,10);
//listskip.stream().skip(2).forEach(System.out::println);
        listskip.stream().skip(2).limit(6).forEach(System.out::println);

    }
}
