package packagestreams;

import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//example from stackoverflow
public class StreamQuestionFromStack {
}
class TestFilter {
    static class Employee {
        String name;
        double salary;
        long id;

        public Employee(String name, long id, double salary) {
            this.name = name;
            this.id = id;
            this.salary = salary;
        }

        String genNextName() {
            return "Emp-" + (this.id + 1);
        }

        double genNextSalary() {
            return new Random().nextDouble() * 1000000;
        }

        long genNextId() {
            return this.id + 1;
        }

        @Override
        public String toString() {
            return this.id + " " + this.name + " " + this.salary + "\n";
        }
    }

    public static void main(String[] args) {
        List<Employee> employees = createDummyEmployee(10000000l);
        List<Employee> emps = null;
        long time = 0;
        for (int i = 0; i < 50; i++) {

            Optional<Employee> e1 = employees.stream()
                    .filter(e -> e.name.endsWith("999"))
                    .filter(e -> e.salary > 10000)
                    .filter(e -> e.id % 2 == 1)
                    .findAny();

            Optional<Employee> e2 = employees.stream()
                    .filter(e -> e.name.endsWith("999"))
                    .filter(e -> e.salary > 10000)
                    .filter(e -> e.id % 2 == 1)
                    .findFirst();

            Optional<Employee> pe1 = employees.parallelStream()
                    .filter(e -> e.name.endsWith("999"))
                    .filter(e -> e.salary > 10000).filter(e -> e.id % 2 == 1)
                    .findAny();

            Optional<Employee> pe2 = employees.parallelStream()
                    .filter(e -> e.name.endsWith("999"))
                    .filter(e -> e.salary > 10000)
                    .filter(e -> e.id % 2 == 1)
                    .findFirst();

            System.out.print("FindAny without parallel : " + (e1.isPresent() ? e1.get().id + "" : "null"));
            System.out.print(" | FindFirst without parallel : " + (e2.isPresent() ? e2.get().id + "" : "null"));
            System.out.print(" | FindAny by Parallel : " + (pe1.isPresent() ? pe1.get().id + "" : "null"));
            System.out.print(" | FindFirst by Parallel : " + (pe2.isPresent() ? pe2.get().id + "" : "null"));
            System.out.println();
        }
    }

    public static List<Employee> createDummyEmployee(long n) {
        Employee e1 = new Employee("Emp-1", 1l, 1.0);
        return Stream.iterate(e1, (Employee e) -> new Employee(e.genNextName(), e.genNextId(), e.genNextSalary())).limit(n).collect(Collectors.toList());
    }
}