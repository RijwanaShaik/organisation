package packagestreams;

import java.util.*;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static java.util.function.UnaryOperator.identity;
import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.groupingBy;

public class StreamPractise {
    public static void main(String[] args) {
        //stream.of()
        Stream<Integer> stream=Stream.of(1,2,3,4,5);
        //stream.forEach(p-> System.out.println(p));
        //stream.of(array)
        Stream<Integer> stream2=Stream.of(new Integer[]{1,2,3,4,5});
       //   stream2.forEach(p-> System.out.println(p));
          //List.stream()
        List<Integer> list=new ArrayList<Integer>();
        for(int i=0;i<=10;i++){
            list.add(i);
        }
        Stream<Integer> stream3=list.stream();
      //  stream3.forEach(p-> System.out.println(p));
        // Stream.generate() or Stream.iterate()
        Stream<Integer> randomNumbers=Stream.generate(()->(new Random().nextInt(100)));
        randomNumbers.limit(20).forEach(System.out::println);
        //stream of string chars or tokens
        IntStream stream1="12345_abcdefg".chars();
        stream1.forEach(p-> System.out.println(p));
               //or
        Stream<String> stream4=Stream.of("A$B$C".split("\\$"));
        stream4.forEach(p-> System.out.println(p));

    }
}
class example1{
    public static void main(String[] args) {
        Stream<String> words = Stream.of("Java", "Magazine", "is",
                "the", "best");
        Map<String,Long> letterToCount=words.map(w->w.split("")).flatMap(Arrays::stream).collect(groupingBy(identity(),counting()));
        System.out.println(letterToCount);
    }
}