package packagestreams;


import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Employee {
    private int id;
    private String name;
    private String grade;
    private double salary;

    public Employee() {
    }

    public Employee(int id, String name, String grade, double salary) {
        this.id = id;
        this.name = name;
        this.grade = grade;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", grade='" + grade + '\'' +
                ", salary=" + salary +
                '}';
    }
    String DepartmentName;

    public static void main(String[] args) {
   /*     List<Employee> employees =  Stream.of(new Employee(101,"john","A",60000),
                            new Employee(109,"peter","B",30000),
                            new Employee(102,"mak","A",80000),
                            new Employee(103,"kim","A",90000),
                            new Employee(104,"json","C",15000))
                    .collect(Collectors.toList());

        //get employee whose grade A
        //get salary
       double avgSalary= employees.stream().filter(employee -> employee.getGrade().equalsIgnoreCase("A"))
                .map(employee -> employee.getSalary())
                .mapToDouble(i -> i)
                .average().getAsDouble();

        System.out.println(avgSalary);

        double sumSalary = employees.stream()
                .filter(employee -> employee.getGrade().equalsIgnoreCase("A"))
                .map(employee -> employee.getSalary())
                .mapToDouble(i -> i)
                .sum();
       //  System.out.println(sumSalary);
          Optional<Employee> salary1=employees.stream().max(Comparator.comparingDouble(Employee::getSalary));
        System.out.println(salary1.get());*/
        List<Employee> list=Arrays.asList(
        new Employee(101,"John","HR",20000),
        new Employee(102,"Peter","Techincal",25000),
        new Employee(103,"Harry","Developer",30000),
        new Employee(104,"Sohal","HR",20000));
        Employee[] emp=list.stream().toArray(Employee[] ::new);
       //   System.out.println(Arrays.toString(emp));
        for(Employee e:emp){
            System.out.println(e+" ");

        }
         //salary increment
        list.stream().map(i->i.salary+ i.salary*20/100).forEach(System.out::println);
       //  list.stream().map(i->i.getSalary()+ i.getSalary()*20/100).collect(Collectors.toList()).forEach(System.out::println);
        List<Employee> salaryGreater=list.stream().filter(e->e.salary>20000).filter(e->e !=null).collect(Collectors.toList());
        System.out.println(salaryGreater);
        //findfirst
       Employee findfirst= list.stream().filter(e->e.salary>20000 && e.salary<30000).findFirst().get();
        System.out.println(findfirst);
        //count of employee salary greater than 20000
        long countlist=list.stream().filter(e->e.salary>20000).count();
        System.out.println(countlist);
        //sort thelist by name
        list.stream().sorted(Comparator.comparing(Employee::getName)).forEach(System.out::println);
        //max,min salary
        Optional<Employee> maxsal=list.stream().max(Comparator.comparingDouble(Employee::getSalary));
        System.out.println(maxsal.get());
        Optional<Employee> minsal=list.stream().min(Comparator.comparingDouble(Employee::getSalary));
        System.out.println(minsal.get());
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter salary: ");
        int sal=sc.nextInt();
        boolean salarygiven=list.stream().allMatch(employee -> employee.getSalary()==sal);
        System.out.println(salarygiven);
        boolean salaryatleastone=list.stream().anyMatch(employee -> employee.getSalary()==sal);
        System.out.println(salaryatleastone);
        boolean salarygivennonematch=list.stream().noneMatch(employee -> employee.getSalary()==sal);
        System.out.println(salarygivennonematch);
        //13)Take a Map, key is Department Name and value is List <Employees>.Perform Stream Functions grouping by Department Name.
       Map<String,List<Employee>> stringEmployeeMap=list.stream().collect(Collectors.groupingBy(Employee::getGrade));
       // System.out.println(stringEmployeeMap);
        stringEmployeeMap.forEach((grade,e)-> System.out.format("grade %s: %s\n",grade,e));
        //16) Take an Employee list print all the employees whose name & id  are not null and salary is greater than 20000.
       Predicate<Employee> p1=e-> e !=null;
       Predicate<Employee> p2=e->e.getSalary()>20000;
     //  list.stream().filter(p1.and(p2)).forEach(System.out::println);
        //get avg salary of employee whose id is odd position
       Predicate<Employee> p=e->(e.id %2 ==1);
       list.stream().filter(p).forEach(System.out::println);
      double avgsal=  list.stream().filter(p).mapToDouble(Employee::getSalary).average().getAsDouble();
        System.out.println(avgsal);
      //changing employee name in uppercase
        List<Employee> nameuppercase= list.stream().map(e -> {e.setName(e.getName().toUpperCase());return e;}).collect(Collectors.toList());
        System.out.println(nameuppercase);
        Predicate<Employee> predicate1=e->e.getName().startsWith("S");
        Predicate<Employee> predicate2=e->e.getName().endsWith("l");
       List<Employee> namestart=list.stream().filter(predicate1.and(predicate2.negate())).collect(Collectors.toList());
        System.out.println(namestart);
        //group by department and their count or fileter by department,group by gender and their count
        Map<String,Long> countbygrade=list.stream().filter(e->e.getGrade()=="HR").collect(Collectors.groupingBy(Employee::getGrade,Collectors.counting()));
        System.out.println(countbygrade.entrySet());
        //avg salary by department or gender
        Map<String,Double> avgsal2=list.stream().collect(Collectors.groupingBy(Employee::getGrade,Collectors.averagingDouble(Employee::getSalary)));
        System.out.println(avgsal2);
    }
}