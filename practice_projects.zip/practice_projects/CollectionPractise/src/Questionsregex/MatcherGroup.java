package Questionsregex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatcherGroup {
    public static void main(String[] args) {
        String regex="(.*)(\\d+)(.*)";
        String input="This is a sample Text, 1234, with numbers in between.";
        //creating a pattern object
        Pattern pattern=Pattern.compile(regex);
        //Matching the complied pattern in the string
        Matcher matcher= pattern.matcher(input);
        if(matcher.find()){
            System.out.println(matcher.group(0));
        }
        System.out.println(matcher.group(1));
    }
}
