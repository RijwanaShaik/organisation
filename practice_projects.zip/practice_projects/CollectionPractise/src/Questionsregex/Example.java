package Questionsregex;

public class Example {
    public static void main(String[] args) {
        //Address
        System.out.println("Address");
        System.out.println("2-63, Sbi-Colony Nandyal".matches("\\d+-?\\d+,\\s([A-z]+)-([A-z]+)\\s([A-z]+)"));
        System.out.println("1234 N Spauld street".
                matches("\\d+\\s([A-Za-z]+|[a-zA-Z]\\s[a-zA-Z]+\\s[a-zA-z]*)"));
        //phone number
        System.out.println("891-234-6578".matches("[1-9]\\d{2}-\\d{3}-\\d{4}"));
        System.out.println("091-234-6578".matches("[1-9]\\d{2}-\\d{3}-\\d{4}"));
        System.out.println("8912346578".matches("[1-9]\\d{2}-?\\d{3}-?\\d{4}"));
        System.out.println("8912346578".matches("\\d{10}"));
        System.out.println("Sum_".matches("^[a-zA-z_$]*"));
        System.out.println("ABC".matches("[a-zA-z]{3}"));
        System.out.println("12-23 abc_$".matches(
                "[1-9]\\d{1}-\\d{2}\\s([A-zA-z_$]*)"));
        //Date of Birth
        System.out.println("Date of Birth");
        System.out.println("2008-02-20".
                matches("\\d{4}-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9])|3[01]"));
        //email validate
        System.out.println("kunal_2shaik@gmail.com".
                matches("^[_A-Za-z0-9-]+(.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(.[A-Za-z0-9]+)*(.[A-Za-z]{2,})$"));
        System.out.println("email validation");
        System.out.println("kunal223@gmail.com".matches("^(\\w+)(.\\w+)(@)([a-z]+)(.[a-z]{3})"));
        //password for email
        System.out.println("Password");
       System.out.println("kunal@123".matches("(\\w+[!@#%&]?){8,}"));

      ;

    }
}
