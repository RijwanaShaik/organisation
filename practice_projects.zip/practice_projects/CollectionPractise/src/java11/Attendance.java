package java11;

public class Attendance {
    int aId;
    String date;
 String status;

    public Attendance(int aId, String date, String status) {
        this.aId = aId;
        this.date = date;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Attendance{" +
                "aId=" + aId +
                ", date=" + date +
                ", status=" + status +
                '}';
    }
}
