package java11;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Example {
}
class att{
    int aId;
    List<String> dateList;
    List<String > status;

    public att(int aId, List<String> dateList, List<String> status) {
        this.aId = aId;
        this.dateList = dateList;
        this.status = status;
    }

    @Override
    public String toString() {
        return "att{" +
                "aId=" + aId +
                ", dateList=" + dateList +
                ", status=" + status +
                '}';
    }
}
class empc{
    int eId;
    String eName;
    List<att> attList;

    public int geteId() {
        return eId;
    }

    public void seteId(int eId) {
        this.eId = eId;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public List<att> getAttList() {
        return attList;
    }

    public void setAttList(List<att> attList) {
        this.attList = attList;
    }

    public empc(int eId, String eName, List<att> attList) {
        this.eId = eId;
        this.eName = eName;
        this.attList = attList;
    }

    @Override
    public String toString() {
        return "empc{" +
                "eId=" + eId +
                ", eName='" + eName + '\'' +
                ", attList=" + attList +
                '}';
    }
}
class org{
        int oId;
        String oName;
        List<empc> empcList;

    public int getoId() {
        return oId;
    }

    public void setoId(int oId) {
        this.oId = oId;
    }

    public String getoName() {
        return oName;
    }

    public void setoName(String oName) {
        this.oName = oName;
    }

    public List<empc> getEmpcList() {
        return empcList;
    }

    public void setEmpcList(List<empc> empcList) {
        this.empcList = empcList;
    }

    public org(int oId, String oName, List<empc> empcList) {
        this.oId = oId;
        this.oName = oName;
        this.empcList = empcList;
        }

@Override
public String toString() {
        return "org{" +
        "oId=" + oId +
        ", oName='" + oName + '\'' +
        ", empcList=" + empcList +
        '}';
        }

public static void main(String[] args) {
        // org o1=new org(3004,"Tcs",Arrays.asList(10,"raj",))
       /* List<String> dateList=new ArrayList<>();
        dateList.add(0,"20-10-2022");
        dateList.add(1,"21-10-2022");
        List<String> statuslist=new*/
        // List<att> attList=new ArrayList<>();
    //attendance objects
        att att1=new att(60, Arrays.asList("20-10-2022","21-10-2022"),Arrays.asList("Present","present"));
        att att2=new att(62,Arrays.asList("20-10-2022","21-10-2022"),Arrays.asList("Absent","present"));
        //list of attendacne objects
        List<att> attList=new ArrayList<>();
        attList.add(att1);
        List<att> attList1=new ArrayList<>();
        attList1.add(att2);
        //emp objects
        empc empc1=new empc(110,"raj",attList);
        empc empc2=new empc(111,"ram",attList1);
        //list of empobjects
        List<empc> empcList1=new ArrayList<>();
        empcList1.add(empc1);
        List<empc> empcList2=new ArrayList<>();
        empcList2.add(empc2);
        //org objects
    org org1=new org(3003,"Tcs",empcList1);
    org org2=new org(3002,"Thrymr",empcList2);
    List<org> orgList1=new ArrayList<>();
    orgList1.add(org1);
    orgList1.add(org2);
    System.out.println(orgList1);
  //  orgList1.stream().filter(e-> Boolean.parseBoolean(e.oName)).collect(Collectors.toList());
    /*Map<Integer,List<org>> listMap=new HashMap<>();
    listMap.put(1,orgList1);
    for(Map.Entry<Integer,List<org>> mn: listMap.entrySet()){
        System.out.println(mn.getValue());
    }*/
    List<String> orgEmp=orgList1.stream().map(e->e.getoName()).collect(Collectors.toList());
    System.out.println(orgEmp);

}
}
/*
public class Organisation {
    int organisationId;
    String organisationName;
    List<Employee> employeeList;
    List<Attendance> attendanceList;
    public Organisation(int organisationId, String organisationName, List<Employee> employeeList, List<Attendance> attendanceList) {
        this.organisationId = organisationId;
        this.organisationName = organisationName;
        this.employeeList = employeeList;
        this.attendanceList = attendanceList;
    }
}
public class Employee {
    int id;
    String employeeName;
    Organisation organisationList;
    List attendanceList;
    public Employee(int id, String employeeName, Organisation organisationList,List attendanceList) {
        this.id = id;
        this.employeeName = employeeName;
        this.organisationList = organisationList;
        this.attendanceList = attendanceList;
    }
    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", employeeName='" + employeeName + '\'' +
                ", organisationList=" + organisationList +
                ", attendanceList=" + attendanceList +
                '}';
    }
}
public class Attendance {
    String attendanceStatus, date;
    Employee employeeSet;
    Organisation organisation;
    public Attendance( String attendanceStatus, String date, Employee employeeSet, Organisation organisations) {
        this.attendanceStatus = attendanceStatus;
        this.date = date;
        this.employeeSet = employeeSet;
        this.organisation = organisations;
    }
    @Override
    public String toString() {
        return "Attendance{" +
                ", attendanceStatus='" + attendanceStatus + '\'' +
                ", date='" + date + '\'' +
                ", employeeSet=" + employeeSet +
                ", organisations=" + organisation +
                '}';
    }
}
public class EmployeeData {
    List<Organisation> organisations1 = new ArrayList<Organisation>();
    List<Employee> employees = new ArrayList<Employee>();
    List<Attendance> attendance = new ArrayList<Attendance>();
    public void initialization() {
        organisations1.add(0,new Organisation(1,"Thrymr", employees,  attendance));
        organisations1.add(1,new Organisation(2,"TCS", employees,  attendance));
        employees.add(0,new Employee(111, "pavan", organisations1.get(0),attendance));
        employees.add(1,new Employee(123, "pavan", organisations1.get(1),attendance));
        employees.add(2,new Employee(122, "sai", organisations1.get(0),attendance));
        employees.add(3,new Employee(199, "arun", organisations1.get(1),attendance));
        attendance.add( new Attendance( "Absent","2022-10-11",employees.get(0),organisations1.get(0)));
        attendance.add( new Attendance( "Present","2022-10-12",employees.get(0),organisations1.get(0)));
        attendance.add( new Attendance( "Absent","2022-10-11",employees.get(0),organisations1.get(0)));
        attendance.add( new Attendance( "Present","2022-10-14",employees.get(0),organisations1.get(0)));
        attendance.add( new Attendance( "Present","2022-10-15",employees.get(0),organisations1.get(0)));
        attendance.add( new Attendance( "Absent","2022-10-16",employees.get(0),organisations1.get(0)));
        attendance.add( new Attendance( "Absent","2022-10-11",employees.get(1),organisations1.get(1)));
        attendance.add( new Attendance( "Absent","2022-10-12",employees.get(1),organisations1.get(1)));
        attendance.add( new Attendance( "Present","2022-10-14",employees.get(1),organisations1.get(1)));
        attendance.add( new Attendance( "Present","2022-10-15",employees.get(1),organisations1.get(1)));
        attendance.add( new Attendance( "Present","2022-10-16",employees.get(1),organisations1.get(1)));
        attendance.add( new Attendance( "Absent","2022-10-17",employees.get(1),organisations1.get(1)));
        attendance.add( new Attendance( "Absent","2022-10-11",employees.get(2),organisations1.get(0)));
        attendance.add( new Attendance( "Absent","2022-10-12",employees.get(2),organisations1.get(0)));
        attendance.add( new Attendance( "Present","2022-10-14",employees.get(2),organisations1.get(0)));
        attendance.add( new Attendance( "Present","2022-10-15",employees.get(2),organisations1.get(0)));
        attendance.add( new Attendance( "Present","2022-10-16",employees.get(2),organisations1.get(0)));
        attendance.add( new Attendance( "Absent","2022-10-17",employees.get(2),organisations1.get(0)));
        attendance.add( new Attendance( "Absent","2022-10-11",employees.get(3),organisations1.get(1)));
        attendance.add( new Attendance( "Absent","2022-10-12",employees.get(3),organisations1.get(1)));
        attendance.add( new Attendance( "Present","2022-10-14",employees.get(3),organisations1.get(1)));
        attendance.add( new Attendance( "Present","2022-10-15",employees.get(3),organisations1.get(1)));
        attendance.add( new Attendance( "Present","2022-10-16",employees.get(3),organisations1.get(1)));
        attendance.add( new Attendance( "Absent","2022-10-17",employees.get(3),organisations1.get(1)));
    }
    public   void organisationAndEmployeeDetail(){
        System.out.println("_________________________________  Display Employee ___________________________________________");
        employees.stream().map(employee ->   employee.organisationList.organisationId +" organisationName :  " +employee.organisationList.organisationName  +"  employeeId : " +employee.id +  "  employeeName :  " + employee.employeeName).forEach(System.out::println);
    }
    int presentDays = 0;
    int absentDays =0;
    public void countNoOfDay(){
        System.out.println("__________________________________Counting Days Of particular Employee_______________________________");
        for(int index =0; index<attendance.size(); index++){
            if(attendance.get(index).attendanceStatus.equalsIgnoreCase("present") && attendance.get(index).employeeSet.id==111){
                presentDays++;
                System.out.println("presentDays  : "+presentDays);
            }
            else if(attendance.get(index).attendanceStatus.equalsIgnoreCase("absent") && attendance.get(index).employeeSet.id==111){
                absentDays++;
            }
        }
        System.out.println("absentDays : "+absentDays);
    }
    public  void findParticularDateOfEmployee(){
        System.out.println("________________________________findParticularDateOfEmployee________________________________________");
        attendance.stream().filter(attendance1 -> attendance1.attendanceStatus.equalsIgnoreCase("absent") && attendance1.attendanceStatus.equalsIgnoreCase("2022-10-12")).forEach(employees-> System.out.println("id :"+employees.employeeSet.id+"  employeeName : "+employees.employeeSet.employeeName));
    }
    public void attendancePercentage() {
        System.out.println("________________________________attendancePercentage________________________________________");
        Double percentage = null;
        int totalDays = 6;
        for (int index = 0; index < attendance.size(); index++) {
            if (attendance.get(index).attendanceStatus.equalsIgnoreCase("Absent")) {
                percentage = (double) (totalDays / presentDays * 100);
            }
        }
        System.out.println(percentage);
    }
    public void organisationEmployee() {
        System.out.println("______________________________________________ Employee Based On Organisation ___________________________________");
        employees.stream().filter(employee -> employee.organisationList.organisationName.equalsIgnoreCase("Thrymr")).forEach(employee -> System.out.println("  id : " + employee.id + "  employeeName : " + employee.employeeName  + "  Organisation : " + employee.organisationList.organisationName));
    }
    public static void main(String[] args) {
        EmployeeData employeeData = new EmployeeData();
        employeeData.initialization();
        employeeData.organisationAndEmployeeDetail();
        employeeData.countNoOfDay();
        employeeData.findParticularDateOfEmployee();
        employeeData.attendancePercentage();
        employeeData.organisationEmployee();
    }
}
*/
