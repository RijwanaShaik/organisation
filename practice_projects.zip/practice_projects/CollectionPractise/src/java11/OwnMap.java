package java11;

import java.util.*;

public class OwnMap {

}
class Key{
    private int key;
    public Key(int k){
        key=k;
    }

    @Override
    public boolean equals(Object o) {
        if(this==o) return true;
        if(o==null || getClass()!=o.getClass()) return false;
        Key key1=(Key)o;
        return Objects.equals(key,key1);
    }
    public int hashCode(){
        return Objects.hash(key);
    }
}
class Value{
    private int value;
    public Value(int v){
        value=v;
    }

    @Override
    public boolean equals(Object o) {
        if(this==o) return true;
        if(o==null || getClass()!=o.getClass()) return false;
        Value value1=(Value)o;
        return value== value1.value;
    }
}
class Entry{
    Key key;
    Value value;
    public Entry(Key k,Value v){
        key=k;
        value=v;
    }
}
class HashMapClass{
    LinkedList<Entry>[] hashmap=new LinkedList[2];
    int size=0;
    public HashMapClass(){

    }
    public void put(Key key,Value value){
        if(size>=hashmap.length){
            resize();
        }
        int ix=getIndex(key)%hashmap.length;
        if(hashmap[ix]==null){
            hashmap[ix]=new LinkedList<>();
            hashmap[ix].add(new Entry(key,value));
            size++;
            return;
        }else {
            for(Entry entry:hashmap[ix]){
                if(entry.key.equals(key)){
                    entry.value=value;
                    size++;
                    return;
                }
            }
            hashmap[ix].add(new Entry(key, value));
            size++;
            return;
        }
    }
    public Value get(Key key){
        int ix=getIndex(key)%hashmap.length;
        if(hashmap[ix]==null)return null;
        for(Entry entry:hashmap[ix]){
            if(entry.key.equals(key)){
                return entry.value;
            }
        }
        return null;
    }
    public void remove(Key key){
        if(key==null)return;
        int ix=getIndex(key)%hashmap.length;
        Entry toRemove=null;
        for(Entry entry:hashmap[ix]){
            if(entry.key.equals(key)){
                toRemove= entry;
            }
        }
        if(toRemove==null) return;;
        hashmap[ix].remove(toRemove);
    }
    public void resize(){
        LinkedList<Entry>[] oldHashMap=hashmap;
        hashmap=new LinkedList[size+2];
        size=0;
        for(int i=0;i<oldHashMap.length;i++){
            if(oldHashMap[i]==null)continue;
            for (Entry entry:oldHashMap[i]){
                put(entry.key,entry.value);
            }
        }
    }
    public int getIndex(Key key){
        return key.hashCode();
    }
   /* public int size(){
        return size;
    }*/
}
class MapTest{
    public static void main(String[] args) {
        HashMapClass hashMapClass=new HashMapClass();
        hashMapClass.put(new Key(10),new Value(20));
        System.out.println(hashMapClass);
    }
}