package java11;

import java.util.Arrays;
import java.util.List;

public class Employe {
    int eId;
    String eName;
    Attendance[] attendances;

    public Employe(int eId, String eName, Attendance[] attendances) {
        this.eId = eId;
        this.eName = eName;
        this.attendances = attendances;
    }

    @Override
    public String toString() {
        return "Employe{" +
                "eId=" + eId +
                ", eName='" + eName + '\'' +
                ", attendances=" + Arrays.toString(attendances) +
                '}';
    }
}
class emp{
    int id;
    List<String> phone;

    public emp(int id, List<String> phone) {
        this.id = id;
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "emp{" +
                "id=" + id +
                ", phone=" + phone +
                '}';
    }

    public static void main(String[] args) {
        emp e1=new emp(1,Arrays.asList("43455","456798"));
        System.out.println(e1);
    }
}