package java11;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Organisation {
    int oId;
    String oName;
    Employe[] employees;

    public Organisation(int oId, String oName, Employe[] employees) {
        this.oId = oId;
        this.oName = oName;
        this.employees = employees;
    }

    @Override
    public String toString() {
        return "Organisation{" +
                "oId=" + oId +
                ", oName='" + oName + '\'' +
                ", employees=" + Arrays.toString(employees) +
                '}';
    }

    public static void main(String[] args) {
     Attendance[] attendances=new Attendance[2];
     attendances[0]=new Attendance(1, "20-10-2022","present");
attendances[1]=new Attendance(1,"1-10-2022","absent");
Attendance[] attendances1=new Attendance[2];
attendances1[0]=new Attendance(2,"22-11-2022","Present");
attendances1[1]=new Attendance(2,"20-11-2022","absent");
Employe[] employes=new Employe[2];
employes[0]=new Employe(110,"raj",attendances);
employes[1]=new Employe(111,"ram",attendances1);

/*
Organisation[] organisations=new Organisation[2];
organisations[0]=new Organisation(011,"Tcs",employes);
organisations[1]=new Organisation(012,"thrymr",employes);
*/


Organisation or1=new Organisation(001,"Tcs",employes);
Organisation or2=new Organisation(102,"Thrymr",employes);
Organisation[] organisations=new Organisation[2];
organisations[0]=or1;
organisations[1]=or2;
for(int i=0;i< organisations.length-1;i++){
    System.out.println(Arrays.toString(organisations));
}


    }
}
