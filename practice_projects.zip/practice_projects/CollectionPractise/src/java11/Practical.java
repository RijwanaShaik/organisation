package java11;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Practical {
}
/*
 class Organisation {
    int ordId;
    String orgName;
    int establishedYear;
    Employee[] employee;

    public Organisation(int ordId, String orgName, int establishedYear, Employee[] employee) {
        this.ordId = ordId;
        this.orgName = orgName;
        this.establishedYear = establishedYear;
        this.employee = employee;
    }

    public int getOrdId() {
        return ordId;
    }

    public void setOrdId(int ordId) {
        this.ordId = ordId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public int getEstablishedYear() {
        return establishedYear;
    }

    public void setEstablishedYear(int establishedYear) {
        this.establishedYear = establishedYear;
    }

    public Employee[] getEmployee() {
        return employee;
    }

    public void setEmployee(Employee[] employee) {
        this.employee = employee;
    }

    @Override
    public String toString() {
        return "Organisation{" +
                "ordId=" + ordId +
                ", orgName='" + orgName + '\'' +
                ", establishedYear=" + establishedYear +
                ", employee=" + Arrays.toString(employee) +
                '}';
    }

    public static void main(String[] args) {
        List<Organisation> organisationList= new ArrayList<Organisation>();
        Organisation [] organisations=new Organisation[2];
        Attendances[] attendances1=new Attendances[6];
        Attendances a=new Attendance(10,"19-11-2022","Present");
        Attendances a1=new Attendance(11,"20-11-2022","Absent");
        Attendances a2=new Attendance(12,"21-11-2022","Present");
        Attendances a3=new Attendance(23,"22-11-2022","Present");
        Attendances a4=new Attendance(24,"23-11-2022","Absent");
        Attendances a5=new Attendance(25,"24-11-2022","Present");
        attendances1[0]=a;
        attendances1[1]=a1;
        attendances1[2]=a2;
        attendances1[3]=a3;
        attendances1[4]=a4;
        attendances1[5]=a5;

        Attendances[] attendances2=new Attendances[6];
        Attendances e=new Attendance(20,"19-11-2022","Present");
        Attendances e2=new Attendance(21,"20-11-2022","Absent");
        Attendances e3=new Attendance(22,"21-11-2022","Present");
        Attendances e4=new Attendance(23,"22-11-2022","Present");
        Attendances e5=new Attendance(24,"23-11-2022","Absent");
        Attendances e6=new Attendance(25,"24-11-2022","Present");
        attendances2[0]=e;
        attendances2[1]=e2;
        attendances2[2]=e3;
        attendances2[3]=e4;
        attendances2[4]=e5;
        attendances2[5]=e6;
        Employee[] employee1 = new Employee[2];
        Employee emp1=new Employee(1,"Siva","Developer",30000,attendances1);
        Employee emp2=new Employee(2,"Raj","Testing",20000,attendances2);

        employee1[0]=emp1;
        employee1[1]=emp2;
        Organisation org=new Organisation(123,"TCS",1980,employee1);

        // Org2
        Attendances[] attendances3=new Attendances[3];
        Attendances o=new Attendances(20,"19-11-2022","Present");
        Attendances o1=new Attendances(21,"20-11-2022","Absent");
        Attendances o2=new Attendances(22,"21-11-2022","Present");
        attendances3[0]=o;
        attendances3[1]=o1;
        attendances3[2]=o2;

        Attendances[] attendances4=new Attendances[3];
        Attendances a21=new Attendances(20,"19-11-2022","Present");
        Attendances a22=new Attendances(21,"20-11-2022","Absent");
        Attendances a23=new Attendances(22,"21-11-2022","Present");

        Employee[] employees2 = new Employee[2];
        Employee emps1=new Employee(10,"Siva","Developer",50000,attendances3);
        Employee emps2=new Employee(11,"Sudeep","Developer",40000,attendances4);
        employees2[0]=emps1;
        employees2[1]=emps2;
        Organisation org1=new Organisation(412,"Wipro",1980,employees2);



        organisations[0]=org;
        organisations[1]=org1;
        organisationList.add(org);
        organisationList.add(org1);
        // System.out.println(organisationList);
        for(Organisation data: organisations){
            System.out.println(data);
        }

        //Map<String ,List<Organisation>> empList = organisationList.stream().collect(Collectors.groupingBy(Organisation::getOrgName));


    }
}



 class Employee {
    int eId;
    String eName;
    String Department;
    double salary;
    Attendances[] attendance;

    public Employee(int eId, String eName, String department, double salary, Attendances[] attendance) {
        this.eId = eId;
        this.eName = eName;
        Department = department;
        this.salary = salary;
        this.attendance = attendance;
    }

    public int geteId() {
        return eId;
    }

    public void seteId(int eId) {
        this.eId = eId;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String department) {
        Department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Attendances[] getAttendance() {
        return attendance;
    }

    public void setAttendance(Attendances[] attendance) {
        this.attendance = attendance;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "eId=" + eId +
                ", eName='" + eName + '\'' +
                ", Department='" + Department + '\'' +
                ", salary=" + salary +
                ", attendance=" + Arrays.toString(attendance) +
                '}';
    }

    public static void main(String[] args) {

    }
}


 class Attendances {
    int aID;
    String Date;
    String status;

    public Attendances(int aID, String date, String status) {
        this.aID = aID;
        Date = date;
        this.status = status;
    }

    public int getaID() {
        return aID;
    }

    public void setaID(int aID) {
        this.aID = aID;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Attendance{" +
                "aID=" + aID +
                ", Date='" + Date + '\'' +
                ", status='" + status + '\'' +
                '}';
    }

    public static void main(String[] args) {


    }
}

*/
/*
1) Stream.collect() Method
public class CollectorsExamples
{
    public static void main(String[] args)
    {
        List<Integer> numbers = Arrays.asList(8, 2, 5, 7, 3, 6);
         
        //collect() method returning List of OddNumbers
         
        List<Integer> oddNumbers = numbers.stream().filter(i -> i%2 != 0).collect(Collectors.toList());
         
        System.out.println(oddNumbers);
         
        //OUTPUT : [5, 7, 3]
    }
}


class Student
{
    String name;
     
            int id;
     
            String subject;
     
            double percentage;
     
            public Student(String name, int id, String subject, double percentage)
    {
        this.name = name;
        this.id = id;
        this.subject = subject;
        this.percentage = percentage;
    }
     
            public String getName()
    {
        return name;
    }
     
            public int getId()
    {
        return id;
    }
     
            public String getSubject()
    {
        return subject;
    }
     
            public double getPercentage()
    {
        return percentage;
    }
     
            @Override
    public String toString()
    {
        return name+"-"+id+"-"+subject+"-"+percentage;
    }
}

    List<Student> studentList = new ArrayList<Student>();
         
        studentList.add(new Student("Paul", 11, "Economics", 78.9));
        studentList.add(new Student("Zevin", 12, "Computer Science", 91.2));
        studentList.add(new Student("Harish", 13, "History", 83.7));
        studentList.add(new Student("Xiano", 14, "Literature", 71.5));
        studentList.add(new Student("Soumya", 15, "Economics", 77.5));
        studentList.add(new Student("Asif", 16, "Mathematics", 89.4));
        studentList.add(new Student("Nihira", 17, "Computer Science", 84.6));
        studentList.add(new Student("Mitshu", 18, "History", 73.5));
        studentList.add(new Student("Vijay", 19, "Mathematics", 92.8));
        studentList.add(new Student("Harry", 20, "History", 71.9));

        Example : Collecting top 3 performing students into List
        List<Student> top3Students = studentList.stream().sorted(Comparator.comparingDouble(Student::getPercentage).reversed()).limit(3).collect(Collectors.toList());
                 
        System.out.println(top3Students);

        Example : Collecting subjects offered into Set.

        Set<String> subjects = studentList.stream().map(Student::getSubject).collect(Collectors.toSet());
                 
        System.out.println(subjects);

        Example : Collecting name and percentage of each student into a Map
        Map<String, Double> namePercentageMap = studentList.stream().collect(Collectors.toMap(Student::getName, Student::getPercentage));
                 
        System.out.println(namePercentageMap);

        Example : Collecting first 3 students into LinkedList

        LinkedList<Student> studentLinkedList = studentList.stream().limit(3).collect(Collectors.toCollection(LinkedList::new));
                 
        System.out.println(studentLinkedList);

        Example : Collecting the names of all students joined as a string

        String namesJoined = studentList.stream().map(Student::getName).collect(Collectors.joining(", "));
                 
        System.out.println(namesJoined);
                 
        Example : Counting number of students.
        Long studentCount = studentList.stream().collect(Collectors.counting());
                 
        System.out.println(studentCount);

        Example : Collecting highest percentage.

        Optional<Double> highPercentage = studentList.stream().map(Student::getPercentage).collect(Collectors.maxBy(Comparator.naturalOrder()));
                 
        System.out.println(highPercentage);

        Example : Collecting lowest percentage.

        Optional<Double> lowPercentage = studentList.stream().map(Student::getPercentage).collect(Collectors.minBy(Comparator.naturalOrder()));
                 
        System.out.println(lowPercentage);

        Example : Collecting sum of percentages
        Double sumOfPercentages = studentList.stream().collect(Collectors.summingDouble(Student::getPercentage));
                 
        System.out.println(sumOfPercentages);
        Example : Collecting average percentage
        Double averagePercentage = studentList.stream().collect(Collectors.averagingDouble(Student::getPercentage));
                 
        System.out.println(averagePercentage);

        Example : Extracting highest, lowest and average of percentage of students

        DoubleSummaryStatistics studentStats = studentList.stream().collect(Collectors.summarizingDouble(Student::getPercentage));
                 
        System.out.println("Highest Percentage : "+studentStats.getMax());
                 
        System.out.println("Lowest Percentage : "+studentStats.getMin());
                 
        System.out.println("Average Percentage : "+studentStats.getAverage());
        Merge Two Maps With Same Keys

        Example : Grouping the students by subject

        Map<String, List<Student>> studentsGroupedBySubject = studentList.stream().collect(Collectors.groupingBy(Student::getSubject));
                 
        System.out.println(studentsGroupedBySubject);

        Example : Partitioning the students who got above 80.0% from who don’t.

        Map<Boolean, List<Student>> studentspartionedByPercentage = studentList.stream().collect(Collectors.partitioningBy(student -> student.getPercentage() > 80.0));
                 
        System.out.println(studentspartionedByPercentage);

        Example : Collecting first three students into List and making it unmodifiable

        List<Student> first3Students = studentList.stream().limit(3).collect(Collectors.collectingAndThen(Collectors.toList(), Collections::unmodifiableList));
                 
        System.out.println(first3Students);
*/
