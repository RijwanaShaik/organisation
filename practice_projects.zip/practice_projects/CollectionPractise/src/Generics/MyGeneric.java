package Generics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//dotnettutorials
public class MyGeneric {
}
//generic interface
interface Tester < T >
{
    void show (T o);
}

//Implementing the generic interface without specifying any generic parameter
class Imp1 implements Tester
{
    public void show (Object o)
    {
        System.out.println(o);
    }
}

//Implementing the generic interface by specifying generic parameter as Integer
class Imp2 implements Tester < Integer >
{
    public void show (Integer o)
    {
        System.out.println(o);
    }
}

//Implementing the generic interface by specifying generic parameter as String
class Imp3 implements Tester < String >
{
    public void show (String o)
    {
        System.out.println(o);
    }
}

//Implementing  the generic interface whose implementation class is also a generic class
class Imp4 < T > implements Tester < T >
{
    public void show (T o)
    {
        System.out.println(o);
    }
}

 class GenericInterface
{
    public static void main (String[]args)
    {
        Imp1 i1 = new Imp1 ();
        i1.show (10);
        i1.show ("abc");
        i1.show (true);

        Imp2 i2 = new Imp2 ();
        i2.show (10);
        // i2.show("abc"); - Invalid

        Imp3 i3 = new Imp3 ();
        i3.show ("abc");
        // i3.show(10.0); - Invalid

        Imp4 < Integer > i4 = new Imp4 < Integer > ();
        i4.show (10);
    }
}
//unbounded wildcards example
class UnboundedDemo
{
    public static void main (String[]args)
    {
        List< Integer > integerList = Arrays.asList (6, 3, 10, 7);
        print (integerList);
        System.out.println ("\n----------");
        List < String > stringList = new ArrayList< String >();
        stringList.add ("A");
        stringList.add ("B");
        stringList.add ("C");
        stringList.add ("D");
        print (stringList);
    }
    public static void print (List < ? >list)
    {
        for (Object input : list)
        {
            System.out.print (input + " ");
        }
    }
}
//1. A class that implements a generic interface MUST be generic.
interface PersonGenericInterface <E> {
    void setPersonName(E name);
    public E getName();
}
 /*class NameGenericClass <E> implements PersonGenericInterface <E>{

    E name;
    @Override
    public void setPersonName(E name) {
        this.name = name;
    }

    @Override
    public E getName() {
        return name;
    }

    public static void main(String[] args) {
        NameGenericClass<String> myName = new NameGenericClass<>();
        myName.setPersonName("John Doe");
        System.out.println("My name is: "+ myName.getName());
    }
}*/
//The generic class implementing a generic interface can have other parameterized type parameters.
 class NameGenericClass <E, T> implements PersonGenericInterface <E>{

    E name;
    T age;

    @Override
    public void setPersonName(E name) {
        this.name = name;
    }

    @Override
    public E getName() {
        return name;
    }

    public void setAge(T age){
        this.age = age;
    }

    public T getAge(){
        return age;
    }

    public static void main(String[] args) {
        NameGenericClass <String, Integer> person = new NameGenericClass<>();
        person.setPersonName("John Doe");
        person.setAge(25);
        System.out.println("My name is "+ person.getName()+ ", "+ person.getAge()+ " years old.");
    }
}