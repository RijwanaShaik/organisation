package Generics;

import java11.Employe;

import java.util.Scanner;

public class ObjectConversion {
}

class Student1<T>{
    int id;
     String name;
    int age;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
class Student<T> {
    int id;
    String name;
    int age;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    public T changeClassMethod(T typeOfClass) {
        if (typeOfClass instanceof Student1) {
            Student1 student1 = (Student1) typeOfClass;
            Student student = new Student();
            student.id = student1.id;
            student.name = student1.name;
            student.age = student1.age;
        } else {
            Student student = (Student) typeOfClass;
            Student1 student1 = new Student1();
            student1.id = student.id;
            student1.name = student.name;
            student1.age = student.age;
        }
        return typeOfClass;
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter student details");
        System.out.println("Enter id of the student");
        int id=sc.nextInt();
        System.out.println("Enter name of the student");
        String name=sc.next();
        System.out.println("Enter age of the student");
        int age=sc.nextInt();
        Student<Student1> student=new Student<Student1>();
        Student1 student1=new Student1();
        student.setId(id);
        student.setName(name);
        student.setAge(age);
        System.out.println(student.changeClassMethod(student1));
     System.out.println(student.toString());
      //  System.out.println(student1.toString());
    }
}












