package Generics;

public class PersonUser {
    public  <T extends User> Person<T> convertObj(User<T> o){
        Person persons=new Person();
        persons.id=o.id;
        persons.name=o.name;
        return persons;

    }

    public static void main(String[] args) {

        PersonUser ps=new PersonUser();

        User users =new User("kunal",2);
        System.out.println(ps.convertObj(users));
        User user1=new User("raj",40);
        System.out.println(ps.convertObj(user1));



    }
}