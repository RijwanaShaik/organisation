package Generics;


import java.util.Arrays;




 class ArrayList1<E>  {

    private Object[] array;
    public static final int DEFAULT_SIZE = 20;
    private int size = 0;

    public ArrayList1(){
        this(DEFAULT_SIZE);
    }

    public ArrayList1(int size){
        array = new Object[size];
    }

    public void add(E element){
        ensureCapacity();
        array[size++] = element;
    }

    public E remove(int index){
        if(index>=size || index < 0 ){throw new RuntimeException("Invalid index");}
        E element = (E) array[index];
        array[index] = null;
        --size;
        System.arraycopy(array,index+1,array,index,size-index);
        array[size]=null;
        return element;
    }

    public E get(int index){
        if(index > size){throw new RuntimeException("Invalid index");}
        E element = (E) array[index];
        return element;
    }

    public int size(){
        return this.size;
    }

    private void ensureCapacity(){
        if(size < array.length){ return;}
        resize();
    }

    private void resize(){
        Object[] temp = new Object[array.length*2];
        copy(array,temp);
        array = temp;
    }

    private void copy(Object[] src, Object[] dest){
        if(dest.length< src.length){throw new RuntimeException(src+ " cannot be copied into "+dest);}
        for(int i=0;i<src.length; i++){
            dest[i] = src[i];
        }
    }


     @Override
     public String toString() {
         return "ArrayList1{" +
                 "array=" + Arrays.toString(array) +
                 ", size=" + size +
                 '}';
     }

     public static void main(String[] args) {
         ArrayList1<Integer> a=new ArrayList1<Integer>();
         a.add(20);
         a.add(30);
         System.out.println(a);
         a.remove(1);
         System.out.println(a.get(0));
     }

}
//ownmap
/*class Entry<k,v>{
    K key;
    V value;
    Entry<K,V> next;
    public Entry(K key,V value,Entry<K,V>next){
        this.key=key;
        this.value=value;
        this.next=next;
    }
}
class CustomMap<K,V>{
    int size=0;
    int initialCapacity=5;
    Entry<K,V>[] entries;
    public void put(K key, V value) {
        Entry entry = new Entry(key, value, null);
        for (int i = 0; i < size; i++) {
            if (entries[i].key.equals(key)) {
                entries[i] = entry;//duplicate key
                return;
            }
        }
    }
    boolean contains(Object key) {
        boolean b = false;
        for (int i = 0; i < size; i++) {
            //System.out.println("Entered: "+ entries[i].key );
            if (Objects.equals(entries[i].key, key)) {
                b = true;
            }
        }
        return b;
    }
    public V remove(Object key) {
        for (int i = 0; i < size; i++) {
            if (Objects.equals(entries[i].key, key)) {
                Entry entry = entries[i];
                entry = null;
                int length = entries.length - (i + 1);
                System.arraycopy(entries, i + 1, entries, i, length);
                size--;
            }
        }
        return null;
    }
}*/

/*
class TaskMap {
    public static void main(String[] args) {
        CustomMap<Integer, String> map = new CustomMap();
        map.put(1, "sai");
        map.put(3, "raghu");
        map.put(4, "siri");
        map.put(2, "hari");
        System.out.println(map);
        System.out.println("Contains: " + map.contains(5));
        System.out.println(" remove method: " +map.remove(3));
    }
}
*/

 class MyHashMap<K, V> {

    private class Entry<K, V> {
        private K key;
        private V value;
        private Entry<K, V> next;

        public Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() {
            return this.key;
        }

        public V getValue() {
            return this.value;
        }

        public void setValue(V value) {
            this.value = value;
        }

        @Override
        public String toString() {
            Entry<K,V> temp = this;
            StringBuilder sb = new StringBuilder();
            while (temp != null) {
                sb.append(temp.key + " -> " + temp.value + ",");
                temp = temp.next;
            }
            return sb.toString();
        }

    }

    private final int SIZE = 5;

    private Entry<K, V> table[];

    public MyHashMap() {
        table = new Entry[SIZE];
    }

    public void put(K key, V value) {
        int hash = key.hashCode() % SIZE;
        Entry<K, V> e = table[hash];

        if (e == null) {
            table[hash]= new Entry<K, V>(key, value);
        } else {
            while (e.next != null) {
                if (e.getKey() == key) {
                    e.setValue(value);
                    return;
                }
                e = e.next;
            }

            if (e.getKey() == key) {
                e.setValue(value);
                return;
            }

            e.next = new Entry<K, V>(key, value);
        }
    }

    public V get(K key) {
        int hash = key.hashCode() % SIZE;
        Entry<K, V> e = table[hash];

        if (e == null) {
            return null;
        }

        while (e != null) {
            if (e.getKey() == key) {
                return e.getValue();
            }
            e = e.next;
        }

        return null;
    }

    public Entry<K, V> remove(K key) {
        int hash = key.hashCode() % SIZE;
        Entry<K, V> e = table[hash];

        if (e == null) {
            return null;
        }

        if (e.getKey() == key) {
            table[hash] = e.next;
            e.next = null;
            return e;
        }

        Entry<K, V> prev = e;
        e = e.next;

        while (e != null) {
            if (e.getKey() == key) {
                prev.next = e.next;
                e.next = null;
                return e;
            }
            prev = e;
            e = e.next;
        }

        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < SIZE; i++) {
            if (table[i] != null) {
                sb.append(i + " " + table[i] + "\n");
            } else {
                sb.append(i + " " + "null" + "\n");
            }
        }

        return sb.toString();
    }

}



class Driver {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        MyHashMap<String, String> myHashMap = new MyHashMap<String, String>();
        myHashMap.put("A", "B");
        myHashMap.put("E", "F");
        myHashMap.put("H", "P");
        myHashMap.put("P", "2");
        myHashMap.put("1",  "G");
        myHashMap.put("2", "6");
        myHashMap.put("3", "2");
        myHashMap.put("4", "4");
        myHashMap.put("1",  "H");


   System.out.println(myHashMap);
   System.out.println(myHashMap.get("A"));
   System.out.println(myHashMap.remove("A"));
        myHashMap.remove("2");
        System.out.println(myHashMap);
    }

}
class ArrayListClass<T> {
    int size=10;
    int  arr[]=new int[10];
    int index=-1;
    public void incrementSize(){
        size +=2;
        int [] temp = new int[size];
        for(int i=0;i < arr.length;i++){
            temp[i] = arr[i];
        }
    }
    public void add(T n){
        index++;

        if(index==(size*0.7)){
            incrementSize();
        }
        arr[index]= (int) n;
    }
    /*public void addAll(T[] elements) {
        for (int i=0;i<elements.length;i++) {
            arr[index] = (int) elements[i];
            index++;
            if (index ==(size* 0.7)) {
                incrementSize();
            }

        }
    }*/
  /*  public void remove(T n){
        for(int i=0;i<arr.length;i++) {
            if (arr[i]==n) {
                index--;
                while (arr[i]!=0){
                    arr[i]=arr[i+1];
                    i++;
                }
                break;
            }
        }
    }*/
    public boolean isEmpty () {
        if (index == -1) {
            return true;
        }
        return false;
    }
    public int size(){
        return index+1;
    }
    public int indexOf(int n){
        int indexOf=0;
        for(int i=0;i<arr.length;i++){
            if(arr[i]==n){
                indexOf=i;
                break;
            }
            else indexOf=-1;
        }
        return indexOf;
    }
    public int[] retainAll(int[] arr1) {
        int k = 0;
        int[] arr2 = new int[arr1.length];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; i < arr1.length; i++) {

                if (arr[i] == arr1[j]) {
                    arr2[k] = arr1[j];
                    k++;
                }
            }
        }
        arr=arr2;
        return arr;
    }
    public static void main(String[] args) {
        ArrayListClass obj= new ArrayListClass();
        obj.add(30);
        obj.add(40);
        obj.add(60);
        System.out.println(Arrays.toString(obj.arr));
        /*int[] arr1={45,65,80};
       // obj.addAll(arr1);
        System.out.println(Arrays.toString(obj.arr));
      //  obj.remove(30);
        System.out.println(Arrays.toString(obj.arr));
        System.out.println(obj.isEmpty());
        System.out.println(obj.size());
        System.out.println(obj.indexOf(45));
        obj.retainAll(arr1);
        System.out.println(Arrays.toString(obj.arr))*/;
    }
}
class CustomGenericArrayList<T>{
     private  Object[] data;
     private static int DEFAULT_SIZE=10;
     private int size=0;
     public CustomGenericArrayList(){
         data=new Object[DEFAULT_SIZE];
     }
     public void add(T num){
         if(size==data.length){
             resize();
         }
         data[size++]=num;
     }
     private void resize(){
         Object[] temp=new Object[data.length*2];
         for(int i=0;i<data.length;i++){
             temp[i]=data[i];
         }
         data=temp;
     }

   /*  public T remove(T index){

        T removed=(T) (data[size--]);
        return removed;
     }*/
     public  T get(int index){
         return (T)data[index];
     }
     public int size(){
         return size;
     }
     public void set(int index,T value){
         data[index]=value;
     }
public Object remove(int index){
         if(index<0||index>=size){
             throw new IndexOutOfBoundsException("Index"+index+",Size"+index);
         }
         Object removedelement=data[index];
         for(int i=index;i<size-1;i++){
             data[i]=data[i +1];
         }
         size--;
         return removedelement;
}
    @Override
    public String toString() {
        return "CustomGenericArrayList{" +
                "data=" + Arrays.toString(data) +
                ", size=" + size +
                '}';
    }

    public static void main(String[] args) {
        CustomGenericArrayList<Integer> c=new CustomGenericArrayList<>();
       c.add(20);
       c.add(30);
       c.add(40);
        System.out.println(c);
        c.remove(2);
        System.out.println(c);
    }
}
class exArra<T>{

    int size=10;
    int  arr[]=new int[10];
    int index=-1;
    public void incrementSize(){
        size +=2;
        int [] temp = new int[size];
        for(int i=0;i < arr.length;i++){
            temp[i] = arr[i];
        }
    }
    public void add(T n){
        index++;

        if(index==(size*0.7)){
            incrementSize();
        }
        arr[index]= (int) n;
    }
}

 /*class OwnArrayList<T> {
    ArrayList<T> ownList;

    public OwnArrayList() {
        super();
        ownList = new ArrayList<T>();
    }

    public void add(T element) {
        ownList.add(element);
    }

    public boolean addAll(List<T> elementList) {
        return ownList.addAll(elementList);
    }

    public boolean remove(T num) {
        return ownList.remove(num);
    }

    public List<T> retainAll(List<T> elementList) {
        ownList.retainAll(elementList);
        return ownList;
    }

    public void isEmpty() {
        return ownList.isEmpty();
    }

    public int size() {
        return ownList.size();
    }

    public int indexOf(T num) {
        return ownList.indexOf(num);
    }

    public static void main(String[] args) {
        OwnArrayList<String> stringOwnArrayList=new OwnArrayList<>();
        stringOwnArrayList.add("JAVA");
        stringOwnArrayList.add("Programm");
        System.out.println(stringOwnArrayList);
    }
}*/