package Generics;

import java.util.ArrayList;

public class OwnGenericList <T>{
    T obj;
    public OwnGenericList(){

    }
    public OwnGenericList(T obj){
        this.obj=obj;
    }
    ArrayList<T> ownList=new ArrayList<>();
    public void add(T obj){
        ownList.add(obj);
    }
    public void remove(int index){
        ownList.remove(index);
    }
    public int size(){
        return ownList.size();
    }
    public boolean isEmpty(){
        return ownList.isEmpty();
    }

    public static void main(String[] args) {
        OwnGenericList<String> ownGenericList=new OwnGenericList<>();
        ownGenericList.add("Java");
        ownGenericList.add("is a");
        ownGenericList.add("Programming");
        ownGenericList.add("language");
        System.out.println(ownGenericList.ownList);
        ownGenericList.remove(1);
        System.out.println(ownGenericList.ownList);
        System.out.println(ownGenericList.size());
        System.out.println(ownGenericList.isEmpty());
    }
}
