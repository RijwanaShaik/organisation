package Generics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyGenericClass<T> {
    T obj;
    void add(T obj){
        this.obj=obj;
    }
    T get(){
        return obj;
    }

    public static void main(String[] args) {
        MyGenericClass<Integer> mInt=new MyGenericClass<Integer>();
        mInt.add(10);
        MyGenericClass<String> mStr=new MyGenericClass<>();
        mStr.add("Test");
        System.out.println(mInt.get());
        System.out.println(mStr.get());
    }
}
class Test_Generics<T1,T2>{
    T1 obj1;
    T2 obj2;
    //constructor
    Test_Generics(T1 obj1,T2 obj2){
        this.obj1=obj1;
        this.obj2=obj2;
    }
    public void print(){
        System.out.println("T1 Object: "+obj1);
        System.out.println("T2 Object: "+obj2);
    }

    public static void main(String[] args) {
        Test_Generics<String,Integer> obj=new Test_Generics<>("Java Generics",1);
        obj.print();
    }
}
//generic methods
class GenericMethods{
    public static <T> void printGenericArray(T[] items){
        for(T item:items){
            System.out.print(item+" ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Integer[] intArr={1,3,5,7,9,11};
        Character[] charArr={'J','A','V','A'};
        printGenericArray(intArr);
        printGenericArray(charArr);
    }

}
//upperbounded wildcards
class UpperboundedWildcards<T>{
    private  static Number summation(List<? extends Number> numbers){
        double sum=0.0;
        for (Number n:numbers)
            sum +=n.doubleValue();
        return sum;
    }

    public static void main(String[] args) {
        //Number subtype :Integer
        List<Integer> intList= Arrays.asList(1,3,5,7);
        System.out.println(summation(intList));
        List<Double> doubleList=Arrays.asList(1.0,2.0,3.0);
        System.out.println(summation(doubleList));

    }
}
//LowerBounded wildcards
class Main
{
    public static void main(String[] args)
    {
        //Integer List
        List<Integer>Int_list= Arrays.asList(1,3,5,7);

        System.out.print("Integer List:");
        printforLowerBoundedWildcards(Int_list);

        //Number list
        List<Number>Number_list= Arrays.asList(2,4,6,8);

        System.out.print("Number List:");
        printforLowerBoundedWildcards(Number_list);

    }

    public static void printforLowerBoundedWildcards(List<? super Integer> list)
    {
        System.out.println(list);
    }
}
//example to upperbounded wildcards
abstract class Shape{
    abstract void draw();
}
class Rectangle extends Shape{
    void draw(){
        System.out.println("drawing rectangle");
    }
}
class Circle extends Shape{
    @Override
    void draw() {
        System.out.println("drawing Circle");
    }
}
class GenericTest{
    //creating method that accepts only child class of shape
    public static void drawShapes(List<? extends Shape> lists){
        for (Shape s:lists){
            s.draw();//calling method of shape class by child class instance
        }
    }

    public static void main(String[] args) {
        List<Rectangle> list1=new ArrayList<Rectangle>();
        list1.add(new Rectangle());
        List<Circle> list2=new ArrayList<Circle>();
        list2.add(new Circle());
drawShapes(list1);
drawShapes(list2);
    }
}