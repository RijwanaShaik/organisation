package packageStudent;

import java.util.*;
import java.util.stream.Collectors;

public class Student {
    int id;
    String name;
    int rollNo;
    int mobileNumber;
    String subject;
    int marks;
    int age;

    public Student(int id, String name, int rollNo, int mobileNumber, String subject, int marks, int age) {
        this.id = id;
        this.name = name;
        this.rollNo = rollNo;
        this.mobileNumber = mobileNumber;
        this.subject = subject;
        this.marks = marks;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", rollNo=" + rollNo +
                ", mobileNumber=" + mobileNumber +
                ", subject='" + subject + '\'' +
                ", marks=" + marks +
                ", age=" + age +
                '}';
    }
Student() {
}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRollNo() {
        return rollNo;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public int getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(int mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public static void main(String[] args) {
        List<Student> studentList=new ArrayList<Student>();
        studentList.add(new Student(1, "Anusha",12, 857865090,"Maths",78,30));
        studentList.add(new Student(2, "Sahil",8, 786598320,"Science",65,20));
        studentList.add(new Student(3, "Rahul",10, 857865090,"Maths",45,37));
        studentList.add(new Student(4, "Kunal",6, 884455678,"English",88,32));
        studentList.add(new Student(5, "Shammem",13, 780389309,"Social",59,33));
        studentList.add(new Student(6, "Rashi",14, 765490387,"English",85,29));
        studentList.add(new Student(7, "Nikhila",50, 630875692,"Hindi",66,44));
       /// Student[] st=new Student[];
/*
for(int i=0;i<studentList.size();i++){
    if(i%2!=0){
        Student[] st=studentList.toArray(new Student[studentList.indexOf(studentList)]);
        st[i]=studentList;
      //  System.out.println(i);
        studentList.add(null);
    }
*/
        //  System.out.println(studentList);
//studentList.stream().sorted((e1,e2)->e1.getName().compareTo(e2.getName())).collect(Collectors.toList());
        List<Student> stuname=studentList.stream().sorted(Comparator.comparing(Student::getName)).collect(Collectors.toList());
       stuname.forEach(System.out::println);// or stuname.forEach(p-> System.out.println(p.name));
        Optional<Student> maxmarks=studentList.stream().max(Comparator.comparing(Student::getMarks));
        System.out.println(maxmarks.get());
        //get distinct subjects in the student list
        studentList.stream().map(Student::getSubject).distinct().forEach(System.out::println);


         Optional<Student> oldeststudentage = studentList.stream().max(Comparator.comparingInt(Student::getAge));

        Student oldeststudent = oldeststudentage.get();
        System.out.println(oldeststudent.getAge());
        System.out.println(oldeststudent.getSubject());
    }
}
