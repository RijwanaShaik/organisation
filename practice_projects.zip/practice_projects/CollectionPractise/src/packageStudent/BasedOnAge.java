package packageStudent;

import java.util.ArrayList;
import java.util.List;
//Sort the student list based on age(ascending order)
public class BasedOnAge {
    public static void main(String[] args) {
        List<Student> studentList = new ArrayList<Student>();
        studentList.add(new Student(1, "Anusha", 12, 857865090, "Maths", 78, 30));
        studentList.add(new Student(2, "Sahil", 8, 786598320, "Science", 65, 20));
        studentList.add(new Student(3, "Rahul", 10, 857865090, "Maths", 45, 37));
        studentList.add(new Student(4, "Kunal", 6, 884455678, "English", 88, 32));
        studentList.add(new Student(5, "Shammem", 13, 780389309, "Social", 59, 33));
        studentList.add(new Student(6, "Rashi", 14, 765490387, "English", 85, 29));
        studentList.add(new Student(7, "Nikhila", 50, 630875692, "Hindi", 66, 44));
        System.out.println("Sorted student age based on ascending order");

               studentList.stream().sorted((a1,a2)->a1.age > a2.age?1:-1).forEach(System.out::println);
       // studentList.stream().sorted((a1,a2)->a1.age > a2.age?1:-1).skip(2).limit(3).forEach(System.out::println);

              /* for(Student s:studentList){
                   if(s.age>30 && s.age<38){
                       s.name="Test_Student_Name";
                       studentList.add(s);
                       System.out.println(studentList);

                   }*/
  /*for (int i = 0; i < studentList.size(); i++) {
            for (int j = i+1; j < studentList.size(); j++) {
                if (studentList.get(i).name.compareTo(studentList.get(j).name) == 0) {
                    if (studentList.get(i).age > studentList.get(i + 1).age) {
                        Student temp = studentList.get(i);
                        studentList.set(i, studentList.get(i + 1));
                        studentList.set(i + 1, temp);
                    }
                }
            }
        }
        System.out.println("\nSorting by age keeping name as it is");

        for (Student s : studentList) {
            System.out.println(s.name + " : " + s.age);
        }*/
        // studentList.stream().sorted(Comparator.comparing(Student::getName).thenComparing(Student::getAge)).collect(Collectors.toList()).forEach(System.out::println);

        //Student emp=studentList.get(studentList.size());

        double avgSalary= studentList.stream()
                .map(student -> student.getAge())
                .mapToDouble(i -> i)
                .average().getAsDouble();

        System.out.println(avgSalary);

    }
}
