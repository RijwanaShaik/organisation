package packageStudent;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
//Convert List to Set object
public class ListToSet {
    public static void main(String[] args) {
        List<Student> studentList = new ArrayList<Student>();
        studentList.add(new Student(1, "Anusha", 12, 857865090, "Maths", 78, 30));
        studentList.add(new Student(2, "Sahil", 8, 786598320, "Science", 65, 20));
        studentList.add(new Student(3, "Rahul", 10, 857865090, "Maths", 45, 37));
        studentList.add(new Student(4, "Kunal", 6, 884455678, "English", 88, 32));
        studentList.add(new Student(5, "Shammem", 13, 780389309, "Social", 59, 33));
        studentList.add(new Student(6, "Rashi", 14, 765490387, "English", 85, 29));
        studentList.add(new Student(7, "Nikhila", 50, 630875692, "Hindi", 66, 44));
        Set<Student> set = studentList.stream().collect(Collectors.toSet());
        System.out.println(set);
    }
}
