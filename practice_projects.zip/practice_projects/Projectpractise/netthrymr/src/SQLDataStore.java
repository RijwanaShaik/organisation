public class SQLDataStore implements Datawarehouse{

    @Override
    public String getDataStoreName(String dataStoreName) {
        return dataStoreName;
    }

    @Override
    public String getTypeOfDataStore(String typeOfDataStore) {
        return typeOfDataStore;
    }
    public String getSQLConnectionURL(String sqlConnectionURL){
        return sqlConnectionURL;
    }
    public String getDatabaseName(String databaseName){
        return databaseName;
    }
}
