public class Oracle extends DbConnection {
    public void connectCommandDb() {
        System.out.println("connectCommandDb: "+"oracle command");
    }

    public static void main(String[] args) {
        Oracle oracle=new Oracle();
        oracle.connectCommandDb();
        DbConnection o=new Oracle();//with reference of dbconnection class we can create object to the oracle class
        o.connectCommandDb();
        o.password();
        //Postgres po=new Oracle();
        //with reference of class postgres the object to the class oracle does not insantiated.because there is no relation between postgres & oracle class

    }
}
