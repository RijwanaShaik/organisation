public class DataWareHouseMain {
    public static void main(String[] args) {
       Datawarehouse object1=new SQLDataStore();
       PostgreSQL object2=new PostgreSQL();
       MySQL object3=new MySQL();
       Mongo object4=new Mongo();
       Dynamo object5=new Dynamo();
        System.out.println("DataStore name: "+object1.getDataStoreName("SQL DataStore"));
        System.out.println("Type of DataStore:"+object1.getTypeOfDataStore("Query based DataStore"));
        System.out.println();
        System.out.println("DataStore name: "+object2.getDataStoreName("SQL DataStore"));
        System.out.println("Type of DataStore:"+object2.getTypeOfDataStore("Query based DataStore"));
        System.out.println("URL Connection: "+object2.getSQLConnectionURL("https://postgresql.com"));
        System.out.println("Database Name: "+object2.getDatabaseName("SQL_Database"));
        System.out.println("Total No.of.Schemas: "+object2.getNumberOfSchemas(2));
        System.out.println("Total no.of. tables:"+object2.getNumberTables(10));
        System.out.println();
        System.out.println("DataStore name: "+object3.getDataStoreName("SQL DataStore"));
        System.out.println("Type of DataStore:"+object3.getTypeOfDataStore("Query based DataStore"));
        System.out.println("URL Connection: "+object3.getSQLConnectionURL("https://mysql.com"));
        System.out.println("Database Name: "+object3.getDatabaseName("MySQL_Database"));
        System.out.println("Total No.of.Schemas: "+object3.getNumberOfSchemas(1));
        System.out.println("Total no.of. tables:"+object3.getNumberTables(5));
        System.out.println();
        System.out.println("DataStore name: "+object4.getDataStoreName("NoSQL DataStore"));
        System.out.println("Type of DataStore:"+object4.getTypeOfDataStore("NoSQL based DataStore"));
        System.out.println("URL Connection: "+object4.getNoSQLConnectionURL("https://Nosql.com"));
        System.out.println("Database Name: "+object4.getDatabaseName("Mongo_Database"));
        System.out.println("Total No.of.Schemas: "+object4.getNumberOfItems(5));
        System.out.println("Total no.of. tables:"+object4.getNumberOfCollections(4));
        System.out.println();
        System.out.println("DataStore name: "+object5.getDataStoreName("NoSQL DataStore"));
        System.out.println("Type of DataStore:"+object5.getTypeOfDataStore("NoSQL based DataStore"));
        System.out.println("URL Connection: "+object5.getNoSQLConnectionURL("https://NosqlDynamo.com"));
        System.out.println("Database Name: "+object5.getDatabaseName("Dynamo_Database"));
        System.out.println("Total No.of.Schemas: "+object5.getNumberOfItems(5));
        System.out.println("Total no.of. tables:"+object5.getNumberOfCollections(4));
        System.out.println();
    }
}
