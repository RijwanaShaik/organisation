import java.util.*;
public class Main {
    public static void main(String args[]){
        int nums[] = {7, -5, 3, 2, 1, 0, 45};

        for(int i = 1; i < nums.length; i++){
            int value = nums[i];
            int j = i - 1;
            while(j >= 0 && nums[j] > value){
                nums[j + 1] = nums[j];
                j = j - 1;
            }
            nums[j + 1] = value;
        }
        System.out.println(Arrays.toString(nums));

    }
}