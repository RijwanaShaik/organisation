public abstract class NoSQLDataStore implements Datawarehouse{
    @Override
    public String getDataStoreName(String dataStoreName) {
        return dataStoreName;
    }


    public String getNoSQLConnectionURL(String nosqlConnectionURL){
        return nosqlConnectionURL;
    }
    public String getDatabaseName(String databaseName){
        return databaseName;
    }
}
