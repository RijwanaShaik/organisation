public interface Datawarehouse {
    String getDataStoreName(String dataStoreName);
    String getTypeOfDataStore(String typeOfDataStore);
}
