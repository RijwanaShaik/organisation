public class PostgreSQL extends SQLDataStore{
    @Override
    public String getDataStoreName(String dataStoreName) {
        return dataStoreName;
    }

    @Override
    public String getTypeOfDataStore(String typeOfDataStore) {
        return typeOfDataStore;
    }

    @Override
    public String getSQLConnectionURL(String sqlConnectionURL) {
        return sqlConnectionURL;
    }

    @Override
    public String getDatabaseName(String databaseName) {
        return databaseName;
    }
    public int getNumberOfSchemas(int numberOfSchemas){
        return numberOfSchemas;
    }
    public int getNumberTables(int numberOfTables){
        return numberOfTables;
    }
}
