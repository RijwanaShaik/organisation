public class Institutes extends ThrymrInstitute implements Institute {
    String instituteName;
    String instituteLocation;
    String instituteOwner;
    String student;



    @Override
    public String getInstituteName(String instituteName) {
        return null;
    }

    @Override
    public String getInstitueName(String institueName) {
        return institueName;
    }

    @Override
    public String getInstituteLocation(String instituteLocation) {
        return instituteLocation;
    }

    @Override
    public String getInstituteOwner(String instituteOwner) {
        return instituteOwner;
    }

    @Override
    public String getStudents(String student) {
        return student;
    }

    public static void main(String[] args) {
        Institutes institutes=new Institutes();
        System.out.println(institutes.getInstitueName("Thrymr")+"\n"+institutes.getInstituteLocation("Hyderabad")+"\n"+institutes.getInstituteOwner("Rishi")+"\n"+institutes.getStudents("Nikihila"));
    }

}
