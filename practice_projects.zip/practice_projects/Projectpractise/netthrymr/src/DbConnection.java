public class DbConnection {
    void password(){
        System.out.println("password: "+"Thrymr@123");
    }
    void username(){
        System.out.println("username: "+"Thrymr");
    }
    void dbName(String dbname){
        System.out.println("dbname: "+dbname);

    }
    public void connectCommandDb(){
        System.out.println("connectCommandDb:");
    }

}
