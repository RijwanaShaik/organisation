public class Postgres extends DbConnection{

    public void connectCommandDb() {

        System.out.println("connectCommandDb:"+"sudo su postgres");

    }

    public static void main(String[] args) {
        Postgres postgres=new Postgres();
        postgres.connectCommandDb();
        DbConnection p=new Postgres();//with reference of dbconnection class we can create object to the postgres class
       // p.password();

    }
}
