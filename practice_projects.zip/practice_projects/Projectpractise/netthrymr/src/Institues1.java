public class Institues1 extends WorkfallInstitute implements Institute{
    String instituteName;
    String instituteLocation;
    String instituteOwner;
    String student;

    @Override
    public String getInstituteOwner(String instituteName) {
        return instituteName;
    }

    @Override
    public String getStudents(String student) {
        return student;
    }


    @Override
    public String getInstituteName(String instituteName) {
        return instituteName;
    }

    @Override
    public String getInstitueName(String institueName) {
        return null;
    }

    @Override
    public String getInstituteLocation(String instituteLocation) {
        return instituteLocation;
    }

    public static void main(String[] args) {
        Institues1 institues1=new Institues1();
        System.out.println(institues1.getInstituteName("Workfall")+"\n"+institues1.getInstituteLocation("Hyderabad")+"\n"+institues1.getInstituteOwner("Suresh")+"\n"+institues1.getStudents("kunal"));
    }
}
