public class Dynamo extends NoSQLDataStore{
    @Override
    public String getTypeOfDataStore(String typeOfDataStore) {
        return typeOfDataStore;
    }

    @Override
    public String getNoSQLConnectionURL(String nosqlConnectionURL) {
        return nosqlConnectionURL;
    }

    @Override
    public String getDatabaseName(String databaseName) {
        return databaseName;
    }
    public int getNumberOfCollections(int numberOfCollections){
        return numberOfCollections;
    }
    public int getNumberOfItems(int numberOfItems){
        return numberOfItems;
    }
}
