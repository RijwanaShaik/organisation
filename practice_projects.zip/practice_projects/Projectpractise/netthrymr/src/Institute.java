public interface Institute {
    String getInstitueName(String institueName);

    String getInstituteLocation(String instituteLocation);

    String getInstituteOwner(String instituteOwner);

    String getStudents(String student);
}
    abstract class ThrymrInstitute {
        public abstract String getInstituteName(String instituteName);

        public abstract String getInstituteLocation(String instituteLocation);
    }

    abstract class WorkfallInstitute {
        public abstract String getInstituteName(String instituteName);

        public abstract String getInstituteLocation(String instituteLocation);
    }

    /*class Institutes extends ThrymrInstitute implements Institute {

        @Override
        public String getInstitueName(String institueName) {
            return institueName;
        }

        @Override
        public String getInstituteOwner(String instituteOwner) {
            return instituteOwner;
        }

        @Override
        public String getStudents(String student) {
            return student;
        }

        @Override
        public String getInstituteName(String instituteName) {
            return instituteName;
        }

        @Override
        public String getInstituteLocation(String instituteLocation) {
            return instituteLocation;
        }
    }*/

   /* class Institute1 extends WorkfallInstitute implements Institute {

        @Override
        public String getInstitueName(String institueName) {
            return institueName;
        }

        @Override
        public String getInstituteOwner(String instituteOwner) {
            return instituteOwner;
        }

        @Override
        public String getStudents(String student) {
            return student;
        }

        @Override
        public String getInstituteName(String instituteName) {
            return instituteName;
        }

        @Override
        public String getInstituteLocation(String instituteLocation) {
            return instituteLocation;
        }
    }

    public static void main(String[] args) {
        //Institutes institutes=new Institutes();
        System.out.println(institutes.getInstitueName("Thrymr")+"\n"+institutes.getInstituteLocation("Hyderabad")+"\n"+institutes.getInstituteOwner("Rishi")+"\n"+institutes.getStudents("Nikihila"));
        Institute1 institute1=new Institute1();
        System.out.println(institute1.getInstituteName("Workfall")+"\n"+institute1.getInstituteLocation("Hyderabad")+"\n"+institute1.getInstituteOwner("Suresh")+"\n"+institute1.getStudents("kunal"));
    }
    }
*/