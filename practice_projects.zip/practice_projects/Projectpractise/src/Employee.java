public class Employee {

        void salary(){
            int salary=25000;
            System.out.println("The employee salary is :"+salary);
        }
}

