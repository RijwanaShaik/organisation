package JavaString;
//String to stringBuffer and StringBuilder
//This one is an easy way out as we can directly pass the
// String class object to StringBuffer and StringBuilder class constructors.
// As the String class is immutable in java, so for editing a string,
// we can perform the same by converting it to StringBuffer or StringBuilder class objects.
public class Experiment2 {
    public static void main(String[] args) {
// Java program to demonstrate conversion from
// String to StringBuffer and StringBuilder
        // Custom input string
                String str = "Geeks";

                // Converting String object to StringBuffer object
                // by
                // creating object of StringBuffer class
                StringBuffer sbr = new StringBuffer(str);

                // Reversing the string
                sbr.reverse();

                // Printing the reversed string
                System.out.println(sbr);

                // Converting String object to StringBuilder object
                StringBuilder sbl = new StringBuilder(str);

                // Adding it to string using append() method
                sbl.append("ForGeeks");

                // Print and display the above appended string
                System.out.println(sbl);
    }
}

