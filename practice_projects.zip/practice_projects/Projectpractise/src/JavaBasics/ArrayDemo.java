package JavaBasics;
//default values
public class ArrayDemo {
    public static void main(String[] args) {
        System.out.println("String array default values: ");
        String str[]=new String[3];
        for(String s:str)
            System.out.println(s+" ");
        System.out.println("integer array default values: ");
        int num[]=new int[2];
        for(int val:num)
            System.out.println(val+" ");
        System.out.println("double array default values: ");
        double dnum[]=new double[2];
        for (double var :dnum)
            System.out.println(var+" ");
        System.out.println("boolean array default values: ");
        boolean bnum[]=new boolean[2];
        for (boolean val:bnum)
            System.out.println(val+" ");
        System.out.println("reference array default values: ");
        ArrayDemo ademo[]=new ArrayDemo[2];
        for (ArrayDemo val:ademo)
            System.out.println(val+" ");

    }

}
