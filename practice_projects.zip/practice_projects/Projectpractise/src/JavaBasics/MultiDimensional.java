package JavaBasics;

import java.util.Scanner;

public class MultiDimensional {
    public static void main(String[] args) {
        /*//delcaring and initializing 2D array
        int[][] arr ={{2,7,9},{3,6,1},{7,4,2}};
        //printing 2D array
        for (int i=0;i<3;i++){
            for (int j=0;j<3;j++) {
                    System.out.print(arr[i][j] + " ");
                }
                System.out.println();
            }*/

      /*  int[][] StudentMarks=new int[3][3];
        StudentMarks[0][0]=90;
        StudentMarks[0][1]=90;
        StudentMarks[1][1]=20;
     for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
        System.out.print(StudentMarks[i][j]+" ");
    }
         System.out.println();
}*/

    /* int[][] a=new int[3][];
     a[0]=new int[2];
     a[1]=new int[4];
     a[2]=new int[5];
     for(int i=0;i<3;i++){
         for(int j=0;j<5;j++){
             System.out.print(a[i][j]+" ");
         }
         System.out.println();
     }
*/

    }
}
