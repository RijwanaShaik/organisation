package JavaBasics;

import java.util.Scanner;

public class ArrayMin {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value of n: ");
        int n=sc.nextInt();
        int[] arr=new int[n];
        System.out.println("Enter "+n+"Numbers: ");
        int i=0;
        while(i<n){
            arr[i]=sc.nextInt();
            i++;
        }
        int small=arr[0];
        i=1;
        while(i<n){
            if(small>arr[i])
                small=arr[i];
            i++;
        }
        System.out.println("\nsmallest Number = "+small);
    }
}
    /*Enter the value of n:
        6
        Enter 6Numbers:
        45
        6
        89
        87
        30
        2

        smallest Number = 2
*/