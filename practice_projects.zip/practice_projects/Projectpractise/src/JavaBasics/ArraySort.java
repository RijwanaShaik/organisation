package JavaBasics;
import java.util.Arrays;
public class ArraySort {
    public static void main(String[] args) {
        int[] arr={45,78,65,21};
        Arrays.sort(arr);
        //for(int num:arr)
      //  System.out.print(num +" ");
        System.out.println(Arrays.toString(arr));
    }

}
