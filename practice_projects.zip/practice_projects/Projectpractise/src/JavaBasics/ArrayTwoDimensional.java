package JavaBasics;

import java.io.*;
import java.util.Scanner;

public class ArrayTwoDimensional {
    public static void print2D(int mat[][]){
        //Loop through all rows
        for (int[] row : mat);

            // converting each row as string
            // and then printing in a separate line
            //System.out.println(Arrays.toString(row));
    }
    public static void main(String[] args) throws IOException {

        /*int row, col, i, j;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Row Size: ");
        row=sc.nextInt();
        System.out.println("Enter column size: ");
        col=sc.nextInt();
        int[][] arr=new int[row][col];
        //matrix program
        System.out.println("\nEnter "+(row*col)+"Elements:");
        for(i=0;i<row;i++){
            for(j=0;j<col;j++){
                arr[i][j]=sc.nextInt();
            }
        }
        System.out.println("\nArray's Elements with its indexes: ");
        for(i=0;i<row;i++){
            for(j=0;j<col;j++){
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }*/
        int mat[][]={{1,2,3,4},{5,6,7,8},{9,10,11}};
        print2D(mat);
    }

}
