package JavaBasics;

public class Employee {
    int empId;
    String empName;
    float salary;
    public Employee(int empId, String empName, float salary) {
        this.empId = empId;
        this.empName = empName;
        this.salary = salary;
    }
    public Employee() {
    }
    @Override
    public String toString() {
        return "Employee{" +
                "empId=" + empId +
                ", empName='" + empName + '\'' +
                ", salary=" + salary +
                '}';
    }
    public static void main(String[] args) {
        /*Employee[] emp = new Employee[10];
        emp[0] = new Employee(1, "sohal", 28000);
        emp[1] = new Employee(2, "kunal", 30000);
        emp[2] = new Employee(3, "rashi", 26000);
        emp[3] = new Employee(4, "payal", 20000);
        emp[4] = new Employee(5, "sahil", 24000);
        emp[5]=new Employee(6,"rahul",32000);
        emp[6]=new Employee(7,"aditya",21000);
        emp[7]=new Employee(8,"koushik",26000);
        emp[8]=new Employee(9,"vijay",22000);
        emp[9]=new Employee(10,"karthik",23000);
        for (int i = 0; i < emp.length; i++) {
            System.out.println(emp[i]);
        }
        System.out.println("******************");
        Employee temp = new Employee();
        for (int i = 0; i < emp.length - 1; i++) {
            for (int j = i + 1; j < emp.length; j++) {
                if (emp[i].salary > emp[j].salary) {
                    temp = emp[i];
                    emp[i] = emp[j];
                    emp[j] = temp;
                }
            }
        }
        System.out.println("******************");
        System.out.println("Sorting employees in ASC with their salary "+"\n");
        for (int i = 0; i < emp.length; i++) {
            System.out.println(emp[i]);
        }*/
Employee[][] emp=new Employee[2][2];
        emp[0][0] = new Employee(1, "sohal", 28000);
        emp[0][1] = new Employee(2, "kunal", 30000);
        emp[1][0] = new Employee(3, "rashi", 26000);
        emp[1][1] = new Employee(4, "payal", 20000);
for(int i=0;i< emp.length;i++){
    for (int j=0;j< emp.length;j++){
        System.out.println(i+" "+j+" "+emp[i][j]);
    }
}
    }
}

