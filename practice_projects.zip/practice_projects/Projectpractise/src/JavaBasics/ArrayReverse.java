package JavaBasics;

import java.util.Scanner;
import java.util.Arrays;
public class ArrayReverse {

    public static void main(String[] args)
    {
        int n, res,i,j=0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter number of elements in the array:");
        n = s.nextInt();
        int array[] = new int[n];
        int rev[] = new int[n];
        System.out.print("Enter "+n+" elements ");
        for( i=0; i < n; i++)
        {
            array[i] = s.nextInt();
        }
        System.out.println("Reverse of an array is :");
        for( i=n;i>0 ; i--,j++)
        {
            rev[j] = array[i-1];
            System.out.print(rev[j]+" ");

        }
    }
}

/* Enter number of elements in the array:5
       Enter 5 elements 34
       78
       32
       49
       50
       Reverse of an array is :
       50 49 32 78 34
*/

//print reverse of an array in java
/*
public class ArrayReverse {

    public static void main(String[] args)
    {
        int i;
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter the Size of Array: ");
        int tot = scan.nextInt();
        int[] arr = new int[tot];

        System.out.print("Enter " +tot+ " Elements for the Array: ");
        for(i=0; i<tot; i++)
            arr[i] = scan.nextInt();

        System.out.println("\nReverse of Given Array is: ");
        for(i=(tot-1); i>=0; i--)
            System.out.print(arr[i]+ " ");
        }
}
*/
    /*Enter the Size of Array: 5
        Enter 5 Elements for the Array: 23
        45
        32
        56
        67

        Reverse of Given Array is:
        67 56 32 45 23 */

//print reverse array with for loop
/*
public class ArrayReverse {

    public static void main(String[] args)
    {
        int i,j,x;
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter the Size of Array: ");
        int tot = scan.nextInt();
        int[] arr = new int[tot];

        System.out.print("Enter " +tot+ " Elements for the Array: ");
        for(i=0; i<tot; i++)
            arr[i] = scan.nextInt();
        j=tot-1;
        for(i=0;i<j;i++,j--){
            x=arr[i];
            arr[i]=arr[j];
            arr[j]=x;
    }

        System.out.println("\nReverse of Given Array is: ");
        for(i=0; i<tot; i++)
            System.out.print(arr[i]+ " ");
    }
}
*/
    /*Enter the Size of Array: 5
        Enter 5 Elements for the Array: 78
        45
        32
        89
        10

        Reverse of Given Array is:
        10 89 32 45 78 */

/*
//print array in java with while loop
public class ArrayReverse {

    public static void main(String[] args)
    {
        int i,j,x;
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter the Size of Array: ");
        int tot = scan.nextInt();
        int[] arr = new int[tot];

        System.out.print("Enter " +tot+ " Elements for the Array: ");
        i=0;
        while(i<tot) {
            arr[i] = scan.nextInt();
            i++;
        }
        j=tot-1;
        i=0;
        while(i<j){
            x=arr[i];
            arr[i]=arr[j];
            arr[j]=x;
            i++;
            j--;
        }

        System.out.println("\nReverse of Given Array is: ");
        i=0;
        while( i<tot) {
            System.out.print(arr[i] + " ");
            i++;
        }
    }
}
*/
   /* Enter the Size of Array: 5
        Enter 5 Elements for the Array: 78
        98
        23
        45
        75

        Reverse of Given Array is:
        75 45 23 98 78 */
