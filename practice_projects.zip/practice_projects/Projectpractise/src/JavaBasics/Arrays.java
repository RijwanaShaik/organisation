package JavaBasics;
import java.util.*;
//java program to illustrate creating an array of objects

public class Arrays {
    public static void main(String[] args) {
     /*Student[] arr=new Student[5];//declaring & allocating memory for 5 objects of type student
        arr[0]=new Student(1,"sohal");
        arr[1]=new Student(2,"kunal");
        arr[2]=new Student(3,"rashi");
        arr[3]=new Student(4,"Krish");
        arr[4]=new Student(5,"Vaibhav");
        Student[] myStudents=new Student[]{new Student(10,"ram"),new Student(11,"sangeetha")};
        //accessing the elements of the specified array

        for(Student m:arr){
            System.out.println(m);
        }
        for (Student y:myStudents){
            System.out.println(y);
        }*/
        int a[]=new int[5];
        long b[]=new long[5];
        String c[]=new String[3];
        a[0]=10;
        a[1]=41;
        a[4]=55;

        b[0]=9014473067l;
        b[1]=7485965874l;
        b[2]=6464726767l;
        b[3]=4657574576676l;

        c[0]="Siva";
        c[1]="Nagendra";
        c[2]="Prasad";

        for(int i=0;i < 5;i++){
            System.out.print(a [i] );
            System.out.println(b[i]);
        }
    }
}
