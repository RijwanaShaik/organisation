package JavaBasics;
import java.util.Scanner;
public class ArrayInsert {
    public static void main(String[] args) {

        int i, element;
        int[] arr = new int[11];
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter 10 Elements: ");
        for (i = 0; i < 10; i++)
            arr[i] = scan.nextInt();

        System.out.print("Enter an Element to Insert: ");
        element = scan.nextInt();
        arr[i] = element;

        System.out.println("\nNow the new array is: ");
        for (i = 0; i < 11; i++)
            System.out.print(arr[i] + " ");
    }
}
/*
Enter 10 Elements: 3
        4
        78
        67
        98
        20
        32
        45
        32
        34
        Enter an Element to Insert: 45

        Now the new array is:
        3 4 78 67 98 20 32 45 32 34 45 */
/*public class ArrayInsert {
    public static void main(String[] args) {

        int i, element,n;
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter the Size of Array: ");
        n=scan.nextInt();
        int[] arr = new int[n+1];

        System.out.print("Enter "+ n +" Elements: ");
        for (i = 0; i <n; i++)
            arr[i] = scan.nextInt();

        System.out.print("Enter an Element to Insert: ");
        element = scan.nextInt();
        arr[i] = element;

        System.out.println("\nNow the new array is: ");
        for (i = 0; i <(n+1); i++)
            System.out.print(arr[i] + " ");
    }
}*/

   /* Enter the Size of Array: 5
        Enter 5 Elements: 78
        43
        8
        76
        54
        Enter an Element to Insert: 80

        Now the new array is:
        78 43 8 76 54 80
*/
//inserting an element in an array at a given position
  /* public class ArrayInsert {
       public static void main(String[] args) {

           int i, element;
           Scanner scan = new Scanner(System.in);

           System.out.print("Enter the Size of Array: ");
           int n = scan.nextInt();
           int[] arr = new int[n + 1];

           System.out.print("Enter " + n + " Elements: ");
           for (i = 0; i < n; i++)
               arr[i] = scan.nextInt();

           System.out.print("Enter an Element to Insert: ");
           element = scan.nextInt();
           System.out.print("At what position ? ");
           int pos = scan.nextInt();
           if (pos < n) {
               for (i = n; i >= pos; i--)
                   arr[i] = arr[i - 1];
               arr[i] = element;
               System.out.println("\nNow the new array is: ");
               for (i = 0; i < (n + 1); i++)
                   System.out.print(arr[i] + " ");
           } else
               System.out.println("\n Invalid Input!");
       }
   }*/
      /* Enter the Size of Array: 5
        Enter 5 Elements: 78
        65
        42
        22
        25
        Enter an Element to Insert: 56
        At what position ? 3

        Now the new array is:
        78 65 56 42 22 25 */