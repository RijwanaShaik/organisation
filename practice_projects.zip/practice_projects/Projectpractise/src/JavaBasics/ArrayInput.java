package JavaBasics;
import java.util.Collections;
import java.util.Scanner;
import java.util.Arrays;
public class ArrayInput {
    public static void main(String[] args) {
       /* Scanner s = new Scanner(System.in);
        System.out.println("Enter the length of the array:");
        int length = s.nextInt();
        int [] myArray = new int[length];
        System.out.println("Enter the elements of the array:");

        for(int i=0; i<length; i++ ) {
            myArray[i] = s.nextInt();
        }
        Arrays.sort(myArray);
        System.out.println();
        System.out.println(Arrays.toString(myArray));
        *//*Arrays.sort(myArray,1,5);
        System.out.println(Arrays.toString(myArray));*//*
*/


        int n;
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the number of elements you want to store: ");
//reading the number of elements from the that we want to enter
        n=sc.nextInt();
//creates an array in the memory of length 10
        int[] array = new int[10];
        int temp=0;
        System.out.println("Enter the elements of the array: ");
        for(int i=0; i<n; i++)
        {
//reading array elements from the user
            array[i]=sc.nextInt();
        }
        for (int i = 0; i < n; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                if (array[i] < array[j])
                {
                    temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
        }
      //  System.out.println("Array elements are: ");
// accessing array elements using the for loop

           /* for (int j = i+1; j < array.length; j++) {
                if(array[i] > array[j]) {
                    temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
*/
            System.out.print("descending Order:");
            for (int i = 0; i < n - 1; i++)
            {
                System.out.print(array[i] + ",");
            }
            System.out.print(array[n - 1]);
        }
}
