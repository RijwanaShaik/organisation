package JavaBasics;
import java.util.Scanner;
public class ArrayRemove {
    public static void main(String[] args) {
        int i, j, size=10, element;
        int[] arr = new int[size];
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter 10 Elements: ");
        for(i=0; i<size; i++)
            arr[i] = scan.nextInt();

        System.out.print("Enter the Element to Remove: ");
        element = scan.nextInt();

        for(i=0; i<size; i++)
        {
            if(element==arr[i])
            {
                for(j=i; j<(size-1); j++)
                    arr[j] = arr[j+1];
                System.out.println("\nRemoved the element successfully!");
                break;
            }
        }

        System.out.println("\nThe new array is: ");
        for(i=0; i<(size-1); i++)
            System.out.print(arr[i]+ " ");
    }
}
/*
Enter 10 Elements: 10
        24
        67
        65
        34
        11
        9
        78
        65
        88
        Enter the Element to Remove: 9

        Removed the element successfully!

        The new array is:
        10 24 67 65 34 11 78 65 88
*/
/*
public class ArrayRemove {
    public static void main(String[] args) {
        int i, j, size, element, count=0;
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter the Size of Array: ");
        size = scan.nextInt();
        int[] arr = new int[size];

        System.out.print("Enter " +size+ " Elements: ");
        for(i=0; i<size; i++)
            arr[i] = scan.nextInt();

        System.out.print("\nEnter the Element to Remove: ");
        element = scan.nextInt();

        for(i=0; i<size; i++)
        {
            if(element==arr[i])
            {
                for(j=i; j<(size-1); j++)
                    arr[j] = arr[j+1];
                size--;
                i--;
                count++;
            }
        }

        if(count==0)
            System.out.println("\nElement not found!");
        else if(count==1)
        {
            System.out.println("\nRemoved the element successfully!");
            System.out.println("\nThe new array is: ");
            for(i=0; i<size; i++)
                System.out.print(arr[i]+ " ");
        }
        */
/*else
        {
            System.out.println("\nRemoved all " +element+ " from the array.");
            System.out.println("\nThe new array is: ");
            for(i=0; i<size; i++)
                System.out.print(arr[i]+ " ");
        }*//*

    }
}
*/
    /*Enter the Size of Array: 5
        Enter 5 Elements: 78
        654
        342
        56
        76

        Enter the Element to Remove: 342

        Removed the element successfully!

        The new array is:
        78 654 56 76 */

//while loop
/*
i=0;
        while(i<size)
        {
        if(element==arr[i])
        {
        j=i;
        while(j<(size-1))
        {
        arr[j] = arr[j+1];
        j++;
        }
        size--;
        i--;
        count++;
        }
        i++;
        }
*/
