package packageMatrix;
//2.Print 3*3 matrix of right diagonal values.
import java.util.Scanner;

public class RightDiagonal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print(" Enter No Of Rows :");
        int rows = sc.nextInt();
        System.out.print(" Enter No Of Columns :");
        int columns = sc.nextInt();
        int[][] array = new int[rows][columns];
        System.out.print(" Enter values ");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                array[i][j] = sc.nextInt();
            }
        }
        System.out.println(" The Result matrix is : ");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                System.out.print(array[i][j] + " ");
            }
            System.out.println();
        }
        for(int i=0;i< array.length;i++){
            for(int j=0;j< array.length;j++){
                if(i==j){

                    System.out.println("The right diagonal values are: "+array[i][j]);
                }
            }
        }
  }
}
   /* Enter No Of Rows :3
        Enter No Of Columns :3
        Enter values 11
        13
        14
        10
        20
        30
        45
        30
        32
        The Result matrix is :
        11 13 14
        10 20 30
        45 30 32
        The right diagonal values are: 11
        The right diagonal values are: 20
        The right diagonal values are: 32
*/
class Ex{
       public static void main(String[] args) {


    int matrix[][] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };

        for(int i=0; i < matrix.length; i++) {
        for(int j=0; j < matrix[0].length; j++) {
        System.out.print(matrix[i][j] + " ");
        }
        System.out.println();
        }

        for(int i=0; i< matrix.length; i++){
        for(int j=0; j<matrix[0].length; j++) {
        if (matrix[i] == matrix[j]) {
        System.out.println("Right diagonal values : "+matrix[i][j]);
        }
        }
        }
        }
        }