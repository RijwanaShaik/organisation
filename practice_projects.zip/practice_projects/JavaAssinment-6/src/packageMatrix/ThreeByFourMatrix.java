package packageMatrix;

import java.util.Scanner;

//1.print 3*4 matrix
//i.Find sum of rows & columns
//ii.Total sum of rows & columns
public class ThreeByFourMatrix {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print(" Enter No Of Rows :");
        int rows = sc.nextInt();
        System.out.print(" Enter No Of Columns :");
        int columns = sc.nextInt();
        int[][] array = new int[rows][columns];
        System.out.print(" Enter values ");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                array[i][j] = sc.nextInt();
            }
        }
      //  int[][] array={{10,20,30,40},{50,60,70,80},{90,10,20,30}};
        int sumRow=0;
        int totalSum=0;
        System.out.println("Sum of values Row wise");
        for (int i = 0; i < array.length; i++) {
            sumRow = 0;
            for (int j = 0; j < array.length; j++) {
                sumRow = sumRow + array[i][j];
                totalSum +=array[i][j];
            }System.out.println(" Sum of " + (i + 1) + " row :" + sumRow);
        }

        System.out.println("Sum of values Column wise ");
        for (int i = 0; i < array.length; i++) {
            int sumCol = 0;
            for (int j = 0; j < array.length; j++) {
                sumCol = sumCol + array[j][i];
                totalSum +=array[i][j];
            }
            System.out.println(" Sum of " + (i + 1) + " Column :" + sumCol);
        }
        System.out.println("total sum rows & columns = "+totalSum);
    }
}
    /*/home/thrymrthrymr123/Documents/practice_projects/JavaAssinment-6/out/production/JavaAssinment-6 packageMatrix.ThreeByFourMatrix
Enter No Of Rows :3
 Enter No Of Columns :4
 Enter values 10
20
30
40
50
60
70
80
90
10
20
30
Sum of values Row wise
 Sum of 1 row :60
 Sum of 2 row :180
 Sum of 3 row :120
Sum of values Column wise
 Sum of 1 Column :150
 Sum of 2 Column :90
 Sum of 3 Column :120
total sum rows & columns = 720
*/