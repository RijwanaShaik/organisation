package packageStrings;
//5.Take any string
//i.Get the count of string without considering spaces,comma,Dot
public class StringCountWithoutSpace {
    public static void main(String[] args) {
        String str="Hello World. Java";
        int count = 0;
        System.out.println("Original string: "+str.length());
        //Counts each character without space,comma,Dot
        for(int i = 0; i < str.length(); i++) {
            if(str.charAt(i) != ' '&& str.charAt(i) !='.'&& str.charAt(i) !=',')
                count++;
        }

        System.out.println("Total number of characters in a string: " + count);

    }
}
/*
/home/thrymrthrymr123/Documents/practice_projects/JavaAssinment-6/out/production/JavaAssinment-6 packageStrings.StringCountWithoutSpace
        Original string: 17
        Total number of characters in a string: 14*/

