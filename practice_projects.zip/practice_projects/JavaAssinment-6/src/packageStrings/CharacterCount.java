package packageStrings;
//3.Take any string
//Find the character which are repeated more than once
public class CharacterCount {
    public static void main(String[] args) {
        String str="Hello World Java World";
        str = str.toLowerCase();
        char[] c = str.toCharArray();
        for (int i = 0; i <= c.length - 1; i++) {
            int count = 1;
            for (int j = i + 1; j < c.length; j++) {
                if (c[i] == c[j]) {
                    count++;
                    c[j] = '0';
                }
            }
            if (count >= 1 && c[i] != '0') {
                System.out.println(c[i] + "=" + count);
            }
        }
    }
}
