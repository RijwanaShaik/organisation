package packageStrings;

import java.util.Arrays;

//4.Take any String e.g:Hello World Java
//i.spilt with space
//ii.Reverse the string by word in uppercase
public class StringSpiltBySpace {
    public static void main(String[] args) {
        String str="Hello World Java";
        String reverseString="";
        String[] spiltString=str.split(" ");

        System.out.println("String before spilting: "+str);

        for(String st:spiltString){
            System.out.println(" After spilting the String basis on space: "+st);
        }

        System.out.println("Reversing the each word in a string");

        for(int i=0; i<spiltString.length;i++){
            String word=spiltString[i];
            String revWord="";
            for(int j=word.length()-1;j>=0;j--) {
                revWord = revWord + word.charAt(j);
            }
            reverseString=reverseString+revWord+" ";
        }
        System.out.println(reverseString.toUpperCase());
    }
}
 /*for(int i=str.length()-1;i>=0;--i){
         reverseString +=str.charAt(i);
         }
         System.out.println(reverseString.toUpperCase());*/
class reverse{
    public String reversestring(String str){
        return "Reversed String";
    }

     public static void main(String[] args) {
         reverse rev=new reverse();
         String str="Hello World";
         String[] splitwords=str.split(" ");
         for(int i=0;i< splitwords.length;i++){
             System.out.println(rev.reversestring(splitwords[i]));
         }
     }
 }
