package packageJavaConcept;
//7.Explain why string is final
public class WhyStringIsFinal {
}
// String class is made final in Java in order to make the String objects immutable.
// when string object is  immutable helps in two ways:
// 1)Security: the system can hand out sensitive bits of read-only information without worrying that they will be altered.
// 2) Performance: immutable data is very useful in making things thread-safe.