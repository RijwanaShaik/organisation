package packageJavaConcept;
//6.final method
public class FinalMethod {
    public final void display(){
        System.out.println("This is a final method of parent class");
    }
}
//the final method can't be overridden in it's extended class
//the class FinalMethod is extended to the class ApplicatingFinalMethod,it shows the below output


/*
/home/thrymrthrymr123/Documents/practice_projects/JavaAssinment-6/src/packageJavaConcept/ApplicatingFinalMethod.java:4:23
        java: display() in packageJavaConcept.ApplicatingFinalMethod cannot override display() in packageJavaConcept.FinalMethod
        overridden method is final*/
