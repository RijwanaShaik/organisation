package packageJavaConcept;
//6.final class
final class FinalClass {
    public void display(){
        System.out.println("The is a method of final class");
    }
}
//the class FinalClass is extended to subclass of "ExtensionOfFinalClass", but it displays the below output
/*/home/thrymrthrymr123/Documents/practice_projects/JavaAssinment-6/src/packageJavaConcept/ExtensionOfFinalClass.java:3:44
        java: cannot inherit from final packageJavaConcept.FinalClass*/
//final class can't be extended to subclasses