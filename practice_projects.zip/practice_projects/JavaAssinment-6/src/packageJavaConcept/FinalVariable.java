package packageJavaConcept;
//6.final varible
public class FinalVariable {
    public static void main(String[] args) {
        final String companyName="Thrymr";
        // companyName="TCS";
        System.out.println(companyName);

    }
}
//All employees of the "thrymr" company contain same name,that can't be different to employees in a company
// in such scenarios final variables can be used.
//if we reassign company name,it shows error : the final variable can't be reassigned.

/*
output: if we reassign companyName
/home/thrymrthrymr123/Documents/practice_projects/JavaAssinment-6/src/packageJavaConcept/FinalVariable.java:6:10
        java: cannot assign a value to final variable companyName*/
