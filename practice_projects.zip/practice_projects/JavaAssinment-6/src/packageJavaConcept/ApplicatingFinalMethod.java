package packageJavaConcept;

/*public class ApplicatingFinalMethod extends FinalMethod{
    public final void display(){
        System.out.println("This is a overridden final method of class FinalMethod");
    }

    public static void main(String[] args) {
        ApplicatingFinalMethod ap=new ApplicatingFinalMethod();
        ap.display();
    }
}*/
