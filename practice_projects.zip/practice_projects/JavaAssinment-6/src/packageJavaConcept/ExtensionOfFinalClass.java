package packageJavaConcept;

/*
public class ExtensionOfFinalClass extends FinalClass{
    @Override
    public void display() {
        System.out.println("This is a method of extension of finalclass");
    }

    public static void main(String[] args) {
        ExtensionOfFinalClass fn=new ExtensionOfFinalClass();
        fn.display();
    }
}
*/
