package Relationship;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Schedule {
    int id;
    LocalDateTime OpenTimings;
    LocalDateTime ClosedTimings;
    Hotel hotel;

    public Schedule(int id, LocalDateTime openTimings, LocalDateTime closedTimings, Hotel hotel) {
        this.id = id;
        OpenTimings = openTimings;
        ClosedTimings = closedTimings;
        this.hotel = hotel;
    }

    public Schedule() {

    }

    @Override
    public String toString() {
        return "Schedule{" +
                "id=" + id +
                ", OpenTimings=" + OpenTimings +
                ", ClosedTimings=" + ClosedTimings +
                ", hotel=" + hotel +
                '}';
    }

    public List<Hotel> hotelList(){
        return List.of(new Hotel(1,"Paradise"),
                new Hotel(2,"Hyderabad Chef"));
    }
    public List<Schedule> scheduleList(){
        return List.of(new Schedule(1, LocalDateTime.of(2022, 12, 5, 9, 00, 00),LocalDateTime.of(2022,12,5,10,00,00),hotelList().get(0)),
                new Schedule(1, LocalDateTime.of(2022, 12, 6, 9, 00, 00),LocalDateTime.of(2022,12,6,10,00,00),hotelList().get(0)),
                new Schedule(1, LocalDateTime.of(2022, 12, 7, 9, 00, 00),LocalDateTime.of(2022,12,7,10,00,00),hotelList().get(0)),
                new Schedule(1, LocalDateTime.of(2022, 12, 8, 9, 00, 00),LocalDateTime.of(2022,12,8,10,00,00),hotelList().get(0)),
                new Schedule(1, LocalDateTime.of(2022, 12, 9, 9, 00, 00),LocalDateTime.of(2022,12,9,10,00,00),hotelList().get(0)),
                new Schedule(1, LocalDateTime.of(2022, 12, 10, 9, 00, 00),LocalDateTime.of(2022,12,10,11,00,00),hotelList().get(0)),
                new Schedule(1, LocalDateTime.of(2022, 12, 11, 9, 00, 00),LocalDateTime.of(2022,12,11,10,00,00),hotelList().get(0)),




        new Schedule(2, LocalDateTime.of(2022, 12, 5, 0, 00, 00),LocalDateTime.of(2022,12,5,0,00,00),hotelList().get(1)),
                new Schedule(2, LocalDateTime.of(2022, 12, 6, 9, 00, 00),LocalDateTime.of(2022,12,6,11,00,00),hotelList().get(1)),
                new Schedule(2, LocalDateTime.of(2022, 12, 7, 9, 00, 00),LocalDateTime.of(2022,12,7,8,00,00),hotelList().get(1)),
                new Schedule(2, LocalDateTime.of(2022, 12, 8, 10, 00, 00),LocalDateTime.of(2022,12,8,10,00,00),hotelList().get(1)),
                new Schedule(2, LocalDateTime.of(2022, 12, 9, 9, 00, 00),LocalDateTime.of(2022,12,9,10,00,00),hotelList().get(1)),
                new Schedule(2, LocalDateTime.of(2022, 12, 10, 10, 00, 00),LocalDateTime.of(2022,12,10,9,00,00),hotelList().get(1)),
                new Schedule(2, LocalDateTime.of(2022, 12, 11, 9, 00, 00),LocalDateTime.of(2022,12,11,10,00,00),hotelList().get(1))
   );
    }

    public static void main(String[] args) {
        Schedule obj=new Schedule();
        List<Schedule> scheduleLists=new ArrayList<>(obj.scheduleList());
        System.out.println(scheduleLists);


    }
}
