package Relationship;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
//3.Find all the hotels which are closed on a particular date
public class ClosedOnParticularDate {
    public static void main(String[] args) {
        Schedule obj=new Schedule();
        List<Schedule> scheduleLists=new ArrayList<>(obj.scheduleList());
        Predicate<Schedule> predicate2= a->a.OpenTimings.equals(a.OpenTimings.withHour(0));
        Predicate<Schedule> predicate3= a->a.ClosedTimings.equals(a.ClosedTimings.withHour(0));

        scheduleLists.stream().filter(predicate2.and(predicate3)).forEach(a-> System.out.println(a.hotel));
    }
}
