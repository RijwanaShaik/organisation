package Relationship;

import java.util.ArrayList;
import java.util.List;
//  2. Find the schedule of a hotel for a week
public class ScheduleOfAHotel {
    public static void main(String[] args) {
        Schedule obj = new Schedule();
        List<Schedule> scheduleLists = new ArrayList<>(obj.scheduleList());
        scheduleLists.stream().filter(a -> a.hotel.name.equals("Paradise")).forEach(a -> System.out.println(a.scheduleList()));
    }
}
