package Relationship;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
//    1. Find all hotels which are open on Saturday after 10 pm
public class OpenAfterTen {
    public static void main(String[] args) {
        Schedule obj=new Schedule();
        List<Schedule> scheduleLists=new ArrayList<>(obj.scheduleList());
        Predicate<Schedule> predicate= a->a.ClosedTimings.isAfter(a.ClosedTimings.withHour(10));//still open after 10
        Predicate<Schedule> predicate1= a->a.ClosedTimings.equals(a.ClosedTimings.withDayOfMonth(10));//open on saturday
        scheduleLists.stream().filter(predicate.and(predicate1)).forEach(a-> System.out.println(a.hotel));

    }
}
