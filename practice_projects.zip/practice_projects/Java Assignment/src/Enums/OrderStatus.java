package Enums;

public enum OrderStatus {
    DELIVERED,NOTDELIVERED
}
