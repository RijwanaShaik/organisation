package Enums;

public enum PaymentStatus {
    PAID,UNPAID
}
