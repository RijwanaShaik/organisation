package Enums;

import java.util.ArrayList;
import java.util.List;

public class Order {
    int id;
    OrderStatus status;
    PaymentStatus  paymentStatus;
    Customer customer;

    public Order(int id, OrderStatus status, PaymentStatus paymentStatus, Customer customer) {
        this.id = id;
        this.status = status;
        this.paymentStatus = paymentStatus;
        this.customer = customer;
    }

    public Order() {

    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", status=" + status +
                ", paymentStatus=" + paymentStatus +
                ", customer=" + customer +
                '}';
    }
public List<Customer> customerList(){
        return List.of(new Customer(1,"raj"),
                new Customer(2,"kunal"));

    }
    public List<Order> orderList(){
        return List.of(new Order(1000,OrderStatus.DELIVERED,PaymentStatus.PAID,customerList().get(0)),
                new Order(1002,OrderStatus.NOTDELIVERED,PaymentStatus.UNPAID,customerList().get(0)),
                new Order(1003,OrderStatus.DELIVERED,PaymentStatus.UNPAID,customerList().get(1)));

    }
    public static void main(String[] args) {
        Order order=new Order();
        List<Order> ordersList=new ArrayList<>(order.orderList());
        System.out.println(ordersList);
        ordersList.stream().filter(a->a.status.equals(OrderStatus.NOTDELIVERED)).forEach(a-> System.out.println("the order which is not deliverd to the customer is: "+a.customer.name));
    }

}
