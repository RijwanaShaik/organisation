package reverified;

import java.time.DayOfWeek;
import java.time.LocalTime;



public class Schedules {
    int id;
    DayOfWeek day;
    String status;
    LocalTime Open;
    LocalTime close;
  //  LocalDate date;

    public Schedules(int id, DayOfWeek day, String status, LocalTime open, LocalTime close) {
        this.id = id;
        this.day = day;
        this.status = status;
        Open = open;
        this.close = close;
    }

    @Override
    public String toString() {
        return "Schedules{" +
                "id=" + id +
                ", day=" + day +
                ", status='" + status + '\'' +
                ", Open=" + Open +
                ", close=" + close +
              //  ", date=" + date +
                '}';
    }
    /* public Schedules(int id, String day, String status, LocalTime open, LocalTime close, LocalDate date) {
        this.id = id;
        this.day = day;
        this.status = status;
        Open = open;
        this.close = close;
        this.date = date;
    }

    @Override
    public String toString() {
        return "Schedules{" +
                "id=" + id +
                ", day='" + day + '\'' +
                ", status='" + status + '\'' +
                ", Open=" + Open +
                ", close=" + close +
                ", date=" + date +
                '}';
    }*/
    //Hotels hotels;

 /*   public Schedules(int id, String day, String status, LocalTime open, LocalTime close, LocalDate date, Hotels hotels) {
        this.id = id;
        this.day = day;
        this.status = status;
        Open = open;
        this.close = close;
        this.date = date;
        this.hotels = hotels;
    }

    public Schedules() {

    }

    @Override
    public String toString() {
        return "Schedules{" +
                "id=" + id +
                ", day='" + day + '\'' +
                ", status='" + status + '\'' +
                ", Open=" + Open +
                ", close=" + close +
                ", date=" + date +
                ", hotels=" + hotels +
                '}';
    }
    public List<Schedules> schedulesList() {
        return List.of(new Schedules(1, "Monday", "Opened", LocalTime.of(9, 00, 00), LocalTime.of(10, 00, 00), LocalDate.of(2022,12,5),hotelsList().get(0)),
                new Schedules(1, "tuesday", "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00),LocalDate.of(2022,12,6),hotelsList().get(0)),
                new Schedules(1, "wednesay", "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00),LocalDate.of(2022,12,7),hotelsList().get(0)),
                new Schedules(1, "thrusday", "Opened", LocalTime.of(8, 9, 00, 00), LocalTime.of( 10, 00, 00),LocalDate.of(2022,12,8),hotelsList().get(0)),
                new Schedules(1, "friday", "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00),LocalDate.of(2022,12,9),hotelsList().get(0)),
                new Schedules(1, "saturday", "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 11, 00, 00),LocalDate.of(2022,12,10),hotelsList().get(0)),
                new Schedules(1, "sunday", "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00),LocalDate.of(2022,12,11),hotelsList().get(0)),




        new Schedules(2, "Monday","closed",LocalTime.of( 0, 00, 00),LocalTime.of(0,00,00), LocalDate.of(2022,12,5),hotelsList().get(1)),
                new Schedules(2, "tuesday","Opened",LocalTime.of( 9, 00, 00),LocalTime.of(11,00,00), LocalDate.of(2022,12,6),hotelsList().get(1)),
                new Schedules(2,"wednesay","Opened", LocalTime.of( 9, 00, 00),LocalTime.of(8,00,00), LocalDate.of(2022,12,7),hotelsList().get(1)),
                new Schedules(2,"thrusday","Opened", LocalTime.of(10, 00, 00),LocalTime.of(10,00,00), LocalDate.of(2022,12,8),hotelsList().get(1)),
                new Schedules(2, "friday","Opened",LocalTime.of( 9, 00, 00),LocalTime.of(10,00,00), LocalDate.of(2022,12,9),hotelsList().get(1)),
                new Schedules(2,"saturday","Opened", LocalTime.of( 10, 00, 00),LocalTime.of(9,00,00), LocalDate.of(2022,12,10),hotelsList().get(1)),
                new Schedules(2, "sunday","Opened",LocalTime.of( 9, 00, 00),LocalTime.of(10,00,00), LocalDate.of(2022,12,11),hotelsList().get(1))
        );
    }
    public List<Hotels> hotelsList(){
        return List.of(new Hotels(1,"Paradise"),
                new Hotels(2,"Hyderabad chef"));
    }

    public static void main(String[] args) {
        Schedules schedules=new Schedules();
        List<Schedules> schedulesList1=new ArrayList<>(schedules.schedulesList());
        //   1. Find all hotels which are open on Saturday after 10 pm
        schedulesList1.stream().filter(a->a.day.equals("saturday")&&a.close.isAfter(a.close.withHour(10))).forEach(a-> System.out.println(a.hotels.name));
        //3.Find all the hotels which are closed on a particular date
       // LocalDate b=LocalDate.of(2022,12,5);
        schedulesList1.stream().filter(a->a.status.equals("closed")&&a.date.isEqual(LocalDate.of(2022,12,5))).forEach(a-> System.out.println(a.hotels.name));
        //  2. Find the schedule of a hotel for a week
*//*
      if(schedules.schedulesList().stream().filter(a->a.hotels.name.equalsIgnoreCase("Paradise"))){

      }*//*
   }*/
}
