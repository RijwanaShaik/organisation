package reverified;


import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Hotels {
    int id;
    String name;
    List<Schedules> schedules;


 public Hotels(int id, String name, List<Schedules> schedules) {
        this.id = id;
        this.name = name;
        this.schedules = schedules;
    }

    public Hotels() {

    }

    @Override
    public String toString() {
        return "Hotels{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", schedules=" + schedules +
                '}';
    }

    /* public Hotels(int id, String name) {
                this.id = id;
                this.name = name;
            }

            public Hotels() {

            }

            @Override
            public String toString() {
                return "Hotels{" +
                        "id=" + id +
                        ", name='" + name + '\'' +

                        '}';
            }*//*
    public List<Schedules> schedulesList1() {
        return List.of(new Schedules(1, "Monday", "Opened", LocalTime.of(9, 00, 00), LocalTime.of(10, 00, 00), LocalDate.of(2022,12,5)),
                new Schedules(1, "tuesday", "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00),LocalDate.of(2022,12,6)),
                new Schedules(1, "wednesay", "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00),LocalDate.of(2022,12,7)),
                new Schedules(1, "thrusday", "Opened", LocalTime.of(8, 9, 00, 00), LocalTime.of( 10, 00, 00),LocalDate.of(2022,12,8)),
                new Schedules(1, "friday", "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00),LocalDate.of(2022,12,9)),
                new Schedules(1, "saturday", "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 11, 00, 00),LocalDate.of(2022,12,10)),
                new Schedules(1, "sunday", "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00),LocalDate.of(2022,12,11))
                );}


    public List<Schedules> schedulesList2() {

           return List.of(     new Schedules(2, "Monday","closed",LocalTime.of( 0, 00, 00), LocalTime.of(0,00,00), LocalDate.of(2022,12,5)),
                new Schedules(2, "tuesday","Opened",LocalTime.of( 9, 00, 00),LocalTime.of(11,00,00), LocalDate.of(2022,12,6)),
                new Schedules(2,"wednesay","Opened", LocalTime.of( 9, 00, 00),LocalTime.of(8,00,00), LocalDate.of(2022,12,7)),
                new Schedules(2,"thrusday","Opened", LocalTime.of(10, 00, 00),LocalTime.of(10,00,00), LocalDate.of(2022,12,8)),
                new Schedules(2, "friday","Opened",LocalTime.of( 9, 00, 00),LocalTime.of(10,00,00), LocalDate.of(2022,12,9)),
                new Schedules(2,"saturday","Opened", LocalTime.of( 10, 00, 00),LocalTime.of(9,00,00), LocalDate.of(2022,12,10)),
                new Schedules(2, "sunday","Opened",LocalTime.of( 9, 00, 00),LocalTime.of(10,00,00), LocalDate.of(2022,12,11))
        );
    }
    public List<Hotels> hotelsList1(){
        return List.of(new Hotels(1,"Paradise",schedulesList1()),
                new Hotels(2,"Hyderabad chef",schedulesList2()));
    }

    public static void main(String[] args) {
        Hotels hotels=new Hotels();
        List<Hotels> hotelsList=new ArrayList<>(hotels.hotelsList1());
        //   1. Find all hotels which are open on Saturday after 10 pm
        hotelsList.stream().filter(i->i.schedules.stream().anyMatch(a->a.day.equalsIgnoreCase("saturday")&&a.close.isAfter(a.close.withHour(10)))).forEach(a-> System.out.println("The hotel which is open on saturday after 10 pm is: "+a.name));

        //  2. Find the schedule of a hotel for a week
        hotelsList.stream().filter(a->a.name.equalsIgnoreCase("Paradise")).forEach(a-> System.out.println("Scheudles of a hotel for a week\n"+a.schedules));

        //3.Find all the hotels which are closed on a particular date
        hotelsList.stream().filter(i-> i.schedules.stream().anyMatch(a -> a.date.isEqual(LocalDate.of(2022, 12, 5)) && a.status.equalsIgnoreCase("closed"))).forEach(a-> System.out.println("The Hotel which is closed on a particular date is: "+a.name));


    }*/
    public List<Schedules> schedulesList1() {
        return List.of(new Schedules(1, DayOfWeek.MONDAY, "Opened", LocalTime.of(9, 00, 00), LocalTime.of(10, 00, 00)),
                new Schedules(1, DayOfWeek.TUESDAY, "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00)),
                new Schedules(1, DayOfWeek.WEDNESDAY, "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00)),
                new Schedules(1, DayOfWeek.THURSDAY, "Opened", LocalTime.of(8, 9, 00, 00), LocalTime.of( 10, 00, 00)),
                new Schedules(1, DayOfWeek.FRIDAY, "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00)),
                new Schedules(1, DayOfWeek.SATURDAY, "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 11, 00, 00)),
                new Schedules(1, DayOfWeek.SUNDAY, "Opened", LocalTime.of( 9, 00, 00), LocalTime.of( 10, 00, 00))
        );}


    public List<Schedules> schedulesList2() {

        return List.of(     new Schedules(2, DayOfWeek.MONDAY,"closed",LocalTime.of( 0, 00, 00), LocalTime.of(0,00,00)),
                new Schedules(2, DayOfWeek.TUESDAY,"Opened",LocalTime.of( 9, 00, 00),LocalTime.of(11,00,00)),
                new Schedules(2,DayOfWeek.WEDNESDAY,"Opened", LocalTime.of( 9, 00, 00),LocalTime.of(8,00,00)),
                new Schedules(2,DayOfWeek.THURSDAY,"Opened", LocalTime.of(10, 00, 00),LocalTime.of(10,00,00)),
                new Schedules(2, DayOfWeek.FRIDAY,"Opened",LocalTime.of( 9, 00, 00),LocalTime.of(10,00,00)),
                new Schedules(2, DayOfWeek.SATURDAY,"Opened", LocalTime.of( 10, 00, 00),LocalTime.of(9,00,00)),
                new Schedules(2, DayOfWeek.SUNDAY,"Opened",LocalTime.of( 9, 00, 00),LocalTime.of(10,00,00))
        );
    }
    public List<Hotels> hotelsList1(){
        return List.of(new Hotels(1,"Paradise",schedulesList1()),
                new Hotels(2,"Hyderabad chef",schedulesList2()));
    }

    public static void main(String[] args) {
        Hotels obj=new Hotels();
        List<Hotels> hotelsList=new ArrayList<>(obj.hotelsList1());
        //1
        hotelsList.stream().filter(a->a.schedules.stream().anyMatch(i-> DayOfWeek.SATURDAY.equals(i.day)&&i.close.isAfter(i.close.withHour(10)))).forEach(a-> System.out.println(a.name));
        //2
        hotelsList.stream().filter(a->a.name.equalsIgnoreCase("Hyderabad chef")).forEach(a-> System.out.println(a.schedules));
        //3.
Calendar calendar=Calendar.getInstance();
calendar.set(2022,12,12);
LocalDate date=LocalDate.now();
date.isEqual(LocalDate.of(2022,12,12));
        hotelsList.stream().filter(i-> i.schedules.stream().filter(a -> Boolean.parseBoolean((a.status.equalsIgnoreCase("closed"))+""+(a.close.atDate(date)))).isParallel()).forEach(a-> System.out.println("The Hotel which is closed on a particular date is: "+a.name));

    }

}
