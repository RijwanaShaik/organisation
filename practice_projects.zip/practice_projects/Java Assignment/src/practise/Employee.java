package practise;

import java.util.*;
import java.util.stream.Collectors;

public class Employee {
    int id;
    String name;
    float salary;

    public Employee(int id, String name, float salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public Employee() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", salary=" + salary +
                '}';
    }
    public List<Employee> employees(){
        return List.of(new Employee(10,"raj",5000),
                new Employee(12,"kunal sharma",6000),
                new Employee(14,"kapil sharma",8000));

    }

    public static void main(String[] args) {
        Employee emp=new Employee();
        List<Employee> employeeList=new ArrayList<>(emp.employees());
        employeeList.stream().filter(a->a.salary>5000).forEach(System.out::println);
        employeeList.stream().filter(a->a.name.length()>3).map(a->a.name.toUpperCase()).forEach(System.out::println);
        Optional<Employee> d=employeeList.stream().max(Comparator.comparingDouble(Employee::getSalary));
        System.out.println(d);
        employeeList.stream().sorted(Comparator.comparing(Employee::getSalary)).forEach(System.out::println);
       DoubleSummaryStatistics sal= employeeList.stream().collect(Collectors.summarizingDouble(Employee::getSalary));
        System.out.println(sal);
    }
}
