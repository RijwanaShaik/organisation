package Serialisation;

import java.io.*;

public class Employee implements Serializable {
    int id;
    String name;
    float salary;
    String email;
   transient int account_no;

    public Employee(int id, String name, float salary, String email, int account_no) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.email = email;
        this.account_no = account_no;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", salary=" + salary +
                ", email='" + email + '\'' +
                ", account_no=" + account_no +
                '}';
    }
    //serializing object
    private static void serialize(Employee employee){
        try {
            System.out.println("Employee serializing : " + employee);
            FileOutputStream fileOut =
                    new FileOutputStream("employee.txt" );
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(employee);
            out.close();
            fileOut.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }
    //deserializing object
    private static void deserialize(){
        try {
            FileInputStream fileIn = new FileInputStream("employee.txt");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            Employee employee = (Employee) in.readObject();
            in.close();
            fileIn.close();
            System.out.println("Employee deserialized and with using tranisent variable to account : " + employee);
        } catch (IOException | ClassNotFoundException i) {
            i.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Employee employee=new Employee(12,"kunal",8000,"kunal123@gmail.com",3456783);
        System.out.println("Before serialization "+employee);
        serialize(employee);
        deserialize();
    }
}
// Serialization & deserialization is used when data is transfer through network to the user
//Serialization :is the process of converting the state of an object into a byte stream.
// A byte-stream is a Java I/O (Input/Output) stream which is essentially flows of data that a programmer can either read from or write .
//by seralization ,we have converted the employee object into a byte-stream which can be saved onto a disk, communicated over the network.
//However, to use them again, we need to convert these byte-streams back to their respective Objects. This reverse process of converting object into byte-stream is called Deserialization
//Deserialization:procsess of converting byte stream to state of an object
//Transient:
// The transient keyword in Java is used to avoid serialization. If any object of a data structure is defined as a transient, then it will not be serialized.
//In the above example ,we used transient to account_no,after deserialization the account no is appear as defualt value to the user.
//when we want to make some information invisible  to users,i.e those information is unneccessary to give information to the user & for security purpose,then transient varibles are helpful.
