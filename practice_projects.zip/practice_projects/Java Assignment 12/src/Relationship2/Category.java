package Relationship2;

public enum Category {
    TOYS,BOOKS,BABY,GROCERY,GAMES
}
