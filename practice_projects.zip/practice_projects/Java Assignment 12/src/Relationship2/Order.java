package Relationship2;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public class Order {
    int id;
    LocalDate orderedDate;
    String DeliveryDate;
    String status;

    Customer customer;
    List<Product> productList;

    public Order(int id, LocalDate orderedDate, String deliveryDate,    String status,
    Customer customer, List<Product> productList) {
        this.id = id;
        this.orderedDate = orderedDate;
        DeliveryDate = deliveryDate;
        this.status = status;

        this.customer = customer;
        this.productList = productList;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", status='" + status + '\'' +
                ", orderedDate=" + orderedDate +
                ", DeliveryDate=" + DeliveryDate +
                ", customer=" + customer +
                ", productList=" + productList +
                '}';
    }
public List<Customer> customers(){
        return List.of(new Customer(1, "Stefan Walker", 1),
                new Customer(2, "Daija Von", 1),
                new Customer(3, "Ariane Rodriguez", 1),
                new Customer(4, "Marques Nikolaus", 2),
                new Customer (5, "Rachelle Greenfelder", 0),
                new Customer(6, "Larissa White", 2),
                new Customer(7, "Fae Heidenreich", 1),
                new Customer(8, "Dino Will", 2),
                new Customer (9, "Eloy Stroman", 1),
                new Customer(10, "Brisa O''Connell", 1));
}
public List<Product> products(){
        return List.of(new Product(1, "omnis quod consequatur", Category.GAMES, 184.83),
                new Product (2, "vel libero suscipit",Category.TOYS, 12.66),
                new Product (3, "non nemo iure", Category.GROCERY, 498.02),
                new Product(4, "voluptatem voluptas aspernatur", Category.TOYS, 536.80),
                new Product(5, "animi cum rem", Category.GAMES, 458.20),
                new Product(6, "dolorem porro debitis", Category.TOYS, 146.52),
                new Product(7, "aspernatur rerum qui", Category.BOOKS, 656.42),
                new Product(8, "deleniti earum et", Category.BABY, 41.46),
                new Product(9, "voluptas ut quidem",  Category.BOOKS, 697.57),
                new Product(10, "eos sed debitis", Category.BABY, 366.90),
                new Product(11, "laudantium sit nihil", Category.TOYS, 95.50),
                new Product(12, "ut perferendis corporis", Category.GROCERY, 302.19),
                new Product(13, "sint voluptatem ut", Category.TOYS, 295.37),
                new Product(14, "quos sunt ipsam", Category.GROCERY, 534.64),
                new Product(15, "qui illo error", Category.BABY, 623.58),
                new Product(16, "aut ex ducimus",  Category.BOOKS, 551.39),
                new Product(17, "accusamus repellendus minus",  Category.BOOKS, 240.58),
                new Product(18, "aut accusamus quia", Category.BABY, 881.38),
                new Product(19, "doloremque incidunt sed",  Category.GAMES, 988.49),
                new Product(20, "libero omnis velit", Category.BABY, 177.61),
                new Product(21, "consectetur cupiditate sunt", Category.TOYS, 95.46),
                new Product(22, "itaque ea qui", Category.BABY, 677.78),
                new Product(23, "non et nulla", Category.GROCERY, 70.49),
                new Product(24, "veniam consequatur et",  Category.BOOKS, 893.44),
                new Product(25, "magnam adipisci voluptat", Category.GROCERY, 366.13),
                new Product(26, "reiciendis consequuntur placeat", Category.TOYS, 359.27),
                new Product(27, "dolores ipsum sit", Category.TOYS, 786.99),
                new Product(28, "ut hic tempore", Category.TOYS, 316.09),
                new Product(29, "quas quis deserunt", Category.TOYS, 772.78),
                new Product(30, "excepturi nesciunt accusantium", Category.TOYS, 911.46));
}
/*public List<Order> orders(){
        return List.of(new Order(1, LocalDate.of(2021,02,28), "2021-03-08", "NEW", customers().get(4),productList.get(0)),
    *//*(2, '2021-02-28', '2021-03-05', "NEW", customers().get(2)),
   (3, '2021-04-10', '2021-04-18', "DELIVERED", customers().get(4));
    (4, '2021-03-22', '2021-03-27', "PENDING", customers().get(2));
    (5, '2021-03-04', '2021-03-12', "NEW", customers().get(0));
     (6, '2021-03-30', '2021-04-07', "DELIVERED", customers().get(8));
   (7, '2021-03-05', '2021-03-09', "PENDING", customers().get(7));
 (8, '2021-03-27', '2021-04-05', "NEW", customers().get(3));
 (9, '2021-04-14', '2021-04-18', "NEW", customers().get(9));
    (10, '2021-03-10', '2021-03-19',"NEW", customers().get(7));
     (11, '2021-04-01', '2021-04-04', "DELIVERED", customers().get(0));
     (12, '2021-02-24', '2021-02-28', "PENDING", customers().get(4));
     (13, '2021-03-15', '2021-03-21',"NEW", customers().get(4));
     (14, '2021-03-30', '2021-04-07', "PENDING", customers().get(4));
    (15, '2021-03-13', '2021-03-14', "DELIVERED", customers().get(4));*//*);
}*/
    public static void main(String[] args) {

    }
}
