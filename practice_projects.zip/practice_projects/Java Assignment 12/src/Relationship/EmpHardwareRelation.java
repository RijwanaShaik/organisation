package Relationship;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static java.time.temporal.ChronoUnit.DAYS;

public class EmpHardwareRelation {
    Employee employee;
HardwareDevices hardwareDevices;
    Status status;
    LocalDate assignedDate;
    LocalDate returnedDate;
    public EmpHardwareRelation(Employee employee, HardwareDevices hardwareDevices, Status status, LocalDate assignedDate, LocalDate returnedDate) {
        this.employee = employee;
        this.hardwareDevices = hardwareDevices;
        this.status = status;
        this.assignedDate = assignedDate;
        this.returnedDate = returnedDate;
    }

    public EmpHardwareRelation() {
    }

    @Override
    public String toString() {
        return "EmpHardwareRelation{" +
                "employee=" + employee +
                ", hardwareDevices=" + hardwareDevices +
                ", status='" + status + '\'' +
                ", assignedDate='" + assignedDate + '\'' +
                ", returnedDate='" + returnedDate + '\'' +
                '}';
    }

    public List<Organisation> organisationList(){
        return List.of(new Organisation(300,"ORG1"),new Organisation(3002,"ORG2"));
    }
    public List<Employee> employeeList() {
        return List.of(new Employee(1, "raj", organisationList().get(0)),

                new Employee(2, "rahul", organisationList().get(1)),
                new Employee(3, "anshu", organisationList().get(0)));
    }

    public List<HardwareDevices> deviceList1() {
        return List.of(new HardwareDevices("TH-DESK-001", Types.DESKTOP, organisationList().get(0)),
                new HardwareDevices("TH-KB-001", Types.KEYBOARD, organisationList().get(0)),
                new HardwareDevices("TH-MS-001", Types.MOUSE, organisationList().get(0)),
                new HardwareDevices("TH-CPU-001", Types.CPU, organisationList().get(0)),


                new HardwareDevices("TH-DESK-002", Types.DESKTOP, organisationList().get(1)),
                new HardwareDevices("TH-KB-002", Types.KEYBOARD, organisationList().get(1)),
                new HardwareDevices("TH-MS-002", Types.MOUSE, organisationList().get(1)),
                new HardwareDevices("TH-CPU-002", Types.CPU, organisationList().get(1)),


                new HardwareDevices("TH-DESK-003", Types.DESKTOP, organisationList().get(0)),
                new HardwareDevices("TH-KB-003", Types.KEYBOARD, organisationList().get(0)),
                new HardwareDevices("TH-MS-003", Types.MOUSE, organisationList().get(0)),
                new HardwareDevices("TH-CPU-003", Types.CPU, organisationList().get(0)),

                new HardwareDevices("TH-CPU-004", Types.CPU, organisationList().get(0)),

                new HardwareDevices("TH-Desk-004", Types.DESKTOP, organisationList().get(0)));

    }
    public List<EmpHardwareRelation> data(){
        return List.of(new EmpHardwareRelation(employeeList().get(0), deviceList1().get(0),Status.ASSIGNED , LocalDate.of(2022,11,20) , null),
                new EmpHardwareRelation(employeeList().get(0), deviceList1().get(1), Status.ASSIGNED, LocalDate.of(2022,11,20) , null),
                new EmpHardwareRelation(employeeList().get(0), deviceList1().get(2), Status.ASSIGNED, LocalDate.of(2022,11,20) , null),
                new EmpHardwareRelation(employeeList().get(0), deviceList1().get(3), Status.ASSIGNED, LocalDate.of(2022,11,20), null),

                new EmpHardwareRelation(employeeList().get(1),deviceList1().get(4), Status.RETURNED, LocalDate.of(2022,11,22) , LocalDate.of(2022,11,25)),
                new EmpHardwareRelation(employeeList().get(1), deviceList1().get(5), Status.ASSIGNED, LocalDate.of(2022,11,22) , null),
                new EmpHardwareRelation(employeeList().get(1), deviceList1().get(6), Status.ASSIGNED,  LocalDate.of(2022,11,22) , null),
                new EmpHardwareRelation(employeeList().get(1), deviceList1().get(7), Status.ASSIGNED,LocalDate.of(2022,11,22) , null),

                new EmpHardwareRelation(employeeList().get(2), deviceList1().get(8), Status.NOTASSIGNED, null, null),
                new EmpHardwareRelation(employeeList().get(2), deviceList1().get(9), Status.NOTASSIGNED, null, null),
                new EmpHardwareRelation(employeeList().get(2), deviceList1().get(10), Status.NOTASSIGNED, null, null),
                new EmpHardwareRelation(employeeList().get(2), deviceList1().get(11), Status.NOTASSIGNED, null, null),
                new EmpHardwareRelation(employeeList().get(2), deviceList1().get(12), Status.NOTASSIGNED, null, null),
                new EmpHardwareRelation(employeeList().get(1), deviceList1().get(13), Status.ASSIGNED, LocalDate.of(2022,11,27), null)

        );
    }

    public static void main(String[] args) {
        EmpHardwareRelation obj=new EmpHardwareRelation();
        List<EmpHardwareRelation> empHardwareRelationList=new ArrayList<>(obj.data());
        System.out.println(empHardwareRelationList);
        //3.Find a device and employee details who got assigned to a particular device. eg: find the device and assigned employee details of device code "TH-DESK-001"
        System.out.println("Device  eId eName");
        empHardwareRelationList.stream().filter(a -> a.hardwareDevices.id.equalsIgnoreCase("TH-DESK-001")).map(a -> a.hardwareDevices.name + " " + a.employee.id + " " + a.employee.name).forEach(System.out::println);
        //count of devices by name
        Map<Types, Long> countOfDevices= obj.deviceList1().stream().collect(Collectors.groupingBy(HardwareDevices::getName, Collectors.counting()));
        System.out.println(countOfDevices);
        //    1. An employee from ORG1 requires a new desktop. Find the requested device availability in this organization's inventory.
        //    Also, Print "DESKTOP shortage in inventory" only If the available desktops count <= 3. Here you should consider the devices which are not in use or not assigned to any employee currently

        long count= empHardwareRelationList.stream().map(a -> a.hardwareDevices.name.equals(Types.DESKTOP) && a.status.equals(Status.NOTASSIGNED)).collect(Collectors.toSet()).stream().count();
        System.out.println("desktop shortage "+count);
        if(count <=3){
            System.out.println("Desktop shortage");
        }


        //4. Find all devices assigned to an employee where the device assigned status is 'RETURNED' and the date difference between the device assigned & returned id < 4 days.
        Predicate<EmpHardwareRelation> p1=a->a.status.equals(Status.RETURNED);
        Predicate<EmpHardwareRelation> p2=a-> DAYS.between(a.assignedDate,a.returnedDate)<4;
       empHardwareRelationList.stream().filter(p1.and(p2)).map(a->a.hardwareDevices.name).forEach(System.out::println);
       //2. Find the counts of each device type that are not in use among all organizations in descending order
        Predicate<EmpHardwareRelation> p3=a->a.status.equals(Status.NOTASSIGNED);
       Map<String,Long> e= empHardwareRelationList.stream().filter(p3).collect(Collectors.groupingBy(p->p.employee.organisation.name+" "+p.hardwareDevices.name,Collectors.counting()));
        System.out.println(e);

    }
}
