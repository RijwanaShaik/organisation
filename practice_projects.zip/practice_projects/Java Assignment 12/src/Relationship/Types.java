package Relationship;

public enum Types {
    DESKTOP,KEYBOARD,MOUSE,CPU
}
