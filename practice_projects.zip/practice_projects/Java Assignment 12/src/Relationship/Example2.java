package Relationship;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Example2 {
}
class Organization{
    int id;
    String name;

    public Organization(int id, String name) {
        this.id = id;
        this.name = name;
           }

    @Override
    public String toString() {
        return "Organization{" +
                "id=" + id +
                ", name='" + name + '\'' +

                '}';
    }
}
class Employe{
    int id;
    String name;

   Organization organization;

    public Employe(int id, String name, Organization organization) {
        this.id = id;
        this.name = name;
        this.organization = organization;
    }

    @Override
    public String toString() {
        return "Employe{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", organization=" + organization +
                '}';
    }
}
class Devise{
    String id;
    String name;
Organization organization;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Devise(String id, String name, Organization organization) {
        this.id = id;
        this.name = name;
        this.organization = organization;
    }

    @Override
    public String toString() {
        return "Devise{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", organization=" + organization +
                '}';
    }
}

class EmpDevise{
    Employe employe;
    Devise devise;
    String status;
    Date assignedDate;
    Date returnedDate;

    public Devise getDevise() {
        return devise;
    }

    public void setDevise(Devise devise) {
        this.devise = devise;
    }

    public EmpDevise(Employe employe, Devise devise, String status,Date assignedDate, Date returnedDate) {
        this.employe = employe;
        this.devise = devise;
        this.status = status;
        this.assignedDate = assignedDate;
        this.returnedDate = returnedDate;
    }

    @Override
    public String toString() {
        return "EmpDevise{" +
                "employe=" + employe +
                ", devise=" + devise +
                ", status='" + status + '\'' +
                ", assignedDate='" + assignedDate + '\'' +
                ", returnedDate='" + returnedDate + '\'' +
                '}';
    }
}
class dataInsertion {
    public List<Organization> organizationList() {
        return List.of(new Organization(3001, "ORG1"), new Organization(3002, "ORG2"));

    }

    public List<Employe> employeList() {
        return List.of(new Employe(1, "raj", organizationList().get(0)),

                new Employe(2, "rahul", organizationList().get(1)),
                new Employe(3, "anshu", organizationList().get(0)));
    }

    public List<Devise> deviceList1() {
        return List.of(new Devise("TH-DESK-001", "Desktop", organizationList().get(0)),
                new Devise("TH-KB-001", "Keyboard", organizationList().get(0)),
                new Devise("TH-MS-001", "Mouse", organizationList().get(0)),
                new Devise("TH-CPU-001", "Cpu", organizationList().get(0)),


                new Devise("TH-DESK-002", "Desktop", organizationList().get(1)),
                new Devise("TH-KB-002", "Keyboard", organizationList().get(1)),
                new Devise("TH-MS-002", "Mouse", organizationList().get(1)),
                new Devise("TH-CPU-002", "Cpu", organizationList().get(1)),


                new Devise("TH-DESK-003", "Desktop", organizationList().get(0)),
                new Devise("TH-KB-003", "Keyboard", organizationList().get(0)),
                new Devise("TH-MS-003", "Mouse", organizationList().get(0)),
                new Devise("TH-CPU-003", "Cpu", organizationList().get(0)),

                new Devise("TH-CPU-004", "Cpu", organizationList().get(0)),

                new Devise("TH-Desk-004", "Desktop", organizationList().get(0)));

    }

    public static void main(String[] args) {
        dataInsertion obj = new dataInsertion();
        List<EmpDevise> empDeviseList = Arrays.asList(new EmpDevise(obj.employeList().get(0), obj.deviceList1().get(0), "Asssigned",new Date(2022-11-20) , null),
                new EmpDevise(obj.employeList().get(0), obj.deviceList1().get(1), "Asssigned", new Date(2022-11-20) , null),
                new EmpDevise(obj.employeList().get(0), obj.deviceList1().get(2), "Asssigned", new Date(2022-11-20) , null),
                new EmpDevise(obj.employeList().get(0), obj.deviceList1().get(3), "Asssigned", new Date(2022-11-20) , null),

                new EmpDevise(obj.employeList().get(1), obj.deviceList1().get(4), "Asssigned", new Date(2022-11-22) , new Date(2022-11-26)),
                new EmpDevise(obj.employeList().get(1), obj.deviceList1().get(5), "Asssigned", new Date(2022-11-22) , null),
                new EmpDevise(obj.employeList().get(1), obj.deviceList1().get(6), "Asssigned", new Date(2022-11-22) , null),
                new EmpDevise(obj.employeList().get(1), obj.deviceList1().get(7), "Asssigned", new Date(2022-11-22) , null),

                new EmpDevise(obj.employeList().get(2), obj.deviceList1().get(8), " Assigned", new Date(2022-11-22) , null),
                new EmpDevise(obj.employeList().get(2), obj.deviceList1().get(9), "Not Assigned", null, null),
                new EmpDevise(obj.employeList().get(2), obj.deviceList1().get(10), "Not Assigned", null, null),
                new EmpDevise(obj.employeList().get(2), obj.deviceList1().get(11), "Not Assigned", null, null),
                new EmpDevise(obj.employeList().get(1), obj.deviceList1().get(12), "Not Assigned", null, null),
                new EmpDevise(obj.employeList().get(1), obj.deviceList1().get(13), " Assigned", new Date(2022-11-27), null)

        );
        // System.out.println(empDeviseList);
        empDeviseList.stream().filter(a -> a.devise.id.equalsIgnoreCase("TH-DESK-001")).map(a -> a.devise.name + " " + a.employe.id + " " + a.employe.name).forEach(System.out::println);
        Map<String, Long> d = empDeviseList.stream().filter(empDevises -> empDevises.status.equalsIgnoreCase("Not Assigned")).collect(Collectors.groupingBy(a->a.employe.organization.name+" "+a.devise.name,
                Collectors.counting()));
          System.out.println(d);
       /* Set<Map.Entry<Devise, Long>> entrySet = d.entrySet();
        for (Map.Entry<Devise, Long> entry : entrySet) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }*/
        Map<String, Long> d1 = obj.deviceList1().stream().collect(Collectors.groupingBy(Devise::getName, Collectors.counting()));
        System.out.println(d1);
 //Predicate<EmpDevise> p1=e->e.status.equalsIgnoreCase("";

        Map<List<Devise>,List<EmpDevise>> deviseEmpDeviseMap = new HashMap<>();
        deviseEmpDeviseMap.put( obj.deviceList1(), empDeviseList);
        System.out.println("Count of not used Devices in all Organisations ");
        long cnt= empDeviseList.stream().filter(e ->e.status.equalsIgnoreCase("Not Assigned")&& e.employe.organization.name.equalsIgnoreCase("ORG1")).map(e -> e.devise.getName()).count();
        System.out.println(cnt);

    }
}