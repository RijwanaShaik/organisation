package Relationship;

public class Employee {
    int id;
    String name;
Organisation organisation;

    public Employee(int id, String name, Organisation organisation) {
        this.id = id;
        this.name = name;
        this.organisation = organisation;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", organisation=" + organisation +
                '}';
    }
}
