package Relationship;

public enum Status {
    ASSIGNED,RETURNED,NOTASSIGNED
}
