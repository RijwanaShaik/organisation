package Relationship;

public class HardwareDevices {
    String id;
    Types name;
   Organisation organisation;

    public Types getName() {
        return name;
    }

    public void setName(Types name) {
        this.name = name;
    }

    public HardwareDevices(String id, Types name, Organisation organisation) {
        this.id = id;
        this.name = name;
        this.organisation = organisation;
    }

    @Override
    public String toString() {
        return "HardwareDevices{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", organisation=" + organisation +
                '}';
    }
}
