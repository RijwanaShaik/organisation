package Relationship;


//    1. An employee from ORG1 requires a new desktop. Find the requested device availability in this organization's inventory. Also, Print "DESKTOP shortage in inventory" only If the available desktops count <= 3. Here you should consider the devices which are not in use or not assigned to any employee currently
//    2. Find the counts of each device type that are not in use among all organizations in descending order
//    3. Find a device and employee details who got assigned to a particular device. eg: find the device and assigned employee details of device code "TH-DESK-001"
//    4. Find all devices assigned to an employee where the device assigned status is 'RETURNED' and the date difference between the device assigned & returned id < 4 days.
public class Data {

}
