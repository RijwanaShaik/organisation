package Relationship;



public class Organisation {
    int oId;
    String oName;

    public Organisation(int oId, String oName) {
        this.oId = oId;
        this.oName = oName;

    }

    @Override
    public String toString() {
        return "Organisation{" +
                "oId=" + oId +
                ", oName='" + oName + '\'' +
                '}';
    }
}
