package Relationship;

import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class MainClass {
    public List<Organisation> organisationList() {
        return List.of(new Organisation(3002,"Wipro"),new Organisation(3003,"Tcs"));
    }
    public List<Employee> employeeList() {
        return List.of(new Employee(111,"Kunal"),new Employee(120,"Kunal"),new Employee(131,"Anshu"));
    }
    public List<Attendance> attendanceList1() {
        return List.of(new Attendance(1,"Present","20-10-2022"),
                new Attendance(1,"Absent", "21-10-2022"),
                new Attendance(1,"Present","22-10-2022"),
                new Attendance(1,"Present","22-10-2022"),
                new Attendance(1,"Absent","23-10-2022"),
                new Attendance(1,"Present","24-10-2022"),
                new Attendance(1,"Absent","25-10-2022"));
    }

    public List<Attendance> attendanceList2() {

        return List.of(new Attendance(2, "Absent", "20-10-2022"),
                new Attendance(2, "Absent", "21-10-2022"),
                new Attendance(2, "Absent", "22-10-2022"),
                new Attendance(2, "Absent", "22-10-2022"),
                new Attendance(2, "Absent", "23-10-2022"),
                new Attendance(2, "Absent", "24-10-2022"),
                new Attendance(2, "Absent", "25-10-2022"));
    }
    public List<Attendance> attendanceList3() {

        return List.of(new Attendance(2, "Present", "20-10-2022"),
                new Attendance(2, "Present", "21-10-2022"),
                new Attendance(2, "Present", "22-10-2022"),
                new Attendance(2, "Present", "22-10-2022"),
                new Attendance(2, "Present", "23-10-2022"),
                new Attendance(2, "Present", "24-10-2022"),
                new Attendance(2, "Absent", "25-10-2022"));
    }

    public List<Data> dataList(){
        List<Organisation> organisationList1=new ArrayList<>(organisationList());
        List<Employee> employeeList1=new ArrayList<>(employeeList());

        return List.of(new Data(organisationList1.get(0),employeeList1.get(0),attendanceList1()),
                new Data(organisationList1.get(1),employeeList1.get(1), attendanceList2()),
                new Data(organisationList1.get(1),employeeList1.get(2), attendanceList3()));
    }

    public static void main(String[] args) {
        MainClass obj=new MainClass();
        List<Data> orgEmp=new ArrayList<>(obj.dataList());
        orgEmp.stream().map(e->e.organisation.oName+" "+e.employee.eName).forEach(System.out::println);
//    3. Find all the employees who all are Absent on a particular date
        for(Data data: orgEmp){
            for (Attendance a : data.attendanceList) {
                if(a.status.equals("Absent") && a.date.equals("19-11-2022")){
                    System.out.println("Employee Id :"+data.employee.eId+" Employee name :"+data.employee.eName);
                }
            }
        }
       Predicate<Attendance> p1=e->e.date.equals("21-10-2022")&& e.status.equalsIgnoreCase("Absent" );
        orgEmp.stream().filter(o->(o.attendanceList.stream().filter(p1).count()>0)).map(e->e.employee.eName).forEach(p-> System.out.println("Employee absent on a particular date : "+p));


//    2. Find all the employees and count of Present and Absent days in last one week of data

        int presentDays=0;
        int absentDays=0;
        for(Data data: orgEmp) {
            for (Attendance attendance : data.attendanceList){
                if(attendance.status.equalsIgnoreCase("Present") ){
                    presentDays++;
                }
                else if(attendance.status.equalsIgnoreCase("Absent")){
                    absentDays++;
                }
            }
            System.out.println("Present days of :"+data.employee.eName+" are "+presentDays);
           presentDays=0;
            System.out.println("absent days of :"+data.employee.eName+" are "+absentDays);
            absentDays=0;

        }

        System.out.println("eName  p  ab");
        Predicate<Attendance> pCount = s->(s.status.equalsIgnoreCase("present"));
        Predicate<Attendance> aCount = s->(s.status.equalsIgnoreCase("absent"));
        orgEmp.stream().map(a->a.employee.eName+"  "+(a.attendanceList.stream().
                filter(pCount).count())+"  "+a.attendanceList.stream()
                .filter(aCount).count()).forEach(System.out::println);
//    4. Find all the employees whose Present attendance percentage is < 30%

       /* System.out.println("\nLess than 30% Percentage Employees ");
        int presentDays=0;
        Double percentage=null;
        for(Data data: orgEmp){
            for(Attendance a : data.attendanceList) {
                if (a.status.equalsIgnoreCase("Present")) {
                    presentDays++;
                }

            }

            int totalDays=7;
            percentage = (double) (presentDays * 100 / totalDays);
            if(percentage < 30 ) {
                System.out.println("Employee Id :" + data.employee.eId + " Employee name : " + data.employee.eName+" "+data.organisation.oName+" percentage: "+percentage);
            }
            presentDays = 0;


        }*/
        Predicate<Attendance> p2=e->e.status.equalsIgnoreCase("Present");
        orgEmp.stream().filter(s->(s.attendanceList.stream().filter(p2).count()<0.30*s.attendanceList.size())).map(e->e.employee.eName+" "+e.organisation.oName).forEach(System.out::println);
        //  5. Find all employees who belongs to multiple organisations
        orgEmp.stream().collect(Collectors.groupingBy(e -> e.employee.eName)).entrySet().stream().filter( s -> s.getValue().size() >1).forEach(System.out::println);
    }
}
