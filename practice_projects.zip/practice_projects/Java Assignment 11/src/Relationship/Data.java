package Relationship;

import java.util.*;

//    1. Find all the Organisations and their employees data using Streams methods
//    2. Find all the employees and count of Present and Absent days in last one week of data
//    3. Find all the employees who all are Absent on a particular date
//    4. Find all the employees whose Present attendance percentage is < 30%
//    5. Find all employees who belongs to multiple organisations
public class Data {

Organisation organisation;
Employee employee;
List<Attendance> attendanceList;

    public Data(Organisation organisation, Employee employee, List<Attendance> attendanceList) {
        this.organisation = organisation;
        this.employee = employee;
        this.attendanceList = attendanceList;
    }

    @Override
    public String toString() {
        return "Data{" +
                "organisation=" + organisation +
                ", employee=" + employee +
                ", attendanceList=" + attendanceList +
                '}';
    }
}

   /* List<String> ol= orgEmp.stream().map(e -> e.organisation.oName + " " + e.employee.eName).toList();
        System.out.println(ol);*/