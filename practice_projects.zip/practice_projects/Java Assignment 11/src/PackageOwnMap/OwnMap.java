package PackageOwnMap;

import java.util.*;

public class OwnMap {
    LinkedList<OwnMapClass> OwnMapList = new LinkedList<OwnMapClass>();

    public void put(String key,Integer value)
    {
        OwnMapList.add(new OwnMapClass(key,value));
    }

    public void remove(String key)
    {
        OwnMapList.remove();
    }

    public Integer get(String key)
    {
        Integer value = 0;
        for(int i=0; i<OwnMapList.size(); i++)
        {
            if(OwnMapList.get(i).key.equals(key))
            {
                value = OwnMapList.get(i).value;
                break;
            }
            else {
                value = -1;
            }
        }
        return value;
    }

    public Set<Map.Entry<String,Integer>> entrySet()
    {
        Map<String,Integer> hashMap = new HashMap<String,Integer>();
        for(int i=0; i<OwnMapList.size(); i++)
        {
            hashMap.put(OwnMapList.get(i).key, OwnMapList.get(i).value);
        }
        return hashMap.entrySet();
    }

    public Collection<Integer> values()
    {
        return OwnMapList.stream().map(entry -> entry.value).toList();
    }

    public void clear()
    {
        OwnMapList.clear();
    }

    @Override
    public String toString() {
        return "MapMethodsWithLinkedList{" +
                "customLinkedList=" + OwnMapList +
                '}';
    }

    public static void main(String[] args) {
        OwnMap map1 = new OwnMap();
        map1.put("kunal",40);
        map1.put("Ishrat",25);
        map1.put("Nikhila",50);
        System.out.println("Before using remove method the map contains: "+map1.OwnMapList);
        map1.remove("Nikhila");
        System.out.println("After using remove method the map contains: "+map1.OwnMapList);
        System.out.println(map1.get("Ishrat"));
        Set<Map.Entry<String,Integer>> entrySet = map1.entrySet();
        System.out.println("Using entrySet method: "+entrySet);
        System.out.println("Getting only values from map"+map1.values());
        map1.clear();
        System.out.println("After clearing the map: "+map1.OwnMapList);
    }
}
