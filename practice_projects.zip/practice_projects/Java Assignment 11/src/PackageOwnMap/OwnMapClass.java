package PackageOwnMap;

public class OwnMapClass {
    String key;
    Integer value;

    public OwnMapClass(String key, Integer value) {
        this.key=key;
        this.value=value;
    }

    @Override
    public String toString() {
        return "OwnMapClass{" +
                "key='" + key + '\'' +
                ", value=" + value +
                '}';
    }
}
