import java.util.Scanner;
public class BarkingDog {
 
 /* public static boolean shouldWakeUp(boolean barking, int hourOfDay) {
  
    if (barking) {
    
      if (hourOfDay < 0 || hourOfDay > 23) {
        return false;
      }
      else if (hourOfDay < 8 || hourOfDay >  22) {
        return true;
      }
      else  {
        return false;
      }
      else {
        return false;
      }
    }
  }*/
/*public static boolean shouldWakeUP ( boolean barking, int hourOfDay){     if ((hourOfDay =<8) && (barking == true)){     return true;
} else if ((hourOfDay >= 22) && (barking == true)){         return true; } else     return false; }*/
/* public static void shouldWakeUp(boolean barking,int hourOfDay){
 if (barking){
      if(hourOfDay=<8 && barking ==true;){
       System.out.println("true");
}
      if(hourOfDay>=22 && barking==true;){
       System.out.println("false");
}
 else System.out.println("false");
}*/

/* public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
         System.out.println("Enter values: ");
          boolean a=in.nextBoolean();
         System.out.println("Enter hour: ");
          int b=in.nextInt();
     shouldWakeUp(a,b);  
    }

}


 public static boolean shouldWakeUp(boolean barking, int hourOfDay) {
        boolean sleepingHours = (hourOfDay >= 0 && hourOfDay < 8) || hourOfDay == 23;

        return barking && sleepingHours;
    }
}*/

public class BrakingDog {
    public static void main(String[] args)
    {
        
       boolean response = shouldWakeUp(true, 1);
        System.out.println(response);
    }
    public static boolean shouldWakeUp(boolean barking, int hourOfDay)
    {
        if (hourOfDay >= 1 && hourOfDay <= 23)
        {
            if ((barking == true) && (hourOfDay < 8 || hourOfDay > 22))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

