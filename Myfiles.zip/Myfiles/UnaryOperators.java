// Java Program to Illustrate Unary  Operator
 

/*public class UnaryOperators {
 
    public static void main(String[] args)
    {
    
        int n1 = 30;
 
        System.out.println("Number = " + n1);
 
        n1 = -n1;
        System.out.println("Result = " + n1);
    }
}*/

/*public class UnaryOperators {
 
    public static void main(String[] args)
    {   boolean cond = true;
        int a = 11, b = 10;
        System.out.println("Cond is: " + cond);
        System.out.println("Var1 = " + a);
        System.out.println("Var2 = " + b);
 
        System.out.println("Now cond is: " + !cond);
        System.out.println("!(a < b) = " + !(a < b));
        System.out.println("!(a > b) = " + !(a > b));
    }
}*/


/*public class UnaryOperators {
 
    public static void main(String[] args)
    {   
        int a = 11, b = 10;
        
        System.out.println(++a);
        System.out.println(--b);
    }
}*/

public class UnaryOperators {
 
    public static void main(String[] args)
    {   
        int a = 11, b = 10;
        
        System.out.println(~a);
        System.out.println(~b);
    }
}
