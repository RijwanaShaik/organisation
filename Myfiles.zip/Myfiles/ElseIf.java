class ElseIf{
 public static void main(String []a){
  int i=20;
 if (i==10 || i<15){
if (i<12){
System.out.println("i value is less than 12");

}
if (i<15){
System.out.println("i value is less than 15");
}
}
else if(i>16) { System.out.println("i value is greater than 50");
}
}
}
