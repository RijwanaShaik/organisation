/*public class RelationalOperators {
 
    public static void main(String[] args)
    {   
        int a = 11, b = 10;
        
        System.out.println(a==b);
      
    }
}*/

/*public class RelationalOperators {
 
    public static void main(String[] args)
    {   
        int a = 11, b = 10;
        
        System.out.println(a>=b);
      
    }
}*/

/*public class RelationalOperators {
 
    public static void main(String[] args)
    {   
        int a = 11, b = 10;
        
        System.out.println(a<=b);
      
    }
}*/

/*public class RelationalOperators {
 
    public static void main(String[] args)
    {   
        int a = 11, b = 10;
        
        System.out.println(a!=b);
      
    }
}*/


/*public class RelationalOperators {
 
    public static void main(String[] args)
    {   
        int a = 11, b = 10;
        
        System.out.println(a>b);
      
    }
}*/
public class RelationalOperators {
 
    public static void main(String[] args)
    {   
        int a = 11, b = 10;
        
        System.out.println(a<b);
      
    }
}
