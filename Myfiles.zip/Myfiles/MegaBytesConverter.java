public class MegaBytesConverter{
public static void PrintMegaBytesAndKiloBytes(int kiloBytes){
 int megabytes;
if(kilobytes<0)
System.out.println("Invalid value");
else
int 
System.out.prinln(kiloBytes +" KB = "+megabytes+ + " MB "+ " and "+ " KB");

}
}























/*public class MegaByte {
    static void printMegaBytesAndKiloBytes(int kiloBytes){
        int megabytes;
        if (kiloBytes < 0){
            System.out.println("invalid values");

        }
        else {
            int mb=kiloBytes /1024;
            int KB=kiloBytes % 1024 ;
            System.out.println(kiloBytes+ " KB ="+mb+" MB "+kiloBytes +" and "+KB +"KB");

        }

    }
    public static void main(String args[]){
        printMegaBytesAndKiloBytes(2500);
    }
}*/
