/*public class ExampleLoop {
    public static void main(String[] args) {
    char name='z';
    switch(name){
     case 'a':
     case 'i':
     case 'e':
     case 'o':
     case 'u':
   System.out.println("This letter is vowel");
     break;
default:
   System.out.println("This letter is consonant");  
}
    }
}*/



/*import java.io.*;
 public class ExampleLoop{
   String studentName;
   String grade;
   static int z=3;
public static void main(String [] a){

int x =10;
 ExampleLoop obj=new ExampleLoop();
obj.studentName="Sam";
obj.grade="A";

System.out.println(x);
System.out.println("Name: "+ obj.studentName);
System.out.println("Grade: "+ obj.grade);
System.out.println(z);

}

}*/
/*public class ExampleLoop{
   String studentName;
   String grade;
   static int z=3;
public static void main(String [] a){
ExampleLoop.z=4;
int x =10;
 ExampleLoop obj1=new ExampleLoop();
 ExampleLoop obj2=new ExampleLoop();
obj1.studentName="Sam";
obj1.grade="A";
obj2.studentName="Ram";
obj2.grade="B";
System.out.println(x);
System.out.println(obj1.studentName +" "+ obj1.grade+" "+ z);
System.out.println(obj1.studentName+" "+ obj2.grade+" "+z);


}

}*/
/*public class ExampleLoop{
public static void main(String args[]){
 int i=0;
for(i=1;i<=4;i++){
System.out.println(i);
}
System.out.println(i);
}
}*/




