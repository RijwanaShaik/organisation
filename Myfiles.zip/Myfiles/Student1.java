class Student1{
String name;
int id;
String contactNumber;
String location;
String grade;
String dateOfBirth;
static int count=0;

static int counter(){
count++;
return count;
}
/*static void details(String name,int id,String contactNumber,String
location,String grade,String dateOfBirth){
System.out.println("Name = "+ name +"\n Id = "+id + " \n contactNumber = "+ contactNumber + " \n Grade =" + grade + " \n DateOfBirth=" + dateOfBirth);
}*/
public Student1(String name,int id,String contactNumber,String
location,String grade,String dateOfBirth){
this.count=counter();
this.name=name;
this.id=id;
this.contactNumber=contactNumber;
this.location=location;
this.grade=grade;
this.dateOfBirth=dateOfBirth;
}
void getStudentdetails(){
System.out.print(this.count);
System.out.print(this.name);
System.out.print(this.id);
System.out.print(this.contactNumber);
System.out.print(this.location);
System.out.print(this.grade);
System.out.print(this.dateOfBirth);
}
}
public class Studentdemo{
public static void main(String [] args){
Student1 s1=new Student1("ram",1,"9963252562","Nandyal","first class","08-03-2020");
Student1 s2=new Student1("raju",2,"6798034564","Nandyal","first class","18-03-2021");
Student1 s3=new Student1("swathi",3,"6798754694","Nandyal","first class","05-06-2020");
Student1 s4=new Student1("shailaja",4,"8765432568","Nandyal","first class","07-11-2020");
Student1 s5=new Student1("sandeep",5,"9987654256","Nandyal","first class","18-10-2020");
Student1 s6=new Student1("sohal",6,"9876543234","Nandyal","first class","24-03-2020");
Student1 s7=new Student1("sujatha",7,"8876543547","Nandyal","first class","17-03-2020");
Student1 s8=new Student1("kunal",8,"9878870568","Nandyal","first class","22-09-2020");
Student1 s9=new Student1("sowmya",9,"8765498588","Nandyal","first class","30-04-2020");
Student1 s10=new Student1("prashanth",10,"8765904356","Nandyal","first class","19-06-2020");
s1.getStudentdetails();

s2.getStudentdetails();

s3.getStudentdetails();

s4.getStudentdetails();

s5.getStudentdetails();

s6.getStudentdetails();

s7.getStudentdetails();

s8.getStudentdetails();

s9.getStudentdetails();

s10.getStudentdetails();

}
}
