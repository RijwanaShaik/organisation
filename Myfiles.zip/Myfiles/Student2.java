public class Student2{
String name;
int id;
String contactNumber;
String location;
String grade;
String dateOfBirth;
static int count=0;

static int counter(){
count++;
return count;
}
static void details(String name,int id,String contactNumber,String
location,String grade,String dateOfBirth){
System.out.println("Name = "+ name +"\n Id = "+id + " \n contactNumber = "+ contactNumber + " \n Grade =" + grade + " \n DateOfBirth=" + dateOfBirth+counter());
}


//public class Studentdemo{
public static void main(String [] args){
Student2 s1=new Student2();
Student2 s2=new Student2();
Student2 s3=new Student2();
Student2 s4=new Student2();
Student2 s5=new Student2();
Student2 s6=new Student2();
Student2 s7=new Student2();
Student2 s8=new Student2();
Student2 s9=new Student2();
Student2 s10=new Student2();
s1.details("ram",1,"9963252562","Nandyal","first class","08-03-2020");

s2.details("raju",2,"6798034564","Nandyal","first class","18-03-2021");

s3.details("swathi",3,"6798754694","Nandyal","first class","05-06-2020");

s4.details("shailaja",4,"8765432568","Nandyal","first class","07-11-2020");

s5.details("sandeep",5,"9987654256","Nandyal","first class","18-10-2020");

s6.details("sohal",6,"9876543234","Nandyal","first class","24-03-2020");

s7.details("sujatha",7,"8876543547","Nandyal","first class","17-03-2020");

s8.details("kunal",8,"9878870568","Nandyal","first class","22-09-2020");

s9.details("sowmya",9,"8765498588","Nandyal","first class","30-04-2020");

s10.details("prashanth",10,"8765904356","Nandyal","first class","19-06-2020");

}
}
