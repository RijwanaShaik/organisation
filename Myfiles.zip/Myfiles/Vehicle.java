/*public  abstract class Vehicle{

  abstract void start();

static void Wheels(int num){
System.out.println("this vehicle contains "+num+" Wheels");
}

}

 class Car extends Vehicle{
public  void start(){
System.out.println("start with key");}

}

class Benz extends Vehicle{

public void start(){
System.out.println("start with button");
}

public static void main(String [] args){
Vehicle obj1=new Car();
obj1.start();
Benz obj=new Benz();
obj.start();

Vehicle.Wheels(4);
}
}*/

public interface Animal{
public void eat();
public void travel();

}
class Mammal implements Animal{
public void eat(){
System.out.println("Mammal eats");
}
public void travel(){
System.out.println("Mammal travels");
}
public int noOfLegs(){
return 0;
}
public static void main(String args[]){
Mammal m=new Mammal();
m.eat();
m.travel();
}
}

