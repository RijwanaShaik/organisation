import java.util.Scanner;
public class StudentGrade{
  public static void main(String [] args){
    int i;
    String grade;
   Scanner sc =new Scanner(System.in);
      i=sc.nextInt();

switch (i){
  case 1:
    grade="c";
   if(i>=40 && i<=50)

    break;
  case 2:
 grade="B";
    if(i>=50 && i<=75)

    break;
  case 3:
 grade="A";

   if(i>=75 && i<=90)

    break;
  case 4:
    grade="A+";
    if(i>=90 && i<=100)

    break;

   default:
    grade="Disqulified";

    
 } 
System.out.println("grade"+" ");
}
}
