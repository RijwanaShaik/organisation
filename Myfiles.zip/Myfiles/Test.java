/*class Test{
int a;
String b;
public static void main(String args []){
Test y=new Test();
System.out.println(y);

}
}*/

/*thrymrthrymr123@thrymrthrymr123-H310M-H:~$ java Test.java
Test@569cfc36
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ javac Test.java
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ java Test
Test@7ad041f3
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ javac Test.java
Test.java:6: error: cannot find symbol
System.out.println(y.hashcode());
                    ^
  symbol:   method hashcode()
  location: variable y of type Test
1 error
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ javac Test.java
Test.java:6: error: int cannot be dereferenced
System.out.println(y.a.hashCode());
                      ^
1 error
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ */


//Java object to toString()
/*class Test{

public static void main(String [] a){
// toString() with object
Object obj1=new Object();
System.out.println(obj1.toString());
}
}

thrymrthrymr123@thrymrthrymr123-H310M-H:~$ javac Test.java
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ java Test
java.lang.Object@7ad041f3*/


//Java object to toString() example 1
/*class Test{

public static void main(String [] a){
// toString() with object
Object obj1=new Object();
System.out.println(obj1.toString());
Object obj2=new Object();
System.out.println(obj2.toString());
Object obj3=new Object();
System.out.println(obj3.toString());
}
}

thrymrthrymr123@thrymrthrymr123-H310M-H:~$ javac Test.java
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ java Test
java.lang.Object@7ad041f3
java.lang.Object@251a69d7
java.lang.Object@7344699f*/

// java object hashCode()

/*class Test{

public static void main(String [] a){
// toString() with object
Object obj1=new Object();
System.out.println(obj1.hashCode());
Object obj2=new Object();
System.out.println(obj2.hashCode());
Object obj3=new Object();
System.out.println(obj3.hashCode());
}
}
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ javac Test.java
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ java Test
2060468723
622488023
1933863327*/

//Hashcode value for equals object

/*class Test{
public static void main(String [] a){
Object obj1=new Object();
Object obj2=obj1;

System.out.println(obj1.equals(obj2));
System.out.println(obj1.hashCode());
System.out.println(obj2.hashCode());
}
}
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ javac Test.java
thrymrthrymr123@thrymrthrymr123-H310M-H:~$ java Test
true
2060468723
2060468723*/

