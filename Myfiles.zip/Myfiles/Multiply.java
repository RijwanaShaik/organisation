class Multiply{
public static void main(String [] args){
float f=7.986f;
float b=6.453f;
float m=f*b;
System.out.println(m);
}
}
