//data hiding using the private specifier
class Person{
private int age;
protected String details;
public int getAge(){
return age;}
public void setAge(int age){
if(age>20){
this.age=age;}
}
public static void main(String [] args){
Person p=new Person();
p.setAge(20);
System.out.println(p.getAge());
}
}
