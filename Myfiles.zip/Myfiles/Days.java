/*import java.util.Scanner;
public class Days{
static void PrintDayOfTheWeek(int day){
switch(day){
case 0:
System.out.println("Sunday");
break;
case 1 :
System.out.println("Monday");
break;
case 2 :
System.out.println("Tuesday");
break;
case 3 :
System.out.println("Wednesday");
break;
case 4 :
System.out.println("Thursday");
break;
case 5 :
System.out.println("Friday");
break;
case 6:
System.out.println("Staurday");
break;
default:
System.out.println("Invalid day");
}
}
 public static void main(String [] args){
   Scanner s=new Scanner(System.in);
      int a=s.nextInt();
    PrintDayOfTheWeek(a);

}
}*/
/*import java.util.Scanner;
public class Days{
static void PrintDayOfTheWeek(int day){

if(day==0)
System.out.println("Sunday");

else if(day==1)
System.out.println("Monday");

else if(day==2)
System.out.println("Tuesday");

else if(day==3)
System.out.println("Wednesday");

else if(day==4)
System.out.println("Thursday");

else if(day==5)
System.out.println("Friday");

else if(day==6)
System.out.println("Staurday");

else
System.out.println("Invaild day");

}

 public static void main(String [] args){
   Scanner s=new Scanner(System.in);
      int a=s.nextInt();
    PrintDayOfTheWeek(a);

}
}*/
/*import java.util.Scanner;
public class Days{
static void PrintNumberInWord(int number){
switch(number){
case 0:
System.out.println("ZERO");
break;
case 1 :
System.out.println("ONE");
break;
case 2 :
System.out.println("TWO");
break;
case 3 :
System.out.println("THREE");
break;
case 4 :
System.out.println("FOUR");
break;
case 5 :
System.out.println("FIVE");
break;
case 6:
System.out.println("SIX");
break;
case 7:
System.out.println("SEVEN");
break;
case 8:
System.out.println("EIGHT");
break;
case 9:
System.out.println("NINE");
break;
default:
System.out.println("OTHER");
}
}
 public static void main(String [] args){
   Scanner s=new Scanner(System.in);
      int a=s.nextInt();
    PrintNumberInWord(a);
}
}*/
import java.util.Scanner;
public class Days{
static void PrintDayOfTheWeek(int number){

if(number==0)
System.out.println("ZERO");

else if(number==1)
System.out.println("ONE");

else if(number==2)
System.out.println("TWO");

else if(number==3)
System.out.println("THREE");

else if(number==4)
System.out.println("FOUR");

else if(number==5)
System.out.println("FIVE");

else if(number==6)
System.out.println("SIX");

else if(number==7)
System.out.println("SEVEN");

else if(number==8)
System.out.println("EIGHT");

else if(number==9)
System.out.println("NINE");

else
System.out.println("OTHER");

}

 public static void main(String [] args){
   Scanner s=new Scanner(System.in);
      int a=s.nextInt();
    PrintDayOfTheWeek(a);

}
}
