import java.util.Scanner;
public class Age{
public static void main(String [] args){
Scanner s=new Scanner(System.in);
int age=s.nextInt();
String result=(age>70)? "OLD" :(age<30) ? "Young" :(age>=30 && age<=70) ? "Middle Age" :"Invalid age";
System.out.println(result);
}
}
