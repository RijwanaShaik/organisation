public class StudentDetails 
{
        String name;
        int id;
        long ContactNumber;
        String Location;
        char Grade;
        String DateOfBirth;
        int Count=0;
        
        public static void mani(String args[])
	{
	StudentDetails Obj1=new StudentDetails();
	count=count+1:
	StudentDetails Obj2=new StudentDetails();
	count=count+1:
	StudentDetails Obj3=new StudentDetails();
	count=count+1:
	StudentDetails Obj4=new StudentDetails();
	count=count+1:
	StudentDetails Obj5=new StudentDetails();
	count=count+1:
	StudentDetails Obj6=new StudentDetails();
	count=count+1:
	StudentDetails Obj7=new StudentDetails();
	count=count+1:
	StudentDetails Obj8=new StudentDetails();
	count=count+1:
	StudentDetails Obj9=new StudentDetails();
	count=count+1:
	StudentDetails Obj10=new StudentDetails();
	count=count+1:
	
	
	Obj1.name="Student1";
	Obj2.name="Student2";
	Obj3.name="Student3";
	Obj4.name="Student4";
	Obj5.name="Student5";
	Obj6.name="Student6";
	Obj7.name="Student7";
	Obj8.name="Student8";
	Obj9.name="Student9";
	Obj10.name="Student10";
		
	System.out.println("name: "+Obj1.name+"");
	System.out.println("name: "+Obj2.name+"");
	System.out.println("name: "+Obj3.name+"");
	System.out.println("name: "+Obj4.name+"");
	System.out.println("name: "+Obj5.name+"");
	System.out.println("name: "+Obj6.name+"");
	System.out.println("name: "+Obj7.name+"");
	System.out.println("name: "+Obj8.name+"");
	System.out.println("name: "+Obj9.name+"");
	System.out.println("name: "+Obj10.name+"");
	}
}



	
