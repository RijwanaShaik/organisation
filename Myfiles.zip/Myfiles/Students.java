public class Students{
String name;
int id;
String contactNumber;
String location;
String grade;
String dateOfBirth;
static int count=0;
static void counter(){
System.out.println("Count= "+count);
count++;

}
public static void main(String [] args){
Students s1=new Students();
s1.name="ram";
s1.id=1;
s1.contactNumber="9963252562";
s1.location="Nandyal";
s1.grade="first class";
s1.dateOfBirth="08-03-2020";

counter();
System.out.println("Name = "+ s1.name +"\n Id = "+s1.id + " \n contactNumber = "+ s1.contactNumber + " \n Grade =" + s1.grade + " \n DateOfBirth=" + s1.dateOfBirth);

Student s2=new Student();
s2.name="raju";
s2.id = 2 ;
s2.contactNumber ="6798754694";
s2.grade ="first class"; 
s2.dateOfBirth="18-03-2021";
counter();
System.out.println("Name = "+ s2.name +"\n Id = "+s2.id + " \n contactNumber = "+ s2.contactNumber + " \n Grade =" + s2.grade + " \n DateOfBirth=" + s2.dateOfBirth);

Student s3=new Student();
s3.name="swathi";
s3.id = 3;
s3.contactNumber ="6798754694";
s3.grade ="first class"; 
s3.dateOfBirth="05-06-2020";

counter();
System.out.println("Name = "+ s3.name +"\n Id = "+s3.id + " \n contactNumber = "+ s3.contactNumber + " \n Grade =" + s3.grade + " \n DateOfBirth=" + s3.dateOfBirth);

Student s4=new Student();
s4.name="shailaja";
s4.id = 4  ;
s4.contactNumber ="8765432568";
s4.grade ="first class"; 
s4.dateOfBirth="07-11-2020";

counter();
System.out.println("Name = "+ s4.name +"\n Id = "+s4.id + " \n contactNumber = "+ s4.contactNumber + " \n Grade =" + s4.grade + " \n DateOfBirth=" + s4.dateOfBirth);

Student s5=new Student();
s5.name="sandeep";
s5.id = 5;
s5.contactNumber ="9987654256";
s5.grade ="first class"; 
s5.dateOfBirth="18-10-2020";

counter();
System.out.println("Name = "+ s5.name +"\n Id = "+s5.id + " \n contactNumber = "+ s5.contactNumber + " \n Grade =" + s5.grade + " \n DateOfBirth=" + s5.dateOfBirth);

Student s6=new Student();
s6.name="sohal";
s6.id = 6  ;
s6.contactNumber ="9876543234  ";
s6.grade ="first class"; 
s6.dateOfBirth="24-03-2020";

counter();
System.out.println("Name = "+ s6.name +"\n Id = "+s6.id + " \n contactNumber = "+ s6.contactNumber + " \n Grade =" + s6.grade + " \n DateOfBirth=" + s6.dateOfBirth);


Student s7=new Student();
s7.name="sujatha";
s7.id =7;
s7.contactNumber ="8876543547";
s7.grade ="first class"; 
s7.dateOfBirth="17-03-2020";

counter();
System.out.println("Name = "+ s7.name +"\n Id = "+s7.id + " \n contactNumber = "+ s7.contactNumber + " \n Grade =" + s7.grade + " \n DateOfBirth=" + s7.dateOfBirth);

Student s8=new Student();
s8.name="kunal";
s8.id = 8;
s8.contactNumber ="9878870568";
s8.grade ="first class"; 
s8.dateOfBirth="22-09-2020";

counter();
System.out.println("Name = "+ s8.name +"\n Id = "+s8.id + " \n contactNumber = "+ s8.contactNumber + " \n Grade =" + s8.grade + " \n DateOfBirth=" + s8.dateOfBirth);

Student s9=new Student();
s9.name="sowmya";
s9.id =9;
s9.contactNumber ="8765498588";
s9.grade ="first class"; 
s9.dateOfBirth="30-04-2020";

counter();
System.out.println("Name = "+ s9.name +"\n Id = "+s9.id + " \n contactNumber = "+ s9.contactNumber + " \n Grade =" + s9.grade + " \n DateOfBirth=" + s9.dateOfBirth);

Student s10=new Student();
s10.name=" prashanth";
s10.id =10;
s10.contactNumber ="8765904356";
s10.grade ="first class"; 
s10.dateOfBirth="19-06-2020";

counter();
System.out.println("Name = "+ s10.name +"\n Id = "+s10.id + " \n contactNumber = "+ s10.contactNumber + " \n Grade =" + s10.grade + " \n DateOfBirth=" + s10.dateOfBirth);

}
}
