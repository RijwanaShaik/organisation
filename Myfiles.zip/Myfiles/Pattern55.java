class Pattern55{
 	public static void main(String args[])
	{
	for(int i=5;i>=0;i--){
System.out.println(i+" "+i);
}
}
}
