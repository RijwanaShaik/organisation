public class AddNumbers{
public static void main(String [] args){
 int num1=2, num2=10;
sum=num1+num2;
System.out.println("sum of "+num1+ "and"+num2+ " is: "+sum);
}
}
