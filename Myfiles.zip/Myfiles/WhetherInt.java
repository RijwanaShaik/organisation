import java.util.Scanner;
class WhetherInt{
public static void main(String args[]){

System.out.println("Enter your number");
Scanner sc=new Scanner(System.in);
System.out.println(sc.nextInt());
}
}
