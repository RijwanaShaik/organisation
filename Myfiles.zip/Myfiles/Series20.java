class Series20 {
	public static void main(String args[]) {
		int a=1;
		do
{
	System.out.print(a+"");
	int b=a+3;
	System.out.print(b+"");
	a++;
}
 	while(a<=20);

}
}
