/*import java.util.Scanner;
public class LeapYear{
 public static void main(String args[]){
  int year ;
 Scanner s=new Scanner(System.in);
System.out.print("enter year: ");
year=s.nextInt();


if(year % 4==0)
 System.out.println("leap year");
if (year % 100==0)
 System.out.println("Not a leap year");
 if(year % 400 ==0)
System.out.println("leap year");

else System.out.println("Not a leap year");
}
}*/
import java.util.Scanner;

public class LeapYear {

  public static void main(String[] args) {

    // year to be checked
    int year; 
    boolean leap;
Scanner s=new Scanner(System.in);
System.out.print("enter year: ");
year=s.nextInt();
    // if the year is divided by 4
    if (year % 4 == 0) {

      // if the year is century
      if (year % 100 == 0) {

        // if year is divided by 400
        // then it is a leap year
        if (year % 400 == 0)
          leap = true;
        else
          leap = false;
      }
      
      // if the year is not century
      else
        leap = true;
    }
    
    else
      leap = false;

    if (leap)
      System.out.println(year + " is a leap year.");
    else
      System.out.println(year + " is not a leap year.");
  }
}


/*class FibonacciExample1{
public static void main(String args[])
{  
 int n1=1,n2=2,n3,i,count=5;  
  System.out.print(n1+" "+n2);
 for(i=2;i<count;++i)//loop starts from 2 because 0 and 1 are already printed  
 {  
  n3=n1+n2;  
  System.out.print(" "+n3);  
   n1=n2;  
  n2=n3; 
 }  

}}*/

