class NumbersSeries{
	public static void main(String args[])
		{
		int a=1;
		while(a<=30)
		{
			System.out.print(a);
		a++;
			System.out.print(a);
		a++;
			System.out.print(a+",");

		}
	}
}
