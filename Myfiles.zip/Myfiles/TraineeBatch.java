public class TraineeBatch{

int id;
String name;
int teamSize;
String teamLocation;
boolean isActive;
String status;
String description;

public static void main(String [] args){

TraineeBatch batch1=new TraineeBatch();
TraineeBatch batch2=new TraineeBatch();
TraineeBatch batch3=new TraineeBatch();

batch1.id=1;
batch1.name="Kunal";
batch1.teamLocation="Hyderabad";
batch1.teamSize=5;   
batch1.isActive=true;
batch1.status="Active";
batch1.description="Excellent";

System.out.println("Id: "+batch1.id+" "+"Name: "+batch1.name+" "+"teamSize: "+batch1.teamSize+" "+"isActive: "+batch1.isActive+" "+"Status: "+batch1.status+" "+"Description: "+batch1.description+" ");

batch2.id=4;
batch2.name="Koushik";
batch2.teamLocation="Nandyal";
batch2.teamSize=8;
batch2.isActive=false;
batch2.status="Inactive";
batch2.description="Bad";

System.out.println("Id: "+batch2.id+" "+"Name: "+batch2.name+" "+"teamSize: "+batch2.teamSize+" "+"isActive: "+batch2.isActive+" "+"Status: "+batch2.status+" "+"Description: "+batch2.description+" ");

batch3.id=5;
batch3.name="Sameera";
batch3.teamLocation="Nandyal";
batch3.teamSize=6;
batch3.isActive=true;
batch3.status="Active";
batch3.description="Good";

System.out.println("Id: "+batch3.id+" "+"Name: "+batch3.name+" "+"teamSize: "+batch3.teamSize+" "+"isActive: "+batch3.isActive+" "+"Status: "+batch3.status+" "+"Description: "+batch3.description+" ");

}
}
