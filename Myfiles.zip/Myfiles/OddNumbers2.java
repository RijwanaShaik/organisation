class OddNumbers {
    public static void main(String args[])
    {
  int i;
        while (i ==7)
              i++;
              continue;
           
            if (i % 2 == 0) 
continue;

           
            System.out.print(i + " ");
        }
    }
}
