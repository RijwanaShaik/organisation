public class Series {
    public static void main(String args[])
    {
      for(i = 0,i<15,i++);
 
        if (i <= 15)
            System.out.println(i);
 
       
  
    }
}
