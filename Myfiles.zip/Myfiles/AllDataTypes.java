class AllDataTypes{
public static void main(String args[]){
char a='G';
int i=8;
byte b=4;
short s=43;
double d=2.3456;
float f= 4.7658f;
long l=12121;
System.out.println("char: " + a);
System.out.println("integer: " + i);
System.out.println("byte: " + b);
System.out.println("short: " + s);
System.out.println("double: " + d);
System.out.println("float: " + f);
System.out.println("long: " + l);
}
}
