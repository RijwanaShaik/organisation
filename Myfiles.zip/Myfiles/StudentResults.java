
import java.util.Scanner;
public class StudentResults{
     public static void main(String[] args) {
         int percentage;

Scanner sc =new Scanner(System.in);
      percentage =sc.nextInt();
        if(percentage>=40 & percentage <50)
         {
             percentage=1;
         }
           else if(percentage>=50 & percentage <75)
         {
             percentage=2;



        }
               else if(percentage>=75 & percentage <90)
         {
             percentage=3;



        }
                 else if(percentage>=90 & percentage <100)
         {
             percentage=4;



        }
                switch(percentage){
                    case 1:
                        System.out.println("student result:" + "C");
                        break;
                    case 2:
                        System.out.println("student result:" + "B");
                        break;
                    case 3:
                        System.out.println("student result:" + "A");
                        break;
                    case 4:
                        System.out.println("student result:" + "A+");
                        break;
                    default:
                        System.out.println("student result:" + "disqualified");



               }
         }
     }
