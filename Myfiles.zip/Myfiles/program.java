public class Program
{
    public static void main(String[] args) {
        Scanner inp = new Scanner(System.in);
        int lng = inp.nextInt();
        int i = 1;
        while (i <= lng) {
            int ii = 0;
            while(ii < i) {
                System.out.print((ii+i)+" ");
                ii++;
            }
            System.out.print("\n");
            i++;
        }
    }
}
