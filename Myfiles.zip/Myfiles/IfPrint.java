// if program
class IfPrint{
 public static void main(String args[]){
 int i=10;
 if (i>12)
 System.out.println("10 is less than 12");
 else
 System.out.println("condition is wrong");

 String str="GeeksforGeeks";
 int z=4;
 if (z == 4;z<=10;z++);
   
   System.out.println(str);
 
  
   System.out.println("z = "+z);
 }
}
