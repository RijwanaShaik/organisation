import java.util.Scanner;
public class Shop {
    static  int coke =10;
    static  int juice =15;
    static  int lemonade =8;
    
         static void orderDrinks(int cost) {
             int remainingAmount;
             Scanner ab = new Scanner(System.in);
             System.out.print("Please Enter No.of Cokes : ");
             int noOfCokes = ab.nextInt();
             System.out.print("Please Enter No.of Juices : ");
             int noOfJuices = ab.nextInt();
             System.out.print("Please Enter No.of Lemonades : ");
             int noOfLemonades = ab.nextInt();
             coke = noOfCokes * 10;
             juice = noOfJuices * 15;
             lemonade = noOfLemonades * 8;
             int totalCost = coke+juice+lemonade;
             if(cost < totalCost) {
                 System.out.println("Insufficent amount for Order");
             }
             if(cost > totalCost) {
                 remainingAmount = cost - totalCost;
                 System.out.println("Remaining Amount is : "+remainingAmount);
             }
             if( cost == totalCost) {
                 System.out.println("TotalCost = " + totalCost);
             }
         }
    public static void main(String[] args) {
  Scanner sc = new Scanner(System.in);
    System.out.println("Please Enter the amount : ");
    int cost = sc.nextInt();
    orderDrinks(cost);
    }
}
