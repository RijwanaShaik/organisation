import java.io.*;
 
/*class AssignmentOperators {
    public static void main(String[] args)
    {
        int num1 = 10, num2 = 20;
 
        System.out.println("num1 = " + num1);
        System.out.println("num2 = " + num2);
        
        num1 += num2;
        System.out.println("num1 = " + num1);
    }
}*/


/*class AssignmentOperators {
    public static void main(String[] args)
    {
     int num1 = 10, num2 = 20;
 
        System.out.println("num1 = " + num1);
        System.out.println("num2 = " + num2);
 
        num1 -= num2;
        System.out.println("num1 = " + num1);
    }
}*/

/*class AssignmentOperators {
    public static void main(String[] args)
    {
 
       
        int num1 = 30, num2 = 50;
 
        System.out.println("num1 = " + num1);
        System.out.println("num2 = " + num2);
 
        num1 *= num2;
        System.out.println("num1 = " + num1);
    }
}*/

/*class AssignmentOperators {
    public static void main(String[] args)
    {
 
       
        int num1 = 20, num2 = 10;
 
        System.out.println("num1 = " + num1);
        System.out.println("num2 = " + num2);
 
       num1 /= num2;
        System.out.println("num1 = " + num1);
    }
}*/

class AssignmentOperators {
    public static void main(String[] args)
    {
 
       
        int num1 = 50, num2 = 30;
 
        System.out.println("num1 = " + num1);
        System.out.println("num2 = " + num2);
 
       num1 %= num2;
        System.out.println("num1 = " + num1);
    }
}


