public class PersonAges{
    public static void main(String args[])
    {
        int i;
 
        if (i <=0 && i<=5)
            System.out.println("No Ticket Booking");
        else
            System.out.println("i is greater than 15");
    }
}

