class GeeksForGeeks{
public static void main(String args[]){
//Boolean datatype is a datatype that has one of two possible values
boolean a=false;
boolean b=true;
//if condition holds
 if (b==true){
System.out.println("Hi Geek");
 if (a==false){
System.out.println("Hello Geek");
}
}
}
}
