class TernaryOperator{
	public static void main(String args[]){
	int age=75;
	String value=age>70?"OLD":(age<30)?"YOUNG":"MIDDLEAGE";
	System.out.println(value);
	}
	
}
