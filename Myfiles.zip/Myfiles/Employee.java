public class Employee{

String name;


  public static void main(String args[]){
     
     String array[]={"Kunal","Sohal","Shameem"};
     for (int i=0;i<array.length;i++){
        System.out.println(array[i]);
     }
     
  }
}
