import java.util.Arrays;
public class Trainee {
    int teamId;
    String teamName;

    Trainee(int teamId, String teamName) {
        this.teamId = teamId;
        this.teamName = teamName;
    }


    public String toString() {
        return "teamId=" + teamId + "teamName= " + teamName;
    }

     class Members {
        int membersId;
        String name;
        Attendance[] attendance;
        Assignment[] assignment;
        Trainee[] trainee;
        Members(int membersId,String name,Attendance[] attendance,Assignment[] assignment,Trainee[] trainee){
            this.membersId = membersId;
            this.name = name;
            this.attendance = attendance;
            this.assignment = assignment;
            this.trainee=trainee;
        }
        public String toString() {
            return "Id: "+membersId+" Name: "+name+" Attendace: "+Arrays.toString(attendance)+" Assignment: "+Arrays.toString(assignment)+"Trainee: "+Arrays.toString(trainee);
        }
        public static void main(String[] args) {
            Trainee[] trainee1=new Trainee[1];
            trainee1[0]=new Trainee(3002,"Java team1");
            Trainee[] trainee2=new Trainee[1];
            trainee2[0]=new Trainee(3003,"Java team2");
            Trainee[] trainee3=new Trainee[1];
            trainee3[0]=new Trainee(3004,"Java team3");
            Members[] members = new Members[3];
            Assignment[] assignment1 = new Assignment[2];
            assignment1[0] = new Assignment(1,"SQL TASK1");
            assignment1[1] = new Assignment(2,"SQL TASK2");
            Attendance[] attendances1 = new Attendance[2];
            attendances1[0] = new Attendance(1,"20-07-2022");
            attendances1[1] = new Attendance(2,"25-07-2022");
            members[0] = new Members(1,"Rahul",attendances1,assignment1,trainee1);
            Assignment[] assignment2 = new Assignment[2];
            assignment2[0] = new Assignment(3,"SQL Task3");
            assignment2[1] = new Assignment(4,"SQL Task4");
            Attendance[] attendances2 = new Attendance[2];
            attendances2[0] = new Attendance(1,"28-07-2022");
            attendances2[1] = new Attendance(2,"30-07-2022");
            members[1] = new Members(2,"Raju",attendances2,assignment2,trainee2);
            Assignment[] assignment3 = new Assignment[2];
            assignment3[0] = new Assignment(5,"JAVA Task5");
            assignment3[1] = new Assignment(6," JAVA Task6");
            Attendance[] attendances3 = new Attendance[2];
            attendances3[0] = new Attendance(1,"10-09-2022");
            attendances3[1] = new Attendance(2,"18-09-2022");
            members[2] = new Members(3,"Kunal",attendances3,assignment3,trainee3);
            for(int i=0; i<members.length; i++) {
                System.out.println(members[i]);
            }
        }
    }class Attendance{
        int aId;
        String date;
    Members members;
        Attendance(int aId,String date) {
            this.aId = aId;
            this.date = date;
        }
        public String toString() {
            return "Id: "+aId+" Date: "+date;
        }
    }
    class Assignment{
        int assigId;
        String assigName;
        Assignment(int assigId,String assigName){
            this.assigId = assigId;
            this.assigName = assigName;
        }
        public String toString() {
            return "Id: "+assigId+" Task_Name: "+assigName;
        }
    }
}

