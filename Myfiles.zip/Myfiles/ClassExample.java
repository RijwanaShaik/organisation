import java.util.Scanner;
public class ClassExample{
   /*int a=20;
   int b=10;
   int c;
public void add(){
 int c=a+b;
 System.out.println("Addition of numbers is : "+ c);
}
public void sub(){
 int c=a-b;
 System.out.println("Substraction of numbers is : "+c);
}
 public static void main(String [] args){
ClassExample obj=new ClassExample();
 obj.add();
 obj.sub();
}
}*/


/*public static void main(String args[]){
int a=15;
//Byte b=Byte.ValueOf(a);
Byte b=(byte)a;
System.out.println(b);
}*/

/*public static void main(String [] args){
Long l=233l;
byte b=(byte)l.byteValue();
System.out.println(b);
}*/

/*public static void main(String [] args){
Integer a=23;
byte b=(byte)a.byteValue();
System.out.println(b);
}*/

/*public static void main(String [] args){
Byte b=90;
int i=b;
System.out.println(i);}*/
/*public static void main(String [] args){
String str="100";
int str1=Integer.parseInt(str);
Integer str2=Integer.parseInt(str);
System.out.println(str1);
System.out.println(str2);
}*/
public static void main(String [] args){
Scanner s=new Scanner(System.in);
System.out.println("Enter a number: ");
int num=s.nextInt();
if(num<0){
num *= -1;}
System.out.println("Digits in a given number:");
while(num!=0){
int remainder=num%10;
System.out.print(remainder+" ");
num=num/10;}
}

}
