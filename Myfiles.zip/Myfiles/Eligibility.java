import java.util.Scanner;
public class Eligibility{
public static void main(String args[]){
int i;
 Scanner sc=new Scanner(System.in);
   i=sc.nextInt();
 if (i>0 && i<=5)
   System.out.println("No Ticket Booking");
  else if (i >5 && i<=10)
   System.out.println("Half Ticket Booking");

 else if (i >10 && i<=60)
   System.out.println("Full Ticket Booking");
 else if (i >=60)
   System.out.println("Senior Citizen Booking");

}
}
