
import java.util.Scanner;

public class AddNonintegers2{
public static void main(String [] args){
 double num1, num2,sum;
 Scanner input = new Scanner(System.in);
System.out.println("Enter First Number:  ");
   num1 = input.nextDouble();
System.out.println("Enter Second Number: ");
   num2 = input.nextDouble();
  input.close();

sum=num1+num2;
System.out.println("Sum of " +num1+ " and "+num2+ " is: "+sum);
}
}
