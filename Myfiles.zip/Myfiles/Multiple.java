public class Multiple
{
public static void main(String[] m)
  {
   int n=18;
   for(int i=1;i<=10;++i)
    {
     System.out.printf("%d * %d = %d \n",n,i,n*i);
    }
}
}
