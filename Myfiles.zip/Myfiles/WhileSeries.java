public class WhileSeries{
 public static void main(String[] args) {
 
 int i=1;
 while( i<=30){
 System.out.print(i);
 i++;
 System.out.print(i);
 i++;
System.out.print(i+",");
}
}
}


/*public class WhileSeries2{
 public static void main(String[] args) {
 int n=0;
 int i=1;
 while( i<=18){
 System.out.print(i);
 i++;
 n++;
 if(n==3){
 System.out.print(",");
 n=0;
}
}
}
}
