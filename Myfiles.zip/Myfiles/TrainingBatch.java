public class TrainingBatch{
int id;
String name;
int teamSize;
String teamLocation;
boolean isActive;
String status;
String description;

public  void id(){
System.out.println("id");
}

}
