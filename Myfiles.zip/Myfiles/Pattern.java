
public class Pattern {
    public static void main(String args[]){
        int n=5;
         for(int i=n;i<=0;i--)
         {
             for(int j=i;j>=n;j++){
                 System.out.println(" ");
		for(j=n;j<=n;j++){
			System.out.println(j);
		}
		
             }
         }
    }
}

