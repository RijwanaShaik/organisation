class EXCommnadLine1 {
    public static void main(String[] args) {
        try {




        for (String str:args) {
            int argument = Integer.parseInt(str);
            System.out.println("Argument in integer form :" + argument);
        }



       }catch (ArithmeticException e){
            System.out.println(e);
        }
        catch (NumberFormatException e){
            System.out.println(e);
        }
    }
}
