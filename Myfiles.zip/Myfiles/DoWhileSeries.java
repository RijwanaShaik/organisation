public class DoWhileSeries{

/*public static void main(String [] args){
 int n=1;
 int i=1;
do{
System.out.print(n+ " ");
      
if((i%2)==0){
 n=n-2;

}
else{
n=n+3;

}   i++;
}while(i<=20);
}
}*/

public static void main(String args[]) {
int i=1;
do
{
System.out.print(i+" ");
int n=i+3;
System.out.print(n+" ");
i++;}
while(i<=20);
}
}

