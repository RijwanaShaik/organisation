import java.util.Scanner;

class GetInputFromUser{
public static void main(String [] ar){
Scanner in=new Scanner(System.in);
String s=in.nextLine();
System.out.println("you entered string " + s);

int a=in.nextInt();
System.out.println("you entered integer " + a);

float f=in.nextFloat();
System.out.println("you entered float " + f);
}
}
