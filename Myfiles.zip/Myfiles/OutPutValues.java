

class OutPutValues{
public static void main(String args[]){
float value1=9.87f;
System.out.println(value1);
}
}
