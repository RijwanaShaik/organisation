public class OddNumbers {
  public static void main(String args[]){
      int i = 0;
      while (i <= 10) {
        if (i == 7){
            i++;
          continue;}

       if (i % 2 != 0){

        System.out.print(i + " ");}
                i++;
   }
 }
}


