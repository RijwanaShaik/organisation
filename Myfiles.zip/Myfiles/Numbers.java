public class Numbers{

  public static void main(String args[]){

   int i;
   for(i=0;i<=15;i++){
    if (i == 9)
       break;
    System.out.println("numbers from 1 to 15 are :" + i);
     }
  }
}
