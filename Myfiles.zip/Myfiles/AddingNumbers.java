// this program to sum the n numbers
public class AddingNumbers{

  public static void main(String args[]){
   int sum=0;
   for (int i=0;i<=1000; i++){
       sum=sum+i;
   }
    System.out.println("Sum: "+ sum);
  }
}
