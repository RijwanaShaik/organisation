from sqlalchemy.orm import declarative_base,sessionmaker
from sqlalchemy import create_engine
from urllib.parse import quote_plus
from sqlalchemy.exc import SQLAlchemyError

import os
from dotenv import load_dotenv
load_dotenv()
# Replace "your_host" with the actual host, and "sense_db" with your database name
host = os.getenv('HOST')
database_name = os.getenv('DATABASE_NAME')
user = os.getenv('POSTGRES_USER')
password = os.getenv('PASSWORD')
# URL-encode the password
encoded_password = quote_plus(password)
 
# Creating the connection string
dsn = f"postgresql://{user}:{encoded_password}@{host}/{database_name}"
 
# Creating the SQLAlchemy engine
engine = create_engine(dsn, echo=False,isolation_level='READ COMMITTED',pool_pre_ping=True)
 
Base = declarative_base()
SessionLocal = sessionmaker(engine)
 
def get_db_session():
    db_session = SessionLocal()
    try:
        print("Session opened")
        yield db_session
    except SQLAlchemyError as e:
        print("sql roll back exception")
        db_session.rollback()
    except Exception as e:
        print("roll back exception")
        db_session.rollback()
    finally:
        print("final closed")
        db_session.close()
