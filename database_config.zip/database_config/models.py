

from sqlalchemy import ForeignKey, String, Integer, Column, TEXT, Float, Boolean, DateTime, func,  JSON,BigInteger

from main_config.database_config.database import Base,engine
from sqlalchemy.orm import relationship
from main_config.enums_config.enums import UserRoleEnum, UserStatus, VideoType, PurchaseStatus

from main_config.database_config.table_name import TableName


def create_tables():
    Base.metadata.create_all(engine)

class BaseEntity(Base):
    __abstract__ = True
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    created_on = Column(DateTime, default=func.now())
    updated_on = Column(DateTime, server_default=func.now(), onupdate=func.now())
    is_active = Column(Boolean, default=True)

class AppUser(BaseEntity):
    __tablename__ = TableName.APP_USER
    name = Column(String(255), index = True)
    email = Column(String(255),unique=True,index=True)
    password=Column(String(255))
    token_balance = Column(Integer,default=0)
    status = Column(String, nullable=False, server_default= UserStatus.ACTIVE)
    role = Column(String, nullable=False, server_default= UserRoleEnum.USER)
    terms_and_condition=Column(Boolean)
    is_forgot_pwd= Column(Boolean ,default= False)
    is_email_verified= Column(Boolean ,default= False)

class TokenPurchase(BaseEntity):
    __tablename__ = TableName.TOKEN_PURCHASE
    token_count = Column(Integer)
    customer_id = Column(String)
    transaction_id = Column(String)
    currency = Column(String,default = "USD")
    purchase_status = Column(String, nullable=False, server_default= PurchaseStatus.INITIATED)
    user_id = Column(Integer, ForeignKey("app_user.id"), nullable=False, index=True)
    token_prchase_user = relationship("AppUser", backref="token_purchase")
    
class VideoContent(BaseEntity):
    __tablename__ = TableName.VIDEO_CONTENT
    video_id = Column(String,unique=True)
    name = Column(String)
    video_link= Column(String)
    is_example= Column(Boolean, default= False)
    tokens_utilized = Column(Integer)
    video_length_in_sec = Column(BigInteger,default=0)
    user_id = Column(Integer, ForeignKey("app_user.id"), nullable=False, index=True)
    thumb = Column(TEXT)
    video_status = Column(String,default='loading')
    video_content_user = relationship("AppUser", backref="video_content")
class AdminConfiguration(BaseEntity):
    __tablename__ = TableName.ADMIN_CONFIGURATIONS
    admin_email = Column(String(255))
    toke_price = Column(Float)
    video_length_in_mins = Column(Integer)
class UserSearchResult(BaseEntity):
    __tablename__ = TableName.USER_SEARCH_RESULT
    user_search_id = Column(Integer)
    video_id = Column(String, ForeignKey("video_content.video_id",ondelete='CASCADE'), nullable=False)
    query = Column(String)
    result = Column(JSON)
class APPConfiguration(BaseEntity):
    __tablename__ = TableName.APP_CONFIGURATION
    name = Column(String)
    key = Column(String)
    
