
class TableName:
    APP_USER = 'app_user'
    TOKEN_PURCHASE = "token_purchase"
    VIDEO_CONTENT = "video_content"
    ADMIN_CONFIGURATIONS = 'admin_configurations'
    USER_SEARCH_RESULT= 'user_search_result'
    EXAMPLE_VIDEO_CONTENT = 'example_video_content'
    APP_CONFIGURATION = 'app_configuration'
    



