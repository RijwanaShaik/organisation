

import boto3

from botocore.exceptions import ClientError
from fastapi import HTTPException
import os


ses_client = boto3.client("ses",region_name=os.getenv('AWS_REGION'))





def send_email(email_data):

    
    CHARSET = "UTF-8"
    EMAIL_URL = os.getenv('SES_EMAIL')
    
    
    
    BODY_HTML = f"""<html>
<head></head>
<body>
  <h1>Hi {email_data["email"]}</h1>
  <p>{email_data["msg"]}
    <a href="{EMAIL_URL}email={email_data["email"]}&{email_data["query"]}">Click Here </a>
    </p>
</body>
</html>
"""
    # Sender's email address (must be verified in SES)
    sender_email = os.getenv('SES_EMAIL_SENDER')

    # Create the email message
    email_message = {
        'Subject': {'Data': email_data["subject"]},
        'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': BODY_HTML,
                }
            },
    }

    try:
        # Send the email using SES
        response = ses_client.send_email(
            Source=sender_email,
            Destination={'ToAddresses': [email_data["email"]]},
            Message=email_message
        )
        print("email sended ")
        return {"message_id": response['MessageId']}
    except ClientError as e:
        error_message = e.response['Error']['Message']
        raise HTTPException(status_code=500, detail=error_message)


def email_verification(email_data):
    CHARSET = "UTF-8"
    EMAIL_URL = os.getenv('SES_EMAIL')
    
    BODY_HTML = f"""<html>
<head></head>
<body>
  <h1>Hi {email_data["email"]}</h1>
  <p>{email_data["msg"]}
    <a href="{EMAIL_URL}?token={email_data['token']}">Click Here to Confirm Your Email</a>
    </p>
</body>
</html>
"""
    # Sender's email address (must be verified in SES)
    sender_email = os.getenv('SES_EMAIL_SENDER')

    # Create the email message
    email_message = {
        'Subject': {'Data': email_data["subject"]},
        'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': BODY_HTML,
                }
            },
    }

    try:
        # Send the email using SES
        response = ses_client.send_email(
            Source=sender_email,
            Destination={'ToAddresses': [email_data["email"]]},
            Message=email_message
        )
        print("email sended ")
        return {"message_id": response['MessageId']}
    except ClientError as e:
        error_message = e.response['Error']['Message']
        raise HTTPException(status_code=500, detail=error_message)







