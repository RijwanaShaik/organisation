import datetime
from urllib.parse import urlparse
from urllib.parse import parse_qs

from main_config.enums_config.enums import AIVideoStatus
def isUrlExpiring(url):
    if url:
        parsed_expiring_url = urlparse(url)
        extracted_expired_epcho_time = parse_qs(parsed_expiring_url.query)['Expires'][0]
        expired_url_details= datetime.datetime.fromtimestamp(int(extracted_expired_epcho_time))
        expire_data = expired_url_details.strftime("%Y-%m-%d")
        expire_hour = int(expired_url_details.strftime("%H"))
        current_date_datails = datetime.datetime.now()
        current_date = current_date_datails.strftime("%Y-%m-%d")
        current_hour = int(current_date_datails.strftime("%H"))
        if (expire_data < current_date or (expire_data == current_date and expire_hour <= current_hour + 2)):
            return True
        else:
            return False  
    else:
        return False     
video_status_error = [AIVideoStatus.UNKNOW,AIVideoStatus.ERROR] 
video_status_valid = [AIVideoStatus.CREATED ,AIVideoStatus.READY ,AIVideoStatus.PROCESSING ] 
            