
import httpx
import os
from dotenv import load_dotenv
load_dotenv()

headers = {
        'X-API-KEY': os.getenv('AIAPIKEY')
    }
timeout = 180

async def postAIResponse(url):
    async with httpx.AsyncClient() as client:
        response = await client.post(url,headers=headers,timeout=timeout)
        return response

async def postAIResponseRetrive(url,data):
    async with httpx.AsyncClient() as client:
        response = await client.post(url,data = data,headers=headers,timeout=timeout)
        return response

async def getAIResponse(url):
    async with httpx.AsyncClient() as client:
        response = await client.get(url,headers=headers,timeout=timeout)
        return response

async def deleteAIResponse(url):
    async with httpx.AsyncClient() as client:
        response = await client.delete(url,headers=headers,timeout=timeout)
        return response