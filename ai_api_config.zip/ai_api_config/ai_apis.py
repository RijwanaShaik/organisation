from asyncio import wait
import json

from fastapi import Depends, HTTPException
from main_config.ai_api_config.ai_api_service import deleteAIResponse, getAIResponse, postAIResponse, postAIResponseRetrive
from http import HTTPStatus
from concurrent.futures import ThreadPoolExecutor,as_completed,wait
import requests
from main_config.database_config.database import get_db_session
from main_config.enums_config.enums import AIVideoStatus
from main_config.utility_config.utility import apiResponse, setContextSearch_data, setUploadVideos, setUploadVideos
import main_config.database_config.models as models
from .ai_utility import isUrlExpiring,video_status_error,video_status_valid
from sqlalchemy import distinct
from main_config.enums_config.message import unSucessMessage

from ..query_config.user_search_queries import filterUserSearchResults, getLatestUserSearchResult, \
    getUserSearchResultsForUserAndVideoOrderBy
from ..query_config.video_content_queries import getExampleVidoes, getVideoContentForUserAndVideo, \
    getVideoContentForUserPagination, getVideoIsExampleTrue, getVideoById, getVideoByIsActiveIsExample
from main_config.loggers_config.file_log import logger
import threading
import time
import os
from dotenv import load_dotenv
load_dotenv()


AI_BASEURL = os.getenv('AI_BASEURL')


# flow of Youtube Al Api
async  def AIYoutubeUpload(title,token_utilization,videos_url,user_id: int):
    url = f"{AI_BASEURL}video/create_new_video?user_id={user_id}&youtube_url={videos_url}"
    try:
        response_upload_video = await postAIResponse(url)
        print(response_upload_video.status_code)
        logger.info("AIYoutubeUpload Process Started")
        if response_upload_video.status_code == HTTPStatus.OK:
            response_upload_video = response_upload_video.json()
            videos_status = await checkStateOfVideo(response_upload_video['video_id'])
            print(videos_status,'videos_status')
            logger.info(f"Checking the Video Status of {response_upload_video['video_id']} during AIYoutubeUpload") 
            while videos_status['state'] not in video_status_error:
                threading.Timer(15,lambda:None)
                videos_status = await checkStateOfVideo(response_upload_video['video_id'])
                time.sleep(15)
                if  videos_status['state']  in video_status_valid:
                    break
            if videos_status['state']  in video_status_valid:
                logger.info(f"Checking the Video Status of video_id {response_upload_video['video_id']} of VideoStatus is {videos_status['state']}")
                length_videos_sec = await checkDurationVideo(response_upload_video['video_id'],user_id) 
                logger.info(f"Checking the Duration of video_id {response_upload_video['video_id']},user_id {user_id} during AIYoutubeUpload") 
                thumb_url = await  getFrameUrlOfVideos(user_id,response_upload_video['video_id'])
                logger.info(f"Getting FrameUrl of video_id {response_upload_video['video_id']},,user_id {user_id} during AIYoutubeUpload ") 
                newRecordVideoData:dict = {}
                newRecordVideoData = {
                    'title':title,
                    'token_utilization':token_utilization,
                    'length_videos_sec':length_videos_sec['duration'],
                    'presigned_url':response_upload_video['presigned_url'],
                    'user_id':user_id,
                    'video_id':response_upload_video['video_id'],
                    "state":videos_status['state'],
                    "thumb_url":thumb_url['presigned_url'],
                    'is_example':False
                }
                logger.info("AIYoutubeUpload Process Completed")  
                return setUploadVideos(newRecordVideoData)
    except Exception as e:
        logger.error(f"An error occurred during AIYoutube upload: {e}")
        print(f"An error occurred Youtube: {e}") 
                
async def checkStateOfVideo(video_id:str):
    url = f"{AI_BASEURL}video/video_state?video_id={video_id}"
    videos_status = await getAIResponse(url)
    return covertAlResponseIntoJson(videos_status)

async def checkDurationVideo(video_id:str,user_id:int):
    url = f"{AI_BASEURL}video/duration?user_id={user_id}&video_id={video_id}"
    videos_duration = await getAIResponse(url)
    return  covertAlResponseIntoJson(videos_duration)

async def getFrameUrlOfVideos(user_id:int,video_id:str):
    url = f"{AI_BASEURL}video/frame?user_id={user_id}&video_id={video_id}&frame_msec=5000"
    thumbUrl = await getAIResponse(url)
    return  covertAlResponseIntoJson(thumbUrl)



async def getStreamUrl(user_id:int,video_id:str):
    url = f"{AI_BASEURL}video/exists?user_id={user_id}&video_id={video_id}"
    stream_url = await getAIResponse(url)
    return  covertAlResponseIntoJson(stream_url)




async def getVideos(getVideosList,current_user ,example_videos_list,offset,per_page,db):
    getAllExistingVideo = await buildPreViewUploads(getVideosList,current_user,offset,per_page,db)
    getAllExampleVideo = await  buildPreviewDefaultVideos(example_videos_list,current_user,db)
    payload = {
        'my_uploads':getAllExistingVideo,
        'exampleVideo': getAllExampleVideo} 
    return payload 

async def buildPreViewUploads(getVideosList,current_user,offset,per_page,db):
    requestBodyRetriveUrl = []

    retriveUrl = f"{AI_BASEURL}video/bulk_retrieve_video_info" 
    for video_detail in getVideosList:
        isExpiredVideoLink =  isUrlExpiring(video_detail.video_link)
        isExpireVideoThumb =  isUrlExpiring(video_detail.thumb)
        if isExpiredVideoLink or isExpireVideoThumb:
            requestBodyRetriveUrl.append({"video_id": video_detail.video_id,"user_id": str(current_user['id']),"request_video_presigned_url": True,"request_thumbnail_presigned_url":True})                 
        else:
            requestBodyRetriveUrl.append ( {"video_id": video_detail.video_id,"user_id": str(current_user['id'])})
    request_body = {"requests": requestBodyRetriveUrl}
    getBulkVideoResponse = await  postAIResponseRetrive(retriveUrl,json.dumps(request_body))
    if getBulkVideoResponse.status_code == HTTPStatus.OK:
        logger.info("Bulk upload video's retrieval successful from AI Server.")
        getBulkVideoResponse =   getBulkVideoResponse.json()['responses']
        for video in getBulkVideoResponse:
            getVideosByIdForRetrive = getVideoContentForUserAndVideo(video['video_id'], current_user['id'],db)
            if video['exists']:
                if video['presigned_video_url'] != None or video['presigned_thumbnail_url'] != None:
                    getVideosByIdForRetrive.video_link = video['presigned_video_url']
                    getVideosByIdForRetrive.thumb = video['presigned_thumbnail_url']
                if getVideosByIdForRetrive.video_status != video['state']:
                    getVideosByIdForRetrive.video_status = video['state'] 
            else:
                getVideosByIdForRetrive.is_active = False        
        db.commit()
        getNewCommitVideosdata = getVideoContentForUserPagination(current_user['id'], offset, per_page,db)
        return getNewCommitVideosdata
    else:
        logger.error("AI API failed to retrieve bulk video information of upload video's.")
        return []
async def buildPreviewDefaultVideos(example_videos_list,current_user,db):
    requestBodyRetriveUrl =[]
    for example_video in example_videos_list:
        isExpiredExampleVideoLink =  isUrlExpiring(example_video.video_link)
        isExpireExampleVideoThumb =  isUrlExpiring(example_video.thumb)
        if isExpiredExampleVideoLink or isExpireExampleVideoThumb:
            requestBodyRetriveUrl.append({"video_id": example_video.video_id,"user_id": "default","request_video_presigned_url": True,"request_thumbnail_presigned_url": True})        
    if len(requestBodyRetriveUrl) > 0:
        retriveUrl = f"{AI_BASEURL}video/bulk_retrieve_video_info" 
        data ={'requests':requestBodyRetriveUrl}
        getNewExampleAssignedUrl = await postAIResponseRetrive(retriveUrl,json.dumps(data))
        if getNewExampleAssignedUrl.status_code == HTTPStatus.OK:
            logger.info("Bulk example video's retrieval successful from AI Server.")
            getNewExampleAssignedUrl = getNewExampleAssignedUrl.json()['responses']
            for exampleVideoUrl in getNewExampleAssignedUrl:
                getExampleVideosByIdForRetrive = getVideoById(exampleVideoUrl['video_id'],db)
                if exampleVideoUrl['exists']:
                    getExampleVideosByIdForRetrive.video_link = exampleVideoUrl['presigned_video_url']
                    getExampleVideosByIdForRetrive.thumb = exampleVideoUrl['presigned_thumbnail_url']
                else:
                    getExampleVideosByIdForRetrive.is_active = False
            db.commit()
        else:
            logger.error("AI API failed to retrieve bulk video information of example video's.")
            return []
    getNewUpdatedExampleVidoes = getExampleVidoes(db)      
    return getNewUpdatedExampleVidoes
    
async def isUrlExpringContextFrameUrl(result,current_user,video_id,db):
    requestBodyRetriveUrl = []
    frame_msecs = []
    frame_query = []
    for records in result:
        for frameUrl in records.result:
            isExpired = isUrlExpiring(frameUrl["pre_signed_url"])
            if isExpired:
                frame_msecs.append(int(frameUrl['frame_msec']))  
                frame_query.append(records.query)                           
    if len(frame_msecs)> 0:
        requestBodyRetriveUrl.append({"video_id": video_id,"user_id": str(current_user['id']),"frame_msecs": frame_msecs})      
    if len(requestBodyRetriveUrl) > 0:
        retriveUrl = f"{AI_BASEURL}video/bulk_retrieve_video_info"
        data ={'requests':requestBodyRetriveUrl}
        getNewAssignedUrl =  await postAIResponseRetrive(retriveUrl,json.dumps(data))
        if getNewAssignedUrl.status_code == HTTPStatus.OK:
            logger.info("Bulk context search video's retrieval successful from AI Server.")
            getNewAssignedUrl = getNewAssignedUrl.json()['responses'][0]['frames']
            newFrames = []
            for i in range(len(getNewAssignedUrl)):
                newFrames.append({
                    'realated_query':frame_query[i],
                    'frame_msec': getNewAssignedUrl[i]['frame_msec'],
                    'pre_signed_url': getNewAssignedUrl[i]['frame_url'] 
                })  
            contextDataSeperation(current_user['id'], video_id,newFrames,db)
            return getUserSearchResultsForUserAndVideoOrderBy(current_user['id'], video_id,db)
        else:
            logger.error("AI API failed to retrieve bulk video information of context search video's.")
            return [] 
    return getUserSearchResultsForUserAndVideoOrderBy(current_user['id'], video_id,db)                          
def contextDataSeperation(current_user, video_id,data,db):
    separated_data = {}
    for entry in data:
        related_query = entry['realated_query']
        if related_query not in separated_data:
            separated_data[related_query] = []
        separated_data[related_query].append(entry)
    result_arrays = list(separated_data.values())
    for result in result_arrays:
        getFramesByQuery = filterUserSearchResults(current_user, video_id, result[0]['realated_query'],db)
        getFramesByQuery.result = result
        db.commit()

# flow File API
async def AIManualFileUpload(manualPayload,user_id):
    try:
        if manualPayload.isUploaded:
            AlCompleteMultipleUpload(manualPayload.title,manualPayload.token_utilization,manualPayload.length_videos_sec,user_id,manualPayload.upload_id,manualPayload.video_id)
        else:
            raise HTTPException(status_code=400,detail="createNewApi failed")  
    except Exception as e:
        print(f"An error occurred file: {e}")  
        
        

async def s3MultipartUploadUrl(file_size:int,user_id:int):
    manualFileUploadUrl = f"{AI_BASEURL}video/create_new_video?user_id={user_id}&filesize={file_size}"
    logger.info("AI S3Multipart Upload started")
    try:
        manualFileAIResponse = await  postAIResponse(manualFileUploadUrl)
        if manualFileAIResponse.status_code == 200:
            logger.info("AI S3Multipart Upload completed")
            return manualFileAIResponse.json() 
        else:
            logger.info("AI S3Multipart Upload Failed")
            raise  HTTPException(status_code=manualFileAIResponse.status_code,detail="createNewApi failed")
    except Exception as e:
        print(f"An error occurred file: {e}")      
        
    
    
                 
        
async def uploadMultiPartUrls(s3_multi_part_upload_urls, file):
    executor = ThreadPoolExecutor()
    futures = []
    part_size = 10 * 1024 * 1024  # 10 MB part size
    
    try:
        for i in range(len(s3_multi_part_upload_urls)):
            file_data = await file.read(part_size)
            futures.append(executor.submit(uploadPartToS3Bucket, s3_multi_part_upload_urls[i], i, file_data))     
        return checkAllAsignedToS3Bucket(futures)   
    except Exception as e:
        print(f"An error occurred uploadMultiPartUrls: {e}")
        
def checkAllAsignedToS3Bucket(future):
    uploadCheckList = []
    for i in future:
        uploadCheckList.append( str(i.result()) )    
    return all(uploadCheckList)  

def covertAlResponseIntoJson(reponse):
    return reponse.json()

def uploadPartToS3Bucket(presigned_url, part_number, data):
    try:
        headers = {'Content-Length': str(len(data))}
        response = requests.put(presigned_url, headers=headers, data=data)
        if response.status_code == 200:
            print(f"Part {part_number} uploaded successfully.")
        else:
            print(f"Failed to upload part {part_number}. Status code: {response.status_code}, Error: {response.text}")
    except Exception as e:
        print(f"An error occurred: {e}")      
        
        


async def AlCompleteMultipleUpload(manualPayload,user_id:int,db):
    completdMultipleUploadUrl = f"{AI_BASEURL}video/complete_multipart_upload?user_id={user_id}&upload_id={manualPayload.upload_id}&video_id={manualPayload.video_id}"
    try:
        logger.info('AlCompleteMultipleUpload  Process Started')
        completdMultipleUploadResponse = await  postAIResponse(completdMultipleUploadUrl)
        print(completdMultipleUploadResponse.status_code,'AlCompleteMultipleUpload')
        if completdMultipleUploadResponse.status_code == HTTPStatus.OK:
            completdMultipleUploadResponse = covertAlResponseIntoJson(completdMultipleUploadResponse)
            thumb_url =  await getFrameUrlOfVideos(user_id,manualPayload.video_id)
            state_video = await checkStateOfVideo(manualPayload.video_id)
            logger.info(f"Getting FrameUrl of video_id {manualPayload.video_id},user_id {user_id} during AlCompleteMultipleUpload ") 
            newRecordVideoData:dict = {}
            newRecordVideoData = {
                    'title':manualPayload.title,
                    'token_utilization':manualPayload.token_utilization,
                    'length_videos_sec':manualPayload.length_videos_sec,
                    'presigned_url':completdMultipleUploadResponse['presigned_url'],
                    'user_id':user_id,
                    'video_id':manualPayload.video_id,
                    "state":state_video['state'],
                    "thumb_url":thumb_url['presigned_url'],
                    'is_example':False
                    }
            newVideo = setUploadVideos(newRecordVideoData)
            db.add(newVideo)
            db.commit()
            logger.info('AlCompleteMultipleUpload  Process Completed')
            return True
        else:
            logger.error("An error/failed occured during AICompletdMultipleUpload ")
            return False
    except Exception as e:
        logger.error(f"An exception occured during AICompletdMultipleUploadResponse: {e} ")
        print(f"An error occurred completdMultipleUploadResponse: {e}")
        
        
        
        
# context Search video

async def AIContextualSearch(video_id:str,user_id:int,query:str,status:str,current_user:int,db):
    logger.info(f'AIContextualSearch called with video_id={video_id}, user_id={user_id}, query={query}')
    contextSearchUrl = f"{AI_BASEURL}contextual_search/search?video_id={video_id}&user_id={user_id}&query={query}"
    logger.info(f'Constructed URL: {contextSearchUrl}')
    contextSearchResponse = await postAIResponse(contextSearchUrl)
    try:
        if status == AIVideoStatus.READY or status == AIVideoStatus.EXPIRED:
            logger.info('Status is ready. Initiating contextual search.')
            logger.info(f'Contextual search response status code: {contextSearchResponse.status_code}')
            if contextSearchResponse.status_code == HTTPStatus.OK:
                newRecord = setContextSearch_data(contextSearchResponse.json(),current_user, video_id)
                db.add(newRecord)
                db.commit()
                return  contextSearchResponse.json()   
            else:
                logger.error(f'Contextual search failed with status code: {contextSearchResponse.status_code}')
                return contextSearchResponse.json() 
        else:
            logger.error(f'Contextual search for video_id {video_id} status is not equal to ready.')
            return contextSearchResponse.json() 
    except Exception as e:
        logger.error(f"An error occurred in Contextual Search: {e}")
        print(f"An error occurred: {e}")
        
        
# delete the Videos from Al api        

async def AIDeleteVideo(video_id:str,user_id:int):
    deleteVideoUrl = f"{AI_BASEURL}video/video?user_id={user_id}&video_id={video_id}"
    logger.info(f"AIDeleteVideo of video_id {video_id} Process Started")
    try:
        deleteVideo = await deleteAIResponse(deleteVideoUrl)
        if deleteVideo.status_code == HTTPStatus.OK:
            logger.info(f"AIDeleteVideo of video_id {video_id} deleted successfully for user {user_id}")
            return True
        else:
            logger.error(f"AIDeleteVideo API Failed to delete video_ID {video_id} for user {user_id}")
            return False
    except Exception as e:
        logger.error(f"An error occurred during AIDeleteVideo: {e}")
        print(f"An error occurred: {e}")  
        
        
async def AIDefaultVideos(user_id:str,db):
    url = f"{AI_BASEURL}video/default_videos"
    getDefaultVideos = await getAIResponse(url)
    if getDefaultVideos.status_code == 200:
        getDefaultVideos = getDefaultVideos.json()
        for default in getDefaultVideos['videos']:
            video_id = default['video_id']
            existing_record = db.query(models.VideoContent).filter_by(video_id=video_id).first()
            if not existing_record:
                streamUrl = f"{AI_BASEURL}video/stream_url?user_id=default&video_id={video_id}"
                durationUrl = f"{AI_BASEURL}video/duration?user_id=default&video_id={video_id}"
                getStreamUrl = await getAIResponse(streamUrl)
                getDuration = await getAIResponse(durationUrl)
                getThumbUrl = await getFrameUrlOfVideos(user_id,video_id) 
                state_video = await checkStateOfVideo(video_id)
                
                newRecordVideoData:dict = {}
                newRecordVideoData = {
                    'title': default['video_name'],
                    'token_utilization':0,
                    'length_videos_sec':getDuration.json()['duration'],
                    'presigned_url':getStreamUrl.json()['presigned_url'],
                    'user_id':1,
                    'video_id':video_id,
                    "state":state_video['state'],
                    "thumb_url":getThumbUrl['presigned_url'],
                    "is_example":True
                    }
                example_video_db = setUploadVideos(newRecordVideoData)
                db.add(example_video_db)
                db.commit() 
                
                
async def YoutubeDuration(url: str):
    logger.info("YoutubeDuration Process Started")
    print("YoutubeDuration Process Started")
    try:
        url = f"{AI_BASEURL}video/youtube_video_duration?youtube_url={url}"
        durationYoutubeUrl = await getAIResponse(url)

        if durationYoutubeUrl.status_code == HTTPStatus.OK:
            logger.info("YoutubeDuration Process Completed")
            return durationYoutubeUrl.json()
        else:
            logger.error("YoutubeDuration Process Failed")
            raise HTTPException(status_code=durationYoutubeUrl.status_code, detail="YouTube API failed")
    except Exception as e:
        logger.error(f"An error occured during YoutubeDuration Process {e}")
        # Handle other exceptions if needed
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")
        
        


            
        
        
    
    
            
        