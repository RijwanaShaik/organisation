package com.wm.cockpit.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.wm.cockpit.enums.ClimateChangeExposure;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.minidev.json.annotate.JsonIgnore;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "tr_scenario_settings",uniqueConstraints = {@UniqueConstraint(name = "customer", columnNames = {"customer_id"})})
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@SuppressWarnings("serial")
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class ScenarioSettings extends BaseEntity{
    @OneToOne
    private Customer customer;
    @OneToOne
    private Dependency dependency;
    @OneToOne
    private Sector sector;
    @OneToOne
    private Country country;
    private double costOfDebt;
    private double accuredStressAsset;
    private double accuredLiquidityEvent;
    private double cashStressAsset;
    private double cashLiquidityEvent;

    private double  swapCashDistributionRate;
    private double swapAccuredDistributionRate;
    private double swapCostOfDebt;

    private double leverageCashDistributionRate;
    private double leverageAccuredDistributionRate;
    private double leverageCostOfDebt;

    private double liquidityCashDistributionRate;
    private double liquidityAccuredDistributionRate;
    private double liquidityCostOfDebt;
    @Enumerated(EnumType.STRING)
    private ClimateChangeExposure climateChangeExposure;

    @OneToMany(mappedBy = "scenarioSettings", cascade = CascadeType.MERGE)
    private List<ScenarioLegalExposure> countryOfLegalExposure = new ArrayList<>();
}
