package com.wm.cockpit.dto.rest;

import com.wm.cockpit.enums.Role;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  17/05/23
 * @Time >>  11:13 am
 * @Project >>  cocpit
 */

@NoArgsConstructor
@Data
public class AdminResponseDto {

    private Long id;

    private String userName;

    private String email;

    private Long phoneNumber;

    private Role role;

    private String status ;

    private String designation;

}
