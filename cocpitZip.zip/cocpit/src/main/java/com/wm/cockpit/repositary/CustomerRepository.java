package com.wm.cockpit.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wm.cockpit.entity.Customer;

import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    Customer findByName(String name);


    String findByEmail(String email);

    boolean existsByEmail(String email);

    Long countByName(String name);
    List<Customer> findAllByAppUserId(Long appUserId);

    List<Customer> findAllByAppUserIdInAndIsActiveAndIsDeleted(List<Long> appUserIds, Boolean aTrue, Boolean aFalse);

    List<Customer> findAllByAppUserIdAndIsActiveAndIsDeleted(Long id, Boolean aTrue, Boolean aFalse);

    Long countByNameAndAppUserId(String customerName, Long adminId);
}
