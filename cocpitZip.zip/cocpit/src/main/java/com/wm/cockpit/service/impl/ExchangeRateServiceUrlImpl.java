package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.ExchangeCurrencyRateMsgDto;
import com.wm.cockpit.entity.ExchangeRate;
import com.wm.cockpit.repositary.LegalExposureRepository;
import com.wm.cockpit.repositary.ExchangeRateRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class ExchangeRateServiceUrlImpl {

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private ExchangeRateRepository exchangeRateRepository;
    @Autowired
    private ModelMapper mapper;
    @Value("${EXCHANGE_RATE}")
    private String exchangeRateUrl;
    @Autowired
    private LegalExposureRepository legalExposureRepository;

    public ExchangeCurrencyRateMsgDto getAllCurrencies(){
        HttpHeaders headers = new HttpHeaders();//        System.out.println(dtos.getRates());
        headers.add("apikey","GsvV0NCn5Pbny2yWuVOrobww9yvifxv5");
        //headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ExchangeCurrencyRateMsgDto dtos =  restTemplate.exchange(exchangeRateUrl,HttpMethod.GET,entity,ExchangeCurrencyRateMsgDto.class).getBody();
        for(Map.Entry<String, Float> exchange :  dtos.getRates().entrySet()){

            ExchangeRate exchangeRate = new ExchangeRate();
            exchangeRate.setCurrencyCode(exchange.getKey());
            exchangeRate.setValue(exchange.getValue());
            exchangeRateRepository.save(exchangeRate);
           // exchangeRateDto.setExchange(exchange.getKey(),exchange.getValue());
            System.out.println(" key : "+exchange.getKey() +"= value : "+exchange.getValue());
        }
        return dtos;
    }
}

