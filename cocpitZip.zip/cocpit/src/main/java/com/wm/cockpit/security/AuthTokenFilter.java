package com.wm.cockpit.security;

import com.wm.cockpit.entity.Token;
import com.wm.cockpit.repositary.TokenRepository;
import io.jsonwebtoken.SignatureException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.annotation.Resource;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;

public class AuthTokenFilter extends OncePerRequestFilter {
    @Autowired
    JwtUtils jwtUtils;
    @Autowired
    UserDetailServiceImpl userDetailsService;
    @Autowired
    private StringRedisTemplate redisTemplate;
    private static final Logger log = LoggerFactory.getLogger(AuthTokenFilter.class);
    private final String hashReference = "cockpit-auth";
    @Resource(name = "redisTemplate")
    private HashOperations<String, String, String> hashOperations;

    @Autowired
    private TokenRepository tokenRepository;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {
            String jwt = parseJwt(request);
            if (jwt != null && jwtUtils.validateJwtToken(jwt) && validateToken(jwt).isPresent()) {
                String email = jwtUtils.getUserNameFromJwtToken(jwt);
                String emailFromRedis = hashOperations.get(jwt, jwt);
                System.out.println("EMAIL FROM JWT : " + email);
                System.out.println("EMAIL FROM REDIS : " + emailFromRedis);
                if (emailFromRedis != null && !emailFromRedis.isEmpty() && emailFromRedis.equals(email)) {
                    UserDetails userDetails = userDetailsService.loadUserByUsername(emailFromRedis);
                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                } else {
                    throw new SignatureException("JWT token is unsupported");
                }
            }
        } catch (Exception e) {
            log.error("Cannot set user authentication: {}", e);
        }
        filterChain.doFilter(request, response);
    }

    private String parseJwt(HttpServletRequest request) {
        String headerAuth = request.getHeader("Authorization");

        if (StringUtils.hasText(headerAuth)) {
            return headerAuth;
        }
        return null;
    }

    private Optional<Token> validateToken(String token) {
        return tokenRepository.findByToken(token);
    }
}