package com.wm.cockpit.service.impl;

import com.wm.cockpit.entity.ExchangeRate;
import com.wm.cockpit.repositary.ExchangeRateRepository;
import com.wm.cockpit.service.ExchangeRateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExchangeRateServiceImpl implements ExchangeRateService {
    @Autowired
    private ExchangeRateRepository exchangeRateRepository;

    @Override
    public List<ExchangeRate> getAllExchangeRates() {
        return exchangeRateRepository.findByIsDeletedFalse();
    }
}