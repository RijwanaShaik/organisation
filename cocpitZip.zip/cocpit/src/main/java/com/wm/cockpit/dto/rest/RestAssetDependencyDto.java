package com.wm.cockpit.dto.rest;

import com.wm.cockpit.dto.DependencyDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class RestAssetDependencyDto {
    private long id;
    private float share;
    private Long assetId;
    private Long dependencyId;

    private DependencyDto dependencyDto;
   }
