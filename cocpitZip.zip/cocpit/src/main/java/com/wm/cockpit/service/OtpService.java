package com.wm.cockpit.service;

import com.wm.cockpit.dto.AppUserRequest;
import com.wm.cockpit.dto.LoginResponseDto;
import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.entity.Otp;
import com.wm.cockpit.exceptions.CustomAuthenticationException;

import java.util.List;

public interface OtpService {
	
	
	ApiResponse sentOtp(AppUserRequest appUserRequest) throws CustomAuthenticationException;
	ApiResponse otpValidation(LoginResponseDto user, String userOtp, AppUser appUser);

	List<Otp>  getAllOtps();
	
	
	
}
