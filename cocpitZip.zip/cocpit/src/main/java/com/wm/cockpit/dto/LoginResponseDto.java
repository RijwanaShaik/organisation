package com.wm.cockpit.dto;

import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.enums.Role;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
public class LoginResponseDto {

    long id;
    String userName;
    String email;

    long phoneNumber;

    Role role;

    String status;

    String auth_token;

    Boolean isFirstTimeLogin = Boolean.TRUE;

    String designation;

    Boolean isTermsAndConditionsAccepted = Boolean.FALSE;
    Long termsAndConditionsId ;
    String otp;


    public LoginResponseDto() {
    }

    public LoginResponseDto(AppUser user) {
        this.email = user.getEmail();
        this.role = user.getRole();
        this.userName = user.getUserName();
        this.id = user.getId();
        this.phoneNumber = user.getPhoneNumber();
        if (user.getIsActive()){
            this.status = "Active";
        }else{
            this.status = "InActive";
        }
    }
}
