package com.wm.cockpit.dto;

import com.wm.cockpit.entity.Country;
import com.wm.cockpit.entity.Customer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CurrencyDto {

    private long id;
    private String currencyCode;
    private CountryDto countryDto;


}
