package com.wm.cockpit.exceptions;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  18/05/23
 * @Time >>  2:11 pm
 * @Project >>  cocpit
 */
public class DuplicateException extends RuntimeException{
    public DuplicateException(String message){
        super(message);
    }
}
