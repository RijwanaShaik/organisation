package com.wm.cockpit.utils;

import java.util.List;

public class DtoUtils {
    public static boolean isEmpty(Object input) {

        if(input == null) {
            return true;
        }

        if (input instanceof String) {
            return ((String) input).trim().isEmpty();
        }
        if (input instanceof Float) {
            return (Float) input ==null;
        }

        if (input instanceof Integer) {
            return (Integer) input ==null;
        }
        if (input instanceof Long) {
            return (Long) input ==null;
        }
        if (input instanceof Double) {
            return  (Double) input ==null ;
        }
        if(input instanceof List<?>) {
            return  (List<?>) input ==null || ((List<?>) input).isEmpty();
        }

        return false;

    }
}
