package com.wm.cockpit.service.impl;

import java.util.List;
import java.util.Optional;

import com.wm.cockpit.entity.Liability;
import com.wm.cockpit.repositary.LiabilityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wm.cockpit.dto.LiabilityDependencyDto;
import com.wm.cockpit.entity.LiabilityDependency;
import com.wm.cockpit.repositary.LiabilityDependencyRepository;
import com.wm.cockpit.service.LiabilityDependencyService;

@Service
public class LiabilityDependencyServiceImpl implements LiabilityDependencyService {

    @Autowired
    private LiabilityDependencyRepository liabilityDependencyRepository;
    @Autowired
    private LiabilityRepository liabilityRepository;

    @Override
    public String createLiabilityDependency(LiabilityDependencyDto liabilityDependencyDto) {
        LiabilityDependency liabilityDependency = new LiabilityDependency();
        liabilityDependency.setShare(liabilityDependencyDto.getShare());
        Liability liability = liabilityRepository.findById(liabilityDependencyDto.getLiabilityId()).get();
        liabilityDependency.setLiability(liability);
        liabilityDependencyRepository.save(liabilityDependency);
        return " Created   LiabilityDependency  Successfully. ";
    }

    @Override
    public List<LiabilityDependency> getAllLiabilityDependency() {
        return liabilityDependencyRepository.findAll();
    }

    @Override
    public LiabilityDependency updatedLiabilityDependencyById(LiabilityDependencyDto liabilityDependencyDto) throws Exception {
        LiabilityDependency liabilityDependency;
        Optional<LiabilityDependency> optional = liabilityDependencyRepository.findById(liabilityDependencyDto.getId());
        if (optional.isPresent()) {
            liabilityDependency = optional.get();
            liabilityDependency.setShare(liabilityDependencyDto.getShare());
            return liabilityDependencyRepository.save(liabilityDependency);
        } else {
            throw new Exception("");
        }

    }
}
