package com.wm.cockpit.controller;

import com.wm.cockpit.dto.TermsAndConditionsDto;
import com.wm.cockpit.entity.Asset;
import com.wm.cockpit.entity.TermsAndCondition;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.TermsAndConditionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/terms-conditions/")
public class TermsAndConditionController {
    @Autowired
    private TermsAndConditionService service;

    private final Logger logger = LoggerFactory.getLogger( TermsAndCondition.class );
    @PostMapping(value = "save")
    public GenericResponse save(@RequestBody TermsAndConditionsDto dto){
        logger.info( "Terms & Conditions Save Service Started" );
        GenericResponse response = service.save(dto);
        logger.info( "Terms & Conditions Save Service Completed" );
        return response;
    }

    @PostMapping(value = "disable/{id}")
    public GenericResponse disable(@PathVariable Long id){
        logger.info( "Terms & Conditions Disable Service Started" );
        GenericResponse response= service.disableTermsAndConditions(id);
        logger.info( "Terms & Conditions Disable Service Completed" );
        return response;
    }

    @GetMapping(value = "get-active")
    public GenericResponse getActiveTermsAndConditions() {
        logger.info( "Get Active Terms & Conditions Service Started" );
        GenericResponse response = service.getActiveTermsAndConditions();
        logger.info( "Get Active Terms & Conditions Service Completed" );
        return response;
    }


}