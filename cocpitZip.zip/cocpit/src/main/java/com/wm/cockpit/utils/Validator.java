package com.wm.cockpit.utils;

import com.wm.cockpit.dto.AppConfigurationRequestDto;
import com.wm.cockpit.response.GenericResponse;
import org.springframework.http.HttpStatus;

public class Validator {

    public static GenericResponse validateAppConfigurationRequest(AppConfigurationRequestDto request) {
        if (Boolean.TRUE.equals(DtoUtils.isEmpty(request)))
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide request");
        if (Boolean.TRUE.equals(DtoUtils.isEmpty(request.getOrgName())))
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide organisation name");
        if ((Boolean.TRUE.equals(DtoUtils.isEmpty(request.getFavIcon()))) ||request.getFavIcon()==0)
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please upload favourite icon image");
        if ((Boolean.TRUE.equals(DtoUtils.isEmpty(request.getLoginImage())) )|| request.getLoginImage()==0)
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please upload login image");
        if ((Boolean.TRUE.equals(DtoUtils.isEmpty(request.getOrganisationLogo()))) || request.getOrganisationLogo()==0)
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please upload organisation logo image");
        return null;
    }

}
