package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.ScenarioItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;



@Repository
public interface ScenarioItemRepository extends JpaRepository<ScenarioItem, Long> {

}
