package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.TermsAndConditionsDto;
import com.wm.cockpit.entity.TermsAndCondition;
import com.wm.cockpit.enums.Role;
import com.wm.cockpit.exceptions.BadRequestException;
import com.wm.cockpit.exceptions.IdNotFoundException;
import com.wm.cockpit.exceptions.UnAuthorisedException;
import com.wm.cockpit.repositary.TermsAndConditionRepo;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.security.LoggedInUser;
import com.wm.cockpit.service.TermsAndConditionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TermsAndConditionServiceImpl implements TermsAndConditionService {
    @Autowired
    private TermsAndConditionRepo repo;
    @Override
    public GenericResponse save(TermsAndConditionsDto dto) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if (user.getRole().equals(Role.SUPER_ADMIN)) {
                if (dto.getText() != null && !dto.getText().trim().isEmpty() ) {
                    String msg = "Terms & conditions saved successfully";
                    TermsAndCondition termsAndCondition = new TermsAndCondition();
                    if (dto.getId() != null) {
                        Optional<TermsAndCondition> optional = repo.findById(dto.getId());
                        if (optional.isPresent()) {
                            termsAndCondition = optional.get();
                            msg = "Terms & conditions updated successfully";
                        } else throw new IdNotFoundException("No Terms & Conditions found with given id!!");
                    }
                    termsAndCondition.setText(dto.getText().trim());
                    return new GenericResponse(HttpStatus.OK, msg, entityToDto(repo.save(termsAndCondition)));
                }
                else throw new BadRequestException("Text must not be null");
            }
            else throw new UnAuthorisedException("Only Super Admin can create Terms & Conditions");
        }
        return null;
    }

    @Override
    public GenericResponse disableTermsAndConditions(Long id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if (user.getRole().equals(Role.SUPER_ADMIN)) {
                Optional<TermsAndCondition> optional = repo.findById(id);
                if (optional.isPresent()) {
                    TermsAndCondition termsAndCondition = optional.get();
                    termsAndCondition.setIsActive(Boolean.FALSE);
                    repo.save(termsAndCondition);
                    return new GenericResponse(HttpStatus.OK, "Terms & Conditions Inactived succesfully");
                } else {
                    throw new IdNotFoundException("No Terms & Condition found with given id!!");
                }
            } else throw new UnAuthorisedException("Only Super Admin can disable Terms & Conditions");
        }return null;
    }

    @Override
    public GenericResponse getActiveTermsAndConditions() {
        List<TermsAndCondition> list = repo.findAllByIsActive(Boolean.TRUE);
        return new GenericResponse(HttpStatus.OK, list.stream().map(this::entityToDto).toList());
    }

    private TermsAndConditionsDto entityToDto(TermsAndCondition save) {
        TermsAndConditionsDto dto = new TermsAndConditionsDto();
        dto.setId(save.getId());
        dto.setText(save.getText());
        return dto;
    }

}
