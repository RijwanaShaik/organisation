package com.wm.cockpit.dto;

import com.wm.cockpit.entity.ScenarioHeader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ScenarioHeaderDto {

    private Long id;
    private Long customer;
    private String name;
  //  private Long scenarioItemDto;
  public ScenarioHeaderDto(ScenarioHeader entity) {
      this.id = entity.getId();
      this.customer = entity.getCustomer().getId();
      this.name = entity.getName();
  }
}
