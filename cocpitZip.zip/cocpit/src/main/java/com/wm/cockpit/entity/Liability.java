package com.wm.cockpit.entity;

import com.wm.cockpit.dto.DependencyDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotNull;


@SuppressWarnings("serial")
@Entity
@Table(name = "tr_liability")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class Liability extends BaseEntity {

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private double value;

    @ManyToOne
    private Customer customer;

    @OneToOne
    private Currency currency;

    private double costOfDebt;

    @OneToOne
    private Country countryOfLegalExposure;

    @OneToOne
    private Currency existingLending;

    private double existingValue;

    @OneToOne
    private Asset specificAsset;

    @OneToMany(mappedBy = "liability", cascade = CascadeType.ALL)
    private List<LiabilityDependency> liabilityDependencies = new ArrayList<>();

    @OneToMany
    private List<FileUpload> fileUploads = new ArrayList<>();
}
