package com.wm.cockpit.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

import javax.persistence.*;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tr_legalExposure")
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class LegalExposure extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
    private Asset asset;
    @ManyToOne
    private Country country;
}
