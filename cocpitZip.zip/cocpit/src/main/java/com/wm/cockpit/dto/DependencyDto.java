package com.wm.cockpit.dto;

import java.util.List;

import com.wm.cockpit.entity.Asset;
import com.wm.cockpit.entity.Customer;
import com.wm.cockpit.entity.Dependency;
import com.wm.cockpit.entity.Liability;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class DependencyDto {

    private long id;
    @NotEmpty(message = "name is Required ")
    private String name;
    @NotNull(message = "Customer is required")
    private Long customer;

}
