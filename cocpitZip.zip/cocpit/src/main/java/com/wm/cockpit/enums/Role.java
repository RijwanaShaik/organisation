package com.wm.cockpit.enums;

public enum Role {
	SUPER_ADMIN, NONE,
	ADMIN;

	public static Role getRoleFromString(String role) {
		if (role != null && !role.isEmpty()) {
			String upperCaseValue = role.toUpperCase();
			return switch (upperCaseValue) {
				case "SUPER_ADMIN", "SUPER ADMIN", "SUPERADMIN", "SUPER-ADMIN" -> Role.SUPER_ADMIN;
				case "ADMIN" -> Role.ADMIN;
				default -> NONE;
			};
		} else {
			return NONE;
		}
	}
}