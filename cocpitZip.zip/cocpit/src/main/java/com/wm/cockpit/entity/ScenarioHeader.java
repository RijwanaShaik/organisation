
package com.wm.cockpit.entity;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.*;

@SuppressWarnings("serial")
@Entity

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Where(clause = "is_deleted=false OR  is_deleted is null ")
@Table(name = "tr_scenario_header")
public class ScenarioHeader extends BaseEntity {

    @ManyToOne
    @JsonIgnore
    private Customer customer;
    private String name;

    @OneToOne(cascade = CascadeType.ALL,mappedBy = "scenarioHeader", orphanRemoval = true)
    @JoinColumn(name = "scenarioHeader_id", referencedColumnName = "id" )
    private ScenarioItem scenarioItem;
}
