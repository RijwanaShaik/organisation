package com.wm.cockpit.common.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PageGetResponse {

    private Object content;
    private Integer totalPages;

    public PageGetResponse(Object content,Integer totalPages){
        this.content=content;
        this.totalPages=totalPages;
    }
}
