package com.wm.cockpit.service;

import java.util.List;

import com.wm.cockpit.dto.AssetDto;
import com.wm.cockpit.dto.EssentialAssetDto;
import com.wm.cockpit.entity.Asset;
import com.wm.cockpit.response.GenericResponse;

public interface AssetService {

	String createAsset(AssetDto assetDto);

	Asset updateAssetById(AssetDto assetDto) throws Exception;

	String deletedAssetById(long id);

	List<Asset> getAllAssets() throws Exception;

	Asset getAssetById(long id) throws Exception;

	Asset getAssetByCustomerId(long id);

	GenericResponse getAllClimateChangeExposures();

	GenericResponse getCountByClimateExposure();

}
