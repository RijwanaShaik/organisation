package com.wm.cockpit.service;

import java.util.List;

import com.wm.cockpit.dto.CustomerDto;
import com.wm.cockpit.entity.Customer;
import com.wm.cockpit.response.GenericResponse;

public interface CustomerService {


    GenericResponse createCustomer(CustomerDto customerDto) throws Exception;

    Customer getCustomerById(long id);

    Customer getCustomerByName(String name);

    String updateCustomerById(CustomerDto customerDto);

    String deletedCustomerById(long id);

    List<CustomerDto> getAllCustomer() throws Exception;
    List<CustomerDto> getCustomerByAdminId(Long adminId);

    GenericResponse getAllCustomers();
}
