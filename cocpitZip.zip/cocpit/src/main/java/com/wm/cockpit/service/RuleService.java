package com.wm.cockpit.service;

import com.wm.cockpit.dto.*;

public interface RuleService {
     LiquidityGraphDto getLiquidityGraph(LiquidityGraphDto liquidityGraph);

     CurrencyMixGraphDto getCurrencyExposures(CurrencyMixGraphDto currencyMixGraph);
     InflationGraphDto getInflation(InflationGraphDto inflationGraph);

     UBOReturnsGraphDto getUBOReturns(UBOReturnsGraphDto uboReturnsGraphDto);
     SectorResponseDto getSectorGraph(SectorRequestDto sectorRequestDto);

}
