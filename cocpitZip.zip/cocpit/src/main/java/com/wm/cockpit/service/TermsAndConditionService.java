package com.wm.cockpit.service;

import com.wm.cockpit.dto.TermsAndConditionsDto;
import com.wm.cockpit.response.GenericResponse;

public interface TermsAndConditionService {
    GenericResponse save(TermsAndConditionsDto dto);

    GenericResponse disableTermsAndConditions(Long id);

    GenericResponse getActiveTermsAndConditions();

}
