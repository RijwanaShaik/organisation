package com.wm.cockpit.service;


import com.wm.cockpit.dto.ScenarioSettingsDto;
import com.wm.cockpit.response.GenericResponse;

import java.util.List;

public interface ScenarioSettingsService {
    GenericResponse saveOrUpdate(ScenarioSettingsDto dto);
    List<ScenarioSettingsDto> getScenarioSettingsList();
    GenericResponse getByScenarioSettingsId(long id);
    GenericResponse delete(Long id);
    GenericResponse getScenarioSettingsByCustomer(Long customerId);
}
