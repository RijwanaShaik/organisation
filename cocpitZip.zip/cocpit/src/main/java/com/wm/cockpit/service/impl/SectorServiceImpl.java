package com.wm.cockpit.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.wm.cockpit.entity.ScenarioSettings;
import com.wm.cockpit.repositary.AssetRepository;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.utils.DtoUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.wm.cockpit.dto.SectorDto;
import com.wm.cockpit.entity.Sector;
import com.wm.cockpit.repositary.SectorRepository;
import com.wm.cockpit.service.SectorService;

@Service
public class SectorServiceImpl implements SectorService {

    @Autowired
    private SectorRepository sectorRepository;
    @Autowired
    private AssetRepository assetRepository;

    @Override
    public String createSector(SectorDto sectorDto) {
        Sector sector = new Sector();
        if (!DtoUtils.isEmpty(sectorDto.getName())) {
            sector.setName(sectorDto.getName());
        }
        sector.setDescription(sectorDto.getDescription());

        sectorRepository.save(sector);
        return "Sector Created Successfully...";
    }

    @Override
    public String updatedSectorById(SectorDto sectorDto) throws Exception {
        Sector sector;
        if (sectorDto != null) {
            Optional<Sector> optional = sectorRepository.findById(sectorDto.getId());
            if (optional.isPresent()) {
                sector = optional.get();
                if (sectorDto.getName() != null) {
                    sector.setName(sectorDto.getName());
                }
                if (sectorDto.getDescription() != null) {
                    sectorDto.setDescription(sectorDto.getDescription());
                }
                sectorRepository.save(sector);
            }
        }
        return " Sector Updated Successfully...";
    }

    @Override
    public String deletedSectorById(long id) throws Exception {
        Optional<Sector> sector = sectorRepository.findById(id);
        if (sector.isPresent()) {
            sectorRepository.deleteById(id);
            return "Sector Is deleted is Successfully .......";
        } else {
            return " Id = %id is Not Found... ";
        }
    }

    @Override
    public List<Sector> getAllSector() {
        List<Sector> sectors = new ArrayList<Sector>();
        sectors = sectorRepository.findAll();
        return sectors;
    }

    @Override
    public Sector getSectorById(long id) throws Exception {
        Optional<Sector> optional = sectorRepository.findById(id);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new Exception("Sector Id %id Is Not Found.....");
        }
    }

    @Override
    public GenericResponse getAllRestSectors() {
        List<SectorDto> sectorDtoList = sectorRepository.findAll().stream().map(this::mapSectorToSectorDto).toList();
        return new GenericResponse(HttpStatus.OK, sectorDtoList);
    }

    public SectorDto mapSectorToSectorDto(Sector sector) {
        SectorDto sectorDto = new SectorDto();
        sectorDto.setId(sector.getId());
        sectorDto.setName(sector.getName());
        // sectorDto.setDescription(sector.getDescription());
        return sectorDto;
    }
}
