package com.wm.cockpit.dto;

import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LiquidityGraphDto {

  private double liquidityRatio;
  private double potentialLiquidityRatio;
  private double percentageLiquidity;
  private double totalWealth;
  private double standardLiquidityUnder1M;
  private double standardLiquidity1MTo5M;
  private double standardLiquidity5MTo10M;
  private double standardLiquidity10MTo100M;
  private double standardLiquidity100MTo500M;
  private double standardLiquidityAbove500M;
  private List<String> response=new ArrayList<>();

}
