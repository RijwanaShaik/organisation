package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wm.cockpit.entity.Liability;

import java.util.List;

@Repository
public interface LiabilityRepository extends JpaRepository<Liability, Long>{

  List<Liability> findByCustomerIdAndIsDeletedFalse(Long id);

  Liability findBySpecificAssetId(Long id);

    Long countByName(String name);

  long countByNameAndCustomer(String name, Customer customer);
}
