package com.wm.cockpit.service;

import java.util.List;

import com.wm.cockpit.dto.SectorDto;
import com.wm.cockpit.entity.Sector;
import com.wm.cockpit.response.GenericResponse;

public interface SectorService {

	String createSector(SectorDto sectorDto);

	String updatedSectorById(SectorDto sectorDto) throws Exception;

	String deletedSectorById(long id) throws Exception;

	List<Sector> getAllSector();
	
	Sector getSectorById(long id) throws Exception;

	GenericResponse getAllRestSectors();
}


