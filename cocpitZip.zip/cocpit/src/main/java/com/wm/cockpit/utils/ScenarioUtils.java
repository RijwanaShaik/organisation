package com.wm.cockpit.utils;

import com.wm.cockpit.dto.ScenarioHeaderDto;
import com.wm.cockpit.dto.ScenarioItemDto;
import com.wm.cockpit.entity.ScenarioHeader;
import com.wm.cockpit.entity.ScenarioItem;

public class ScenarioUtils {

        public static ScenarioHeaderDto ScenarioHeaderConvertEntityToDto(ScenarioHeader scenarioHeader) {
            ScenarioHeaderDto scenarioHeaderDto = new ScenarioHeaderDto(scenarioHeader);
            scenarioHeaderDto.setId(scenarioHeader.getId());
            scenarioHeaderDto.setName(scenarioHeader.getName());
            scenarioHeaderDto.setCustomer(scenarioHeader.getCustomer().getId());
            return scenarioHeaderDto;
        }

        public static ScenarioItemDto ScenarioItemConvertEntityToDto(ScenarioItem scenarioItem) {
            ScenarioItemDto scenarioItemDto = new ScenarioItemDto(scenarioItem);
            scenarioItemDto.setId(scenarioItem.getId());
            scenarioItemDto.setFamilyHoldingExchange(scenarioItem.getFamilyHoldingExchange());
            scenarioItemDto.setReferenceCurrencyExchange(scenarioItem.getReferenceCurrencyExchange());
            scenarioItemDto.setStandardDeviation(scenarioItem.getStandardDeviation());
            scenarioItemDto.setDebtSwapSource(scenarioItem.getDebtSwapSource().getId());
            scenarioItemDto.setDebtSwapValue(scenarioItem.getDebtSwapValue());
            scenarioItemDto.setDebtSwapTarget(scenarioItem.getDebtSwapTarget().getId());
            scenarioItemDto.setLiquidityEventValue(scenarioItem.getLiquidityEventValue());
            scenarioItemDto.setLiquidityEventCurrency(scenarioItem.getLiquidityEventCurrency().getId());
            scenarioItemDto.setLiquidityEventInYear(scenarioItem.getLiquidityEventInYear());
            scenarioItemDto.setLeveragePurchaseWorth(scenarioItem.getLeveragePurchaseWorth());
            scenarioItemDto.setLeveragePurchaseCurrency(scenarioItem.getLeveragePurchaseCurrency().getId());
            scenarioItemDto.setScenarioHeader(scenarioItem.getScenarioHeader().getId());
            return scenarioItemDto;
        }
    }

