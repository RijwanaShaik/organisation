package com.wm.cockpit.service.impl.validations;

import com.wm.cockpit.dto.AssetDto;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.entity.Customer;
import com.wm.cockpit.entity.Sector;
import com.wm.cockpit.repositary.CountryRepository;
import com.wm.cockpit.repositary.CurrencyRepository;
import com.wm.cockpit.repositary.CustomerRepository;
import com.wm.cockpit.repositary.SectorRepository;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class AssetValidations {
    private final CountryRepository countryRepositary;

    public AssetValidations(CountryRepository countryRepositary) {
        this.countryRepositary = countryRepositary;
    }

    public void assetValidateDbDependencies(SectorRepository sectorRepository, AssetDto assetDto, CustomerRepository customerRepository, CurrencyRepository currencyRepository) {

        List<String> errors = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        Optional<Sector> sector = sectorRepository.findById(assetDto.getId());
        if (sector.isEmpty() || sector == null) {
            errors.add("Invalid Sector  Id ");
        } else {
            map.put("sector", sector.get());
        }
        Optional<Customer> customer = customerRepository.findById(assetDto.getCustomerId());
        if (customer.isEmpty() || customer == null) {
            errors.add("Invalid Sector Id ");
        } else {
            map.put("customer", customer.get());
        }
        Optional<Currency> currency = currencyRepository.findById(assetDto.getCurrencyId());
        if (currency.isEmpty() || currency == null) {
            errors.add("Invalid Currency Id");
        } else {
            map.put("currency", currency);
        }
//        Country country = countryRepositary.findByInventoryIds(assetDto.getCountryOfLegalExposure());
//        if(country == null){
//            errors.add("Invalid Countriwes Id");
//        }
    }
}
