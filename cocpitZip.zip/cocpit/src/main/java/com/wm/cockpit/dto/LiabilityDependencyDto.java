package com.wm.cockpit.dto;

import com.wm.cockpit.entity.Liability;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class LiabilityDependencyDto {

    private long id;

    private float share;

    private Long liabilityId;
    private Long dependencyId;
}
