package com.wm.cockpit.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UBOReturnsGraphDto {
    private double threshold;
    private double averageCashReturn;
    private double averageAccuredReturn;
    private List<UBODto> ubosCashReturn =new ArrayList<>();
    private List<UBODto> ubosAccuredReturn= new ArrayList<>();
    @JsonIgnore
    private List<String> averageCashList=new ArrayList<>();
    @JsonIgnore
    private List<String> averageAccuredList=new ArrayList<>();
    private List<String> responseList=new ArrayList<>();
}
