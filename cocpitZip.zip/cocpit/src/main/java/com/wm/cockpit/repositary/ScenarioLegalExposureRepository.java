package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.ScenarioLegalExposure;
import com.wm.cockpit.entity.ScenarioSettings;
import io.lettuce.core.dynamic.annotation.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public interface ScenarioLegalExposureRepository extends JpaRepository<ScenarioLegalExposure,Long> {

    void deleteScenarioSettingsById(Long id);
    @Modifying
    @Query("update ScenarioLegalExposure p set is_deleted = true where p.scenarioSettings.id = :id")
    void isDeleteScenarioSettingsById(@Param("id") long id);
    List<ScenarioLegalExposure> findByScenarioSettingsId(Long id);
}
