package com.wm.cockpit.service;

import java.util.List;

import com.wm.cockpit.dto.LiabilityDependencyDto;
import com.wm.cockpit.entity.LiabilityDependency;

public interface LiabilityDependencyService {

	String createLiabilityDependency(LiabilityDependencyDto liabilityDependencyDto);

	List<LiabilityDependency> getAllLiabilityDependency();
	
	LiabilityDependency updatedLiabilityDependencyById(LiabilityDependencyDto liabilityDependencyDto) throws Exception;
	
	
}
