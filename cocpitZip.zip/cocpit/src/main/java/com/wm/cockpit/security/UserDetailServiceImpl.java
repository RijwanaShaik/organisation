package com.wm.cockpit.security;

import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.repositary.AppUserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserDetailServiceImpl implements UserDetailsService {

    @Autowired
    AppUserRepo appUserRepo;

    @Override
    @Transactional
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        AppUser appUser = appUserRepo.findByEmail(email).orElseThrow(() ->
                new UsernameNotFoundException("user not found with this username:" + email));

        return LoggedInUser.build(appUser);
    }
}