package com.wm.cockpit.repositary;

import com.wm.cockpit.enums.Role;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wm.cockpit.entity.AppUser;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface AppUserRepo extends JpaRepository<AppUser, Long> {
    AppUser findByUserName(String username);

    Optional<AppUser> findByEmail(String email);

    boolean existsByEmail(String email);

    List<AppUser> findAllByCreatedBy(Long id);

    Page<AppUser> findAllByRoleAndSearchKeyContainingIgnoreCase(Role role, String searchKey, PageRequest pageRequest);

    Page<AppUser> findAllByRoleAndCreatedBy(Role role, Long id, PageRequest pageRequest);

    Page<AppUser> findAllByRoleAndCreatedByAndSearchKeyContainingIgnoreCase(Role role, Long id, String searchKey, PageRequest pageRequest);
    Page<AppUser> findAllByRole(Role role, Pageable pageable);

    Page<AppUser> findAllByRoleAndSearchKeyContainingIgnoreCase(Role role, String searchKey, Pageable pageRequest);

    List<AppUser> findAllByCreatedByAndRole(Long id, Role role);

    List<AppUser> findAllByCreatedByAndIsActiveAndIsDeleted(Long createdUser, Boolean isActive, Boolean isDeleted);

    List<AppUser> findAllByCreatedByAndRoleAndIsActive(Long id, Role role, Boolean isActive);

    boolean existsByEmailIgnoreCase(String lowercaseEmail);
@Modifying
@Transactional
    @Query("UPDATE AppUser u SET u.isTermsAndConditionsAccepted = true WHERE u.id = :userId")
    int updateIsTermsAndConditionsAccepted(@Param("userId") Long userId);


}
