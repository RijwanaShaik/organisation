package com.wm.cockpit.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wm.cockpit.dto.AppUserDto;
import com.wm.cockpit.entity.AppUser;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class AppUserUtils {

	static final ObjectMapper mapper = new ObjectMapper();

	public static AppUser convertDtoToEntity(AppUserDto appUserDto) {
		AppUser appUser = new AppUser();
		appUser.setId(appUserDto.getId());
		appUser.setUserName(appUserDto.getUserName());
		appUser.setEmail(appUserDto.getEmail());
		appUser.setPhoneNumber(appUserDto.getPhoneNumber());
		//appUser.setPassword(new BCryptPasswordEncoder().encode(appUserDto.getPassword()));
		appUser.setRole(appUserDto.getRole());

		return appUser;
	}

	public static AppUserDto convertEntityToDto(AppUser appUser) {
		AppUserDto appUserDto = new AppUserDto(appUser);
		appUserDto.setId(appUser.getId());
		appUserDto.setUserName(appUser.getUserName());
		appUserDto.setEmail(appUser.getEmail());
		//appUserDto.setPassword(appUser.getPassword());
		appUserDto.setPhoneNumber(appUser.getPhoneNumber());
		appUserDto.setRole(appUser.getRole());
		return appUserDto;
	}

//	public static CustomerDto convertEntityToDto(Customer customer) {
//
//		CustomerDto customerDto = new CustomerDto(customer);
//		customerDto.setId(customer.getId());
//		customerDto.setName(customer.getName());
//		customerDto.setPhoneNumber(customer.getPhoneNumber());
//		customerDto.setCurrencyDto(currency);
//
//		return customerDto;
//	}
//
//	public static Customer convertDtoToEntity(CustomerDto customerDto) {
//		Customer customer = new Customer();
//		customer.setId(customerDto.getId());
//		customer.setName(customerDto.getName());
//		customer.setPhoneNumber(customerDto.getPhoneNumber());
//		customer.setCurrency(customerDto.getCurrency());
//
//		return customer;
//	}

	public static String getStringFromObject(Object object) {
		if (object != null) {
			try {
				return mapper.writeValueAsString( object );
			} catch (JsonProcessingException e) {
				e.printStackTrace();
				return "";
			}
		}
		return "";
	}
}
