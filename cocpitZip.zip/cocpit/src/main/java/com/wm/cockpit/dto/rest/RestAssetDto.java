package com.wm.cockpit.dto.rest;

import com.wm.cockpit.dto.*;
import com.wm.cockpit.enums.DirectLiquidity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class RestAssetDto {

    private long id;
    private String name;
    private long value;
    private Long currencyId;
    private DirectLiquidity directLiquidity;
    private float indirectLiquidity;
    private float cashDistributionRate;
    private float accruedDistributionRate;
    private Long  countryOfEconomicExposure;
    private List<CountryDto> countryOfLegalExposure =new ArrayList<>();
    private Boolean isFamilyHolding;
    private Long existingLending;
    private double existingValue;
    private Long specificLiability;
    private Long customerId;
    private Long sectorId;
    private List<AssetDependencyDto> assetDependencyDtos = new ArrayList<>();

    CurrencyDto currencyDto;
    private List<RestAssetDependencyDto> assetDependency = new ArrayList<>();
    private SectorDto sectorDto;

    private RestExistingLandingDto existingLendingVal;

    private LiabilityDto specificLiabilityDto;

    private CountryDto countryOfEconomicExposureInfo;

    private List<Long> fileIds = new ArrayList<>();

    private List<FileUploadDto> fileDtos = new ArrayList<>();

    private String climateChangeExposure;

}
