package com.wm.cockpit.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ExchangeCurrencyRateMsgDto {
    private Boolean success;
    private long timestamp ;
    private String base;
    private Timestamp date;

    @JsonProperty("rates")
    private HashMap<String,Float> rates;

    public void setRates(String key, Float value) {
        this.setRates(key,value);
    }
}
