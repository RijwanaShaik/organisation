package com.wm.cockpit.service.impl;

import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import com.wm.cockpit.dto.AppUserRequest;
import com.wm.cockpit.dto.LoginResponseDto;
import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.entity.TermsAndCondition;
import com.wm.cockpit.exceptions.BadRequestException;
import com.wm.cockpit.exceptions.CustomAuthenticationException;
import com.wm.cockpit.exceptions.IdNotFoundException;
import com.wm.cockpit.repositary.TermsAndConditionRepo;
import com.wm.cockpit.security.JwtUtils;
import com.wm.cockpit.security.LoggedInUser;
import com.wm.cockpit.utils.PasswordUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.http.HttpStatus;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.wm.cockpit.dto.MailDto;
import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.entity.Otp;
import com.wm.cockpit.enums.OtpStatus;
import com.wm.cockpit.repositary.AppUserRepo;
import com.wm.cockpit.repositary.OtpRepository;
import com.wm.cockpit.service.OtpService;
import com.wm.cockpit.utils.GenerateOtp;

import javax.annotation.Resource;

@Service
public class OtpServiceImpl implements OtpService {

	@Autowired
	private OtpRepository otpRepository;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private AppUserRepo appUserRepo;

	@Value("${cockpit.otp.length}")
	private int otpLength;
	@Value("${spring.mail.username}")
	private  String from;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtUtils jwtUtils;

	@Resource(name = "redisTemplate")
	private HashOperations<String, String, String> hashOperations;

	@Autowired
	private TermsAndConditionRepo termsAndConditionRepo;

	@Override
	public ApiResponse sentOtp(AppUserRequest appUserRequest) {
		AppUser appUser = null;
			Optional<AppUser> user = appUserRepo.findByEmail(appUserRequest.getUsername());
			LoginResponseDto loginResponse = null;

			if (user.isPresent()  && passwordEncoder.matches(PasswordUtils.passwordDecode(appUserRequest.getPassword()),user.get().getPassword())) {
					appUser = user.get();
					loginResponse = createLoginResponse(appUser, appUserRequest);
					updateTermsAndConditions(appUserRequest, appUser, loginResponse);
					return new ApiResponse(HttpStatus.OK, "Send Otp Successfully", loginResponse);

				}


			/*	mailDto.setFrom(from);
			mailDto.setTo(to);
			mailDto.setSubject("Email Verification");
			mailDto.setApp_user_id(user.get().getId());
			mailDto.setBody("please check this for verification");*/
//			String oneTimePwd = GenerateOtp.generateOTP(otpLength);
			//	sendMail(mailDto, oneTimePwd);

		 else {
			throw new BadRequestException("Please enter valid credentials");
		}
	}

	private void saveOtp(String oneTimePwd, AppUser user) {
		Otp otp = new Otp();
		otp.setAppUser(user);
//		otp.setAppUser(appUserRepo.findById(mailDto.getApp_user_id()).get());
		otp.setOtp(oneTimePwd);
		otp.setStatus(OtpStatus.ACTIVE);
		otpRepository.save(otp);
	}

	@Override
	public ApiResponse otpValidation(LoginResponseDto user, String userOtp, AppUser appUser) {

		List<Otp> otps = otpRepository.findByAppUserEmailOrderByCreatedOnDesc(user.getEmail());

		if (otps.size() > 0) {
			// Taking first/latest OTP
			Otp latestOtp = otps.get(0);
			if (latestOtp.getStatus().equals(OtpStatus.ACTIVE) && latestOtp.getOtp().equals(userOtp)) {
				inactiveOtp(latestOtp.getId());
				return new ApiResponse(HttpStatus.OK, "Valid OTP", user);
			} else {
				return new ApiResponse(HttpStatus.OK, "Invalid OTP");
			}
		} else {
			return new ApiResponse(HttpStatus.OK, "No OTP has been Unavailable");
		}

	}

	@Override
	public List<Otp> getAllOtps() {
		return otpRepository.findAll();
	}


	public Integer inactiveOtp(Long id) {
		return otpRepository.updateOtpStatus(OtpStatus.VERIFIED, id);
	}

	private Authentication authenticateUser(AppUserRequest appUserRequest) {
		return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
				appUserRequest.getUsername(),
				PasswordUtils.passwordDecode(appUserRequest.getPassword())
		));
	}

	private LoginResponseDto createLoginResponse( AppUser appUser, AppUserRequest appUserRequest) {
		LoginResponseDto loginResponse = new LoginResponseDto();
//		loginResponse.setId(appUser.getId());
//		loginResponse.setUserName(appUser.getUserName());
//		loginResponse.setPhoneNumber(appUser.getPhoneNumber());
//		loginResponse.setEmail(appUser.getEmail());
//		loginResponse.setRole(appUser.getRole());
//		loginResponse.setAuth_token(jwt);
//		loginResponse.setStatus("Active");
		loginResponse.setOtp(GenerateOtp.generateOTP(otpLength));
		saveOtp(loginResponse.getOtp(), appUser);
		loginResponse.setIsFirstTimeLogin(appUser.getIsFirstTimeLogin());

		return loginResponse;
	}

	private void updateTermsAndConditions(AppUserRequest appUserRequest, AppUser appUser, LoginResponseDto loginResponse) {
		if (appUser != null) {
//			if (appUserRequest.getIsTermsAndConditionsAccepted() != null) {
				Optional<TermsAndCondition> optional = termsAndConditionRepo.findById(appUserRequest.getTermsAndConditionId());
				if (optional.isPresent()) {
//					appUser.setTermsAndCondition(optional.get());
//					appUser.setIsTermsAndConditionsAccepted(appUserRequest.getIsTermsAndConditionsAccepted());
//					appUserRepo.save(appUser);
					loginResponse.setIsTermsAndConditionsAccepted(appUser.getIsTermsAndConditionsAccepted());
					loginResponse.setTermsAndConditionsId(optional.get().getId());
				} else {
					throw new IdNotFoundException("No Terms & Conditions found with the given id!!");
				}
			}
		}

	}


