package com.wm.cockpit.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ConvertCurrency {
    private float currencyCode;
    private float value;
    private float targetCurrency;
}
