package com.wm.cockpit.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class  AppUserRequest {

    private String username;
    private String password;
    private String otp;
    private Long termsAndConditionId;
    private Boolean isTermsAndConditionsAccepted;
}
