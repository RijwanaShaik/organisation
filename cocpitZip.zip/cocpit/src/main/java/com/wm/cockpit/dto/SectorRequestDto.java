package com.wm.cockpit.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SectorRequestDto {
    private List<SectorGraphDto> sectorGraphDtoList;
    private double thresholdValue;
    private double countryOrSectorThreshold;
    private List<String> responseMessages =new ArrayList<>();
}
