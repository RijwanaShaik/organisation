package com.wm.cockpit.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FileUploadDto {

    private Long id;

    private String name;

    private String originalFileName;

    private String type;

    private Integer fileSizeInBytes;

    private Long fileSize;

    private String downloadUrl;

    private String previewUrl;

    private byte[] fileData;
}
