package com.wm.cockpit.entity;

import javax.persistence.*;

import com.wm.cockpit.dto.AssetDto;
import com.wm.cockpit.dto.CurrencyDto;
import com.wm.cockpit.dto.CustomerDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

@SuppressWarnings("serial")
@Entity
@Table(name = "mt_currency")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class Currency extends BaseEntity {
    @OneToOne
    private Country countryCode;
    @Column(nullable = false)
    private String currencyCode;

    private boolean isUiCode = false;
}
