package com.wm.cockpit.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AssetDependencyDto {
    private long id;
    private float share;
    private Long assetId;
    private Long dependencyId;

   }
