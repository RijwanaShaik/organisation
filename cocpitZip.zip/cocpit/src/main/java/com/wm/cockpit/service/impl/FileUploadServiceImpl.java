package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.dto.FileRequestDto;
import com.wm.cockpit.dto.FileUploadDto;
import com.wm.cockpit.entity.FileUpload;
import com.wm.cockpit.exceptions.BadRequestException;
import com.wm.cockpit.exceptions.IdNotFoundException;
import com.wm.cockpit.repositary.FileUploadRepository;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.FileUploadService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.util.Optional;
import java.util.UUID;

@Service
public class FileUploadServiceImpl implements FileUploadService {

    private static final Logger logger = LoggerFactory.getLogger(FileUploadServiceImpl.class);

    @Autowired
    private FileUploadRepository fileUploadRepo;

    @Autowired
    Environment environment;
    @Override
    @Transactional
    public GenericResponse uploadFile(MultipartFile file, String fileName) {
        if (file != null && !file.isEmpty()) {
            logger.info(" file size " + file.getSize());
            if (file.getSize() > 10485760) {
                throw new BadRequestException("File size should not exceed more than 10MB");
            }
            try {
                FileUpload fileUpload = new FileUpload();

                fileUpload.setName(fileName);
                fileUpload.setType(file.getContentType());
                fileUpload.setFileSizeInBytes(file.getBytes().length);
                fileUpload.setFileData(file.getBytes());
                fileUpload.setFileSize(file.getSize());
                fileUpload.setOriginalFileName(file.getOriginalFilename());
                FileUpload savedFile = fileUploadRepo.save(fileUpload);
                return new GenericResponse(HttpStatus.OK, "File Uploaded successfully", entityToDto(savedFile));

            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        } else throw new BadRequestException("File is empty!!");
    }

    @Override
    public FileUploadDto getFileById(Long fileId) {
        Optional<FileUpload> optional = fileUploadRepo.findById(fileId);
        if(optional.isPresent()){
            FileUpload fileUpload = optional.get();
            FileUploadDto dto = new FileUploadDto();
            dto.setId(fileUpload.getId());
            dto.setName(fileUpload.getName());
            dto.setType(fileUpload.getType());
            dto.setFileSizeInBytes(fileUpload.getFileSizeInBytes());
            dto.setFileData(fileUpload.getFileData());
            return dto;
        }
        else throw new IdNotFoundException("No File found with given id!!");
    }

    @Override
    public ApiResponse deleteFileById(Long fileId) {
        Optional<FileUpload> fileUpload = fileUploadRepo.findById(fileId);
        if(fileUpload.isPresent()){
            fileUploadRepo.delete(fileUpload.get());
            return new ApiResponse(HttpStatus.OK, "File deleted successfully");
        }else throw new IdNotFoundException("No File Found with given id!!");
    }
    @Override
    public FileUploadDto entityToDto(FileUpload savedFile) {
        FileUploadDto dto = new FileUploadDto();
        dto.setId(savedFile.getId());
        dto.setName(savedFile.getName());
        if(savedFile.getOriginalFileName()!=null) {
            dto.setOriginalFileName(savedFile.getOriginalFileName());
        }
        dto.setType(savedFile.getType());
        dto.setFileSizeInBytes(savedFile.getFileSizeInBytes());
        dto.setFileSize(savedFile.getFileSize());
        String fileDownloadUrl = "/api/v1/file/get-by-id/"+savedFile.getId();
        String filePreviewUrl = "/api/v1/file/preview/"+savedFile.getId();
        dto.setDownloadUrl(fileDownloadUrl);
        dto.setPreviewUrl(filePreviewUrl);
        dto.setFileData(savedFile.getFileData());
        return dto;
    }
    @Override
    @Transactional
    public GenericResponse getFileByName(String fileName) {
        if (fileName != null && !fileName.isEmpty()) {
            Optional<FileUpload> optional = fileUploadRepo.findTop1ByNameOrderByCreatedOnDesc(fileName);
            if (optional.isPresent()) {
                FileUpload fileUpload = optional.get();
                FileUploadDto dto = new FileUploadDto();
                dto.setId(fileUpload.getId());
                dto.setName(fileUpload.getName());
                dto.setType(fileUpload.getType());
                dto.setFileSizeInBytes(fileUpload.getFileSizeInBytes());
                dto.setFileData(fileUpload.getFileData());
                String fileDownloadUrl = "/api/v1/file/get-by-id/"+fileUpload.getId();
                String filePreviewUrl = "/api/v1/file/preview/"+fileUpload.getId();
                dto.setDownloadUrl(fileDownloadUrl);
                dto.setPreviewUrl(filePreviewUrl);
                return new GenericResponse(HttpStatus.OK, "File is founded",dto);
            } else return new GenericResponse(HttpStatus.NOT_FOUND, "File not found");
        } else return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide valid file name");
    }

}
