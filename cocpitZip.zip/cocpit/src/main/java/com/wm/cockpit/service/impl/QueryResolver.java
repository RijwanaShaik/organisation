package com.wm.cockpit.service.impl;

import java.util.List;

import com.wm.cockpit.common.dto.GetAdminDto;
import com.wm.cockpit.dto.CurrencyResponseDto;
import com.wm.cockpit.dto.CustomerDto;
import com.wm.cockpit.dto.PaginationResponse;
import com.wm.cockpit.entity.*;
import com.wm.cockpit.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Component;

@Component
public class QueryResolver {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private AssetService assetService;

    @Autowired
    private LiabilityService liabilityService;

    @Autowired
    private SectorService sectorService;

    @Autowired
    private LiabilityDependencyService liabilityDependencyService;

    @Autowired
    private CountryService countryService;

    @Autowired
    private CurrencyService currencyService;
    @Autowired
    private DependencyService dependencyService;
    @Autowired
    private AssetDependencyService assetDependencyService;
    @Autowired
    private LegalExposureService legalExposureService;

    @Autowired
    private ExchangeRateService exchangeRateService;

    @Autowired
    private OtpService otpService;

    @Autowired
    private AppUserService appUserService;

    @QueryMapping(name = "getCustomerById")
    public Customer getCustomerById(@Argument long id) {
        return customerService.getCustomerById(id);
    }

    @QueryMapping(name = "getCustomerByName")
    public Customer getCustomerByName(@Argument String name) {
        return customerService.getCustomerByName(name);
    }

    @QueryMapping(name = "getAllCustomer")
    public List<CustomerDto> getAllCustomer() throws Exception {
        return customerService.getAllCustomer();
    }

    @QueryMapping(name = "getAssetById")
    public Asset getAssetById(@Argument(name = "id") long id) throws Exception {
        return assetService.getAssetById(id);
    }

    @QueryMapping(name = "getAssetByCustomerId")
    public Asset getAssetsByCustomerId(@Argument(name = "id") long id) {
        return assetService.getAssetByCustomerId(id);
    }

    @QueryMapping(name = "getAllAssets")
    public List<Asset> getAllAssets() throws Exception {
        return assetService.getAllAssets();
    }

    @QueryMapping(name = "getAllLiabilities")
    public List<Liability> getAllLiabilities() {
        return liabilityService.getAllLiabilities();
    }

    @QueryMapping(name = "getLiabilityById")
    public Liability getLiabilityById(@Argument long id) throws Exception {
        return liabilityService.getLiabilityById(id);
    }

    @QueryMapping(name = "getSectorById")
    public Sector getSectorById(@Argument long id) throws Exception {
        return sectorService.getSectorById(id);
    }

    @QueryMapping(name = "getAllSector")
    public List<Sector> getAllSector() {
        return sectorService.getAllSector();
    }

    @QueryMapping(name = "getAllLiabilityDependency")
    public List<LiabilityDependency> getAllLiabilityDependency() {
        return liabilityDependencyService.getAllLiabilityDependency();
    }

    @QueryMapping(name = "getAllCountries")
    public List<Country> getAllCountries() {
        return countryService.getAllCountries();
    }

    @QueryMapping(name = "getAllCurrencies")
    public List<Currency> getAllCurrencies() {
        return currencyService.getAllCurrencies();
    }

    @QueryMapping(name = "getAllDependencies")
    public List<Dependency> getAllDependencies() {
        return dependencyService.getAllDependencies();
    }

    @QueryMapping(name = "getAllAssetDependencies")
    public List<AssetDependency> getAllAssetDependencies() {
        return assetDependencyService.getAllAssetDependencies();
    }

    @QueryMapping(name = "getAllEconomicExposure")
    public List<LegalExposure> getAllEconomicExposure() {
        return legalExposureService.getAllEconomicExposure();
    }

    @QueryMapping(name = "getAllExchangeRates")
    public List<ExchangeRate> getAllExchangeRates() throws Exception {
        return exchangeRateService.getAllExchangeRates();
    }
    @QueryMapping(name = "getAllUniqueCurrencies")
    public List<Currency> getAllUniqueCurrencies() {
        return currencyService.getAllUniqueCurrencies();
    }

    @QueryMapping(name = "getAllOtps")
    public List<Otp> getAllOtps(){
        return otpService.getAllOtps();
    }

   /* @QueryMapping("getAllAdmins")
    public PaginationResponse getAllAdmins(@Argument(name="input") GetAdminDto getAdminDto){
        return appUserService.getAllAdmins(getAdminDto);
    }*/
}