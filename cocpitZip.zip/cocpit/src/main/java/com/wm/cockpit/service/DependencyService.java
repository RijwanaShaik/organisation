package com.wm.cockpit.service;

import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.dto.DependencyDto;
import com.wm.cockpit.entity.Dependency;

import java.util.List;

public interface DependencyService {


    ApiResponse createDependency(DependencyDto dependencyDto) throws Exception;

    String updateDependencyById(DependencyDto dependencyDto) throws Exception;

    String deletedDependencyById(long id);

    List<Dependency> getAllDependencies();

}
