package com.wm.cockpit.service;

import com.wm.cockpit.entity.ExchangeRate;

import java.util.List;

public interface ExchangeRateService {
    List<ExchangeRate> getAllExchangeRates() throws Exception;
}