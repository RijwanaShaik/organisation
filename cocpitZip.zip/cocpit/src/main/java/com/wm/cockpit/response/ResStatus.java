package com.wm.cockpit.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class ResStatus
{
    private int code;

    private String message;

    public ResStatus(int code, String message){
        this.code = code;
        this.message = message;
    }

}
