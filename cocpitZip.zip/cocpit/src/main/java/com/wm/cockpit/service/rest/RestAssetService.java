package com.wm.cockpit.service.rest;

import com.wm.cockpit.common.dto.AssetReq;
import com.wm.cockpit.common.dto.AssetsDto;
import com.wm.cockpit.dto.rest.RestAssetDto;
import com.wm.cockpit.entity.Asset;
import com.wm.cockpit.response.GenericResponse;

public interface RestAssetService {
    GenericResponse save(RestAssetDto dto);

    GenericResponse updateById(RestAssetDto dto);

    GenericResponse deleteById(long id);

    GenericResponse getById(long id);

    GenericResponse countryAssets();
}
