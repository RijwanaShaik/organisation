package com.wm.cockpit.dto;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class Constants {

  //  public static final String ABSTRACT_API_EXCHANGE_API = "curl--requestGET'https://api.apilayer.com/fixer/latest?base=USD&symbols='--header'apikey:GsvV0NCn5Pbny2yWuVOrobww9yvifxv5'";




    public  static URL CountryExchangeRates() throws URISyntaxException, MalformedURLException {
        URI uri = new URI(
                "http",
                "curl --request GET 'https://api.apilayer.com/fixer/latest?base=USD&symbols=' --header 'apikey:GsvV0NCn5Pbny2yWuVOrobww9yvifxv5'",
                null);
        URL url = uri.toURL();
        return url;
    }
}

