package com.wm.cockpit.service.rest;

import com.wm.cockpit.common.dto.AssetsDto;
import com.wm.cockpit.dto.rest.LiabilityRestDto;
import com.wm.cockpit.dto.rest.RestAssetDto;
import com.wm.cockpit.response.GenericResponse;

public interface RestLiabilityService {
    GenericResponse save(LiabilityRestDto dto);


  GenericResponse delete(Long id);

  GenericResponse getDataByCustomerId(Long id);

  GenericResponse getDataByLiabilityId(Long id);
}
