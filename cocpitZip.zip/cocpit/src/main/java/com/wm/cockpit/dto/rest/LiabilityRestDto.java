package com.wm.cockpit.dto.rest;

import com.wm.cockpit.dto.AssetDependencyDto;
import com.wm.cockpit.dto.CountryDto;
import com.wm.cockpit.dto.LiabilityDependencyDto;
import com.wm.cockpit.enums.DirectLiquidity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class LiabilityRestDto {

  private long id;
  private String name;
  private long value;
  private double costOfDebt;
  private Long countryOfLegalExposure;

  private Long currencyId;
  private DirectLiquidity directLiquidity;
  private float indirectLiquidity;
  private float cashDistributionRate;
  private float accruedDistributionRate;
//  private Long  countryOfEconomicExposure;
  private Boolean isFamilyHolding;
  private Long existingLending;
  private double existingValue;
  private Long specificLiability;
  private Long customer;
  private Long sectorId;

  private Long specificAsset;

  private List<LiabilityDependencyDto> liabilityDependencyDto;

  List<Long> fileIds = new ArrayList<>();

}
