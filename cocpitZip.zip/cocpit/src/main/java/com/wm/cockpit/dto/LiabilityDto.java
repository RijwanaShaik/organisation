package com.wm.cockpit.dto;

import java.util.ArrayList;
import java.util.List;

import com.wm.cockpit.entity.Country;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.entity.LiabilityDependency;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LiabilityDto {

    private long id;

    private String name;

    private double value;

    private Long currencyId;

    private long customer;
    private double costOfDebt;

    private Long countryOfLegalExposure;

    private Long existingLending;
    private double existingValue;

    private Long specificAsset;

    private List<LiabilityDependencyDto> liabilityDependencyDto;

    private List<Long> fileIds = new ArrayList<>();
}
