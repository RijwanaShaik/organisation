package com.wm.cockpit.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Setter
@Getter
@NoArgsConstructor
public class GenericResponse {

    private Object data;

    private ResStatus status;

    private HttpStatus statusCode;

    private String message;

    public GenericResponse(HttpStatus statusCode, String msg){
        this.status = new ResStatus(statusCode.value(), msg);
        this.statusCode = statusCode;
        this.message=msg;
    }

    public GenericResponse(HttpStatus statusCode, Object data){
        this.status = new ResStatus(statusCode.value(), null);
        this.data = data;
    }

    public GenericResponse(HttpStatus statusCode, String msg,  Object data) {
        this.statusCode = statusCode;
        this.data = data;
        this.status = new ResStatus(statusCode.value(), msg);
    }

}

