package com.wm.cockpit.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllAssets {

    private String name;

    private Double values;

}
