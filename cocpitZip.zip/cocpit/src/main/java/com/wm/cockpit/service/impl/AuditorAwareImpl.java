package com.wm.cockpit.service.impl;

import com.wm.cockpit.security.LoggedInUser;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

public class AuditorAwareImpl implements AuditorAware<Long> {

    @Override
    public Optional<Long> getCurrentAuditor() {
        Long userId = null;
        if (SecurityContextHolder.getContext().getAuthentication() != null) {
            userId = ((LoggedInUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getId();
        }
        return Optional.ofNullable(userId);
    }
}
