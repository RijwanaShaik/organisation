package com.wm.cockpit.validation;

import graphql.ErrorClassification;
import graphql.ErrorType;
import graphql.GraphQLError;
import graphql.validation.ValidationErrorType;

import org.apache.commons.lang3.StringUtils;
import org.springframework.graphql.ResponseError;
import org.springframework.graphql.server.WebGraphQlInterceptor;
import org.springframework.graphql.server.WebGraphQlRequest;
import org.springframework.graphql.server.WebGraphQlResponse;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ErrorInterceptor implements WebGraphQlInterceptor {

    @Override
    public Mono<WebGraphQlResponse> intercept(WebGraphQlRequest request, Chain chain) {
        return chain.next(request)
                .map(response -> {
                    List<GraphQLError> graphQLErrors = response.getErrors().stream()
                            .filter(error -> ErrorType.InvalidSyntax.equals(error.getErrorType())
                                    || ErrorType.ValidationError.equals(error.getErrorType()))
                            .map(this::resolveException)
                            .collect(Collectors.toList());

                    if (!graphQLErrors.isEmpty()) {
                        return response.transform(builder -> builder.errors(graphQLErrors));
                    }

                    return response;
                });
    }

    private GraphQLError resolveException(ResponseError responseError) {

        ErrorClassification errorType = responseError.getErrorType();

        if (ErrorType.InvalidSyntax.equals(responseError.getErrorType())) {
            return new BadRequestException("1", responseError.getLocations());
        }

        if (ErrorType.ValidationError.equals(errorType)) {
            String message = responseError.getMessage();

            if (ValidationErrorType.WrongType.equals(
                    extractValidationErrorFromErrorMessage(responseError.getMessage()))) {
                return new BadRequestException("2", responseError.getLocations(), StringUtils.substringsBetween(message, "argument '", "'"));
            }

            if (ValidationErrorType.UnknownArgument.equals(
                    extractValidationErrorFromErrorMessage(responseError.getMessage()))) {
                return new BadRequestException("6", responseError.getLocations(), StringUtils.substringBetween(message, "argument ", " @"));
            }
        }

        return new BadRequestException("5", responseError.getLocations());
    }

    private ValidationErrorType extractValidationErrorFromErrorMessage(String message) {
        return ValidationErrorType.valueOf(StringUtils.substringBetween(message, "type ", ":"));
    }

}
