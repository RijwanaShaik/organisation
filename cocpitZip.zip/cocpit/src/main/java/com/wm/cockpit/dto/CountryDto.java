package com.wm.cockpit.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CountryDto {

    private long id;
    private String name;

    private String code;
}
