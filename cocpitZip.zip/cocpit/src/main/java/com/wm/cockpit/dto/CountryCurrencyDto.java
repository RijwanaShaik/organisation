package com.wm.cockpit.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CountryCurrencyDto {
    private String name;
    private String currency;
    private double longitude;
    private double latitude;
    private String iso2;
    private String iso3;
}