package com.wm.cockpit.validation;



import graphql.GraphQLError;
import graphql.language.SourceLocation;
import graphql.schema.DataFetchingEnvironment;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.graphql.execution.DataFetcherExceptionResolver;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import javax.validation.ConstraintViolationException;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class
GraphQLExceptionHandler implements DataFetcherExceptionResolver {

    @Override
    public Mono<List<GraphQLError>> resolveException(Throwable exception, DataFetchingEnvironment environment) {

        List<SourceLocation> sourceLocation = List.of (environment.getField().getSourceLocation());

        if (exception instanceof ConstraintViolationException) {
            return Mono.just(handleConstraintViolationException((ConstraintViolationException) exception,
                    sourceLocation));
        }

        if (exception instanceof UnprocessableEntityException) {
            UnprocessableEntityException unprocessableEntityException = (UnprocessableEntityException) exception;
            unprocessableEntityException.setLocations(sourceLocation);
            return Mono.just(Collections.singletonList(unprocessableEntityException));
        }

        return Mono.just(List.of());
    }

    private List<GraphQLError> handleConstraintViolationException(ConstraintViolationException exception,
                                                                  List<SourceLocation> locations) {
        return exception.getConstraintViolations().stream()
                .map(constraint -> new BadRequestException(constraint.getMessageTemplate(), locations,
                        ((PathImpl) constraint.getPropertyPath()).getLeafNode()))
                .map(badRequestException -> (GraphQLError) badRequestException)
                .collect(Collectors.toList());
    }
}