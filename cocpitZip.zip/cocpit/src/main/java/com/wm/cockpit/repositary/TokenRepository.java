package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.Token;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TokenRepository extends JpaRepository<Token, Long> {

    @Query(value = "SELECT t FROM Token t INNER JOIN t.user a WHERE a.id = :id")
    List<Token> findAllValidTokenByUser(Long id);

    Optional<Token> findByToken(String token);
}
