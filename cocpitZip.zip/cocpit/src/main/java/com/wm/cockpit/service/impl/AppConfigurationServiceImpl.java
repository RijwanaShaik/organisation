package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.AppConfigurationRequestDto;
import com.wm.cockpit.dto.AppConfigurationResponseDto;
import com.wm.cockpit.dto.FileUploadDto;
import com.wm.cockpit.entity.AppConfiguration;
import com.wm.cockpit.entity.FileUpload;
import com.wm.cockpit.enums.Role;
import com.wm.cockpit.repositary.AppConfigurationRepository;
import com.wm.cockpit.repositary.FileUploadRepository;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.security.LoggedInUser;
import com.wm.cockpit.service.AppConfigurationService;
import com.wm.cockpit.service.FileUploadService;
import com.wm.cockpit.utils.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Optional;

@Service
public class AppConfigurationServiceImpl implements AppConfigurationService {
    @Autowired
    AppConfigurationRepository appConfigurationRepo;
    @Autowired
    private FileUploadRepository fileUploadRepo;

    @Autowired
    private FileUploadService fileUploadService;

    @Override
    @Transactional
    public GenericResponse getAppConfiguration() {
       Optional<AppConfiguration> appConfiguration = appConfigurationRepo.findFirstByOrderByCreatedOnDesc();
       AppConfigurationResponseDto dto=entityToDto(appConfiguration.get());
       return new GenericResponse(HttpStatus.OK,dto);
    }

    @Override
    @Transactional
    public GenericResponse saveAppConfiguration(AppConfigurationRequestDto dto) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if (user.getRole().equals(Role.SUPER_ADMIN)) {
                GenericResponse genericResponse = Validator.validateAppConfigurationRequest(dto);
                if (genericResponse != null) return genericResponse;
                AppConfiguration appConfiguration = dtoToEntity(dto);
                    appConfiguration = appConfigurationRepo.save(appConfiguration);
                    AppConfigurationResponseDto dto1 = entityToDto(appConfiguration);
                    return new GenericResponse(HttpStatus.OK, "Application Customization is Complete", dto1);
            }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Access Denied");
        }return null;
    }

    @Override
    @Transactional
    public GenericResponse resetById(Long id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if (user.getRole().equals(Role.SUPER_ADMIN)) {
                Optional<AppConfiguration> appConfiguration = appConfigurationRepo.findById(id);
                if (appConfiguration.isPresent()) {
                    appConfiguration.get().setIsCustomize(Boolean.FALSE);
                    return new GenericResponse(HttpStatus.OK,"Reset Success");
                }else return new GenericResponse(HttpStatus.NOT_FOUND,"Id not Found");
            }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Access Denied");
        }
        return null;
    }

    private AppConfigurationResponseDto entityToDto(AppConfiguration appConfiguration) {
        AppConfigurationResponseDto dto=new AppConfigurationResponseDto();
        dto.setId(appConfiguration.getId());
        dto.setOrgName(appConfiguration.getOrgName());
        if(appConfiguration.getIsCustomize()) {
            if (appConfiguration.getFavIcon() != null) {
                Optional<FileUpload> fileUpload = fileUploadRepo.findById(appConfiguration.getFavIcon().getId());
                if (fileUpload.isPresent()) {
                    dto.setFavIcon(fileUploadService.entityToDto(fileUpload.get()));
                }
            }
            if (appConfiguration.getOrganisationLogo() != null) {
                Optional<FileUpload> fileUpload1 = fileUploadRepo.findById(appConfiguration.getOrganisationLogo().getId());
                if (fileUpload1.isPresent()) {
                    dto.setOrganisationLogo(fileUploadService.entityToDto(fileUpload1.get()));
                }
            }
            if (appConfiguration.getLoginImage() != null) {
                Optional<FileUpload> fileUpload2 = fileUploadRepo.findById(appConfiguration.getLoginImage().getId());
                if (fileUpload2.isPresent()) {
                    dto.setLoginImage(fileUploadService.entityToDto(fileUpload2.get()));
                }
            }
        }else {
            FileUploadDto fileUploadDto=new FileUploadDto();
            dto.setOrgName(null);
            dto.setFavIcon(fileUploadDto);
            dto.setLoginImage(fileUploadDto);
            dto.setOrganisationLogo(fileUploadDto);
        }
        dto.setIsCustomize(appConfiguration.getIsCustomize());
        return dto;
    }

    private AppConfiguration dtoToEntity(AppConfigurationRequestDto dto) {
        AppConfiguration appConfiguration=new AppConfiguration();
        Optional<AppConfiguration> orgExists = appConfigurationRepo.findFirstByOrderByCreatedOnDesc();
        if (orgExists.isPresent()) {
            appConfiguration = orgExists.get();
            appConfiguration.setIsCustomize(Boolean.TRUE);
        } else {
            appConfiguration = new AppConfiguration();
        }
        appConfiguration.setOrgName(dto.getOrgName());

        Optional<FileUpload> fileUpload = fileUploadRepo.findById(dto.getFavIcon());
        if (fileUpload.isPresent()) {
            appConfiguration.setFavIcon(fileUpload.get());
        }

        fileUpload = fileUploadRepo.findById(dto.getLoginImage());
        if (fileUpload.isPresent()) {
            appConfiguration.setLoginImage(fileUpload.get());
        }

        fileUpload = fileUploadRepo.findById(dto.getOrganisationLogo());
        if (fileUpload.isPresent()) {
            appConfiguration.setOrganisationLogo(fileUpload.get());
        }

        return appConfiguration;
    }
}
