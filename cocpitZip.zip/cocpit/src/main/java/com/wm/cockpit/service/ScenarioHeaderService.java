package com.wm.cockpit.service;

import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.dto.ScenarioDto;
import com.wm.cockpit.dto.ScenarioHeaderDto;
import com.wm.cockpit.dto.ScenarioResponseDto;
import com.wm.cockpit.entity.ScenarioHeader;
import com.wm.cockpit.entity.ScenarioItem;

import java.util.List;

public interface ScenarioHeaderService {

    String createScenarioHeader(ScenarioHeaderDto scenarioHeaderDto);

    List<ScenarioHeaderDto> getAllScenarioHeadersRest();

    List<ScenarioHeader> getAllScenarioHeaders();

    ScenarioHeaderDto savedScenarioHeaderById(long id, ScenarioHeaderDto scenarioHeaderDto);
    ScenarioHeader savedScenarioHeader(ScenarioHeaderDto scenarioHeaderDto);

    ScenarioHeader getScenarioById(long id) throws Exception;

    ScenarioDto getScenarioResponseDto(ScenarioHeader scenarioHeader);

    ScenarioHeader createScenario(ScenarioDto scenarioDto) throws Exception;

    ScenarioHeader updateScenario(ScenarioDto scenarioDto);

    List<ScenarioDto> getScenarioResponseDtoInList(List<ScenarioHeader>  headers);

    List<ScenarioHeader> getScenarioByCustomer(long customerId) throws Exception;
}


