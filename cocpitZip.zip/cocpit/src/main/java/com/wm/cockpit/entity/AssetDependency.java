package com.wm.cockpit.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

import javax.persistence.*;

@SuppressWarnings("serial")
@Entity
@Table(name = "tr_asset_dependency")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class AssetDependency extends BaseEntity {
    private float share;
    @ManyToOne(fetch = FetchType.LAZY)
    private Asset asset;
    @ManyToOne(fetch = FetchType.LAZY)
    private Dependency dependency;
}
