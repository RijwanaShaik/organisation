package com.wm.cockpit.security;

import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.enums.Role;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


import java.util.Collection;
import java.util.Collections;

@Getter
@Setter
@NoArgsConstructor
public class LoggedInUser implements UserDetails {

    private Long id;

    private String userName;

    private String email;

    private Long phoneNumber;

    private String password;

    private Role role;
    private Boolean isActive;
    private String designation;
    public LoggedInUser(Long id, String userName, String email, Long phoneNumber, String password, Role role, Boolean isActive) {
        this.id = id;
        this.userName = userName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.role = role;
        this.isActive=isActive;

    }

    public static LoggedInUser build(AppUser appUser) {
        return new LoggedInUser(appUser.getId(),
                appUser.getUserName(),
                appUser.getEmail(),
                appUser.getPhoneNumber(),
                appUser.getPassword(),
                appUser.getRole(),
                appUser.getIsActive());
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.emptyList();
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return userName;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

}