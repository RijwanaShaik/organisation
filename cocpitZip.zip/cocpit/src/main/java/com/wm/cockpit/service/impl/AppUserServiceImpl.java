package com.wm.cockpit.service.impl;

import com.wm.cockpit.common.dto.GetAdminDto;
import com.wm.cockpit.common.dto.PageGetResponse;
import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.dto.AppUserDto;
import com.wm.cockpit.dto.AppUserRequest;
import com.wm.cockpit.dto.LoginResponseDto;
import com.wm.cockpit.dto.*;
import com.wm.cockpit.dto.rest.AdminResponseDto;
import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.entity.Otp;
import com.wm.cockpit.entity.TermsAndCondition;
import com.wm.cockpit.entity.Token;
import com.wm.cockpit.enums.Role;
import com.wm.cockpit.exceptions.BadRequestException;
import com.wm.cockpit.exceptions.DuplicateException;
import com.wm.cockpit.exceptions.IdNotFoundException;
import com.wm.cockpit.exceptions.UnAuthorisedException;
import com.wm.cockpit.repositary.AppUserRepo;
import com.wm.cockpit.repositary.OtpRepository;
import com.wm.cockpit.repositary.TermsAndConditionRepo;
import com.wm.cockpit.repositary.TokenRepository;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.security.JwtUtils;
import com.wm.cockpit.security.LoggedInUser;
import com.wm.cockpit.service.AppUserService;
import com.wm.cockpit.service.OtpService;
import com.wm.cockpit.utils.AppUserUtils;
import com.wm.cockpit.utils.GenerateOtp;
import com.wm.cockpit.utils.PasswordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AppUserServiceImpl implements AppUserService {

    final Logger logger = LoggerFactory.getLogger(AppUserServiceImpl.class);

    @Autowired
    private AppUserRepo appUserRepo;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private OtpService otpService;

    @Autowired
    private TermsAndConditionRepo termsAndConditionRepo;
    private final String hashReference = "cockpit-auth";
    @Resource(name = "redisTemplate")
    private HashOperations<String, String, String> hashOperations;

    @Autowired
    private OtpRepository otpRepository;

    @Autowired
    private TokenRepository tokenRepository;


    public String ChangeEncryptPwd(AppUser appUser) {
        String encrptPwd = passwordEncoder.encode(appUser.getPassword());
        appUser.setPassword(encrptPwd);
        AppUser addUser = appUserRepo.save(appUser);
        passwordEncoder.matches(appUser.getPassword(), addUser.getPassword());
        return addUser.getUserName() + " Password has been changed successfully.";

    }

    public GenericResponse createUser(AppUserDto appUserDto) {
        logger.info("Create User Request :: " + AppUserUtils.getStringFromObject(appUserDto));
        //   ApiResponse apiResponse = UserServiceValidator.validateInitialSignupRequest(environment, request);
        /*if (apiResponse != null) {
            return apiResponse;
        }*/
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if (user.getRole().equals(Role.SUPER_ADMIN)) {
                AppUser appUser = new AppUser();
                appUser.setUserName(appUserDto.getUserName());
                if (appUserDto.getEmail() != null && !appUserRepo.existsByEmailIgnoreCase(appUserDto.getEmail())) {
                    appUser.setEmail(appUserDto.getEmail().toLowerCase());
                } else {
                    return new GenericResponse(HttpStatus.BAD_REQUEST, " This Email id is already Existed ");
                }
                appUser.setPhoneNumber(appUserDto.getPhoneNumber());
                appUser.setPassword(new BCryptPasswordEncoder().encode("Cockpit@123"));
                appUser.setRole(Role.ADMIN);
                appUser.setCreatedBy(user.getId());
                appUser.setDesignation(appUserDto.getDesignation());
                appUser.setSearchKey(setSearchKeyForUser(appUserDto));
                appUser = appUserRepo.save(appUser);

                AdminResponseDto savedUser = appUserToDto(appUser);
                return new GenericResponse(HttpStatus.OK, " Created AppUser Successfully.....", savedUser);
            }
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Only SuperAdmin can add Admin and Super admin");
        }
        return new GenericResponse(HttpStatus.BAD_REQUEST, "Super Admin should be login");
    }


    private String setSearchKeyForUser(AppUserDto request) {
        String searchKey = " ";
        if (request.getEmail() != null) {
            searchKey = searchKey + request.getEmail();
        }
        if (request.getUserName() != null) {
            searchKey = searchKey + request.getUserName();
        }
        return searchKey;
    }

    public GenericResponse savedUserById(AdminResponseDto appUserDto) {
        AppUser appUser = appUserRepo.findById(appUserDto.getId()).get();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if (appUser.getCreatedBy() == user.getId()) {
                appUser.setUserName(appUserDto.getUserName());
                appUser.setPhoneNumber(appUserDto.getPhoneNumber());
                appUser.setDesignation(appUserDto.getDesignation());
                //appUser.setRole(appUserDto.getRole());
                // appUser.setEmail(appUserDto.getEmail());
                AppUser savedUser = appUserRepo.save(appUser);
                return new GenericResponse(HttpStatus.OK, "Admin Details Updated Successfully", appUserToDto(savedUser));
            } else throw new UnAuthorisedException("Only created person can update details");
        }
        return null;
    }

    public ApiResponse findByUserAppId(long id) {
        Optional<AppUser> appUser = appUserRepo.findById(id);
        if (appUser.isPresent()) {
            AppUser user = appUser.get();
        } else {
            return new ApiResponse(HttpStatus.NOT_FOUND, " AppUser ");
        }
        return new ApiResponse(HttpStatus.OK, appUser);
    }

    public ApiResponse getLoggedInUser() {
        Object loggedInUserResponse = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (loggedInUserResponse != null && !loggedInUserResponse.equals("anonymousUser")) {
            System.out.println(loggedInUserResponse);
            LoginResponseDto loginResponse = new LoginResponseDto();
            LoggedInUser loggedInUser = (LoggedInUser) loggedInUserResponse;
            loginResponse.setId(loggedInUser.getId());
            loginResponse.setUserName(loggedInUser.getUsername());
            loginResponse.setEmail(loggedInUser.getEmail());
            loginResponse.setPhoneNumber(loggedInUser.getPhoneNumber());
            loginResponse.setRole(loggedInUser.getRole());

            return new ApiResponse(HttpStatus.OK, "Logged in User Details Found Successfully", loginResponse);
        } else {
            return new ApiResponse(HttpStatus.BAD_REQUEST, "Please login !!", null);
        }
    }


    public List<AppUser> getAllAppUser() {
        return appUserRepo.findAll();
    }

    @Override
    public String deletedAppUserById(long id) throws Exception {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            Optional<AppUser> appUser = appUserRepo.findById(id);
            if (appUser.isPresent()) {
                if (user.getId() == appUser.get().getCreatedBy()) {
                    appUserRepo.deleteById(id);
                } else throw new UnAuthorisedException("Only created person can delete user");
            } else {
                throw new IdNotFoundException("User Id Is  Not Found...");
            }
            return "Deleted Id %id Successfully...";
        }
        return null;
    }

    public ApiResponse login(AppUserRequest appUserRequest) {
            Optional<AppUser> appUser = appUserRepo.findByEmail(appUserRequest.getUsername());
            if (appUser.isPresent()) {

                Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(appUserRequest.getUsername(), PasswordUtils.passwordDecode(appUserRequest.getPassword())));
                SecurityContextHolder.getContext().setAuthentication(authentication);
                String jwt = jwtUtils.generateJwtToken(authentication);
                hashOperations.put(jwt,jwt, appUserRequest.getUsername());
                saveUserToken(appUser.get(),jwt);
                //hashOperations.put(hashReference, jwt, appUserRequest.getUsername()+ "-" +Math.random());

                Otp otp = otpRepository.findFirstByAppUserIdOrderByCreatedOnDesc(appUser.get().getId());
                String otp1 = "111111";
                if (otp1.equals(PasswordUtils.passwordDecode(appUserRequest.getOtp()))) {
                    if (appUserRequest.getIsTermsAndConditionsAccepted()) {
                        appUserRepo.updateIsTermsAndConditionsAccepted(appUser.get().getId());
                    }
                    return new ApiResponse(HttpStatus.OK, "Successfully Login", createLoginResponse(appUser.get(),jwt,appUserRequest));
                } else {
                    throw new BadRequestException("invalid Otp");
                }

            } else {
                throw new BadRequestException("invalid Email Id");
            }

     /*   Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(appUserRequest.getUsername(), appUserRequest.getPassword()));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtils.generateJwtToken(authentication);
        hashOperations.put(jwt,jwt, appUserRequest.getUsername());
        //hashOperations.put(hashReference, jwt, appUserRequest.getUsername()+ "-" +Math.random());
        
        LoggedInUser loggedInUser = (LoggedInUser) authentication.getPrincipal();
        AppUser appUser = null;
        if(loggedInUser.getIsActive()) {
                Optional<AppUser> appUserOptional = appUserRepo.findByEmail(loggedInUser.getEmail());
                if (appUserOptional.isPresent()) {
                    appUser = appUserOptional.get();
                }
                else throw new IdNotFoundException("No App User found with this email !!");
            LoginResponseDto loginResponse = new LoginResponseDto();
            loginResponse.setId(loggedInUser.getId());
            loginResponse.setUserName(loggedInUser.getUsername());
            loginResponse.setPhoneNumber(loggedInUser.getPhoneNumber());
            loginResponse.setEmail(loggedInUser.getEmail());
            loginResponse.setRole(loggedInUser.getRole());
            loginResponse.setAuth_token(jwt);
            loginResponse.setStatus("Active");

            if (appUser!=null) {
                loginResponse.setIsFirstTimeLogin(appUser.getIsFirstTimeLogin());
                if (appUserRequest.getIsTermsAndConditionsAccepted() != null){
                    Optional<TermsAndCondition> optional = termsAndConditionRepo.findById(appUserRequest.getTermsAndConditionId());
                    if(optional.isPresent()) {
                        appUser.setTermsAndCondition(optional.get());
                        appUser.setIsTermsAndConditionsAccepted(appUserRequest.getIsTermsAndConditionsAccepted());
                        appUserRepo.save(appUser);
                        loginResponse.setIsTermsAndConditionsAccepted(appUser.getIsTermsAndConditionsAccepted());
                        loginResponse.setTermsAndConditionsId(optional.get().getId());
                    }
                    else throw new IdNotFoundException("No Terms & Conditions found with given id !!");
                }
            }
            return new ApiResponse(HttpStatus.OK, "USER LOGIN SUCCESSFULLY", loginResponse);
        }else throw  new UnAuthorisedException("Inactive User cannot login");*/
    }

    public ApiResponse logout(HttpServletRequest request) {
        String headerAuth = request.getHeader("Authorization");
        System.out.println("AUTH IN LOGOUT   " + headerAuth);
        Long result = hashOperations.delete(hashReference, headerAuth);
        System.out.println("LOGOUT RESULT   " + result);
        return new ApiResponse(HttpStatus.OK, "LOGOUT SUCCESSFULLY");
    }

    @Override
    public GenericResponse getAllAdmins(GetAdminDto requestDto) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if (user.getRole().equals(Role.SUPER_ADMIN)) {
                PageRequest pageRequest = PageRequest.of(requestDto.getPageNumber(), requestDto.getPageSize());
                Page<AppUser> appUserList = appUserRepo.findAllByRoleAndCreatedBy(Role.ADMIN, user.getId(), pageRequest);
                if (requestDto.getSearchKey() != null) {
                    appUserList = appUserRepo.findAllByRoleAndCreatedByAndSearchKeyContainingIgnoreCase(Role.ADMIN, user.getId(), requestDto.getSearchKey(), pageRequest);
                }
                if (!CollectionUtils.isEmpty(appUserList.getContent())) {
                    List<AdminResponseDto> appUserDtoList = appUserList.getContent().stream().sorted(Comparator.comparing(AppUser::getCreatedOn).reversed()).map(this::appUserToDto).toList();
                    return new GenericResponse(HttpStatus.OK, "All Admins Found Successfully", new PageGetResponse(appUserDtoList, appUserList.getTotalPages()));
                }
            } else throw new UnAuthorisedException("Only Super Admin can access");
        }
        return null;
    }

    @Override
    public GenericResponse inActiveAppUser(Long appUerId) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if (user.getRole().equals(Role.SUPER_ADMIN)) {
                Optional<AppUser> optionalAppUser = appUserRepo.findById(appUerId);
                if (optionalAppUser.isPresent()) {
                    AppUser appUser = optionalAppUser.get();
                    if (appUser.getIsActive()) {
                        appUser.setIsActive(Boolean.FALSE);
                    } else {
                        appUser.setIsActive(Boolean.TRUE);
                    }
                    return new GenericResponse(HttpStatus.OK, "Success", appUserToDto(appUserRepo.save(appUser)));
                } else throw new IdNotFoundException("No AppUser found with given id !!");
            } else throw new UnAuthorisedException("Only Super Admin can do this");
        } else return null;
    }

    @Override
    public GenericResponse changePassword(ChangePasswordRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if (user.getEmail().equals(request.getEmail())) {
                Optional<AppUser> optionalAppUser = appUserRepo.findByEmail(request.getEmail());
                if (optionalAppUser.isPresent()) {
                    AppUser appUser = optionalAppUser.get();
                    BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
                    if (encoder.matches(request.getOldPassword(), appUser.getPassword())) {
                        //if(appUser.getPassword().equals(new BCryptPasswordEncoder().encode(request.getOldPassword()))){
                        appUser.setPassword(new BCryptPasswordEncoder().encode(request.getNewPassword()));
                        appUser.setIsFirstTimeLogin(Boolean.FALSE);
                        appUserRepo.save(appUser);
                        revokeAllUserTokens(appUser);
                        return new GenericResponse(HttpStatus.OK, "Password changed successfully");
                    } else throw new BadRequestException("Old password didnt match !!");
                } else throw new IdNotFoundException("No App user found with given id !!");
            } else throw new UnAuthorisedException("You cannot change others password !!");
        }
        return null;
    }

    @Override
    public GenericResponse getAdminDetails() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if (user.getRole().equals(Role.SUPER_ADMIN)) {
                List<AppUser> appUserList = appUserRepo.findAllByCreatedByAndRoleAndIsActive(user.getId(), Role.ADMIN, Boolean.TRUE);
                List<AdminDetailsResponseDto> adminDetailsResponseDtoList = new ArrayList<>();
                if (appUserList != null && !appUserList.isEmpty()) {
                    for (AppUser appUser : appUserList) {
                        AdminDetailsResponseDto dto = new AdminDetailsResponseDto();
                        dto.setId(appUser.getId());
                        dto.setName(appUser.getUserName());
                        adminDetailsResponseDtoList.add(dto);
                    }
                }
                if (!CollectionUtils.isEmpty(adminDetailsResponseDtoList)) {
                    return new GenericResponse(HttpStatus.OK, "Admin Names Found Successfully ", adminDetailsResponseDtoList);
                }
                return new GenericResponse(HttpStatus.OK, "Data Not Found");
            }
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Access Denied");
        }
        return null;
    }


    @Override
    public GenericResponse acceptTermsAndConditions(Long appUserId, Long termsCondtionId) {
        Optional<AppUser> optionalAppUser = appUserRepo.findById(appUserId);
        if (optionalAppUser.isPresent()) {
            Optional<TermsAndCondition> optional = termsAndConditionRepo.findById(termsCondtionId);
            if (optional.isPresent()) {
                if (optional.get().getIsActive()) {
                    AppUser appUser = optionalAppUser.get();
                    appUser.setIsTermsAndConditionsAccepted(Boolean.TRUE);
                    appUser.setTermsAndCondition(optional.get());
                    appUserRepo.save(appUser);
                    return new GenericResponse(HttpStatus.OK, "Terms & Conditions Accepted Successfully");
                } else throw new BadRequestException("Terms & Consitions are Disabled");
            } else throw new IdNotFoundException("No terms & Conditions found given id!!");
        } else throw new IdNotFoundException("No AppUser found with given id!!");
    }
/*    @Override
    public GenericResponse getAdminDetails() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            if(user.getRole().equals(Role.SUPER_ADMIN)){
                List<AdminDetailsDto> dtoList=new ArrayList<>();
                List<AppUser> list=appUserRepo.findAllByCreatedByAndRole(user.getId(), Role.ADMIN);
                if(!CollectionUtils.isEmpty(list)){
                    for(AppUser appUser:list){
                        AdminDetailsDto dto=new AdminDetailsDto();
                        dto.setId(appUser.getId());
                        dto.setName(appUser.getUserName());
                        dtoList.add(dto);
                    }
                    return new GenericResponse(HttpStatus.OK, dtoList);
                }else return new GenericResponse(HttpStatus.OK, "No Admins found!!");
            }else throw new AccessDeniedException("Only Super admin can get admins");
        }else return null;
    }*/

  /*  @Override
    public List<AppUserDto> getAllAdminsByLoggedInUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            List<AppUser> appUserList = appUserRepo.findAllByCreatedBy(user.getId());
            if(!CollectionUtils.isEmpty(appUserList)){
                return appUserList.stream().map(this::appUserToDto).toList();
            }else throw new AccessDeniedException("No Admins found :(");
        }return null;
    }*/

    private AdminResponseDto appUserToDto(AppUser appUser) {
        AdminResponseDto dto = new AdminResponseDto();
        dto.setId(appUser.getId());
        dto.setUserName(appUser.getUserName());
        dto.setEmail(appUser.getEmail());
        dto.setPhoneNumber(appUser.getPhoneNumber());
        dto.setRole(appUser.getRole());
        dto.setDesignation(appUser.getDesignation());
        if (appUser.getIsActive()) {
            dto.setStatus("Active");
        } else {
            dto.setStatus("InActive");
        }
        return dto;
    }
 /*   private boolean isOtpValid(Otp otp, String enteredOtp) {
        if (otp.getCreatedOn() == null) {
            return false; // Handle the case where createdOn is null
        }

        // Calculate the difference between current time and the OTP creation time
        long currentTimeMillis = System.currentTimeMillis();
        long otpCreationTimeMillis = otp.getCreatedOn().getTime();
        long timeDifferenceMillis = currentTimeMillis - otpCreationTimeMillis;

        // Check if the time difference is within 3 minutes (3 * 60,000 milliseconds)
        if (timeDifferenceMillis <= 60_000) {
            return otp.getOtp().equals(PasswordUtils.passwordDecode(enteredOtp));
        }

        return false; // OTP has expired
    }
*/

    private LoginResponseDto createLoginResponse( AppUser appUser, String jwt, AppUserRequest appUserRequest) {
        LoginResponseDto loginResponse = new LoginResponseDto();
		loginResponse.setId(appUser.getId());
		loginResponse.setUserName(appUser.getUserName());
		loginResponse.setPhoneNumber(appUser.getPhoneNumber());
		loginResponse.setEmail(appUser.getEmail());
		loginResponse.setRole(appUser.getRole());
		loginResponse.setAuth_token(jwt);
		loginResponse.setStatus("Active");
        loginResponse.setIsFirstTimeLogin(appUser.getIsFirstTimeLogin());

        return loginResponse;
    }
    private void saveUserToken(AppUser user, String jwtToken) {
        var token = Token.builder()
                .user(user)
                .token(jwtToken)
                .expired(false)
                .revoked(false)
                .build();
        tokenRepository.save(token);
    }
    private void revokeAllUserTokens(AppUser user) {
        List<Token> validUserTokens = tokenRepository.findAllValidTokenByUser(user.getId());
        if (!validUserTokens.isEmpty()) {
            user.getTokens().removeAll(validUserTokens);
            appUserRepo.save(user);
            tokenRepository.deleteAll(validUserTokens);
        }

    }

}