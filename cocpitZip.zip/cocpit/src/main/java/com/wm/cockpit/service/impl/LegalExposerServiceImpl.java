package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.LegalExposureDto;
import com.wm.cockpit.entity.Asset;
import com.wm.cockpit.entity.LegalExposure;
import com.wm.cockpit.repositary.AssetRepository;
import com.wm.cockpit.repositary.CountryRepository;
import com.wm.cockpit.repositary.CustomerRepository;
import com.wm.cockpit.repositary.LegalExposureRepository;
import com.wm.cockpit.service.LegalExposureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LegalExposerServiceImpl implements LegalExposureService {

    @Autowired
    private LegalExposureRepository legalExposureRepository;
    @Autowired
    private AssetRepository assetRepository;
    @Autowired
    private CountryRepository countryRepositary;
    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public String createEconomicExposure(LegalExposureDto legalExposureDto) {
        LegalExposure economicExposure = new LegalExposure();
        Asset asset = assetRepository.findById(legalExposureDto.getAssetId()).get();
        economicExposure.setAsset(asset);
        legalExposureRepository.save(economicExposure);
        return "Created EconomicExploser Successfully....";
    }

    @Override
    public List<LegalExposure> getAllEconomicExposure() {
        return legalExposureRepository.findAll();
    }
}
