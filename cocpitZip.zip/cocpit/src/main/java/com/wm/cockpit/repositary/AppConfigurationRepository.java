package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.AppConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AppConfigurationRepository extends JpaRepository<AppConfiguration, Long> {
    Optional<AppConfiguration> findFirstByOrderByCreatedOnDesc();

    Optional<AppConfiguration> findByOrgName(String orgName);
}
