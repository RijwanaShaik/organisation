package com.wm.cockpit.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CountryCurrencyMsgDto {

    private boolean error;

    private String msg;

    private List<CountryCurrencyDto> data;
}
