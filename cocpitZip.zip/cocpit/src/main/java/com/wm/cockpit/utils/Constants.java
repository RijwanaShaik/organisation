package com.wm.cockpit.utils;

public class Constants {
    public static final String ERROR = "error";
}
