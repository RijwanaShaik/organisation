package com.wm.cockpit.controller;


import com.wm.cockpit.dto.AssetDependencyDto;
import com.wm.cockpit.entity.AssetDependency;
import com.wm.cockpit.service.AssetDependencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/assetDependency")
public class AssetDependencyController {
    @Autowired
    private AssetDependencyService assetDependencyService;

    @MutationMapping(name = "createAssetDependency")
    public String createAssetDependency(@Argument(name = "input") AssetDependencyDto assetDependencyDto) {
        return assetDependencyService.createAssetDependency(assetDependencyDto);
    }

    @QueryMapping(name = "getAllAssetDependencies")
    public List<AssetDependency> getAllAssetDependencies() {
        return assetDependencyService.getAllAssetDependencies();
    }
}
