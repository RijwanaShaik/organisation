package com.wm.cockpit.service.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.repositary.AppUserRepo;

@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private AppUserRepo appUserRepo;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		AppUser appUser = appUserRepo.findByUserName(username);

		return new User(appUser.getUserName(), appUser.getPassword(), new ArrayList<GrantedAuthority>());
	}

}
