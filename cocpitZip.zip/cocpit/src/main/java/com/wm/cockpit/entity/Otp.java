package com.wm.cockpit.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.wm.cockpit.enums.OtpStatus;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.Where;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import java.sql.Timestamp;
import java.util.Date;

@SuppressWarnings("serial")
@Entity
@Setter
@Getter
@Table(name = "tr_user_otp")
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class Otp {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "created_on", updatable = false)
	@JsonIgnore
	@CreationTimestamp
	private Timestamp createdOn = new Timestamp(new Date().getTime());

	@Version
	@Column(name = "updated_on")
	@UpdateTimestamp
	private Timestamp updatedOn = new Timestamp(new Date().getTime());

	@Column(columnDefinition = "boolean default false")
	private Boolean isDeleted = Boolean.FALSE;

	@JsonIgnore
	@CreatedBy
	private Long createdBy;

	@JsonIgnore
	@LastModifiedBy
	private Long updatedBy;

	@ManyToOne
	private AppUser appUser;

	private String otp;

	@Enumerated(EnumType.STRING)
	private OtpStatus status;

}
