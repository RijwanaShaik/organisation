package com.wm.cockpit.service;

import com.wm.cockpit.dto.AppConfigurationRequestDto;
import com.wm.cockpit.response.GenericResponse;

public interface AppConfigurationService {

    GenericResponse getAppConfiguration();
    GenericResponse saveAppConfiguration(AppConfigurationRequestDto dto);
    GenericResponse resetById(Long id);
}
