package com.wm.cockpit.dto;

import com.wm.cockpit.entity.Currency;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.OneToOne;

@Getter @Setter
public class ScenarioResponseDto {

    String name;
    private Double referenceCurrencyExchange;
    private Double familyHoldingExchange;
    private Double standardDeviation;
    private Long debtSwapSourceId;
    private String debtSwapSource;
    private Double debtSwapValue;
    private Long debtSwapTargetId;
    private String debtSwapTarget;
    private Double liquidityEventValue;
    private Long liquidityEventCurrencyId;
    private String liquidityEventCurrency;
    private String liquidityEventInYear;
    private Double leveragePurchaseWorth;
    private Long leveragePurchaseCurrencyId;
    private String additionalLeveragePurchase;
    private String leveragePurchaseCurrency;
}
