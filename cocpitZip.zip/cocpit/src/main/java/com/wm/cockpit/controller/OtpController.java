package com.wm.cockpit.controller;

import java.util.List;
import java.util.Map;

import com.wm.cockpit.dto.AppUserRequest;
import com.wm.cockpit.entity.Otp;
import com.wm.cockpit.exceptions.CustomAuthenticationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.service.OtpService;

@RestController
@RequestMapping("/api/v1/otp")
public class OtpController {

    private final Logger log = LoggerFactory.getLogger(OtpController.class);

    @Autowired
    private OtpService otpService;

    @PostMapping("/sent")
    public ResponseEntity otp(@RequestBody AppUserRequest appUserRequest) throws CustomAuthenticationException {

        log.info("OTP Send Server is Started");
        ApiResponse apiResponse = otpService.sentOtp(appUserRequest);

        log.info("OTP Sent  Server is Completed..");
        return new ResponseEntity<>(apiResponse, apiResponse.getStatus());
    }

//	@PostMapping("/verification")
//	public ResponseEntity otpValidation(@RequestBody Map<String, String> req) {
//		// 1-> By using dto, 2-> map refernce
//
//		log.info(" OTP Validation Server Is Started ");
//		ApiResponse apiResponse = otpService.otpValidation(req.get("email"), req.get("otp"));
//
//		log.info("OTP Validation Server Completed ");
//		return new ResponseEntity<>(apiResponse, apiResponse.getStatus());
//	}


    @QueryMapping(name = "getAllOtps")
    public List<Otp> getAllOtps() {
        return otpService.getAllOtps();
    }
}
