package com.wm.cockpit.entity;

import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.wm.cockpit.dto.CustomerDto;
import com.wm.cockpit.enums.CustomerLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;
import org.hibernate.validator.constraints.NotBlank;

@SuppressWarnings("serial")
@Entity
@Table(name = "mt_customer")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class Customer extends BaseEntity {
    @NotEmpty
    @Column(nullable = false)
    private String name;
    private Long phoneNumber;
    @Column(unique = true)
    private String email;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "customer")
    private List<Dependency> dependencies;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "customer")
    private List<ScenarioHeader> scenarioHeaders;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "customer")
    private List<Asset> assets;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "customer")
    private List<Liability> liabilities;

    @OneToOne
    @NotNull(message = "Currency is required")
    private Currency currency;

    @ManyToOne(fetch = FetchType.LAZY)
    private AppUser appUser;

    @Enumerated(EnumType.STRING)
    private CustomerLevel level;
}
