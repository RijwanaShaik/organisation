package com.wm.cockpit.common.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SectorReq {
    private String name;
}
