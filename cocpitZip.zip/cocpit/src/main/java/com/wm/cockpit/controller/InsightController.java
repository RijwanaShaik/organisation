package com.wm.cockpit.controller;

import com.wm.cockpit.dto.*;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.RuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/rule/engine/")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class InsightController {
    @Autowired
    RuleService ruleService;

    @PostMapping("liquidity")
    public GenericResponse getLiquidityAnalysis(@RequestBody LiquidityGraphDto liquidityGraph){
        liquidityGraph=ruleService.getLiquidityGraph(liquidityGraph);
        return new GenericResponse(HttpStatus.OK,liquidityGraph.getResponse());
    }
    @PostMapping("currency")
    public GenericResponse getCurrencyMix(@RequestBody CurrencyMixGraphDto currencyMixGraph){
        currencyMixGraph=ruleService.getCurrencyExposures(currencyMixGraph);
        return new GenericResponse(HttpStatus.OK,currencyMixGraph);

    }
    @PostMapping("inflation")
    public GenericResponse getInflation(@RequestBody InflationGraphDto inflationGraph){
        inflationGraph=ruleService.getInflation(inflationGraph);
        return new GenericResponse(HttpStatus.OK,inflationGraph);
    }
    @PostMapping("ubo-returns")
    public GenericResponse getUboReturns(@RequestBody UBOReturnsGraphDto uboReturnsGraphDto){
        uboReturnsGraphDto=ruleService.getUBOReturns(uboReturnsGraphDto);
        return new GenericResponse(HttpStatus.OK,uboReturnsGraphDto);
    }
    @PostMapping("sector")
    public GenericResponse getSectorGraph(@RequestBody SectorRequestDto sectorRequestDto){
        SectorResponseDto responseDto=ruleService.getSectorGraph(sectorRequestDto);
        return new GenericResponse(HttpStatus.OK,responseDto);
    }
}
