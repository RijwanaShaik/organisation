package com.wm.cockpit.common.dto;

import com.wm.cockpit.dto.AssetDto;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
public class AssetsDto {
    List<AssetReq> assets = new ArrayList<>();
}
