package com.wm.cockpit.utils;

import java.util.Arrays;
import java.util.Base64;

public class PasswordUtils {
    public static String passwordDecode(String encodedPassword){
        byte[] decode = new byte[0];
        if(encodedPassword!=null) {
            decode = Base64.getDecoder().decode(encodedPassword.getBytes());
        }else {
            throw new RuntimeException("Password is null");
        }
        return new String(decode);
    }
}
