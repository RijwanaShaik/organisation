package com.wm.cockpit.controller;

import java.util.List;

import com.wm.cockpit.response.GenericResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wm.cockpit.dto.LiabilityDto;
import com.wm.cockpit.entity.Liability;
import com.wm.cockpit.service.LiabilityService;

@RestController
@RequestMapping("/api/vi/liability")
public class LiabilityController {

	@Autowired
	private LiabilityService liabilityService;

	@MutationMapping(name = "createLiability")
	public String createLiability(@Argument(name = "input")  LiabilityDto liabilityDto) {
		return liabilityService.createLiability(liabilityDto);
	}

	@MutationMapping(name = "updatedLiabilityById")
	public GenericResponse updatedLiabilityById(@Argument(name = "input")  LiabilityDto liabilityDto) throws Exception {
		return liabilityService.updatedLiabilityById(liabilityDto);
	}

	@MutationMapping(name = "deletedLiabilityById")
	public String deletedLiabilityById(@Argument long id) {
		return liabilityService.deletedLiabilityById(id);
	}

	@QueryMapping(name = "getAllLiabilities")
	public List<Liability> getAllLiabilities() {
		return liabilityService.getAllLiabilities();
	}

	
	@QueryMapping(name = "getLiabilityById")
	public Liability getLiabilityById(@Argument long id) throws Exception {
		return liabilityService.getLiabilityById(id);
	}

}
