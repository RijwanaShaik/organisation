package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.ScenarioItemDto;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.entity.ScenarioHeader;
import com.wm.cockpit.entity.ScenarioItem;
import com.wm.cockpit.repositary.CurrencyRepository;
import com.wm.cockpit.repositary.ScenarioHeaderRepository;
import com.wm.cockpit.repositary.ScenarioItemRepository;
import com.wm.cockpit.service.ScenarioItemService;
import com.wm.cockpit.utils.ScenarioUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ScenarioItemServiceImpl implements ScenarioItemService {

    @Autowired
    private ScenarioItemRepository scenarioItemRepository;

    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private ScenarioHeaderRepository scenarioHeaderRepository;

    @Override
    public String createScenarioItem(ScenarioItemDto scenarioItemDto) {
        ScenarioItem scenarioItem = new ScenarioItem();
        scenarioItem.setReferenceCurrencyExchange(scenarioItemDto.getReferenceCurrencyExchange());
        scenarioItem.setFamilyHoldingExchange(scenarioItemDto.getFamilyHoldingExchange());
        scenarioItem.setStandardDeviation(scenarioItemDto.getStandardDeviation());
        Currency currency = currencyRepository.findById(scenarioItemDto.getDebtSwapSource()).get();
        scenarioItem.setDebtSwapSource(currency);
        scenarioItem.setDebtSwapValue(scenarioItemDto.getDebtSwapValue());
        Currency currencyId = currencyRepository.findById(scenarioItemDto.getDebtSwapTarget()).get();
        scenarioItem.setDebtSwapTarget(currencyId);
        scenarioItem.setLiquidityEventValue(scenarioItemDto.getLiquidityEventValue());
        Currency liquidityCurrency = currencyRepository.findById(scenarioItemDto.getLiquidityEventCurrency()).get();
        scenarioItem.setLiquidityEventCurrency(liquidityCurrency);
        scenarioItem.setLiquidityEventInYear(scenarioItemDto.getLiquidityEventInYear());
      //  scenarioItem.setAdditionalLeveragePurchase(scenarioItemDto.getAdditionalLeveragePurchase());
        scenarioItem.setLeveragePurchaseWorth(scenarioItemDto.getLeveragePurchaseWorth());
        Currency purchaseCurrency = currencyRepository.findById(scenarioItemDto.getLeveragePurchaseCurrency()).get();
        scenarioItem.setLeveragePurchaseCurrency(purchaseCurrency);
        ScenarioHeader header = scenarioHeaderRepository.findById(scenarioItemDto.getScenarioHeader()).get();
        scenarioItem.setScenarioHeader(header);
        scenarioItemRepository.save(scenarioItem);
        return "Created ScenarioItem Successfully.....";
    }

    @Override
    public ScenarioItemDto savedScenarioItemById(long id, ScenarioItemDto scenarioItemDto) {
        ScenarioItem scenarioItem = new ScenarioItem();
        Optional<ScenarioItem> scenarioItemId = scenarioItemRepository.findById(id);
        if (scenarioItemId.isPresent()) {
            scenarioItem = scenarioItemId.get();
            scenarioItem.setReferenceCurrencyExchange(scenarioItemDto.getReferenceCurrencyExchange());
            scenarioItem.setFamilyHoldingExchange(scenarioItemDto.getFamilyHoldingExchange());
            scenarioItem.setStandardDeviation(scenarioItemDto.getStandardDeviation());
            Currency currency = currencyRepository.findById(scenarioItemDto.getDebtSwapSource()).get();
            scenarioItem.setDebtSwapSource(currency);
            scenarioItem.setDebtSwapValue(scenarioItemDto.getDebtSwapValue());
            Currency currencyId = currencyRepository.findById(scenarioItemDto.getDebtSwapTarget()).get();
            scenarioItem.setDebtSwapTarget(currencyId);
            scenarioItem.setLiquidityEventValue(scenarioItemDto.getLiquidityEventValue());
            Currency liquidityCurrency = currencyRepository.findById(scenarioItemDto.getLiquidityEventCurrency()).get();
            scenarioItem.setLiquidityEventCurrency(liquidityCurrency);
            scenarioItem.setLiquidityEventInYear(scenarioItemDto.getLiquidityEventInYear());
    //        scenarioItem.setAdditionalLeveragePurchase(scenarioItemDto.getAdditionalLeveragePurchase());
            scenarioItem.setLeveragePurchaseWorth(scenarioItemDto.getLeveragePurchaseWorth());
            Currency purchaseCurrency = currencyRepository.findById(scenarioItemDto.getLeveragePurchaseCurrency()).get();
            scenarioItem.setLeveragePurchaseCurrency(purchaseCurrency);
            ScenarioHeader header = scenarioHeaderRepository.findById(scenarioItemDto.getScenarioHeader()).get();
            scenarioItem.setScenarioHeader(header);
            scenarioItemRepository.save(scenarioItem);

        }
        return ScenarioUtils.ScenarioItemConvertEntityToDto(scenarioItem);
    }

    @Override
    public ScenarioItem savedScenarioItem(ScenarioItemDto scenarioItemDto) {
        ScenarioItem scenarioItem = new ScenarioItem();
        Optional<ScenarioItem> scenarioItemId = scenarioItemRepository.findById(scenarioItemDto.getId());
        if (scenarioItemId.isPresent()) {
            scenarioItem = scenarioItemId.get();
            scenarioItem.setReferenceCurrencyExchange(scenarioItemDto.getReferenceCurrencyExchange());
            scenarioItem.setFamilyHoldingExchange(scenarioItemDto.getFamilyHoldingExchange());
            scenarioItemDto.setStandardDeviation(scenarioItemDto.getStandardDeviation());
            Currency currency = currencyRepository.findById(scenarioItemDto.getDebtSwapSource()).get();
            scenarioItem.setDebtSwapSource(currency);
            scenarioItem.setDebtSwapValue(scenarioItemDto.getDebtSwapValue());
            Currency currencyId = currencyRepository.findById(scenarioItemDto.getDebtSwapTarget()).get();
            scenarioItem.setDebtSwapTarget(currencyId);
            scenarioItem.setLiquidityEventValue(scenarioItemDto.getLiquidityEventValue());
            Currency liquidityCurrency = currencyRepository.findById(scenarioItemDto.getLiquidityEventCurrency()).get();
            scenarioItem.setLiquidityEventCurrency(liquidityCurrency);
            scenarioItem.setLiquidityEventInYear(scenarioItemDto.getLiquidityEventInYear());
            scenarioItem.setLeveragePurchaseWorth(scenarioItemDto.getLeveragePurchaseWorth());
            Currency purchaseCurrency = currencyRepository.findById(scenarioItemDto.getLeveragePurchaseCurrency()).get();
            scenarioItem.setLeveragePurchaseCurrency(purchaseCurrency);
            ScenarioHeader header = scenarioHeaderRepository.findById(scenarioItemDto.getScenarioHeader()).get();
            scenarioItem.setScenarioHeader(header);
            scenarioItemRepository.save(scenarioItem);

        }
        return scenarioItem;
    }

    @Override
    public List<ScenarioItemDto> getAllScenarioItemsRest() {
        return scenarioItemRepository.findAll().stream().map(ScenarioItemDto::new).toList();
    }

    @Override
    public List<ScenarioItem> getAllScenarioItems() {
        return scenarioItemRepository.findAll();
    }

}
