package com.wm.cockpit.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wm.cockpit.entity.Currency;

@Repository
public interface CurrencyRepository extends JpaRepository<Currency, Long> {

   // Currency findByCurrencyCode(CurrencyDto assetCurrency);

    Currency findFirstByCurrencyCode(String currencyCode);
}
