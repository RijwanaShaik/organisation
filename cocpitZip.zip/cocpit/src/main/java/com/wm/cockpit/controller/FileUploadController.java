package com.wm.cockpit.controller;

import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.dto.FileUploadDto;
import com.wm.cockpit.entity.FileUpload;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.FileUploadService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/v1/file/")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class FileUploadController {
    @Autowired
    private FileUploadService service;

    private final Logger logger = LoggerFactory.getLogger( FileUpload.class );
    @PostMapping(value = "upload/{fileName}")
    public GenericResponse uploadFile(@RequestParam("file") MultipartFile file ,  @PathVariable String fileName){
        logger.info( "File Upload Service Started" );
        GenericResponse response= service.uploadFile(file,fileName);
        logger.info( "File Upload Service Completed" );
        return response;
    }
    @GetMapping(value = "get-by-id/{fileId}")
    public ResponseEntity<byte[]> downloadFile(@PathVariable Long fileId) {
        logger.info( "Get File by Id Service Started" );
        FileUploadDto fileDto = service.getFileById(fileId);
        if (fileDto != null && fileDto.getFileData() != null) {
            final byte[] isr = fileDto.getFileData();
            HttpHeaders respHeaders = new HttpHeaders();
            respHeaders.setContentLength(isr.length);
            if(fileDto.getType().equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                respHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
                respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileDto.getName() + ".xlsx");
            } else {
                respHeaders.setContentType(MediaType.parseMediaType(fileDto.getType()));
                respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileDto.getName());

            }
            logger.info( "Get File by Id Service Completed" );
            return new ResponseEntity<>(isr, respHeaders, HttpStatus.OK);
        }
        return null;
    }

    @DeleteMapping("/delete/{fileId}")
    public ApiResponse deleteFileById(@PathVariable Long fileId) {
        return service.deleteFileById(fileId);
    }

    @GetMapping(value = "preview/{fileId}")
    public ResponseEntity<byte[]> previewFile(@PathVariable Long fileId) {
        logger.info( "Get File by Id Service Started" );
        FileUploadDto fileDto = service.getFileById(fileId);
        if (fileDto != null && fileDto.getFileData() != null) {
            final byte[] isr = fileDto.getFileData();
            HttpHeaders respHeaders = new HttpHeaders();
            respHeaders.setContentLength(isr.length);
            if(fileDto.getType().equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                respHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
                respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=" + fileDto.getName() + ".xlsx");
            } else {
                respHeaders.setContentType(MediaType.parseMediaType(fileDto.getType()));
                respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=" + fileDto.getName());
            }
            logger.info( "Get File by Id Service Completed" );
            return new ResponseEntity<>(isr, respHeaders, HttpStatus.OK);
        }
        return null;
    }
    @GetMapping("get-by-name/{fileName}")
    public GenericResponse getByFileName(@PathVariable String fileName){
       return service.getFileByName(fileName);
    }
}
