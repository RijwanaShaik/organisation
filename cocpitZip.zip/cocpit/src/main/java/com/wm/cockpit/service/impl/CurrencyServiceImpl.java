package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.CurrencyDto;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.repositary.CurrencyRepository;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.CurrencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
public class CurrencyServiceImpl implements CurrencyService {

    @Autowired
    private CurrencyRepository currencyRepository;


    @Override
    public List<Currency> getAllCurrencies() {
        List<Currency> currencies = currencyRepository.findAll(Sort.by(Sort.Direction.ASC, "currencyCode")).stream().filter(currency -> !currency.getCurrencyCode().isEmpty()).toList();

        return currencies;
    }

    @Override
    public List<Currency> getAllUniqueCurrencies() {
        List<Currency> currencies = getAllCurrencies();
        List<Currency> uniqCurrenciesList = currencies.stream().filter(currency -> currency.isUiCode() == true).toList();
        uniqCurrenciesList.stream().sorted((c1, c2) -> ((c1.getCurrencyCode()).compareTo(c2.getCurrencyCode())));

        return uniqCurrenciesList;
    }

    @Override
    public Currency getCurrencyById(long id) throws Exception {
        Optional<Currency> optional = currencyRepository.findById(id);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new Exception("Currency Id %id Not Found.");
        }
    }

    @Override
    public GenericResponse getAllRestCurrencies() {
        List<CurrencyDto> currencies = currencyRepository.findAll(Sort.by(Sort.Direction.ASC, "currencyCode")).stream().
                filter(currency -> !currency.getCurrencyCode().isEmpty()).filter(Currency::isUiCode)
                .map(this::currencyToDto).toList();
        currencies.stream().sorted((c1, c2) -> ((c1.getCurrencyCode()).compareTo(c2.getCurrencyCode())));
        return new GenericResponse(HttpStatus.OK, currencies);
    }

    private CurrencyDto currencyToDto(Currency currency) {
        CurrencyDto dto = new CurrencyDto();
        dto.setId(currency.getId());
        dto.setCurrencyCode(currency.getCurrencyCode());
        return dto;
    }

}

