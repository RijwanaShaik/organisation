package com.wm.cockpit.exceptions;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  18/05/23
 * @Time >>  2:09 pm
 * @Project >>  cocpit
 */
public class IdNotFoundException extends RuntimeException{
    public IdNotFoundException(String message){
        super(message);
    }
}
