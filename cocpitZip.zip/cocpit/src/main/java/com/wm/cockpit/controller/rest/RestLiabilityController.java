package com.wm.cockpit.controller.rest;

import com.wm.cockpit.common.dto.AssetsDto;
import com.wm.cockpit.dto.LiabilityDto;
import com.wm.cockpit.dto.rest.LiabilityRestDto;
import com.wm.cockpit.dto.rest.RestAssetDto;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.LiabilityService;
import com.wm.cockpit.service.impl.LiabilityServiceImpl;
import com.wm.cockpit.service.rest.RestAssetService;
import com.wm.cockpit.service.rest.RestLiabilityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/rest/liability")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class RestLiabilityController {

    @Autowired
    RestLiabilityService restLiabilityService;

    @Autowired
    LiabilityService liabilityService;

    @PostMapping("/add")
    public GenericResponse save(@RequestBody LiabilityRestDto dto) {
        return restLiabilityService.save(dto);
        // return new GenericResponse(HttpStatus.OK, "SUCCESS");
    }

    @PostMapping("/update")
    public GenericResponse save(@RequestBody LiabilityDto dto) throws Exception {
        return liabilityService.updatedLiabilityRest(dto);
    }

    @DeleteMapping("/delete/{id}")
    public GenericResponse delete(@PathVariable Long id) {
        return restLiabilityService.delete(id);
    }

    @GetMapping("/customer/get/{id}")
    public GenericResponse getDataByCustomerId(@PathVariable Long id) {
        return restLiabilityService.getDataByCustomerId(id);
    }

    @GetMapping("/get/{id}")
    public GenericResponse getDataByLiabilityId(@PathVariable Long id) {
        return restLiabilityService.getDataByLiabilityId(id);
    }


}
