package com.wm.cockpit.dto;

import com.wm.cockpit.entity.ScenarioItem;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ScenarioItemDto {
    private Long id;
    private Double referenceCurrencyExchange;
    private Double familyHoldingExchange;
    private Double standardDeviation;
    private Long debtSwapSource;
    private Double debtSwapValue;
    private Long debtSwapTarget;
    private Double liquidityEventValue;
    private Long liquidityEventCurrency;
    private String liquidityEventInYear;
    private Double leveragePurchaseWorth;
    private Long leveragePurchaseCurrency;
    private String additionalLeveragePurchase;
    private Long scenarioHeader;

    public ScenarioItemDto(ScenarioItem entity){
        this.id = entity.getId();
        this.referenceCurrencyExchange = entity.getReferenceCurrencyExchange();
        this.familyHoldingExchange = entity.getFamilyHoldingExchange();
        this.standardDeviation = entity.getStandardDeviation();
        this.debtSwapSource = entity.getDebtSwapSource().getId();
        this.debtSwapValue = entity.getDebtSwapValue();
        this.debtSwapTarget = entity.getDebtSwapTarget().getId();
        this.liquidityEventValue =entity.getLiquidityEventValue();
        this.liquidityEventCurrency =entity.getLiquidityEventCurrency().getId();
        this.liquidityEventInYear = entity.getLiquidityEventInYear();
        this.leveragePurchaseWorth = entity.getLeveragePurchaseWorth();
        this.leveragePurchaseCurrency = entity.getLeveragePurchaseCurrency().getId();
        this.scenarioHeader =entity.getScenarioHeader().getId();
    }
}
