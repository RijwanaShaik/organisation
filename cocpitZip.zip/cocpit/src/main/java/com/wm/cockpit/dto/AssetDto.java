package com.wm.cockpit.dto;

import java.util.List;

import com.wm.cockpit.entity.AssetDependency;
import com.wm.cockpit.entity.Country;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.enums.DirectLiquidity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AssetDto {

    private long id;
    private String name;
    private long value;
    private Long currencyId;
    private DirectLiquidity directLiquidity;
    private float indirectLiquidity;
    private float cashDistributionRate;
    private float accruedDistributionRate;
    private Long  countryOfEconomicExposure;
    private List<CountryDto> countryOfLegalExposure;
    private Boolean isFamilyHolding;
    private Long existingLending;
    private double existingValue;
    private Long specificLiability;
    private Long customerId;
    private Long sectorId;
    private List<AssetDependencyDto> assetDependencyDtos;
    private String climateChangeExposure;

}
