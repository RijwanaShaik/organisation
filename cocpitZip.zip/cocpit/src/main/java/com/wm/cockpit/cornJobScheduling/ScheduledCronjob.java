package com.wm.cockpit.cornJobScheduling;

import com.wm.cockpit.repositary.ExchangeRateRepository;
import com.wm.cockpit.repositary.OtpRepository;
import com.wm.cockpit.service.impl.ExchangeRateServiceUrlImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.stereotype.Component;

@Component
public class ScheduledCronjob {

    @Autowired
    private OtpRepository otpRepository;

    @Autowired
    private ExchangeRateRepository exchangeRateRepository;

    @Autowired
    private ExchangeRateServiceUrlImpl exchangeRateServiceUrl;

    @Qualifier("sessionRegistry")
    private SessionRegistry sessionRegistry;

    //  @Scheduled(cron = "*/30 * * * *")
    public void disableLoginOtp() {
        try {
            otpRepository.updateExpiryStatus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //@Scheduled(cron = "0 45 8 * * *")
    public void updateOfCronJobForExchangeRate() {
        System.out.println(":: IN updateOfCronJobForExchangeRate JOB");
        try {
            // Disable previous exchange rates
            exchangeRateRepository.disablePreviousExchangneRates();
            //Dump latest exchange rates into DB
            exchangeRateServiceUrl.getAllCurrencies();
            System.out.println(":: DONE updateOfCronJobForExchangeRate JOB");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}