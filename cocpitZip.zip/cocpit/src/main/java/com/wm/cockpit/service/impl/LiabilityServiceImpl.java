package com.wm.cockpit.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.wm.cockpit.dto.LiabilityDependencyDto;
import com.wm.cockpit.entity.*;
import com.wm.cockpit.enums.CustomerLevel;
import com.wm.cockpit.exceptions.IdNotFoundException;
import com.wm.cockpit.repositary.*;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.utils.DtoUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.wm.cockpit.dto.LiabilityDto;
import com.wm.cockpit.service.LiabilityService;
import org.springframework.transaction.annotation.Transactional;

@Service
public class LiabilityServiceImpl implements LiabilityService {

    @Autowired
    private LiabilityRepository liabilityRepository;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private CountryRepository countryRepositary;
    @Autowired
    private AssetRepository assetRepository;
    @Autowired
    private DependencyRepository dependencyRepository;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private LiabilityDependencyRepository liabilityDependencyRepository;
    @Autowired
    private FileUploadRepository fileUploadRepository;

    @Override
    public String createLiability(LiabilityDto liabilityDto) {
        Liability liability = new Liability();
        liability.setName(liabilityDto.getName());
        liability.setValue(liabilityDto.getValue());
        if (liabilityDto.getCurrencyId() != null) {
            Currency currency = currencyRepository.findById(liabilityDto.getCurrencyId()).get();
            liability.setCurrency(currency);
        }
        if (liabilityDto.getCustomer() != 0) {
            Customer customer = customerRepository.findById(liabilityDto.getCustomer()).get();
            liability.setCustomer(customer);
        }
        liability.setCostOfDebt(liabilityDto.getCostOfDebt());
        if (liabilityDto.getCountryOfLegalExposure() != null) {
            Country country = countryRepositary.findById(liabilityDto.getCountryOfLegalExposure()).get();
            liability.setCountryOfLegalExposure(country);
        }
        if (liabilityDto.getExistingLending() != null) {
            Currency currencyId = currencyRepository.findById(liabilityDto.getExistingLending()).get();
            liability.setExistingLending(currencyId);
        }
        liability.setExistingValue(liabilityDto.getExistingValue());
        if (liabilityDto.getLiabilityDependencyDto() != null) {
            List<LiabilityDependencyDto> liabilityDependencyDtos = liabilityDto.getLiabilityDependencyDto();
            List<LiabilityDependency> liabilityDependenciesList = new ArrayList<>();
            for (LiabilityDependencyDto dependencyDto : liabilityDependencyDtos) {
                LiabilityDependency liabilityDependencyModel = new LiabilityDependency();
                Dependency dependency = dependencyRepository.findById(dependencyDto.getDependencyId()).get();
                liabilityDependencyModel.setDependency(dependency);
                liabilityDependencyModel.setLiability(liability);
                liabilityDependencyModel.setShare(dependencyDto.getShare());
                liabilityDependenciesList.add(liabilityDependencyModel);
            }

            liability.setLiabilityDependencies(liabilityDependenciesList);
        }
        Asset asset = assetRepository.findById(liabilityDto.getSpecificAsset()).get();
        liability.setSpecificAsset(asset);
        liabilityRepository.save(liability);
        return "Created Liability Successfully...";
    }

    @Override
    public GenericResponse updatedLiabilityById(LiabilityDto liabilityDto) throws Exception {
        return liablityUpdate(liabilityDto);
    }

    @Override
    @Transactional
    public GenericResponse updatedLiabilityRest(LiabilityDto liabilityDto) throws Exception {
        Liability liability = null;
        Liability optionalLiability = liabilityRepository.getById(liabilityDto.getId());
        if (liabilityDto != null && optionalLiability != null) {
            if (!optionalLiability.getName().equals(liabilityDto.getName())) {
                long optLiability = liabilityRepository.countByNameAndCustomer(liabilityDto.getName(), optionalLiability.getCustomer());
                if (optLiability >= 1) {
                    return new GenericResponse(HttpStatus.BAD_REQUEST, "Liability Already  Existed...");
                }
            }
            List<LiabilityDependency> liabilityDependenciesList = new ArrayList<>();
            liability = optionalLiability;
            Customer customer = customerRepository.findById(liabilityDto.getCustomer()).get();
            if(customer.getLevel().equals(CustomerLevel.LEVEL_1)){
                if (!DtoUtils.isEmpty(liabilityDto.getName())) {
                    liability.setName(liabilityDto.getName());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getValue())) {
                    liability.setValue(liabilityDto.getValue());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCurrencyId())) {
                    Currency currency = currencyRepository.findById(liabilityDto.getCurrencyId()).get();
                    liability.setCurrency(currency);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCustomer())) {
                   // Customer customer = customerRepository.findById(liabilityDto.getCustomer()).get();
                    liability.setCustomer(customer);
                }
                if (liabilityDto.getFileIds() != null) {
                    List<FileUpload> fileUploads = new ArrayList<>();
                    for (Long fileId : liabilityDto.getFileIds()) {
                        Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                        if (optional.isPresent()) {
                            fileUploads.add(optional.get());
                        } else {
                            throw new IdNotFoundException("No File found with given id!!");
                        }
                    }
                    liability.setFileUploads(fileUploads);
                }
                liabilityRepository.save(liability);
            }
            else if(customer.getLevel().equals(CustomerLevel.LEVEL_2)){
                if (!DtoUtils.isEmpty(liabilityDto.getName())) {
                    liability.setName(liabilityDto.getName());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getValue())) {
                    liability.setValue(liabilityDto.getValue());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCurrencyId())) {
                    Currency currency = currencyRepository.findById(liabilityDto.getCurrencyId()).get();
                    liability.setCurrency(currency);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCustomer())) {
                  //  Customer customer = customerRepository.findById(liabilityDto.getCustomer()).get();
                    liability.setCustomer(customer);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCountryOfLegalExposure())) {
                    Country country = countryRepositary.findById(liabilityDto.getCountryOfLegalExposure()).get();
                    liability.setCountryOfLegalExposure(country);
                }
                if (liabilityDto.getFileIds() != null) {
                    List<FileUpload> fileUploads = new ArrayList<>();
                    for (Long fileId : liabilityDto.getFileIds()) {
                        Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                        if (optional.isPresent()) {
                            fileUploads.add(optional.get());
                        } else {
                            throw new IdNotFoundException("No File found with given id!!");
                        }
                    }
                    liability.setFileUploads(fileUploads);
                }
                liabilityRepository.save(liability);
            }
            else if(customer.getLevel().equals(CustomerLevel.LEVEL_3)) {

                if (!DtoUtils.isEmpty(liabilityDto.getName())) {
                    liability.setName(liabilityDto.getName());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getValue())) {
                    liability.setValue(liabilityDto.getValue());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCurrencyId())) {
                    Currency currency = currencyRepository.findById(liabilityDto.getCurrencyId()).get();
                    liability.setCurrency(currency);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCustomer())) {
                 //   Customer customer = customerRepository.findById(liabilityDto.getCustomer()).get();
                    liability.setCustomer(customer);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCostOfDebt())) {
                    liability.setCostOfDebt(liabilityDto.getCostOfDebt());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCountryOfLegalExposure())) {
                    Country country = countryRepositary.findById(liabilityDto.getCountryOfLegalExposure()).get();
                    liability.setCountryOfLegalExposure(country);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getExistingLending())) {
                    Currency currencyId = currencyRepository.findById(liabilityDto.getExistingLending()).get();
                    liability.setExistingLending(currencyId);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getExistingValue())) {
                    liability.setExistingValue(liabilityDto.getExistingValue());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getLiabilityDependencyDto())) {

                    List<LiabilityDependencyDto> liabilityDependencyDtos = liabilityDto.getLiabilityDependencyDto();
                    List<LiabilityDependency> liabilityDependencies = liability.getLiabilityDependencies();
                    for (LiabilityDependencyDto liabilityDependencyDto : liabilityDependencyDtos) {
                        if (!DtoUtils.isEmpty(liabilityDependencyDto.getId()) && liabilityDependencyDto.getId() != 0) {
                            LiabilityDependency liabilityDependency = liabilityDependencyRepository.findById(liabilityDependencyDto.getId()).get();
                            if (!DtoUtils.isEmpty(liabilityDependencyDto.getDependencyId())) {
                                Dependency dependency = dependencyRepository.findById(liabilityDependencyDto.getDependencyId()).get();
                                liabilityDependency.setDependency(dependency);
                            }
                            liabilityDependency.setShare(liabilityDependencyDto.getShare());
                            liabilityDependency.setIsDeleted(false);
                            liabilityDependenciesList.add(liabilityDependency);
                        } else {
                            LiabilityDependency liabilityDependency = new LiabilityDependency();
                            Dependency dependency = dependencyRepository.findById(liabilityDependencyDto.getDependencyId()).get();
                            liabilityDependency.setDependency(dependency);
                            liabilityDependency.setShare(liabilityDependencyDto.getShare());
                            liabilityDependenciesList.add(liabilityDependency);
                            liabilityDependency.setLiability(liability);
                        }
                    }
                    liability.setLiabilityDependencies(liabilityDependenciesList);
                }
                Asset asset = null;
                if (!DtoUtils.isEmpty(liabilityDto.getSpecificAsset())) {
                    asset = assetRepository.getById(liabilityDto.getSpecificAsset());
                    liability.setSpecificAsset(asset);
                }
                liability.setLiabilityDependencies(liabilityDependenciesList);
                if (liabilityDto.getFileIds() != null) {
                    List<FileUpload> fileUploads = new ArrayList<>();
                    for (Long fileId : liabilityDto.getFileIds()) {
                        Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                        if (optional.isPresent()) {
                            fileUploads.add(optional.get());
                        } else {
                            throw new IdNotFoundException("No File found with given id!!");
                        }
                    }
                    liability.setFileUploads(fileUploads);
                }
                Liability savedLiability = liabilityRepository.save(liability);
                if (liabilityDto.getSpecificAsset() != null && liabilityDto.getSpecificAsset() != 0) {
                    asset.setSpecificLiability(savedLiability);
                    assetRepository.save(asset);
                }
            }

            return new GenericResponse(HttpStatus.OK, "Updated Success");

        } else if (optionalLiability == null) {
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Data Not found with Liability Id");
        }
        return new GenericResponse(HttpStatus.BAD_REQUEST, " Please Provide Proper Info");

    }

    private GenericResponse liablityUpdate(LiabilityDto liabilityDto) throws Exception {
        Liability liability = null;
        if (liabilityDto != null) {
            Liability optionalLiability = liabilityRepository.getById(liabilityDto.getId());
            if (optionalLiability != null) {
                if (optionalLiability.getName().equals(liabilityDto.getName())) {
                    long optLiability = liabilityRepository.countByNameAndCustomer(liabilityDto.getName(), optionalLiability.getCustomer());
                    if (optLiability >= 1) {
                        return new GenericResponse(HttpStatus.BAD_REQUEST, "Liability Already  Existed...");
                    }
                }
                List<LiabilityDependency> liabilityDependenciesList = new ArrayList<>();
                liability = optionalLiability;
                if (!DtoUtils.isEmpty(liabilityDto.getName())) {
                    liability.setName(liabilityDto.getName());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getValue())) {
                    liability.setValue(liabilityDto.getValue());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCurrencyId())) {
                    Currency currency = currencyRepository.findById(liabilityDto.getCurrencyId()).get();
                    liability.setCurrency(currency);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCustomer())) {
                    Customer customer = customerRepository.findById(liabilityDto.getCustomer()).get();
                    liability.setCustomer(customer);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCostOfDebt())) {
                    liability.setCostOfDebt(liabilityDto.getCostOfDebt());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getCountryOfLegalExposure())) {
                    Country country = countryRepositary.findById(liabilityDto.getCountryOfLegalExposure()).get();
                    liability.setCountryOfLegalExposure(country);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getExistingLending())) {
                    Currency currencyId = currencyRepository.findById(liabilityDto.getExistingLending()).get();
                    liability.setExistingLending(currencyId);
                }
                if (!DtoUtils.isEmpty(liabilityDto.getExistingValue())) {
                    liability.setExistingValue(liabilityDto.getExistingValue());
                }
                if (!DtoUtils.isEmpty(liabilityDto.getLiabilityDependencyDto())) {

                    List<LiabilityDependencyDto> liabilityDependencyDtos = liabilityDto.getLiabilityDependencyDto();
                    List<LiabilityDependency> liabilityDependencies = liability.getLiabilityDependencies();
                    for (LiabilityDependencyDto liabilityDependencyDto : liabilityDependencyDtos) {
                        if (!DtoUtils.isEmpty(liabilityDependencyDto.getId()) && liabilityDependencyDto.getId() != 0) {
                            LiabilityDependency liabilityDependency = liabilityDependencyRepository.findById(liabilityDependencyDto.getId()).get();
                            if (!DtoUtils.isEmpty(liabilityDependencyDto.getDependencyId())) {
                                Dependency dependency = dependencyRepository.findById(liabilityDependencyDto.getDependencyId()).get();
                                liabilityDependency.setDependency(dependency);
                            }
                            liabilityDependency.setShare(liabilityDependencyDto.getShare());
                            liabilityDependency.setIsDeleted(false);
                            liabilityDependenciesList.add(liabilityDependency);
                        } else {
                            LiabilityDependency liabilityDependency = new LiabilityDependency();
                            Dependency dependency = dependencyRepository.findById(liabilityDependencyDto.getDependencyId()).get();
                            liabilityDependency.setDependency(dependency);
                            liabilityDependency.setShare(liabilityDependencyDto.getShare());
                            liabilityDependenciesList.add(liabilityDependency);
                            liabilityDependency.setLiability(liability);
                        }
                    }
                    liability.setLiabilityDependencies(liabilityDependenciesList);
                }
                Asset asset = null;
                if (!DtoUtils.isEmpty(liabilityDto.getSpecificAsset())) {
                    asset = assetRepository.getById(liabilityDto.getSpecificAsset());
                    liability.setSpecificAsset(asset);
                }
                liability.setLiabilityDependencies(liabilityDependenciesList);
                Liability savedLiability = liabilityRepository.save(liability);
                if (liabilityDto.getSpecificAsset() != null && liabilityDto.getSpecificAsset() != 0) {
                    asset.setSpecificLiability(savedLiability);
                    assetRepository.save(asset);
                }

                return new GenericResponse(HttpStatus.OK, "Updated Success");

            } else if (optionalLiability == null) {
                return new GenericResponse(HttpStatus.BAD_REQUEST, "Data Not found with Liability Id");
            }
        }
        return new GenericResponse(HttpStatus.BAD_REQUEST, " Please Provide Proper Info");
    }

    @Override
    public String deletedLiabilityById(long id) {
        if (id != 0) {
            Optional<Liability> optional = liabilityRepository.findById(id);
            if (optional.isPresent())
                liabilityRepository.deleteById(id);
            return "Liability Id %id is Successfully deleted......+";
        } else {
            return "Id = %id Is Not Found ........";
        }
    }

    @Override
    public Liability getLiabilityById(long id) throws Exception {

        Optional<Liability> optional = liabilityRepository.findById(id);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new Exception(" Liability Id %id is Not Found....");
        }
    }

    @Override
    public List<Liability> getAllLiabilities() {
        return liabilityRepository.findAll().stream().sorted(Comparator.comparing(Liability::getUpdatedOn).reversed()).collect(Collectors.toList());
    }
}
