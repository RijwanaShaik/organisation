package com.wm.cockpit.controller;

import java.util.List;

import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.response.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wm.cockpit.dto.AssetDto;
import com.wm.cockpit.entity.Asset;
import com.wm.cockpit.service.AssetService;

@RestController
@RequestMapping("/api/v1/asset")
public class AssetController {

	@Autowired
	private AssetService assetService;

	private final Logger logger = LoggerFactory.getLogger( Asset.class );
	@MutationMapping(name = "createAsset")
	public String createAsset(@Argument(name = "input") AssetDto assetDto) {
		return assetService.createAsset(assetDto);
	}

	@MutationMapping(name = "updateAssetById")
	public Asset updateAssetById(@Argument(name = "id") AssetDto assetDto) throws Exception {
		return assetService.updateAssetById(assetDto);
	}

	@MutationMapping(name = "deletedAssetById")
	public String deletedAssetById(@Argument(name ="id") long id) {
		return assetService.deletedAssetById(id);
	}

	@QueryMapping(name = "getAssetById")
	public Asset getAssetById(@Argument(name = "id") long id) throws Exception {
		return assetService.getAssetById(id);
	}

	@QueryMapping(name = "getAllAssets")
	public List<Asset> getAllAssets() throws Exception {
		return assetService.getAllAssets();
	}

	@QueryMapping(name ="getAssetByCustomerId")
	public  Asset getAssetCustomerById(@Argument(name = "id") long id ){
		return assetService.getAssetByCustomerId(id);
	}

	@GetMapping(value = "/get-all-climate-change-exposures")
	public GenericResponse getAllClimateChangeExposures(){
		logger.info( "Get All CLimate Exposures Service Started" );
		GenericResponse response = assetService.getAllClimateChangeExposures();
		logger.info( "Get All CLimate Exposures Service Completed" );
		return response;

	}

	@GetMapping(value = "/get-count-by-climate-exposure")
	public GenericResponse getCountByClimateExposure(){
		logger.info( "Get Count Of Assets By CLimate Exposures Service Started" );
		GenericResponse response = assetService.getCountByClimateExposure();
		logger.info( "Get Count Of Assets By CLimate Exposures Service Completed" );
		return response;
	}


}
