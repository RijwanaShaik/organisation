package com.wm.cockpit.controller;

import com.wm.cockpit.dto.LegalExposureDto;
import com.wm.cockpit.entity.LegalExposure;
import com.wm.cockpit.service.LegalExposureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/economicExploser")
public class EconomicExposureController {
    @Autowired
    private LegalExposureService legalExposureService;

    @MutationMapping(name = "createEconomicExposure")
    public String createEconomicExposure(@Argument(name = "input") LegalExposureDto legalExposureDto) {
        return legalExposureService.createEconomicExposure(legalExposureDto);
    }

    @QueryMapping(name = "getAllEconomicExposure")
    public List<LegalExposure> getAllEconomicExposure() {
        return legalExposureService.getAllEconomicExposure();
    }
}
