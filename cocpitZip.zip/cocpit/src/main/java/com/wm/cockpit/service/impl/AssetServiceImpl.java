package com.wm.cockpit.service.impl;


import java.util.*;
import java.util.stream.Collectors;

import com.wm.cockpit.dto.*;
import com.wm.cockpit.entity.*;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.enums.ClimateChangeExposure;
import com.wm.cockpit.repositary.*;
import com.wm.cockpit.response.GenericResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.wm.cockpit.service.AssetService;

@Service
public class AssetServiceImpl implements AssetService {

    @Autowired
    private AssetRepository assetRepository;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private CountryRepository countryRepositary;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private SectorRepository sectorRepository;
    @Autowired
    private LiabilityRepository liabilityRepository;
    @Autowired
    private LegalExposureRepository legalExposureRepository;

    @Autowired
    private DependencyRepository dependencyRepository;

    @Override
    public String createAsset(AssetDto assetDto) {
        Asset asset = convertDtoToEntity(assetDto);
        assetRepository.save(asset);
        return "Asset Created Succesfully";
    }

    private Asset convertDtoToEntity(AssetDto assetDto) {
        Asset asset = new Asset();
        asset.setName(assetDto.getName());
        asset.setValue(assetDto.getValue());
        Sector sector = sectorRepository.findById(assetDto.getSectorId()).get();
        asset.setSector(sector);
        Customer customer = customerRepository.findById(assetDto.getCustomerId()).get();
        asset.setCustomer(customer);
        Currency currency = currencyRepository.findById(assetDto.getCurrencyId()).get();
        asset.setCurrency(currency);
        asset.setDirectLiquidity(assetDto.getDirectLiquidity());
        asset.setIndirectLiquidity(asset.getIndirectLiquidity());
        asset.setCashDistributionRate(assetDto.getCashDistributionRate());
        asset.setAccruedDistributionRate(assetDto.getAccruedDistributionRate());
        List<CountryDto> countryDtos = assetDto.getCountryOfLegalExposure();
        List<LegalExposure> legalExposures = new ArrayList<>();
        for (CountryDto countryDto : countryDtos) {
            LegalExposure legalExposure = new LegalExposure();
            Country country = countryRepositary.findById(countryDto.getId()).get();
            legalExposure.setCountry(country);
            legalExposure.setAsset(asset);
            legalExposures.add(legalExposure);
        }
        asset.setCountryOfLegalExposure(legalExposures);
        List<AssetDependencyDto> assetDependencyDtos = assetDto.getAssetDependencyDtos();
        List<AssetDependency> assetDependencyList = new ArrayList<>();
        for (AssetDependencyDto dependencyDto : assetDependencyDtos) {
            AssetDependency assetDependencyModel = new AssetDependency();
            Dependency dependency = dependencyRepository.findById(dependencyDto.getDependencyId()).get();
            assetDependencyModel.setDependency(dependency);
            assetDependencyModel.setAsset(asset);
            assetDependencyModel.setShare(dependencyDto.getShare());
            assetDependencyList.add(assetDependencyModel);
        }
        asset.setAssetDependencies(assetDependencyList);

        Country countryId = countryRepositary.findById(assetDto.getCountryOfEconomicExposure()).get();
        asset.setCountryOfEconomicExposure(countryId);
        asset.setIsFamilyHolding(assetDto.getIsFamilyHolding());
        Currency currencyId = currencyRepository.findById(assetDto.getExistingLending()).get();
        asset.setExistingLending(currencyId);
        asset.setExistingValue(assetDto.getExistingValue());
        Liability liability = liabilityRepository.findById(assetDto.getSpecificLiability()).get();
        asset.setSpecificLiability(liability);
        asset.setClimateChangeExposure(ClimateChangeExposure.getEnum(assetDto.getClimateChangeExposure()));
        return asset;
    }

    @Override
    public Asset updateAssetById(AssetDto assetDto) throws Exception {
        Asset asset;
        if (assetDto != null) {
            Optional<Asset> assetId = assetRepository.findById(assetDto.getId());
            if (assetId.isPresent()) {
                asset = assetId.get();
                asset.setName(assetDto.getName());
                asset.setValue(assetDto.getValue());
                Sector sector = sectorRepository.findById(assetDto.getSectorId()).get();
                asset.setSector(sector);
                Customer customer = customerRepository.findById(assetDto.getCustomerId()).get();
                asset.setCustomer(customer);
                Currency currency = currencyRepository.findById(assetDto.getCurrencyId()).get();
                asset.setCurrency(currency);
                asset.setDirectLiquidity(assetDto.getDirectLiquidity());
                asset.setIndirectLiquidity(asset.getIndirectLiquidity());
                asset.setCashDistributionRate(assetDto.getCashDistributionRate());
                asset.setAccruedDistributionRate(assetDto.getAccruedDistributionRate());
                List<CountryDto> countryDtos = assetDto.getCountryOfLegalExposure();
                List<LegalExposure> legalExposures = new ArrayList<>();
                for (CountryDto countryDto : countryDtos) {
                    LegalExposure legalExposure = new LegalExposure();
                    Country country = countryRepositary.findById(countryDto.getId()).get();
                    legalExposure.setCountry(country);
                    legalExposure.setAsset(asset);
                    legalExposures.add(legalExposure);
                }
                asset.setCountryOfLegalExposure(legalExposures);
                List<AssetDependencyDto> assetDependencyDtos = assetDto.getAssetDependencyDtos();
                List<AssetDependency> assetDependencyList = new ArrayList<>();
                for (AssetDependencyDto dependencyDto : assetDependencyDtos) {
                    AssetDependency assetDependencyModel = new AssetDependency();
                    Dependency dependency = dependencyRepository.findById(dependencyDto.getDependencyId()).get();
                    assetDependencyModel.setDependency(dependency);
                    assetDependencyModel.setAsset(asset);
                    assetDependencyModel.setShare(dependencyDto.getShare());
                    assetDependencyList.add(assetDependencyModel);
                }
                asset.setAssetDependencies(assetDependencyList);

                Country countryId = countryRepositary.findById(assetDto.getCountryOfEconomicExposure()).get();
                asset.setCountryOfEconomicExposure(countryId);
                asset.setIsFamilyHolding(assetDto.getIsFamilyHolding());
                Currency currencyId = currencyRepository.findById(assetDto.getExistingLending()).get();
                asset.setExistingLending(currencyId);
                asset.setExistingValue(assetDto.getExistingValue());
                Liability liability = liabilityRepository.findById(assetDto.getSpecificLiability()).get();
                asset.setSpecificLiability(liability);
                asset.setClimateChangeExposure(ClimateChangeExposure.getEnum(assetDto.getClimateChangeExposure()));
                return assetRepository.save(asset);
            } else {
                throw new Exception("Asset Id  Not Found");
            }
        }
        return new Asset();
    }

    @Override
    public String deletedAssetById(long id) {
        Optional<Asset> optional = assetRepository.findById(id);
        if (optional.isPresent()) {
            assetRepository.deleteById(id);
            return "Asset Id Is Deleted Successfully......";
        } else {
            return "Id  Is Not Found .....";
        }
    }

    @Override
    public List<Asset> getAllAssets() throws Exception {
        List<Asset> assets = new ArrayList<>();
        assets = assetRepository.findAll();
        if (assets != null && assets.size() > 0) {
            return assets.stream().sorted(Comparator.comparing(Asset::getId).reversed()).collect(Collectors.toList());
        } else {
            throw new Exception(" There Is No Assets For The Customers ");
        }
    }

    @Override
    public Asset getAssetById(long id) throws Exception {
        Optional<Asset> optional = assetRepository.findById(id);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new Exception(" Asset Id  is Not Found .....");
        }
    }

    @Override
    public Asset getAssetByCustomerId(long id) {
        Asset asset = assetRepository.findAssetsByCustomerId(id);
        System.out.println(asset);
        return asset;
    }

    @Override
    public GenericResponse getAllClimateChangeExposures() {
        List<ClimateChangeExposure> list = List.of(ClimateChangeExposure.values());
        return new GenericResponse(HttpStatus.OK, list.stream().map(enumValue -> Map.of("name", ClimateChangeExposure.getString(enumValue))).collect(Collectors.toList()));
    }

    @Override
    public GenericResponse getCountByClimateExposure() {
        List<Asset> assetList = assetRepository.findAll();
        ClimateChangeResponseDto dto = new ClimateChangeResponseDto();
        Map<ClimateChangeExposure, Long> exposureCountMap = assetList.stream()
                .filter(asset -> asset.getClimateChangeExposure() != null)
                .collect(Collectors.groupingBy(
                        Asset::getClimateChangeExposure,
                        Collectors.counting()
                ));
        exposureCountMap.forEach((exposure, count) -> {
            switch (exposure) {
                case LOW:
                    dto.setLow(count);
                    break;
                case HIGH:
                    dto.setHigh(count);
                    break;
                case MEDIUM:
                    dto.setMedium(count);
                    break;
                case VERY_HIGH:
                    dto.setVeryHigh(count);
                    break;
                case NONE:
                    dto.setNone(count);
                    break;
            }
        });
        return new GenericResponse(HttpStatus.OK, dto);
    }

}
