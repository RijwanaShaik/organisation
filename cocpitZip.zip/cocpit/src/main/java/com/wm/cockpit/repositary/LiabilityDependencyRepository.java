package com.wm.cockpit.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import com.wm.cockpit.entity.LiabilityDependency;
import java.util.List;

@Repository
public interface LiabilityDependencyRepository extends JpaRepository<LiabilityDependency, Long>{

  @Modifying
  void deleteByLiabilityId(Long id);

  List<LiabilityDependency> findByLiabilityCustomerIdAndIsDeletedFalse(Long id);
}
