package com.wm.cockpit.validation;

import java.util.List;

public class Validator {

    public static Boolean isValid(List<?> objList) {
        if ((objList != null) && !objList.isEmpty()) {
            return Boolean.TRUE;
        }

        return Boolean.FALSE;
    }

}
