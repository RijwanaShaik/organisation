package com.wm.cockpit.service;

import java.util.List;

import com.wm.cockpit.dto.LiabilityDto;
import com.wm.cockpit.entity.Liability;
import com.wm.cockpit.response.GenericResponse;

public interface LiabilityService {

	String createLiability(LiabilityDto liabilityDto);
	
	GenericResponse updatedLiabilityById(LiabilityDto liabilityDto) throws Exception;

	GenericResponse updatedLiabilityRest(LiabilityDto liabilityDto) throws Exception;

	String deletedLiabilityById(long id);
	
	Liability getLiabilityById(long id) throws Exception;
	
	List<Liability> getAllLiabilities();
	
	
}
