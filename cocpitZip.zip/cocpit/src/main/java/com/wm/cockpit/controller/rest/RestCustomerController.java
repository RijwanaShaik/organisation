package com.wm.cockpit.controller.rest;

import com.wm.cockpit.dto.CustomerDto;
import com.wm.cockpit.dto.rest.RestCustomerDto;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.rest.RestCustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/rest/customer")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class RestCustomerController {


    @Autowired
    RestCustomerService restCustomerService;

    @PostMapping("/add")
    public GenericResponse save(@RequestBody RestCustomerDto dto) {
        return restCustomerService.save(dto);
    }

    @GetMapping("/get-all")
    public GenericResponse getAll() {
        return restCustomerService.getAll();
    }


    @GetMapping("/get-wealth/{id}")
    public GenericResponse getWealth(@PathVariable long id) {

        return restCustomerService.getTotalWealth(id);
    }

    @GetMapping("/get-wealth")
    public GenericResponse getWealth() {
        return restCustomerService.getTotalWealth();
    }

    @GetMapping("/conversion/{source}/{destination}/{value}")
    public GenericResponse getWealth(@PathVariable String source, @PathVariable String destination, @PathVariable double value) {
        return restCustomerService.convert(source, destination, value);
    }


    @DeleteMapping("/delete/{id}")
    public GenericResponse delete(@PathVariable long id) {
        return restCustomerService.delete(id);
    }

    @GetMapping("/get-all-with-wealth")
    public GenericResponse getAllWithWealth(){
        return restCustomerService.getAllCustomersWithWealth();
    }
    @GetMapping("/get-by-id-with-wealth/{customerId}")
    public GenericResponse getCustomerById(@PathVariable Long customerId){
        return restCustomerService.getCustomerByIdWithWealth(customerId);
    }

}
