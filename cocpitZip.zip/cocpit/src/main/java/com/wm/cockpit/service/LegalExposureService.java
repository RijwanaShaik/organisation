package com.wm.cockpit.service;

import com.wm.cockpit.dto.LegalExposureDto;
import com.wm.cockpit.entity.LegalExposure;

import java.util.List;

public interface LegalExposureService {
    String createEconomicExposure(LegalExposureDto legalExposureDto);
    List<LegalExposure>getAllEconomicExposure();
}
