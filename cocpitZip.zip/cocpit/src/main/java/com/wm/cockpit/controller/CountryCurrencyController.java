package com.wm.cockpit.controller;

import com.wm.cockpit.dto.CountryCurrencyMsgDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/template/countries")
@ComponentScan(basePackages = {"com.wm.cockpit.*"})
public class CountryCurrencyController {
    @Autowired
    private com.wm.cockpit.service.impl.CountryCurrencyServiceImpl countryCurrencyServiceImpl;

    @GetMapping("/save")
    public CountryCurrencyMsgDto getCountryCurrDto(){
        return countryCurrencyServiceImpl.getCountries();
    }

    @GetMapping("/updateLocation")
    public void getUpdateLocation(){
        countryCurrencyServiceImpl.updateLocation();
    }


}
