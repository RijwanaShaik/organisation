package com.wm.cockpit.controller;

import com.wm.cockpit.dto.ExchangeCurrencyRateMsgDto;
import com.wm.cockpit.entity.ExchangeRate;
import com.wm.cockpit.service.ExchangeRateService;
import com.wm.cockpit.service.impl.ExchangeRateServiceUrlImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.List;

@RestController
@RequestMapping("/api/v1/exchangeRate")
@ComponentScan(basePackages = {"com.wm.cockpit.*"})
public class ExchangeRateController {

    @Autowired
    private ExchangeRateServiceUrlImpl exchangeRateServiceUrl;

    @Autowired
    private ExchangeRateService exchangeRateService;

    @GetMapping
    public ExchangeCurrencyRateMsgDto getAllExchangeRate() throws MalformedURLException, URISyntaxException {
        return exchangeRateServiceUrl.getAllCurrencies();
    }

    @QueryMapping(name = "getAllExchangeRates")
    public List<ExchangeRate> getAllExchangeRates() throws Exception {
        return exchangeRateService.getAllExchangeRates();
    }
}
