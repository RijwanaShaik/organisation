package com.wm.cockpit.controller;

import com.wm.cockpit.entity.Country;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/country")
@ComponentScan(basePackages = {"com.wm.cockpit.*"})
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class CountryController {

    @Autowired
    private CountryService countryService;

//    @GetMapping
//   public ResponseEntity<List<Country>> getAllCountries(){
//        return new ResponseEntity<>(countryService.getAllCountries(), HttpStatus.OK);
//    }

   /* @GetMapping("/get-all-countries")
    public List<Country> getAllCountries() {
        return countryService.getAllCountries();
    }*/


    @QueryMapping(name = "getAllCountries")
    public List<Country> getAllCountries() {
        return countryService.getAllCountries();
    }

    @GetMapping("/id")
    public ResponseEntity<Country> getCountryById(long id) throws Exception {
        return new ResponseEntity<>(countryService.getCountryById(id), HttpStatus.OK);
    }

    @GetMapping("/get-all-countries")
    public GenericResponse getAllRestCountries() {
        return countryService.getAllRestCountries();
    }

}
