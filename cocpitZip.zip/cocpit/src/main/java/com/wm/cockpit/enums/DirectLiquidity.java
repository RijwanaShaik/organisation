package com.wm.cockpit.enums;

public enum DirectLiquidity {

    LIQUID_ASSET, ILLIQUID_ASSET;

}
