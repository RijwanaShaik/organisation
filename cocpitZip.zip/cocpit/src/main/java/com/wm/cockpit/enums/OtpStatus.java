package com.wm.cockpit.enums;

public enum OtpStatus {

    ACTIVE, VERIFIED, EXPERIED;

}
