package com.wm.cockpit.service.impl.rest;

import com.wm.cockpit.dto.FileUploadDto;
import com.wm.cockpit.dto.LiabilityDependencyDto;
import com.wm.cockpit.dto.ScenarioSettingsDto;
import com.wm.cockpit.dto.ScenariosSettingLegalExposureDto;
import com.wm.cockpit.dto.rest.CustomerLiabilityResponseDto;
import com.wm.cockpit.dto.rest.LiabilityRestDto;
import com.wm.cockpit.entity.*;
import com.wm.cockpit.enums.ClimateChangeExposure;
import com.wm.cockpit.enums.CustomerLevel;
import com.wm.cockpit.exceptions.IdNotFoundException;
import com.wm.cockpit.repositary.*;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.rest.RestLiabilityService;
import com.wm.cockpit.utils.DtoUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RestLiabilityServiceImpl implements RestLiabilityService {


    @Autowired
    private LiabilityDependencyRepository liabilityDependencyRepository;

    @Autowired
    private DependencyRepository dependencyRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    AssetDependencyRepository assetDependencyRepository;

    @Autowired
    private LiabilityRepository liabilityRepository;

    @Autowired
    private CurrencyRepository currencyRepository;

    @Autowired
    private CountryRepository countryRepositary;

    @Autowired
    private AssetRepository assetRepository;

    @Autowired
    private ScenarioSettingsRepository scenarioSettingsRepository;

    @Autowired
    private FileUploadRepository fileUploadRepository;

    @Autowired
    private Environment environment;
    @Override
    @Transactional
    public GenericResponse save(LiabilityRestDto dto) {
        Liability liability = null;
        try {
            Customer customer = customerRepository.findById(dto.getCustomer()).get();

            long optLiability = liabilityRepository.countByNameAndCustomer(dto.getName(), customer);
            if (optLiability >= 1) {
                return new GenericResponse(HttpStatus.BAD_REQUEST, "Liability Is Already Existed ....");
            }
            if (dto.getId() != 0) {
                liability = liabilityRepository.findById(dto.getId()).orElseThrow(() -> new RuntimeException("Please provide valid id"));
            } else {
                liability = new Liability();
            }
            if(customer.getLevel().equals(CustomerLevel.LEVEL_1)){
                if (!DtoUtils.isEmpty(dto.getName())) {
                    liability.setName(dto.getName());
                }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Liability Name Is A Mandatory Field");
                liability.setCurrency(currencyRepository.findById(dto.getCurrencyId()).get());
                if (!DtoUtils.isEmpty(dto.getValue())) {
                    liability.setValue(dto.getValue());
                }else return new GenericResponse(HttpStatus.BAD_REQUEST," Liability Value Is A Mandatory Field");
                liability.setCustomer(customer);
                if (dto.getFileIds() != null) {
                    List<FileUpload> fileUploads = new ArrayList<>();
                    for (Long fileId : dto.getFileIds()) {
                        Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                        if (optional.isPresent()) {
                            fileUploads.add(optional.get());
                        } else {
                            throw new IdNotFoundException("No File found with given id!!");
                        }
                    }
                    liability.setFileUploads(fileUploads);
                }
                liabilityRepository.save(liability);
            }
            else if(customer.getLevel().equals(CustomerLevel.LEVEL_2)){
                if (!DtoUtils.isEmpty(dto.getName())) {
                    liability.setName(dto.getName());
                }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Liability Name Is A Mandatory Field");
                liability.setCurrency(currencyRepository.findById(dto.getCurrencyId()).get());
                if (!DtoUtils.isEmpty(dto.getValue())) {
                    liability.setValue(dto.getValue());
                }else return new GenericResponse(HttpStatus.BAD_REQUEST," Liability Value Is A Mandatory Field");
               if(dto.getCountryOfLegalExposure()!=null) {
                   liability.setCountryOfLegalExposure(countryRepositary.findById(dto.getCountryOfLegalExposure()).get());
               }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Country Of LegalExposure Is A Mandatory Field");
                liability.setCustomer(customer);
                if (dto.getFileIds() != null) {
                    List<FileUpload> fileUploads = new ArrayList<>();
                    for (Long fileId : dto.getFileIds()) {
                        Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                        if (optional.isPresent()) {
                            fileUploads.add(optional.get());
                        } else {
                            throw new IdNotFoundException("No File found with given id!!");
                        }
                    }
                    liability.setFileUploads(fileUploads);
                }
                liabilityRepository.save(liability);
            }
            else if(customer.getLevel().equals(CustomerLevel.LEVEL_3)) {
                if (!DtoUtils.isEmpty(dto.getName())) {
                    liability.setName(dto.getName());
                }
                liability.setCustomer(customer);
                liability.setCurrency(currencyRepository.findById(dto.getCurrencyId()).get());
                if (!DtoUtils.isEmpty(dto.getValue())) {
                    liability.setValue(dto.getValue());
                }
                if (!DtoUtils.isEmpty(dto.getCostOfDebt())) {
                    liability.setCostOfDebt(dto.getCostOfDebt());
                }
                liability.setCountryOfLegalExposure(countryRepositary.findById(dto.getCountryOfLegalExposure()).get());
                if (dto.getExistingLending() != null) {
                    liability.setExistingLending(currencyRepository.findById(dto.getExistingLending()).get());
                } else {
                    liability.setExistingLending(null);
                }
                if (!DtoUtils.isEmpty(dto.getExistingLending())) {
                    liability.setExistingValue(dto.getExistingValue());
                }
                Asset asset = null;
                if (dto.getSpecificAsset() != null && dto.getSpecificAsset() != 0) {
                    asset = assetRepository.getById(dto.getSpecificAsset());

                    liability.setSpecificAsset(asset);
                } else {
                    liability.setSpecificAsset(null);
                }
                //TODO:remove teh existed liability
                if (liability.getId() != null) {
                    liabilityDependencyRepository.deleteByLiabilityId(liability.getId());
                    liability.getLiabilityDependencies().clear();
                }
                if (dto.getLiabilityDependencyDto() != null && !dto.getLiabilityDependencyDto().isEmpty()) {
                    List<LiabilityDependency> liabilityDependencies = new ArrayList<>();
                    for (LiabilityDependencyDto liabilityDependencyDto : dto.getLiabilityDependencyDto()) {
                        Dependency dependency = dependencyRepository.findById(liabilityDependencyDto.getId()).get();
                        LiabilityDependency liabilityDependency = new LiabilityDependency();
                        liabilityDependency.setDependency(dependency);
                        liabilityDependency.setShare(liabilityDependencyDto.getShare());
                        liabilityDependency.setLiability(liability);
                        liabilityDependencies.add(liabilityDependency);
                    }
                    liability.setLiabilityDependencies(liabilityDependencies);

                }
                if (dto.getFileIds() != null) {
                    List<FileUpload> fileUploads = new ArrayList<>();
                    for (Long fileId : dto.getFileIds()) {
                        Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                        if (optional.isPresent()) {
                            fileUploads.add(optional.get());
                        } else {
                            throw new IdNotFoundException("No File found with given id!!");
                        }
                    }
                    liability.setFileUploads(fileUploads);
                }
                Liability savedLiability = liabilityRepository.save(liability);
                if (dto.getSpecificAsset() != null && dto.getSpecificAsset() != 0) {
                    asset.setSpecificLiability(savedLiability);
                    assetRepository.save(asset);
                }
            }
            return new GenericResponse(HttpStatus.OK, "Liability Added Successfully");
        } catch (Exception e) {
            e.printStackTrace();
            return new GenericResponse(HttpStatus.BAD_REQUEST, "FAILURE");
        }

    }

    @Override
    @Transactional
    public GenericResponse delete(Long id) {

        Liability liability = liabilityRepository.findById(id).orElseThrow(() -> new RuntimeException("Please provide valid id"));
        Asset asset = assetRepository.findAssetBySpecificLiabilityId(liability.getId());
        if (asset != null) {
            asset.setSpecificLiability(null);
            assetRepository.save(asset);
        }

        liability.setIsDeleted(Boolean.TRUE);
        liabilityRepository.save(liability);

        return new GenericResponse(HttpStatus.OK, "DELETED SUCCESS");
    }

    @Override
    @Transactional
    public GenericResponse getDataByCustomerId(Long id) {
        Customer customer = customerRepository.findById(id).orElseThrow(() -> new RuntimeException("Please provide valid id"));
        CustomerLiabilityResponseDto response = new CustomerLiabilityResponseDto(customer);
        List<Liability> liabilities = liabilityRepository.findByCustomerIdAndIsDeletedFalse(customer.getId());
        List<Asset> assets = assetRepository.findByCustomerIdAndIsDeletedFalse(customer.getId());
        List<Liability> sortedLiability = liabilities.stream().sorted(Comparator.comparing(Liability::getUpdatedOn).reversed()).collect(Collectors.toList());
        List<Asset> sortedAssets = assets.stream().sorted(Comparator.comparing(Asset::getUpdatedOn).reversed()).collect(Collectors.toList());
        List<Liability> usedLiabilities = new ArrayList<>();
        for (Asset asset : sortedAssets) {
            if (asset.getSpecificLiability() != null) {
                usedLiabilities.add(asset.getSpecificLiability());
            }
        }
        List<Asset> usedAsset = new ArrayList<>();
        for (Liability liability : sortedLiability) {
            if (liability.getSpecificAsset() != null) {
                usedAsset.add(liability.getSpecificAsset());
            }
        }
        response.setLiabilities(sortedLiability.stream().map(CustomerLiabilityResponseDto.GenericDto::new).toList());
        response.setAssets(sortedAssets.stream().map(CustomerLiabilityResponseDto.GenericDto::new).toList());
        response.setDependencyList(dependencyRepository.findByCustomerIdAndIsDeletedFalse(customer.getId()).stream().map(CustomerLiabilityResponseDto.GenericDto::new).sorted(Comparator.comparing(CustomerLiabilityResponseDto.GenericDto::getId)).collect(Collectors.toList()));
        ScenarioSettingsDto dto = new ScenarioSettingsDto();
        List<ScenarioSettings> scenarioSettings = scenarioSettingsRepository.findScenarioSettingByCustomerId(id);
        for (CustomerLiabilityResponseDto.GenericDto liability : response.getLiabilities()) {
            Liability liability1 = usedLiabilities.stream()
                    .filter(lia -> lia.getId().equals(liability.getId()))
                    .findFirst()
                    .orElse(null);

            if (liability1 != null) {
                liability.setAvailable(false);
            }

        }
        for (CustomerLiabilityResponseDto.GenericDto asset : response.getAssets()) {
            Asset asset1 = usedAsset.stream()
                    .filter(ass -> ass.getId().equals(asset.getId()))
                    .findFirst()
                    .orElse(null);
            if (asset1 != null) {
                asset.setAvailable(false);
            }
        }

        if (scenarioSettings != null && scenarioSettings.size() > 0) {
            // Customer will have only on setting, So that tacking o index value
            ScenarioSettings setting = scenarioSettings.get(0);

            if (!DtoUtils.isEmpty(setting.getId())) {
                dto.setId(setting.getId());
            }
            if (!DtoUtils.isEmpty(setting.getCustomer().getId())) {
                dto.setCustomerId(setting.getCustomer().getId());
            }
            if (!DtoUtils.isEmpty(setting.getCostOfDebt())) {
                dto.setCostOfDebt(setting.getCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getCountry().getId())) {
                dto.setCountryId(setting.getCountry().getId());
                dto.setCountryName(setting.getCountry().getName());
                dto.setCountryCode(setting.getCountry().getCode());

            }
            if (!DtoUtils.isEmpty(setting.getCashLiquidityEvent())) {
                dto.setCashLiquidityEvent(setting.getCashLiquidityEvent());
            }
            if (!DtoUtils.isEmpty(setting.getCashStressAsset())) {
                dto.setCashStressAsset(setting.getCashStressAsset());
            }
            if (!DtoUtils.isEmpty(setting.getAccuredLiquidityEvent())) {
                dto.setAccuredLiquidityEvent(setting.getAccuredLiquidityEvent());
            }
            if (!DtoUtils.isEmpty(setting.getSector().getId())) {
                dto.setSectorId(setting.getSector().getId());
                dto.setSectorName(setting.getSector().getName());
            }
            if (!DtoUtils.isEmpty(setting.getDependency().getId())) {
                dto.setDependentId(setting.getDependency().getId());
                dto.setDependentName(setting.getDependency().getName());
            }
            if (!DtoUtils.isEmpty(setting.getSwapAccuredDistributionRate())) {
                dto.setSwapAccuredDistributionRate(setting.getSwapAccuredDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getCostOfDebt())) {
                dto.setSwapCostOfDebt(setting.getCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getAccuredStressAsset())) {
                dto.setAccuredStressAsset(setting.getAccuredStressAsset());
            }
            if (!DtoUtils.isEmpty(setting.getSwapCashDistributionRate())) {
                dto.setSwapCashDistributionRate(setting.getSwapCashDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getLeverageCostOfDebt())) {
                dto.setLeverageCostOfDebt(setting.getLeverageCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getLeverageCashDistributionRate())) {
                dto.setLeverageCashDistributionRate(setting.getLeverageCashDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getLeverageAccuredDistributionRate())) {
                dto.setLeverageAccuredDistributionRate(setting.getLeverageAccuredDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getLiquidityCostOfDebt())) {
                dto.setLiquidityCostOfDebt(setting.getLiquidityCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getLiquidityCashDistributionRate())) {
                dto.setLiquidityCashDistributionRate(setting.getLiquidityCashDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getLiquidityAccuredDistributionRate())) {
                dto.setLiquidityAccuredDistributionRate(setting.getLiquidityAccuredDistributionRate());
            }
            if(setting.getClimateChangeExposure()!=null){
                dto.setClimateChangeExposure(ClimateChangeExposure.getString(setting.getClimateChangeExposure()));
            }

            List<ScenariosSettingLegalExposureDto> legalExposureDtos = new ArrayList<>();
            List<ScenarioLegalExposure> legalExposures = setting.getCountryOfLegalExposure();
            for (ScenarioLegalExposure exposure : legalExposures) {
                ScenariosSettingLegalExposureDto exposureDto = new ScenariosSettingLegalExposureDto();
                if (!DtoUtils.isEmpty(exposure.getCountry().getId())) {
                    exposureDto.setCountryId(exposure.getCountry().getId());
                    exposureDto.setCountryName(exposure.getCountry().getName());
                }
                legalExposureDtos.add(exposureDto);
            }
            if (!DtoUtils.isEmpty(legalExposureDtos)) {
                dto.setCountryOfLegalExposure(legalExposureDtos);
            }

            response.setScenarioSetting(dto);
        }

        return new GenericResponse(HttpStatus.OK, response);
    }

    @Override
    @Transactional
    public GenericResponse getDataByLiabilityId(Long id) {
        Liability liability = liabilityRepository.findById(id).orElseThrow(() -> new RuntimeException("Please provide valid id"));
        CustomerLiabilityResponseDto response = new CustomerLiabilityResponseDto(liability);
        response.setCountryOfLegalExposure(liability.getCountryOfLegalExposure()!=null ? new CustomerLiabilityResponseDto.GenericDto(liability.getCountryOfLegalExposure()) : null);
        response.setExistingLending(liability.getExistingLending()!=null ? new CustomerLiabilityResponseDto.GenericDto(liability.getExistingLending()) : null);
        response.setSpecificAsset(liability.getSpecificAsset() == null ? null : new CustomerLiabilityResponseDto.GenericDto(liability.getSpecificAsset()));
        response.setLiabilityDependencies(liability.getLiabilityDependencies().stream().map(CustomerLiabilityResponseDto.GenericDto::new).toList());
        if(liability.getFileUploads()!=null){
            response.setFileUploadDtos(liability.getFileUploads().stream().map(this::entityToDto).toList());
        }
        return new GenericResponse(HttpStatus.OK, response);
    }


    private FileUploadDto entityToDto(FileUpload savedFile) {
        FileUploadDto dto = new FileUploadDto();
        dto.setId(savedFile.getId());
        dto.setName(savedFile.getName());
        if(savedFile.getOriginalFileName()!=null) {
            dto.setOriginalFileName(savedFile.getOriginalFileName());
        }
        dto.setType(savedFile.getType());
        dto.setFileSizeInBytes(savedFile.getFileSizeInBytes());
        dto.setFileSize(savedFile.getFileSize());
        dto.setFileData(savedFile.getFileData());
        String fileDownloadUrl = "/api/v1/file/get-by-id/"+savedFile.getId();
        String filePreviewUrl = "/api/v1/file/preview/"+savedFile.getId();
        dto.setDownloadUrl(fileDownloadUrl);
        dto.setPreviewUrl(filePreviewUrl);
        return dto;
    }

}
