package com.wm.cockpit.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AppConfigurationRequestDto {
    private String orgName;
    private Long favIcon;
    private Long organisationLogo;
    private Long loginImage;
    private Boolean isCustomize;
}
