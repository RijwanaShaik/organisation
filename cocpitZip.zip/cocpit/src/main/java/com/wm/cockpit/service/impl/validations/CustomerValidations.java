package com.wm.cockpit.service.impl.validations;

import com.wm.cockpit.dto.CustomerDto;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.repositary.CurrencyRepository;
import com.wm.cockpit.validation.UnprocessableEntityException;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class CustomerValidations {

    public Map<String, Object> validateDbDependencies(CurrencyRepository currencyRepository, CustomerDto dto) {
        List<String> errors = new ArrayList<>();
        Map<String, Object> data = new HashMap<>();
        Optional<Currency> currency = currencyRepository.findById(dto.getCurrencyId());
        if (currency.isEmpty() || currency == null) {
            errors.add("Invalid Currency Id");
        } else {
            data.put("currency", currency.get());
        }
        if (errors.size() > 0) {
            throw new UnprocessableEntityException(errors.toString(), true);
        }
        return data;
    }
}
