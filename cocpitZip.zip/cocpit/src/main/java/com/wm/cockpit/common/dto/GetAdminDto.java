package com.wm.cockpit.common.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  11/05/23
 * @Time >>  2:14 pm
 * @Project >>  cocpit
 */
@Data
@NoArgsConstructor
public class GetAdminDto {
    private int pageNumber;
    private int pageSize;
    private String searchKey;
}
