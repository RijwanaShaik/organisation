package com.wm.cockpit.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ClimateChangeResponseDto {
    private Long low;
    private Long medium;
    private Long high;
    private Long veryHigh;
    private Long none;

}