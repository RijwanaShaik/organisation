package com.wm.cockpit.dto.rest;

import com.wm.cockpit.entity.Customer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.*;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class RestCustomerDto {
    private long id;

    private long currencyId;

    @NotNull(message = "name is required ")
    @NotEmpty(message = "name is required ")
    private String name;

    @NotNull(message = "Currency is required")
    private String currencyCode;

    public RestCustomerDto(Customer customer){

        this.id = customer.getId();
        this.name = customer.getName();
        if(customer.getCurrency() != null){
            this.currencyCode = customer.getCurrency().getCurrencyCode();
        }

    }

}