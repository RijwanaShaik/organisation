package com.wm.cockpit.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.wm.cockpit.common.dto.AssetReq;
import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.entity.Asset;
import com.wm.cockpit.entity.Customer;
import com.wm.cockpit.repositary.CustomerRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
@RequestMapping()
public class PythonApisAccessController {

    @Autowired
    CustomerRepository customerRepository;

    @GetMapping("/asset-report/{customerId}")
    public ApiResponse getAssetResport(@PathVariable Long customerId) throws Exception {

        Optional<Customer> customer = customerRepository.findById(customerId);
        // Customer data = customer.get();
        List<Map<Object, Object>> reqList = new ArrayList<>();
        List<Asset> responseData = customer.get().getAssets();
        List<Map<Object, Object>> data = new ArrayList<>();
        for (Asset asset : customer.get().getAssets()) {
            Map<Object, Object> dataMap = new HashMap<>();
            AssetReq req = new AssetReq();
            BeanUtils.copyProperties(asset, dataMap);
            reqList.add(dataMap);

        }
        BeanUtils.copyProperties(customer.get().getAssets(), data);
        System.out.println(reqList);
        ObjectMapper Obj = new ObjectMapper();
        String jsonStr = Obj.writeValueAsString(responseData);

        // Displaying JSON String on console
        System.out.println(jsonStr);
        Gson gson = new Gson();
        // gson.toJson(data);
        return new ApiResponse(HttpStatus.OK, gson.toJson(reqList));
    }
}
