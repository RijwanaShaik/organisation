package com.wm.cockpit.service.impl.validations;

import com.wm.cockpit.dto.DependencyDto;
import com.wm.cockpit.entity.Customer;
import com.wm.cockpit.repositary.CustomerRepository;
import com.wm.cockpit.validation.UnprocessableEntityException;

import java.util.*;

public class DependencyValidations {
    public Map<String, Object>  validateDbDependencies(CustomerRepository customerRepository, DependencyDto dependencyDto) {
        List<String> errors = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        Optional<Customer> customer = customerRepository.findById(dependencyDto.getCustomer());
        if (customer.isEmpty() || customer == null) {
            errors.add("Invalid Customer id");
        } else {
            map.put("customer", customer.get());
        }
        if (errors.size() > 0) {
            throw new UnprocessableEntityException(errors.toString(), true);
        }
        return map;
    }
}
