package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.*;
import com.wm.cockpit.entity.*;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class
MutationResolver {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private DependencyService dependencyService;

    @Autowired
    private AssetService assetService;

    @Autowired
    private LiabilityService liabilityService;

    @Autowired
    private LiabilityDependencyService liabilityDependencyService;

    @Autowired
    private SectorService sectorService;

    @Autowired
    private LegalExposureService legalExposureService;
    @Autowired
    private AssetDependencyService assetDependencyService;

    @Autowired
    AppUserService appUserService;

  /*  @MutationMapping(name = "createCustomer")
    public String createCustomer(@Argument CustomerDto customerDto) throws Exception {
        return customerService.createCustomer(customerDto);
    }*/

    @MutationMapping(name = "updateCustomerById")
    public String updateCustomerById(@Argument CustomerDto customerDto) {
        return customerService.updateCustomerById(customerDto);
    }

    @MutationMapping(name = "deletedCustomerById")
    public String deletedCustomerById(@Argument long id) {

        return customerService.deletedCustomerById(id);
    }

    @MutationMapping(name = "createDependency")
    public ApiResponse createDependency(@Argument(name = "input") DependencyDto dependencyDto) throws Exception {
        return new ApiResponse(HttpStatus.OK,dependencyService.createDependency(dependencyDto));
    }

    @MutationMapping(name = "updateDependencyById")
    public String updateDependencyById(@Argument DependencyDto dependencyDto) throws Exception {
        return dependencyService.updateDependencyById(dependencyDto);
    }

    @MutationMapping(name = "deletedDependencyById")
    public String deletedDependencyById(@Argument long id) {
        return dependencyService.deletedDependencyById(id);
    }

    @MutationMapping(name = "createAsset")
    public String createAsset(@Argument AssetDto assetDto) {
        return assetService.createAsset(assetDto);
    }

    @MutationMapping(name = "updateAssetById")
    public Asset updateAssetById(@Argument AssetDto assetDto) throws Exception {
        return assetService.updateAssetById(assetDto);
    }

    @MutationMapping(name = "deletedAssetById")
    public String deletedAssetById(@Argument long id) {
        return assetService.deletedAssetById(id);
    }

    @MutationMapping(name = "createLiability")
    public String createLiability(@Argument LiabilityDto liabilityDto) {
        return liabilityService.createLiability(liabilityDto);
    }

    @MutationMapping(name = "updatedLiabilityById")
    public GenericResponse updatedLiabilityById(@Argument LiabilityDto liabilityDto) throws Exception {
        return liabilityService.updatedLiabilityById(liabilityDto);
    }

    @MutationMapping(name = "deletedLiabilityById")
    public String deletedLiabilityById(@Argument long id) {
        return liabilityService.deletedLiabilityById(id);
    }

    @MutationMapping(name = "createSector")
    public String createSector(@Argument SectorDto sectorDto) {
        return sectorService.createSector(sectorDto);
    }

    @MutationMapping(name = "updatedSectorById")
    public String updatedSectorById(@Argument SectorDto sectorDto) throws Exception {
        return sectorService.updatedSectorById(sectorDto);
    }

    @MutationMapping(name = "deletedSectorById")
    public String deletedSectorById(@Argument long id) throws Exception {
        return sectorService.deletedSectorById(id);
    }

    @MutationMapping(name = "createLiabilityDependency")
    public String createLiabilityDependency(@Argument LiabilityDependencyDto liabilityDependencyDto) {
        return liabilityDependencyService.createLiabilityDependency(liabilityDependencyDto);
    }

    @MutationMapping(name = "createAssetDependency")
    public String createAssetDependency(@Argument AssetDependencyDto assetDependencyDto) {
        return assetDependencyService.createAssetDependency(assetDependencyDto);
    }

    @MutationMapping(name = "createEconomicExposure")
    public String createEconomicExposure(@Argument(name = "input") LegalExposureDto legalExposureDto) {
        return legalExposureService.createEconomicExposure(legalExposureDto);
    }

  /*  @MutationMapping("inActiveAppUser")
    public String inActiveAppUser(@Argument Long appUserId){
        return  appUserService.inActiveAppUser(appUserId);
    }*/
}