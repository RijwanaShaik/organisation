package com.wm.cockpit.controller;

import com.wm.cockpit.dto.CustomerDto;
import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.entity.Customer;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@RestController
@RequestMapping("/api/v1/customer/")
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RequiredArgsConstructor
@Validated
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    private final Logger logger = LoggerFactory.getLogger( AppUser.class );

    @MutationMapping(name = "updateCustomerById")
    public String updateCustomerById(@Argument(name = "input") CustomerDto customerDto) {
        return customerService.updateCustomerById(customerDto);
    }

    @PostMapping("create-customer")
    public GenericResponse createCustomer(@RequestBody CustomerDto customerDto) throws Exception {
        return customerService.createCustomer(customerDto);
    }

    @QueryMapping(name = "getCustomerById")
    public Customer getCustomerById(@Argument(name = "id") long id) {
        return customerService.getCustomerById(id);
    }

    @QueryMapping(name = "getCustomerByName")
    public Customer getCustomerByName(@Argument(name = "name") @NotNull String name) {
        return customerService.getCustomerByName(name);
    }

    /*@QueryMapping(name = "getAllCustomer")
    public List<CustomerDto> getAllCustomer() throws Exception {
        return customerService.getAllCustomer();
    }*/

    @GetMapping("get-all-customers")
    public GenericResponse getAllCustomers(){
        logger.info("Get All Customers Service Started");
        return customerService.getAllCustomers();
    }

    @MutationMapping(name = "deletedCustomerById")
    public String deletedCustomerById(@Argument(name = "id") long id) {
        return customerService.deletedCustomerById(id);
    }
    @GetMapping("/get-customers-by-admin-id/{adminid}")
    public List<CustomerDto> getCustomersByAdminId(@PathVariable Long adminid){
        return customerService.getCustomerByAdminId(adminid);
    }
}
