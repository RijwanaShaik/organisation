package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.TermsAndCondition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TermsAndConditionRepo extends JpaRepository<TermsAndCondition, Long> {
    List<TermsAndCondition> findAllByIsActive(Boolean aTrue);
}
