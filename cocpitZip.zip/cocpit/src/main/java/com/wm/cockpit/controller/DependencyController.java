package com.wm.cockpit.controller;

import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.response.GenericResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wm.cockpit.dto.DependencyDto;
import com.wm.cockpit.entity.Dependency;
import com.wm.cockpit.service.DependencyService;

import java.util.List;

@RestController
@RequestMapping("/api/v1/dependency")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class DependencyController {

    @Autowired
    private DependencyService dependencyService;

    @MutationMapping(name = "createDependency")
    public ApiResponse createDependency(@Argument(name = "input") DependencyDto dependencyDto) throws Exception {
        return new ApiResponse(HttpStatus.OK,dependencyService.createDependency(dependencyDto));
    }

    @MutationMapping(name = "updateDependencyById")
    public String updateDependencyById(@Argument(name = "input") DependencyDto dependencyDto) throws Exception {
        return dependencyService.updateDependencyById(dependencyDto);
    }

    @MutationMapping(name = "deletedDependencyById")
    public String deletedDependencyById(@Argument long id) {
        return dependencyService.deletedDependencyById(id);
    }

    @QueryMapping(name = "getAllDependencies")
    private List<Dependency> getAllDependencies() {
        return dependencyService.getAllDependencies();
    }


}
