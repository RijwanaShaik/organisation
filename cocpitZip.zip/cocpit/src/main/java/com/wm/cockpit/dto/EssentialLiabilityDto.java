package com.wm.cockpit.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class EssentialLiabilityDto {

    private long id;
    private String liability_name;

    private long liability_value;
    private CurrencyDto liability_currency;

    private float liability_exchange;
    private float reference_exchange;

    private CountryDto country_of_legal_exposure;
    private float cast_of_debut;
    private long existing_lending_value;

    private CurrencyDto existing_lending_currency;
    private List<LiabilityDependencyDto> shareHolders;

}
