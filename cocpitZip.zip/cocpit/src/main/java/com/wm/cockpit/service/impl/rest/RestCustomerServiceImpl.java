package com.wm.cockpit.service.impl.rest;

import com.wm.cockpit.dto.CustomerDto;
import com.wm.cockpit.dto.ScenarioSettingsDto;
import com.wm.cockpit.dto.ScenariosSettingLegalExposureDto;
import com.wm.cockpit.dto.rest.CustomerLiabilityResponseDto;
import com.wm.cockpit.dto.rest.RestCustomerDto;
import com.wm.cockpit.entity.*;
import com.wm.cockpit.enums.ClimateChangeExposure;
import com.wm.cockpit.enums.CustomerLevel;
import com.wm.cockpit.enums.Role;
import com.wm.cockpit.repositary.*;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.security.LoggedInUser;
import com.wm.cockpit.service.rest.RestCustomerService;
import com.wm.cockpit.utils.CockpitUtil;
import com.wm.cockpit.utils.CurrencyUtil;
import com.wm.cockpit.utils.DtoUtils;
import com.wm.cockpit.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class
RestCustomerServiceImpl implements RestCustomerService {

    @Autowired
    CustomerRepository customerRepository;

    @Autowired
    CurrencyRepository currencyRepository;

    @Autowired
    CurrencyUtil util;

    @Autowired
    private AppUserRepo appUserRepo;

    @Autowired
    private DependencyRepository dependencyRepository;
    @Autowired
    private LiabilityRepository liabilityRepository;
    @Autowired
    private AssetRepository assetRepository;

    @Autowired
    private ScenarioSettingsRepository scenarioSettingsRepository;
    @Override
    public GenericResponse save(RestCustomerDto dto) {

        Customer customer = null;
        if (dto.getId() != 0) {
            customer = customerRepository.findById(dto.getId()).orElseThrow(() -> new RuntimeException("Please provide valid id"));
        } else {
            customer = new Customer();
        }

        //TODO
        customer.setPhoneNumber(98681326478L);
        customer.setEmail("abcd@gmail.com");
        customer.setName(dto.getName());
        //customer.setCurrency(currencyRepositary.findFirstByCurrencyCode(dto.getCurrencyCode()));
        customer.setCurrency(currencyRepository.findById(dto.getCurrencyId()).get());
        customerRepository.save(customer);

        return new GenericResponse(HttpStatus.OK, "SUCCESS");
    }

    @Override
    public GenericResponse getAll() {
        return new GenericResponse(HttpStatus.OK, customerRepository.findAll().stream().sorted().map(CustomerDto::new).toList());
    }


    public GenericResponse getTotalWealth() {
        List<Customer> customers = customerRepository.findAll();
        Map<Long, Map<String, Double>> responseMap = new HashMap<>();
        for (Customer customer : customers) {
            responseMap.put(customer.getId(), customerWealth(customer, true));
        }
        Map<Long, Map<String, Double>> result = responseMap.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (oldValue, newValue) -> oldValue, LinkedHashMap::new));

        Map<Long, Map<String, Double>> sortedTreeMapInDesc = new TreeMap<>(Comparator.reverseOrder());
        sortedTreeMapInDesc.putAll(result);

        return new GenericResponse(HttpStatus.OK, sortedTreeMapInDesc);
    }

    private Map<String, Double> customerWealth(Customer customer, boolean isAllCustomers) {
        Double totalAseet = 0.0;
        Double totalLiability = 0.0;
        Double totalWealth = 0.0;

        for (Asset asset : customer.getAssets()) {
            totalAseet = totalAseet + util.convert(asset.getCurrency().getCurrencyCode(), customer.getCurrency().getCurrencyCode(), asset.getValue());
        }

        for (Liability liability : customer.getLiabilities()) {
            totalLiability = totalLiability + util.convert(liability.getCurrency().getCurrencyCode(), customer.getCurrency().getCurrencyCode(), liability.getValue());
        }
        Map<String, Double> responseMap = new HashMap<>();
        if (isAllCustomers) {
            responseMap.put("totalAsset", CockpitUtil.convertToMillions(util.convert(customer.getCurrency().getCurrencyCode(), CurrencyUtil.BASE_CURRENCY, totalAseet)));
            responseMap.put("totalLiability", CockpitUtil.convertToMillions(util.convert(customer.getCurrency().getCurrencyCode(), CurrencyUtil.BASE_CURRENCY, totalLiability)));
            responseMap.put("totalWealth", CockpitUtil.convertToMillions(util.convert(customer.getCurrency().getCurrencyCode(), CurrencyUtil.BASE_CURRENCY, totalAseet - totalLiability)));
        } else {
            responseMap.put("totalAsset", CockpitUtil.convertToMillions(totalAseet));
            responseMap.put("totalLiability", CockpitUtil.convertToMillions(totalLiability));
            responseMap.put("totalWealth", CockpitUtil.convertToMillions(totalAseet - totalLiability));
        }
        return responseMap;
    }

    @Override
    public GenericResponse getTotalWealth(long customerId) {
        Optional<Customer> data = customerRepository.findById(customerId);
        if (data.isEmpty()) {
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide valid customer id");
        }
        Customer customer = data.get();
        return new GenericResponse(HttpStatus.OK, customerWealth(customer, false));
    }

    @Override
    public GenericResponse convert(String source, String destination, double value) {
        return new GenericResponse(HttpStatus.OK, util.convert(source, destination, value));
    }

    @Override
    public GenericResponse delete(long customerId) {

        Optional<Customer> customerOpt = customerRepository.findById(customerId);

        if (customerOpt.isEmpty()) {
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide valid customer id");
        }

        Customer customer = customerOpt.get();

        List<Asset> assets = customer.getAssets();
        List<Liability> liabilities = customer.getLiabilities();

        for (Asset asset : assets) {
            List<AssetDependency> dependencies = asset.getAssetDependencies();
            List<LegalExposure> legalExposures = asset.getCountryOfLegalExposure();
            dependencies.forEach(dependecy -> dependecy.setIsDeleted(true));
            legalExposures.forEach(legalExposure -> legalExposure.setIsDeleted(true));
            asset.setIsDeleted(true);
        }

        for (Liability liability : liabilities) {
            List<LiabilityDependency> dependencies = liability.getLiabilityDependencies();
            dependencies.forEach(dependecy -> dependecy.setIsDeleted(true));
            liability.setIsDeleted(true);
        }

        List<Dependency> dependencyList = customer.getDependencies();
        dependencyList.forEach(dependency -> dependency.setIsDeleted(true));

        List<ScenarioHeader> scenarioHeaders = customer.getScenarioHeaders();
        for (ScenarioHeader scenarioHeader : scenarioHeaders) {
            ScenarioItem item = scenarioHeader.getScenarioItem();
            item.setIsDeleted(true);
            scenarioHeader.setIsDeleted(true);
        }

        //  ScenarioSettings setting = customer.getScenarioSettings();
        //  List<ScenarioLegalExposure> legalExposures = setting.getCountryOfLegalExposure();
        // legalExposures.forEach(exposure -> exposure.setIsDeleted(true));

        // setting.setIsDeleted(true);

        customer.setIsDeleted(true);

        customerRepository.save(customer);

        return new GenericResponse(HttpStatus.OK, "DELETED SUCCESS");
    }

    @Override
    public GenericResponse getAllCustomersWithWealth() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            List<Customer> customers = new ArrayList<>();
                customers = customerRepository.findAllByAppUserId(user.getId());
            if (user.getRole().equals(Role.SUPER_ADMIN)){
                List<AppUser> appUserList = appUserRepo.findAllByCreatedByAndIsActiveAndIsDeleted(user.getId(), Boolean.TRUE, Boolean.FALSE);
                if (Validator.isValid(appUserList)){
                    List<Long> appUserIds = new ArrayList<>(appUserList.stream().map(AppUser::getId).toList());
                    appUserIds.add(user.getId());
                    customers = customerRepository.findAllByAppUserIdInAndIsActiveAndIsDeleted(appUserIds, Boolean.TRUE, Boolean.FALSE);
                }
            }
            if (Validator.isValid(customers)){
                return new GenericResponse(HttpStatus.OK, "Found All Customers ",customers.stream().sorted(Comparator.comparing(Customer::getUpdatedOn).reversed()).map(this::customerToDtoWithWealth).collect(Collectors.toList()));
            } else {
                return new GenericResponse(HttpStatus.OK, "There Is No Customer ");
            }

        }return null;
    }

    @Override
    @Transactional
    public GenericResponse getCustomerByIdWithWealth(Long customerId) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(() -> new RuntimeException("Please provide valid id"));
        CustomerLiabilityResponseDto response = new CustomerLiabilityResponseDto(customer);
        List<Liability> liabilities = liabilityRepository.findByCustomerIdAndIsDeletedFalse(customer.getId());
        List<Asset> assets = assetRepository.findByCustomerIdAndIsDeletedFalse(customer.getId());
        List<Liability> sortedLiability = liabilities.stream().sorted(Comparator.comparing(Liability::getUpdatedOn).reversed()).collect(Collectors.toList());
        List<Asset> sortedAssets = assets.stream().sorted(Comparator.comparing(Asset::getUpdatedOn).reversed()).collect(Collectors.toList());
        List<Liability> usedLiabilities = new ArrayList<>();

        for (Asset asset : sortedAssets) {
            if (asset.getSpecificLiability() != null) {
                usedLiabilities.add(asset.getSpecificLiability());
            }
        }
        List<Asset> usedAsset = new ArrayList<>();
        for (Liability liability : sortedLiability) {
            if (liability.getSpecificAsset() != null) {
                usedAsset.add(liability.getSpecificAsset());
            }
        }

        response.setLiabilities(sortedLiability.stream().map(entity -> new CustomerLiabilityResponseDto.GenericDto(entity, customer.getLevel())).toList());
        response.setAssets(sortedAssets.stream().map(entity -> new CustomerLiabilityResponseDto.GenericDto(entity, customer.getLevel())).toList());
        response.setDependencyList(dependencyRepository.findByCustomerIdAndIsDeletedFalse(customer.getId()).stream().map(CustomerLiabilityResponseDto.GenericDto::new).sorted(Comparator.comparing(CustomerLiabilityResponseDto.GenericDto::getId)).collect(Collectors.toList()));
        ScenarioSettingsDto dto = new ScenarioSettingsDto();
        List<ScenarioSettings> scenarioSettings = scenarioSettingsRepository.findScenarioSettingByCustomerId(customerId);
        for (CustomerLiabilityResponseDto.GenericDto liability : response.getLiabilities()) {
            Liability liability1 = usedLiabilities.stream()
                    .filter(lia -> lia.getId().equals(liability.getId()))
                    .findFirst()
                    .orElse(null);

            if (liability1 != null) {
                liability.setAvailable(false);
            }

        }
        for (CustomerLiabilityResponseDto.GenericDto asset : response.getAssets()) {
            Asset asset1 = usedAsset.stream()
                    .filter(ass -> ass.getId().equals(asset.getId()))
                    .findFirst()
                    .orElse(null);
            if (asset1 != null) {
                asset.setAvailable(false);
            }
        }

        if (scenarioSettings != null && scenarioSettings.size() > 0) {
            // Customer will have only on setting, So that tacking o index value
            ScenarioSettings setting = scenarioSettings.get(0);

            if (!DtoUtils.isEmpty(setting.getId())) {
                dto.setId(setting.getId());
            }
            if (!DtoUtils.isEmpty(setting.getCustomer().getId())) {
                dto.setCustomerId(setting.getCustomer().getId());
            }
            if(customer.getLevel().equals(CustomerLevel.LEVEL_2) || customer.getLevel().equals(CustomerLevel.LEVEL_3)){
                if (!DtoUtils.isEmpty(setting.getCountry().getId())) {
                    dto.setCountryId(setting.getCountry().getId());
                    dto.setCountryName(setting.getCountry().getName());
                    dto.setCountryCode(setting.getCountry().getCode());

                }
                if (!DtoUtils.isEmpty(setting.getSector().getId())) {
                    dto.setSectorId(setting.getSector().getId());
                    dto.setSectorName(setting.getSector().getName());
                }
                List<ScenariosSettingLegalExposureDto> legalExposureDtos = new ArrayList<>();
                List<ScenarioLegalExposure> legalExposures = setting.getCountryOfLegalExposure();
                for (ScenarioLegalExposure exposure : legalExposures) {
                    ScenariosSettingLegalExposureDto exposureDto = new ScenariosSettingLegalExposureDto();
                    if (!DtoUtils.isEmpty(exposure.getCountry().getId())) {
                        exposureDto.setCountryId(exposure.getCountry().getId());
                        exposureDto.setCountryName(exposure.getCountry().getName());
                    }
                    legalExposureDtos.add(exposureDto);
                }
                if (!DtoUtils.isEmpty(legalExposureDtos)) {
                    dto.setCountryOfLegalExposure(legalExposureDtos);
                }
            }
            if(customer.getLevel().equals(CustomerLevel.LEVEL_3)) {
                if (!DtoUtils.isEmpty(setting.getCostOfDebt())) {
                    dto.setCostOfDebt(setting.getCostOfDebt());
                }
                if (!DtoUtils.isEmpty(setting.getCashLiquidityEvent())) {
                    dto.setCashLiquidityEvent(setting.getCashLiquidityEvent());
                }
                if (!DtoUtils.isEmpty(setting.getCashStressAsset())) {
                    dto.setCashStressAsset(setting.getCashStressAsset());
                }
                if (!DtoUtils.isEmpty(setting.getAccuredLiquidityEvent())) {
                    dto.setAccuredLiquidityEvent(setting.getAccuredLiquidityEvent());
                }
                if(setting.getDependency() !=null) {
                    if (!DtoUtils.isEmpty(setting.getDependency().getId())) {
                        dto.setDependentId(setting.getDependency().getId());
                        dto.setDependentName(setting.getDependency().getName());
                    }
                }
                if (!DtoUtils.isEmpty(setting.getSwapAccuredDistributionRate())) {
                    dto.setSwapAccuredDistributionRate(setting.getSwapAccuredDistributionRate());
                }
                if (!DtoUtils.isEmpty(setting.getCostOfDebt())) {
                    dto.setSwapCostOfDebt(setting.getCostOfDebt());
                }
                if (!DtoUtils.isEmpty(setting.getAccuredStressAsset())) {
                    dto.setAccuredStressAsset(setting.getAccuredStressAsset());
                }
                if (!DtoUtils.isEmpty(setting.getSwapCashDistributionRate())) {
                    dto.setSwapCashDistributionRate(setting.getSwapCashDistributionRate());
                }
                if (!DtoUtils.isEmpty(setting.getLeverageCostOfDebt())) {
                    dto.setLeverageCostOfDebt(setting.getLeverageCostOfDebt());
                }
                if (!DtoUtils.isEmpty(setting.getLeverageCashDistributionRate())) {
                    dto.setLeverageCashDistributionRate(setting.getLeverageCashDistributionRate());
                }
                if (!DtoUtils.isEmpty(setting.getLeverageAccuredDistributionRate())) {
                    dto.setLeverageAccuredDistributionRate(setting.getLeverageAccuredDistributionRate());
                }
                if (!DtoUtils.isEmpty(setting.getLiquidityCostOfDebt())) {
                    dto.setLiquidityCostOfDebt(setting.getLiquidityCostOfDebt());
                }
                if (!DtoUtils.isEmpty(setting.getLiquidityCashDistributionRate())) {
                    dto.setLiquidityCashDistributionRate(setting.getLiquidityCashDistributionRate());
                }
                if (!DtoUtils.isEmpty(setting.getLiquidityAccuredDistributionRate())) {
                    dto.setLiquidityAccuredDistributionRate(setting.getLiquidityAccuredDistributionRate());
                }
                if (setting.getClimateChangeExposure() != null) {
                    dto.setClimateChangeExposure(ClimateChangeExposure.getString(setting.getClimateChangeExposure()));
                }
            }

            response.setScenarioSetting(dto);
        }
        response.setWealthData(customerWealth(customer, Boolean.FALSE));
        return new GenericResponse(HttpStatus.OK, response);
    }

    private CustomerDto customerToDtoWithWealth(Customer customer) {
        CustomerDto dto= new CustomerDto();
        dto.setId(customer.getId());
        dto.setName(customer.getName());
        dto.setEmail(customer.getEmail());
        dto.setPhoneNumber(customer.getPhoneNumber());
        dto.setCurrencyId(customer.getCurrency().getId());
        dto.setCurrencyCode(customer.getCurrency().getCurrencyCode());
        dto.setCreatedBy(customer.getAppUser().getUserName());
        dto.setWealthData(customerWealth(customer, Boolean.TRUE));
        return dto;
    }

}
