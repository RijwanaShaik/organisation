package com.wm.cockpit.common.dto;

import com.wm.cockpit.entity.*;
import com.wm.cockpit.enums.DirectLiquidity;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;


@Getter
@Setter
public class AssetReq {

        private String name;

        private long value;
        private Sector sector;

        private Customer customer;
        private Currency currency;

        private DirectLiquidity directLiquidity;

        private float indirectLiquidity;

        private float cashDistributionRate;

        private float accruedDistributionRate;


        private List<LegalExposure> countryOfEconomicExposure = new ArrayList<>();


        private Country countryOfLegalExposure;
        private Boolean isFamilyHolding;

        private List<AssetDependency> assetDependencies = new ArrayList<>();

        private Currency existingLending;

        private double existingValue;

        private Liability specificLiability;

}
