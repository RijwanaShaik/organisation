package com.wm.cockpit.service.rest;

import com.wm.cockpit.dto.CustomerDto;
import com.wm.cockpit.dto.rest.RestCustomerDto;
import com.wm.cockpit.response.GenericResponse;

public interface RestCustomerService {
    GenericResponse save(RestCustomerDto dto);

    GenericResponse getAll();

    GenericResponse getTotalWealth(long customerId);

    GenericResponse getTotalWealth();

    GenericResponse convert(String source, String destination, double value);

    GenericResponse delete(long customerId);
    GenericResponse getAllCustomersWithWealth();

    GenericResponse getCustomerByIdWithWealth(Long customerId);
}
