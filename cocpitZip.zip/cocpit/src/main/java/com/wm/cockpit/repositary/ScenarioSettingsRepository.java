package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.ScenarioSettings;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ScenarioSettingsRepository extends JpaRepository<ScenarioSettings,Long>{

    List<ScenarioSettings> findScenarioSettingByCustomerId(long customerId);
}
