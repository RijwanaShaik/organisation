package com.wm.cockpit.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.wm.cockpit.enums.Role;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.Where;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Entity
@Setter
@Getter
@Table(name = "mt_app_user")
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotEmpty
    @Size(min = 2, message = "user name should have at least 2 characters")
    @Column(name = "name",nullable = false)
    private String userName;

    @Email
    @Column(nullable = false)
    private String email;

    private Long phoneNumber;

    @Column(nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    private Role role;

    private Boolean isVerified = Boolean.TRUE;

    @JsonIgnore
    @CreatedBy
    private Long createdBy;

    @JsonIgnore
    @LastModifiedBy
    private Long updatedBy;

    @Column(name = "created_on", updatable = false)
    @JsonIgnore
    @CreationTimestamp
    private Timestamp createdOn = new Timestamp(new Date().getTime());

//    @Version
    @Column(name = "updated_on")
    @UpdateTimestamp
    private Timestamp updatedOn = new Timestamp(new Date().getTime());

    @Column(columnDefinition = "boolean default false")
    private Boolean isDeleted = Boolean.FALSE;

    @OneToMany(mappedBy = "appUser")
    private List<Otp> otps;

    @OneToMany(mappedBy = "appUser")
    private List<Customer> customers;

    @Column(columnDefinition = "text", name = "search_key")
    private String searchKey;

    @Column(columnDefinition = "boolean default true")
    private Boolean isActive = Boolean.TRUE;

    @Column(columnDefinition = "boolean default true")
    private Boolean isFirstTimeLogin = Boolean.TRUE;

    @Column(name = "designation")
    private String designation;


    private Boolean isTermsAndConditionsAccepted = Boolean.FALSE;

    @ManyToOne
    private TermsAndCondition termsAndCondition;

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    private List<Token> tokens = new ArrayList<>();

}