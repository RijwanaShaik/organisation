package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.*;
import com.wm.cockpit.service.RuleService;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.io.ResourceFactory;
import org.springframework.stereotype.Service;

@Service
public class RuleServiceImpl implements RuleService {
    @Override
    public LiquidityGraphDto getLiquidityGraph(LiquidityGraphDto liquidityGraph){

        KieSession kieSession = kiaSession("rules/liquidity.drl");
        kieSession.insert(liquidityGraph);
        kieSession.fireAllRules();
        kieSession.dispose();
        return liquidityGraph;
    }

    @Override
    public CurrencyMixGraphDto getCurrencyExposures(CurrencyMixGraphDto currencyMixGraph) {
        KieSession kieSession = kiaSession("rules/currencyMix.drl");
        kieSession.insert(currencyMixGraph);
        for (AssetGraphDto asset : currencyMixGraph.getAssetList()) {
            if(!asset.getIsReferenceCurrency().equals(Boolean.TRUE))
                kieSession.insert(asset);

        }
        kieSession.fireAllRules();
        kieSession.dispose();
        return currencyMixGraph;
    }


    @Override
    public InflationGraphDto getInflation(InflationGraphDto inflationGraph) {
        KieSession kieSession = kiaSession("rules/inflation.drl");
        kieSession.insert(inflationGraph);
        kieSession.fireAllRules();
        kieSession.dispose();
        return inflationGraph;
    }

    @Override
    public UBOReturnsGraphDto getUBOReturns(UBOReturnsGraphDto uboReturnsGraphDto) {
        KieSession kieSession = kiaSession("rules/uboReturns.drl");
        kieSession.insert(uboReturnsGraphDto);
        for (UBODto uboDto : uboReturnsGraphDto.getUbosCashReturn()) {
            kieSession.insert(uboDto);
        }
        for(UBODto uboDto: uboReturnsGraphDto.getUbosAccuredReturn()){
            kieSession.insert(uboDto);
        }

        kieSession.fireAllRules();
        kieSession.dispose();
        return uboReturnsGraphDto;
    }

    @Override
    public SectorResponseDto getSectorGraph(SectorRequestDto sectorRequestDto) {
        SectorResponseDto responseDto=new SectorResponseDto();
        KieSession kieSession = kiaSession("rules/sector.drl");
        kieSession.insert(sectorRequestDto);
        for(SectorGraphDto dto: sectorRequestDto.getSectorGraphDtoList()){
            kieSession.insert(dto);
        }
        kieSession.setGlobal("responseDto",responseDto);
        kieSession.fireAllRules();
        kieSession.dispose();
        return responseDto;
    }

    public KieSession kiaSession(String rdlFile){

        KieFileSystem kieFileSystem = getKieFileSystem(rdlFile);
        KieBuilder kieBuilder = KieServices.Factory.get().newKieBuilder(kieFileSystem);
        kieBuilder.buildAll();
        KieModule kieModule = kieBuilder.getKieModule();
        KieContainer kieContainer = KieServices.Factory.get().newKieContainer(kieModule.getReleaseId());
        KieSession kieSession = kieContainer.newKieSession();
        return kieSession;
    }

    private KieFileSystem getKieFileSystem(String rdlFile) {
        KieFileSystem kieFileSystem = KieServices.Factory.get().newKieFileSystem();
        kieFileSystem.write(ResourceFactory.newClassPathResource(rdlFile));
        return kieFileSystem;
    }
}
