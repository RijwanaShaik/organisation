package com.wm.cockpit.dto;

import com.wm.cockpit.entity.Country;
import com.wm.cockpit.entity.ScenarioSettings;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.minidev.json.annotate.JsonIgnore;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ScenarioLegalExposureDto {

    @JsonIgnore
    private Long scenarioSettingsId;
    private Long countryId;
}
