package com.wm.cockpit.common.dto;

import com.wm.cockpit.dto.SectorDto;
import com.wm.cockpit.enums.DirectLiquidity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class FamilyAssetDto {
    private String assetName;
    private long value;
    private String currency;
    private float referenceExchange;
    private DirectLiquidity assetType;
    private SectorDto sectorDto;

}
