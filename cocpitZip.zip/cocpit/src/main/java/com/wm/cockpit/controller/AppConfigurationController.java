package com.wm.cockpit.controller;

import com.wm.cockpit.dto.AppConfigurationRequestDto;
import com.wm.cockpit.entity.AppConfiguration;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.AppConfigurationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/app/config/")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class AppConfigurationController {
@Autowired
    AppConfigurationService appConfigurationService;
    private final Logger logger = LoggerFactory.getLogger( AppConfiguration.class );

    @PostMapping(value = "save")
    public GenericResponse saveAppConfiguration(@RequestBody AppConfigurationRequestDto appConfigurationRequestDto) {
        GenericResponse response=appConfigurationService.saveAppConfiguration(appConfigurationRequestDto);
        return response;
    }
    @GetMapping("get")
    public GenericResponse getAppConfiguration(){
        return appConfigurationService.getAppConfiguration();
    }

    @PostMapping("reset/{id}")
    public GenericResponse resetById(@PathVariable Long id){
        return appConfigurationService.resetById(id);
    }
}
