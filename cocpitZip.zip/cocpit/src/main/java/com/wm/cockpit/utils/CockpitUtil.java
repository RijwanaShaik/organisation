package com.wm.cockpit.utils;

import java.text.DecimalFormat;

public class CockpitUtil {

    private static final int MILLION = 1000000;
    public static double roundTo(double value) {
        DecimalFormat df = new DecimalFormat("#.00");
        double number = Double.valueOf(df.format(value));
        return number;
    }

    public static int convertToInt(double value) {
        DecimalFormat df = new DecimalFormat("#.00");
        double number = Double.valueOf(df.format(value));
        return (int) number;
    }
    public static double convertToMillions(double value) {
        DecimalFormat df = new DecimalFormat("#.00");
        double number = Double.valueOf(df.format(value));
        double totalValue = number / MILLION;
        return roundTo(totalValue);
    }
}
