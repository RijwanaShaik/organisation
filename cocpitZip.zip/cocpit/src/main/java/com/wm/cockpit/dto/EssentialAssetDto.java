package com.wm.cockpit.dto;

import com.wm.cockpit.enums.DirectLiquidity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class EssentialAssetDto {
    private long id;
    private String name;
    private long value;
    private DirectLiquidity asset_type;
    private SectorDto sector;

    private List<CountryDto> country_of_economic_exposure;
    private CountryDto country_of_legal_exposure;

    private float accrued_distribution_rate;
    private float indirect_liquidity;
    private long existing_lending_value;
    private CurrencyDto existing_lending_currency;
    private List<AssetDependencyDto> share_holders;

    private CurrencyDto asset_currency;

    private CurrencyDto reference_currency;

    private float asset_exchange;
    private boolean key_family_holding;
    private float reference_exchange;

}
