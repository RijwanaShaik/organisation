package com.wm.cockpit.dto;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  17/05/23
 * @Time >>  9:20 am
 * @Project >>  cocpit
 */
@NoArgsConstructor
@Data
public class ChangePasswordRequest {
    private String email;
    private String oldPassword;
    private String newPassword;
}
