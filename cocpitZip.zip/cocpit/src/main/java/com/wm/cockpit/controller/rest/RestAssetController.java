package com.wm.cockpit.controller.rest;

import com.wm.cockpit.common.dto.AssetReq;
import com.wm.cockpit.common.dto.AssetsDto;
import com.wm.cockpit.dto.AssetDto;
import com.wm.cockpit.dto.rest.RestAssetDto;
import com.wm.cockpit.dto.rest.RestCustomerDto;
import com.wm.cockpit.entity.Asset;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.rest.RestAssetService;
import com.wm.cockpit.service.rest.RestCustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/rest/asset")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class RestAssetController {

    @Autowired
    RestAssetService restAssetService;

    @PostMapping("/add")
    public GenericResponse save(@RequestBody RestAssetDto dto) {

        return restAssetService.save(dto);
    }

    @PostMapping("/update-by-id")
    public GenericResponse updateById(@RequestBody RestAssetDto dto) {

        return restAssetService.updateById(dto);
    }

    @DeleteMapping("/delete-by-id/{id}")
    public GenericResponse deletedAssetById(@PathVariable long id) {
        return restAssetService.deleteById(id);
    }

    @GetMapping("/get-by-id/{id}")
    public GenericResponse getAssetById(@PathVariable long id) throws Exception {
        return restAssetService.getById(id);
        // return null;
    }

    @GetMapping("/total-assets")
    public GenericResponse getCountryAssets() {
        return restAssetService.countryAssets();
    }

}
