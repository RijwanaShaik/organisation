package com.wm.cockpit.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  18/05/23
 * @Time >>  11:33 am
 * @Project >>  cocpit
 */
@NoArgsConstructor
@Data
public class AdminDetailsDto {
    private Long id;
    private String name;
}
