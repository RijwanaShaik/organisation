package com.wm.cockpit.service;

import com.wm.cockpit.entity.Country;
import com.wm.cockpit.response.GenericResponse;

import java.util.List;

public interface CountryService {

    List<Country> getAllCountries();
    Country getCountryById(long id) throws Exception;

    GenericResponse getAllRestCountries();
}
