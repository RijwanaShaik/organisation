package com.wm.cockpit.dto;

import lombok.*;
import java.util.List;
@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CurrencyMixGraphDto {
    private List<AssetGraphDto> assetList;
    private double threshold;
    private String response;
}
