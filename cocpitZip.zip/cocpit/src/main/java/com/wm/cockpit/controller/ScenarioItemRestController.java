package com.wm.cockpit.controller;

import com.wm.cockpit.dto.ScenarioItemDto;
import com.wm.cockpit.service.ScenarioItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/v1/scenarioItem")
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RequiredArgsConstructor
@Validated
public class ScenarioItemRestController {
    @Autowired
    private ScenarioItemService scenarioItemService;

    @PostMapping("/create")
    public String createScenarioItem(@RequestBody ScenarioItemDto scenarioItemDto) {
        return scenarioItemService.createScenarioItem(scenarioItemDto);
    }
    @PutMapping("/{id}")
    public ScenarioItemDto savedScenarioItemById(@PathVariable long id , @RequestBody ScenarioItemDto scenarioItemDto) {
        return scenarioItemService.savedScenarioItemById(id,scenarioItemDto);
    }
    @GetMapping("/")
    public List<ScenarioItemDto> getAllScenarioItems(){
        return scenarioItemService.getAllScenarioItemsRest();
    }
}
