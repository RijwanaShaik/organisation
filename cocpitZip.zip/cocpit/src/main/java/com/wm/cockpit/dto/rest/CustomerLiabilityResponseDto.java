package com.wm.cockpit.dto.rest;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.wm.cockpit.dto.CurrencyDto;
import com.wm.cockpit.dto.FileUploadDto;
import com.wm.cockpit.dto.ScenarioSettingsDto;
import com.wm.cockpit.dto.ScenariosSettingLegalExposureDto;
import com.wm.cockpit.entity.*;
import com.wm.cockpit.enums.ClimateChangeExposure;
import com.wm.cockpit.enums.CustomerLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Setter
@Getter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerLiabilityResponseDto {

  private Long id;

  private String name;

  private double value;

  private Double costOfDebt;

  private double existingValue;

  private double share;

  private Long phoneNumber;

  private String email;

  private String currencyCode;

  private GenericDto countryOfLegalExposure;

  private GenericDto existingLending;

  private GenericDto specificAsset;

  private List<GenericDto> Liabilities;

  private List<GenericDto> liabilityDependencies;

  private List<GenericDto> assets;

  private List<GenericDto> dependencyList;

  private ScenarioSettingsDto scenarioSetting=new ScenarioSettingsDto();

  private Long currencyId;

  private CurrencyDto currencyDto;

  private List<FileUploadDto> fileUploadDtos = new ArrayList<>();

  private Map<String, Double> wealthData = new HashMap<>();
  private String level;
  private Boolean isNotValidAsset;
  private Boolean isNotValidLiability;

  public CustomerLiabilityResponseDto(Customer entity){
    this.id = entity.getId();
    this.name = entity.getName();
    this.email = entity.getEmail();
    this.phoneNumber = entity.getPhoneNumber();

    if(entity.getCurrency() != null){
      this.currencyCode = entity.getCurrency().getCurrencyCode();
      this.currencyId=entity.getCurrency().getId();
    }
    this.level= CustomerLevel.getString(entity.getLevel());
  }

  public CustomerLiabilityResponseDto(Liability entity){
    this.id = entity.getId();
    this.name = entity.getName();
    this.value = entity.getValue();
    this.costOfDebt = entity.getCostOfDebt();
    this.existingValue = entity.getExistingValue();
    if(entity.getCurrency() != null){
      this.currencyCode = entity.getCurrency().getCurrencyCode();
      CurrencyDto currencyDtoData=new CurrencyDto();
      currencyDtoData.setId(entity.getCurrency().getId());
      currencyDtoData.setCurrencyCode(entity.getCurrency().getCurrencyCode());
      this.currencyDto=currencyDtoData;
    }

  }

  @Setter
  @Getter
  @NoArgsConstructor
  @JsonInclude(JsonInclude.Include.NON_NULL)
  public static class GenericDto{
    private Long id;

    private String name;

    private float share;

    private double value;

    private String currencyCode;
    private GenericDto dependency;
    private String climateChangeExposure;

    private boolean isAvailable = true;
    private Boolean isNotValid;


    public GenericDto(Liability entity){
      this.id = entity.getId();
      this.name = entity.getName();
      this.value = entity.getValue();
      if(entity.getCurrency() != null){
        this.currencyCode = entity.getCurrency().getCurrencyCode();
      }

    }
    public GenericDto(Liability entity,CustomerLevel customerLevel){
      this.id = entity.getId();
      this.name = entity.getName();
      this.value = entity.getValue();
      if(entity.getCurrency() != null){
        this.currencyCode = entity.getCurrency().getCurrencyCode();
      }
      this.isNotValid = isLiabilityNotValid(entity, customerLevel);

    }
    public GenericDto(Asset entity){
      this.id = entity.getId();
      this.name = entity.getName();
      this.value = entity.getValue();
     if(entity.getClimateChangeExposure()!=null) {
       this.climateChangeExposure = ClimateChangeExposure.getString(entity.getClimateChangeExposure());
     }
      if(entity.getCurrency() != null){
        this.currencyCode = entity.getCurrency().getCurrencyCode();
      }

    }
    public GenericDto(Asset entity,CustomerLevel customerLevel){
      this.id = entity.getId();
      this.name = entity.getName();
      this.value = entity.getValue();
      if(entity.getClimateChangeExposure()!=null) {
        this.climateChangeExposure = ClimateChangeExposure.getString(entity.getClimateChangeExposure());
      }
      if(entity.getCurrency() != null){
        this.currencyCode = entity.getCurrency().getCurrencyCode();
      }
      this.isNotValid = isAssetNotValid(entity, customerLevel);

    }

    public GenericDto(Currency entity){
      this.id = entity.getId();
      this.currencyCode = entity.getCurrencyCode();
    }

    public GenericDto(Dependency entity){
      this.id = entity.getId();
      this.name = entity.getName();
    }
    public GenericDto(Country entity){
      this.id = entity.getId();
      this.name = entity.getName();
    }
    public GenericDto(LiabilityDependency entity){
      this.id = entity.getId();
      this.share = entity.getShare();
      if(entity.getDependency() != null){
        this.dependency = new GenericDto(entity.getDependency());
      }

    }
  }
  private static boolean isAssetNotValid(Asset asset, CustomerLevel customerLevel) {
    if (customerLevel == CustomerLevel.LEVEL_2) {
      return asset.getSector() == null || asset.getCountryOfEconomicExposure() == null || asset.getCountryOfLegalExposure() == null;
    } else if (customerLevel == CustomerLevel.LEVEL_3) {
      List<AssetDependency> dependencies = asset.getAssetDependencies();
      return asset.getClimateChangeExposure() == null || dependencies == null || dependencies.isEmpty();
    }
    return false;
  }

  private static boolean isLiabilityNotValid(Liability liability, CustomerLevel customerLevel) {
    if (customerLevel == CustomerLevel.LEVEL_2) {
      return liability.getCountryOfLegalExposure() == null;
    } else if (customerLevel == CustomerLevel.LEVEL_3) {
      List<LiabilityDependency> dependencies = liability.getLiabilityDependencies();
      return dependencies == null || dependencies.isEmpty();
    }
    return false;
  }

}
