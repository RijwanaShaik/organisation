package com.wm.cockpit.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.wm.cockpit.dto.DependencyDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.List;

@SuppressWarnings("serial")
@Entity
@Table(name = "tr_dependency")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class Dependency extends BaseEntity {
    @ManyToOne
    @JsonIgnore
    private Customer customer;

    @Column(nullable = false)
    private String name;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "dependency")
    private List<AssetDependency> assetDependencies;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "dependency")
    private List<LiabilityDependency> liabilityDependencies;

}
