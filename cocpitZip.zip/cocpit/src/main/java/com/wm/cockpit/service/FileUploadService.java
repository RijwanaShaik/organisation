package com.wm.cockpit.service;

import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.dto.FileRequestDto;
import com.wm.cockpit.dto.FileUploadDto;
import com.wm.cockpit.entity.FileUpload;
import com.wm.cockpit.response.GenericResponse;
import org.springframework.web.multipart.MultipartFile;

public interface FileUploadService {
    GenericResponse uploadFile(MultipartFile file, String fileName);

    FileUploadDto getFileById(Long fileId);

    ApiResponse deleteFileById(Long fileId);

    GenericResponse getFileByName(String fileName);
    FileUploadDto entityToDto(FileUpload fileUpload);


}
