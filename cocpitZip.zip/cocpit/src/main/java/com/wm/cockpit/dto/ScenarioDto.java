package com.wm.cockpit.dto;

import com.wm.cockpit.enums.DirectLiquidity;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ScenarioDto {
    private Long customer;
    private String name;
    private Double referenceCurrencyExchange;
    private Double familyHoldingExchange;
    private Double standardDeviation;
    private Long debtSwapSource;
    private Double debtSwapValue;
    private Long debtSwapTarget;
    private Double liquidityEventValue;
    private Long liquidityEventCurrency;

    private String liquidityEventInYear;
    private Double leveragePurchaseWorth;
    private Long leveragePurchaseCurrency;
    private DirectLiquidity additionalLeveragePurchase;
    private Long scenarioHeader;
}
