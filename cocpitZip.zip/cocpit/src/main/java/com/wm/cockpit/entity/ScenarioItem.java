package com.wm.cockpit.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.wm.cockpit.enums.DirectLiquidity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

import javax.persistence.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@SuppressWarnings("/serial")
@Table(name = "tr_scenario_item", uniqueConstraints = {@UniqueConstraint(name = "scenarioHeader", columnNames = {"scenario_header_id"})})
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class ScenarioItem extends BaseEntity {
    private Double referenceCurrencyExchange;
    private Double familyHoldingExchange;
    private Double standardDeviation;
    @OneToOne
    private Currency debtSwapSource;
    private Double debtSwapValue;
    @OneToOne
    private Currency debtSwapTarget;
    private Double liquidityEventValue;
    @OneToOne
    private Currency liquidityEventCurrency;
    private String liquidityEventInYear;
    private Double leveragePurchaseWorth;
    @OneToOne
    private Currency leveragePurchaseCurrency;
    @Enumerated(EnumType.STRING)
    private DirectLiquidity additionalLeveragePurchase;
    @OneToOne
    @JsonIgnore
    private ScenarioHeader scenarioHeader;

}
