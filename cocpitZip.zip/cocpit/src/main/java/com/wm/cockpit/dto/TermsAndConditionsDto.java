package com.wm.cockpit.dto;

import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@Data
public class TermsAndConditionsDto {
    private Long id;
    private String text;
}