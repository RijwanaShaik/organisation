package com.wm.cockpit.dto;

import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InflationGraphDto {
    private double inflationRate;
    private double finalWealth;
    private List<String> insight=new ArrayList<>();
}
