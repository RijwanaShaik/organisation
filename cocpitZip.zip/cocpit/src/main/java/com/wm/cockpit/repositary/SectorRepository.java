package com.wm.cockpit.repositary;

import com.wm.cockpit.dto.SectorDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wm.cockpit.entity.Sector;

@Repository
public interface SectorRepository extends JpaRepository<Sector, Long> {

    Sector findByName(SectorDto sector);
}
