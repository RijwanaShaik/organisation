package com.wm.cockpit.service;


public interface ScenarioLegalExposureService {

}
