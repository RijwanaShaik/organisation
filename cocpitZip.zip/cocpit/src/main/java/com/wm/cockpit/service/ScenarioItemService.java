package com.wm.cockpit.service;

import com.wm.cockpit.dto.ScenarioItemDto;
import com.wm.cockpit.entity.ScenarioItem;

import java.util.List;

public interface ScenarioItemService {

    String createScenarioItem(ScenarioItemDto scenarioItemDto);

    ScenarioItemDto savedScenarioItemById(long id, ScenarioItemDto scenarioItemDto);

    ScenarioItem savedScenarioItem(ScenarioItemDto scenarioItemDto);
    List<ScenarioItem> getAllScenarioItems();
    List<ScenarioItemDto> getAllScenarioItemsRest();
}

