package com.wm.cockpit.controller;

import java.util.List;

import com.wm.cockpit.response.GenericResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wm.cockpit.dto.SectorDto;
import com.wm.cockpit.entity.Sector;
import com.wm.cockpit.service.SectorService;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/sector")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class SectorController {

    @Autowired
    private SectorService sectorService;

    @MutationMapping(name = "createSector")
    public String createSector(@Argument(name = "input") SectorDto sectorDto) {
        return sectorService.createSector(sectorDto);
    }

    @MutationMapping(name = "updatedSectorById")
    public String updatedSectorById(@Argument SectorDto sectorDto) throws Exception {
        return sectorService.updatedSectorById(sectorDto);
    }

    @MutationMapping(name = "deletedSectorById")
    public String deletedSectorById(@Argument long id) throws Exception {
        return sectorService.deletedSectorById(id);
    }

    @QueryMapping(name = "getSectorById")
    public Sector getSectorById(@Argument long id) throws Exception {
        return sectorService.getSectorById(id);
    }

    @QueryMapping(name = "getAllSector")
    public List<Sector> getAllSector() {
        return sectorService.getAllSector();
    }
    @GetMapping("/get-all-rest-sectors")
    public GenericResponse getAllRestSectors() {
        return sectorService.getAllRestSectors();
    }
}
