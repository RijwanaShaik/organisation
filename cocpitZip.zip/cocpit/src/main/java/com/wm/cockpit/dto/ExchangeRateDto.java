package com.wm.cockpit.dto;


import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;


@Setter
@Getter
public class ExchangeRateDto {
    private String currencyCode;
    private float value;

}
