package com.wm.cockpit.dto;

import com.wm.cockpit.entity.AppUser;

public class AppUserDto extends LoginResponseDto {
  //  private String password;
    private Boolean isDeleted;

    public AppUserDto() {
    }

    public AppUserDto(AppUser user) {
        this.email = user.getEmail();
        this.role = user.getRole();
        this.userName = user.getUserName();
        this.id = user.getId();
        this.phoneNumber = user.getPhoneNumber();
    }

   /* public String getPassword() {
        return password;
    }*/

    /*public void setPassword(String password) {
        this.password = password;
    }*/

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted=isDeleted;
    }

}
