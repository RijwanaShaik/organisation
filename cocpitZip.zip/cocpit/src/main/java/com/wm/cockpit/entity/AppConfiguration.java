package com.wm.cockpit.entity;

import lombok.Getter;
import lombok.Setter;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
@Setter
@Getter
public class AppConfiguration extends BaseEntity {

    private String orgName;
    @OneToOne
    private FileUpload favIcon;
    @OneToOne
    private FileUpload organisationLogo;
    @OneToOne
    private FileUpload loginImage;
    private Boolean isCustomize=Boolean.TRUE;

}
