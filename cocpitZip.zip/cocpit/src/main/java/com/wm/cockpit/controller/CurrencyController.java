package com.wm.cockpit.controller;

import com.wm.cockpit.dto.CurrencyResponseDto;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.CurrencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/currency")
@ComponentScan(basePackages = {"com.wm.cockpit.*"})
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class CurrencyController {

    @Autowired
    private CurrencyService currencyService;

//    @GetMapping
//    public ResponseEntity<List<Currency>> getAllCurrencies() {
//        return new ResponseEntity<>(currencyService.getAllCurrencies(), HttpStatus.OK);
//    }

    @QueryMapping(name = "getAllNotUniqueCurrencies")
    public List<Currency> getAllCurrencies() {
        return currencyService.getAllCurrencies();
    }

    @QueryMapping(name = "getAllCurrencies")
    public List<Currency> getAllUniqueCurrencies() {
        return currencyService.getAllUniqueCurrencies();
    }

  /*  @GetMapping("/get-all-currency")
    public List<CurrencyResponseDto> getAllUniqueCurrencies() {
        return currencyService.getAllUniqueCurrencies();
    }*/

    @GetMapping("/id")
    private ResponseEntity<Currency> getCurrencyById(long id) throws Exception {
        return new ResponseEntity<>(currencyService.getCurrencyById(id), HttpStatus.OK);
    }
    @GetMapping("/get-all-currency")
    public GenericResponse getAllRestCurrencies() {
        return currencyService.getAllRestCurrencies();
    }
}
