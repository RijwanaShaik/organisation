package com.wm.cockpit.utils;

import java.text.DecimalFormat;
import java.util.Random;

public class GenerateOtp {

	public static String generateOTP(int length) {
		return new DecimalFormat("000000").format(new Random().nextInt(999999));
	}

}
