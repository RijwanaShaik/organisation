package com.wm.cockpit.enums;

public enum ClimateChangeExposure {
    NONE, LOW, MEDIUM, HIGH, VERY_HIGH;

    public static ClimateChangeExposure getEnum(String values){
        String upperCase=values.toUpperCase();
        return switch (upperCase){
            case "LOW"->LOW;
            case "MEDIUM"->MEDIUM;
            case "HIGH"->HIGH;
            case  "NONE"->NONE;
            case "VERY HIGH"->VERY_HIGH;
            default ->NONE;
        };
    }
    public static String getString(ClimateChangeExposure enumValue){
        return switch (enumValue){
            case LOW -> "Low";
            case MEDIUM -> "Medium";
            case HIGH -> "High";
            case VERY_HIGH -> "Very High";
            case NONE -> "None";
        };
    }
}
