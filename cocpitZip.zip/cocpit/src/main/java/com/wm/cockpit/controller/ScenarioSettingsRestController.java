package com.wm.cockpit.controller;

import com.wm.cockpit.dto.ScenarioSettingsDto;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.ScenarioSettingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/scenario/settings")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class ScenarioSettingsRestController {

    @Autowired
    private ScenarioSettingsService scenarioSettingsService;

    @PostMapping("/")
    public GenericResponse saveUpdate(@RequestBody ScenarioSettingsDto dto) {
        return scenarioSettingsService.saveOrUpdate(dto);
    }
    @GetMapping("/")
    public List<ScenarioSettingsDto> getScenarioSettingsList(){
        return scenarioSettingsService.getScenarioSettingsList();
    }
    @GetMapping("/{id}")
    public GenericResponse getScenarioSettingsById(@PathVariable long id){
        return scenarioSettingsService.getByScenarioSettingsId(id);
    }

    @DeleteMapping("/{id}")
    public GenericResponse deleteByScenarioSettingsId(@PathVariable Long id){
        return scenarioSettingsService.delete(id);
    }
    @GetMapping("/customer/{customerId}")
    public GenericResponse getScenarioSettingsByCustomer(@PathVariable Long  customerId){
        return scenarioSettingsService.getScenarioSettingsByCustomer(customerId);

    }

}
