package com.wm.cockpit.controller;

import com.google.gson.Gson;
import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.dto.ScenarioDto;
import com.wm.cockpit.dto.ScenarioHeaderDto;
import com.wm.cockpit.dto.ScenarioResponseDto;
import com.wm.cockpit.entity.ScenarioHeader;
import com.wm.cockpit.repositary.ScenarioHeaderRepository;
import com.wm.cockpit.repositary.ScenarioItemRepository;
import com.wm.cockpit.service.ScenarioHeaderService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/scenario")
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RequiredArgsConstructor
@Validated
public class ScenarioHeaderRestController {

    @Autowired
    private ScenarioHeaderService scenarioHeaderService;
    private final ScenarioHeaderRepository scenarioHeaderRepository;
    private final ScenarioItemRepository scenarioItemRepository;

    @PostMapping("/")
    public ResponseEntity<String> createScenarioHeader(@RequestBody ScenarioHeaderDto scenarioHeaderDto) {
        String scenarioHeader = scenarioHeaderService.createScenarioHeader(scenarioHeaderDto);
        return new ResponseEntity<>(scenarioHeader, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ScenarioHeader> savedScenarioHeader(@PathVariable long id, @RequestBody ScenarioHeaderDto scenarioHeaderDto) {
        ScenarioHeaderDto scenarioHeader = scenarioHeaderService.savedScenarioHeaderById(id, scenarioHeaderDto);
        return new ResponseEntity(scenarioHeader, HttpStatus.OK);

    }

    @GetMapping("/")
    public List<ScenarioHeaderDto> getAllScenarioHeaders() {
        return scenarioHeaderService.getAllScenarioHeadersRest();
    }

    @GetMapping("/{id}")
    public ResponseEntity getScenarioById(@PathVariable("id") long id) {
        try {

            ScenarioHeader scenarioHeader = scenarioHeaderService.getScenarioById(id);
            if (scenarioHeader != null && scenarioHeader.getScenarioItem() != null) {

                ScenarioDto dto = scenarioHeaderService.getScenarioResponseDto(scenarioHeader);
                return new ResponseEntity<ScenarioDto>(dto, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Scenario Not Found", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }


    @PostMapping("/create")
    public ResponseEntity<ScenarioHeader> createScenario(@RequestBody ScenarioDto scenarioDto) throws Exception {
        ScenarioHeader header = scenarioHeaderService.createScenario(scenarioDto);
        ScenarioDto dto = scenarioHeaderService.getScenarioResponseDto(header);
        return new ResponseEntity(dto, HttpStatus.OK);
    }

    @PutMapping("/update")
    public ResponseEntity<ScenarioHeader> updateByIdScenario(@RequestBody ScenarioDto scenarioDto) {
        ScenarioHeader header = scenarioHeaderService.updateScenario(scenarioDto);
        ScenarioDto dto = scenarioHeaderService.getScenarioResponseDto(header);
        return new ResponseEntity(dto, HttpStatus.OK);
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity getScenarioByCustomer(@PathVariable("customerId") long customerId) throws Exception {
        try {
            List<ScenarioHeader> scenarioHeaders = scenarioHeaderService.getScenarioByCustomer(customerId);
            if (!scenarioHeaders.isEmpty()) {
                List<ScenarioDto> dtos = scenarioHeaderService.getScenarioResponseDtoInList(scenarioHeaders);
                return new ResponseEntity<List<ScenarioDto>>(dtos, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(scenarioHeaders, HttpStatus.OK);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }

    }
}
