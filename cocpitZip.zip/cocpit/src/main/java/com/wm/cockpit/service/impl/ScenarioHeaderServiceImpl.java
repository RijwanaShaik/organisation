package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.ScenarioDto;
import com.wm.cockpit.dto.ScenarioHeaderDto;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.entity.Customer;
import com.wm.cockpit.entity.ScenarioHeader;
import com.wm.cockpit.entity.ScenarioItem;
import com.wm.cockpit.repositary.CurrencyRepository;
import com.wm.cockpit.repositary.CustomerRepository;
import com.wm.cockpit.repositary.ScenarioHeaderRepository;
import com.wm.cockpit.repositary.ScenarioItemRepository;
import com.wm.cockpit.service.ScenarioHeaderService;
import com.wm.cockpit.utils.DtoUtils;
import com.wm.cockpit.utils.ScenarioUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ScenarioHeaderServiceImpl implements ScenarioHeaderService {

    @Autowired
    private ScenarioHeaderRepository scenarioHeaderRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CurrencyRepository currencyRepository;

    @Autowired
    private ScenarioItemRepository scenarioItemRepository;
    @Autowired
    private ModelMapper mapper;

    @Override
    public String createScenarioHeader(ScenarioHeaderDto scenarioHeaderDto) {
        ScenarioHeader scenarioHeader = new ScenarioHeader();
        if (!DtoUtils.isEmpty(scenarioHeaderDto.getName())) {
            scenarioHeader.setName(scenarioHeaderDto.getName());
        }
        Customer customer = customerRepository.findById(scenarioHeaderDto.getCustomer()).get();
        scenarioHeader.setCustomer(customer);
        scenarioHeaderRepository.save(scenarioHeader);
        return "Scenario Created Successfully";
    }

    @Override
    public List<ScenarioHeaderDto> getAllScenarioHeadersRest() {

        return scenarioHeaderRepository.findAll().stream().map(ScenarioHeaderDto::new).toList();
    }

    @Override
    public List<ScenarioHeader> getAllScenarioHeaders() {
        List<ScenarioHeader> scenarioHeaders = new ArrayList<>();
        scenarioHeaders = scenarioHeaderRepository.findAll();
        return scenarioHeaders;
    }


    @Override
    public ScenarioHeaderDto savedScenarioHeaderById(long id, ScenarioHeaderDto scenarioHeaderDto) {
        ScenarioHeader scenarioHeader = scenarioHeaderRepository.findById(id).get();
        if (!DtoUtils.isEmpty(scenarioHeaderDto.getName())) {
            scenarioHeader.setName(scenarioHeaderDto.getName());
        }
        Customer customer = customerRepository.findById(scenarioHeaderDto.getCustomer()).get();
        scenarioHeader.setCustomer(customer);
        ScenarioHeader savedScenario = scenarioHeaderRepository.save(scenarioHeader);
        return ScenarioUtils.ScenarioHeaderConvertEntityToDto(savedScenario);
    }

    @Override
    public ScenarioHeader savedScenarioHeader(ScenarioHeaderDto scenarioHeaderDto) {
        ScenarioHeader scenarioHeader = scenarioHeaderRepository.findById(scenarioHeaderDto.getId()).get();
        if (!DtoUtils.isEmpty(scenarioHeaderDto.getName())) {
            scenarioHeader.setName(scenarioHeaderDto.getName());
        }
        Customer customer = customerRepository.findById(scenarioHeaderDto.getCustomer()).get();
        scenarioHeader.setCustomer(customer);
        ScenarioHeader savedScenario = scenarioHeaderRepository.save(scenarioHeader);
        return savedScenario;
    }

    @Override
    public ScenarioHeader getScenarioById(long id) throws Exception {
        Optional<ScenarioHeader> optionalHeader = scenarioHeaderRepository.findById(id);
        if (optionalHeader.isPresent()) {
            return optionalHeader.get();
        } else {
            throw new Exception("Scenario Not Found");
        }
    }

    public ScenarioDto getScenarioResponseDto(ScenarioHeader scenarioHeader) {
        ScenarioDto dto = new ScenarioDto();
        dto.setName(scenarioHeader.getName());
        dto.setCustomer(scenarioHeader.getCustomer().getId());
        dto.setScenarioHeader(scenarioHeader.getId());
        dto.setReferenceCurrencyExchange(scenarioHeader.getScenarioItem().getReferenceCurrencyExchange());
        dto.setFamilyHoldingExchange(scenarioHeader.getScenarioItem().getFamilyHoldingExchange());
        dto.setDebtSwapSource(scenarioHeader.getScenarioItem().getDebtSwapSource().getId());
        dto.setDebtSwapValue(scenarioHeader.getScenarioItem().getDebtSwapValue());
        dto.setDebtSwapTarget(scenarioHeader.getScenarioItem().getDebtSwapTarget().getId());
        dto.setStandardDeviation(scenarioHeader.getScenarioItem().getStandardDeviation());
        dto.setLiquidityEventValue(scenarioHeader.getScenarioItem().getLiquidityEventValue());
        dto.setLiquidityEventCurrency(scenarioHeader.getScenarioItem().getLiquidityEventCurrency().getId());
        dto.setLiquidityEventInYear(scenarioHeader.getScenarioItem().getLiquidityEventInYear());
        dto.setAdditionalLeveragePurchase(scenarioHeader.getScenarioItem().getAdditionalLeveragePurchase());
        dto.setLeveragePurchaseWorth(scenarioHeader.getScenarioItem().getLeveragePurchaseWorth());
        dto.setLeveragePurchaseCurrency(scenarioHeader.getScenarioItem().getLeveragePurchaseCurrency().getId());
        return dto;
    }

    public List<ScenarioDto> getScenarioResponseDtoInList(List<ScenarioHeader> scenarioHeaders) {
        List<ScenarioDto> dtos = new ArrayList<>();
        for (ScenarioHeader scenarioHeader : scenarioHeaders) {
            ScenarioDto dto = new ScenarioDto();
            if (!DtoUtils.isEmpty(scenarioHeader.getName())) {
                dto.setName(scenarioHeader.getName());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getCustomer())) {
                dto.setCustomer(scenarioHeader.getCustomer().getId());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getId())) {
                dto.setScenarioHeader(scenarioHeader.getId());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getReferenceCurrencyExchange())) {
                dto.setReferenceCurrencyExchange(scenarioHeader.getScenarioItem().getReferenceCurrencyExchange());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getFamilyHoldingExchange())) {
                dto.setFamilyHoldingExchange(scenarioHeader.getScenarioItem().getFamilyHoldingExchange());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getDebtSwapSource())) {
                dto.setDebtSwapSource(scenarioHeader.getScenarioItem().getDebtSwapSource().getId());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getDebtSwapValue())) {
                dto.setDebtSwapValue(scenarioHeader.getScenarioItem().getDebtSwapValue());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getDebtSwapTarget())) {
                dto.setDebtSwapTarget(scenarioHeader.getScenarioItem().getDebtSwapTarget().getId());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getStandardDeviation())) {
                dto.setStandardDeviation(scenarioHeader.getScenarioItem().getStandardDeviation());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getLiquidityEventValue())) {
                dto.setLiquidityEventValue(scenarioHeader.getScenarioItem().getLiquidityEventValue());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getLiquidityEventCurrency())) {
                dto.setLiquidityEventCurrency(scenarioHeader.getScenarioItem().getLiquidityEventCurrency().getId());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getLiquidityEventInYear())) {
                dto.setLiquidityEventInYear(scenarioHeader.getScenarioItem().getLiquidityEventInYear());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getAdditionalLeveragePurchase())) {
                dto.setAdditionalLeveragePurchase(scenarioHeader.getScenarioItem().getAdditionalLeveragePurchase());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getLeveragePurchaseWorth())) {
                dto.setLeveragePurchaseWorth(scenarioHeader.getScenarioItem().getLeveragePurchaseWorth());
            }
            if (!DtoUtils.isEmpty(scenarioHeader.getScenarioItem().getLeveragePurchaseCurrency())) {
                dto.setLeveragePurchaseCurrency(scenarioHeader.getScenarioItem().getLeveragePurchaseCurrency().getId());
            }
            dtos.add(dto);
        }
        return dtos;
    }

    @Override
    public ScenarioHeader createScenario(ScenarioDto scenarioDto) throws Exception {
        ScenarioHeader scenarioHeader = new ScenarioHeader();
        ScenarioItem scenarioItem = new ScenarioItem();
        Customer customer = customerRepository.findById(scenarioDto.getCustomer()).get();
        long optScenario = scenarioHeaderRepository.countByNameAndCustomer(scenarioDto.getName(), customer);
        if (optScenario >= 1) {
            throw new RuntimeException("Customer Scenario Already Existed ..... ");
        }
        if (!DtoUtils.isEmpty(scenarioDto.getName())) {
            scenarioHeader.setName(scenarioDto.getName());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getCustomer())) {

            scenarioHeader.setCustomer(customer);
        }
        if (!DtoUtils.isEmpty(scenarioDto.getReferenceCurrencyExchange())) {
            scenarioItem.setReferenceCurrencyExchange(scenarioDto.getReferenceCurrencyExchange());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getFamilyHoldingExchange())) {
            scenarioItem.setFamilyHoldingExchange(scenarioDto.getFamilyHoldingExchange());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getStandardDeviation())) {
            scenarioItem.setStandardDeviation(scenarioDto.getStandardDeviation());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getDebtSwapSource())) {
            Currency currency = currencyRepository.findById(scenarioDto.getDebtSwapSource()).get();
            scenarioItem.setDebtSwapSource(currency);
        }
        scenarioItem.setDebtSwapValue(scenarioDto.getDebtSwapValue());
        if (!DtoUtils.isEmpty(scenarioDto.getDebtSwapTarget())) {
            Currency currencyId = currencyRepository.findById(scenarioDto.getDebtSwapTarget()).get();
            scenarioItem.setDebtSwapTarget(currencyId);
        }
        if (!DtoUtils.isEmpty(scenarioDto.getLiquidityEventValue())) {
            scenarioItem.setLiquidityEventValue(scenarioDto.getLiquidityEventValue());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getLiquidityEventCurrency())) {
            Currency liquidityCurrency = currencyRepository.findById(scenarioDto.getLiquidityEventCurrency()).get();
            scenarioItem.setLiquidityEventCurrency(liquidityCurrency);
        }
        if (!DtoUtils.isEmpty(scenarioDto.getLiquidityEventInYear())) {
            scenarioItem.setLiquidityEventInYear(scenarioDto.getLiquidityEventInYear());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getAdditionalLeveragePurchase())) {
            scenarioItem.setAdditionalLeveragePurchase(scenarioDto.getAdditionalLeveragePurchase());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getLeveragePurchaseWorth())) {
            scenarioItem.setLeveragePurchaseWorth(scenarioDto.getLeveragePurchaseWorth());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getLeveragePurchaseCurrency())) {
            Currency purchaseCurrency = currencyRepository.findById(scenarioDto.getLeveragePurchaseCurrency()).get();
            scenarioItem.setLeveragePurchaseCurrency(purchaseCurrency);
        }
        scenarioItem.setScenarioHeader(scenarioHeader);
        scenarioHeader.setScenarioItem(scenarioItem);
        ScenarioHeader savedScenario = scenarioHeaderRepository.save(scenarioHeader);
        return savedScenario;
    }

    @Override
    public ScenarioHeader updateScenario(ScenarioDto scenarioDto) {
        ScenarioHeader scenarioHeader = scenarioHeaderRepository.findById(scenarioDto.getScenarioHeader()).get();
        ScenarioItem scenarioItem = scenarioHeader.getScenarioItem() == null ? null : scenarioHeader.getScenarioItem();
        if (!DtoUtils.isEmpty(scenarioDto.getName())) {
            scenarioHeader.setName(scenarioDto.getName());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getReferenceCurrencyExchange())) {
            scenarioItem.setReferenceCurrencyExchange(scenarioDto.getReferenceCurrencyExchange());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getFamilyHoldingExchange())) {
            scenarioItem.setFamilyHoldingExchange(scenarioDto.getFamilyHoldingExchange());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getStandardDeviation())) {
            scenarioItem.setStandardDeviation(scenarioDto.getStandardDeviation());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getDebtSwapSource())) {
            Currency currency = currencyRepository.findById(scenarioDto.getDebtSwapSource()).get();
            scenarioItem.setDebtSwapSource(currency);
        }
        if (!DtoUtils.isEmpty(scenarioDto.getDebtSwapValue())) {
            scenarioItem.setDebtSwapValue(scenarioDto.getDebtSwapValue());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getDebtSwapTarget())) {
            Currency currencyId = currencyRepository.findById(scenarioDto.getDebtSwapTarget()).get();
            scenarioItem.setDebtSwapTarget(currencyId);
        }
        if (!DtoUtils.isEmpty(scenarioDto.getLiquidityEventValue())) {
            scenarioItem.setLiquidityEventValue(scenarioDto.getLiquidityEventValue());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getLiquidityEventCurrency())) {
            Currency liquidityCurrency = currencyRepository.findById(scenarioDto.getLiquidityEventCurrency()).get();
            scenarioItem.setLiquidityEventCurrency(liquidityCurrency);
        }
        if (!DtoUtils.isEmpty(scenarioDto.getLiquidityEventInYear())) {
            scenarioItem.setLiquidityEventInYear(scenarioDto.getLiquidityEventInYear());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getAdditionalLeveragePurchase())) {
            scenarioItem.setAdditionalLeveragePurchase(scenarioDto.getAdditionalLeveragePurchase());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getLeveragePurchaseWorth())) {
            scenarioItem.setLeveragePurchaseWorth(scenarioDto.getLeveragePurchaseWorth());
        }
        if (!DtoUtils.isEmpty(scenarioDto.getLeveragePurchaseCurrency())) {
            Currency purchaseCurrency = currencyRepository.findById(scenarioDto.getLeveragePurchaseCurrency()).get();
            scenarioItem.setLeveragePurchaseCurrency(purchaseCurrency);
        }
        scenarioItem.setScenarioHeader(scenarioHeader);
        scenarioHeader.setScenarioItem(scenarioItem);
        ScenarioHeader savedScenario = scenarioHeaderRepository.save(scenarioHeader);
        return savedScenario;
    }

    @Override
    public List<ScenarioHeader> getScenarioByCustomer(long customerId) throws Exception {
        Optional<List<ScenarioHeader>> customerScenario = scenarioHeaderRepository.findScenarioByCustomerId(customerId);
        if (customerScenario.isPresent()) {
            return customerScenario.get();
        } else {
            throw new Exception("These Customer Have No Scenarios");
        }
    }
}
