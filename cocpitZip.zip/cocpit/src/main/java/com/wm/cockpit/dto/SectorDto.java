package com.wm.cockpit.dto;

import com.wm.cockpit.entity.Asset;
import com.wm.cockpit.entity.Sector;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.test.autoconfigure.webservices.client.WebServiceClientTest;

import javax.persistence.Access;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SectorDto {

    private long id;
    @NotEmpty(message = "name is required ")
    @NotNull(message = "name is required ")
    private String name;

    private String description;

}
