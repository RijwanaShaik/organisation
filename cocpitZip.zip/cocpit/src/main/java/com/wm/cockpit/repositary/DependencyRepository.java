package com.wm.cockpit.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wm.cockpit.entity.Dependency;

import java.util.List;

@Repository
public interface DependencyRepository extends JpaRepository<Dependency, Long>{

  List<Dependency> findByCustomerIdAndIsDeletedFalse(Long id);

    Long countByName(String name);

    Long countByNameAndCustomer(String name, Object o);
}
