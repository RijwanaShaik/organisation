package com.wm.cockpit.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

/**
 * @Author >> Swetha Kumari Medi
 * @Date >>  25/08/23
 * @Time >>  4:08 pm
 * @Project >>  cocpit
 */
@Getter
@Setter
@NoArgsConstructor
public class FileRequestDto {
    private String fileName;
    private MultipartFile fileData;
}
