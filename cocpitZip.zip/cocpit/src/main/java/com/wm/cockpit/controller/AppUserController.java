package com.wm.cockpit.controller;

import com.wm.cockpit.common.dto.GetAdminDto;
import com.wm.cockpit.dto.*;
import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.dto.rest.AdminResponseDto;
import com.wm.cockpit.response.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.wm.cockpit.dto.AppUserDto;
import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.dto.AppUserRequest;
import com.wm.cockpit.service.AppUserService;
import com.wm.cockpit.service.OtpService;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class AppUserController {

    @Autowired
    private AppUserService appUserService;

    @Autowired
    private OtpService otpService;

    private final Logger logger = LoggerFactory.getLogger( AppUser.class );

    @GetMapping("/home")
    public AppUser home() {
        AppUser appUser = new AppUser();

        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal.equals(appUser)) {
            String username = ((AppUser) principal).getUserName();
        } else {
            String username = principal.toString();
        }
        return appUser;
    }

    @PostMapping("/update-admin")
    public GenericResponse savedAppUserById(@RequestBody AdminResponseDto appUserDto) {
        logger.info( "Update Admin Service Started" );
        GenericResponse apiResponse = appUserService.savedUserById(appUserDto);
        logger.info( "Update Admin Service Completed" );
        return apiResponse;
    }

    @PostMapping("/login")
    public ApiResponse loginUser(@RequestBody AppUserRequest appUserRequest) throws Exception {
        return appUserService.login(appUserRequest);

    }

    @GetMapping("/logged-in-user")
    public ApiResponse getLoggedInUser() {
        return appUserService.getLoggedInUser();
    }

    @PostMapping("/create-user")
    public GenericResponse createUser(@RequestBody AppUserDto appUserDto) {
        logger.info("Create User Service Started");
        //	return new ResponseEntity<>(appUserService.ChangeEncryptPwd(appUser), HttpStatus.CREATED);
        //return new ResponseEntity<>(appUserService.createUser(appUserDto), HttpStatus.OK);

        logger.info( "Create Admin Service Started" );
        GenericResponse apiResponse = appUserService.createUser(appUserDto);
        logger.info( "Create Admin Service Completed" );
        return apiResponse;
    }

    //	@PostMapping("/otp")
//	public ResponseEntity<String> generateOtp(@RequestBody AppUserRequestDto userRequestDto) throws Exception {
//		return new ResponseEntity<>(appUserService.generateOtp(userRequestDto), HttpStatus.CREATED);
//
//	}
    @GetMapping("/logout")
    public ApiResponse logout(HttpServletRequest request) throws Exception {
        return appUserService.logout(request);
    }


    @QueryMapping("allAppUsers")
    public List<AppUser> GetAllUser() {
        return appUserService.getAllAppUser();
    }

    @DeleteMapping("/id")
    public String deletedAppUserById(@PathVariable long id) throws Exception {
        return appUserService.deletedAppUserById(id);
    }
    @PostMapping("/get-all-admins")
    public GenericResponse getAllAdmins(@RequestBody GetAdminDto getAdminDto){
        logger.info( "Get All Admins Service Started" );
        GenericResponse apiResponse = appUserService.getAllAdmins(getAdminDto);
        logger.info( "Get All Admins ServiceCompleted" );
        return apiResponse;
    }

    @GetMapping("/change-user-status/{appUerId}")
    public GenericResponse inActiveAppUser(@PathVariable Long appUerId){
        return  appUserService.inActiveAppUser(appUerId);
    }
    @PostMapping("/change-password")
    public GenericResponse changePassword(@RequestBody ChangePasswordRequest request){
        return appUserService.changePassword(request);
    }

    @GetMapping("/get-admin-details")
    public GenericResponse getAdminDetails(){
        return  appUserService.getAdminDetails();
    }

    @PostMapping("/accept-terms-and-conditions/{appUserId}/{termsConditionId}")
    public GenericResponse acceptTermsAndConditions(@PathVariable Long appUserId, @PathVariable Long termsConditionId){
        logger.info( "Accept Terms & Conditions Service Started" );
       GenericResponse response = appUserService.acceptTermsAndConditions(appUserId, termsConditionId);
        logger.info( "Accept Terms & Conditions Service Completed" );
        return response;
    }

  /*  @GetMapping("/get-all-avatars-by-super-admin")
    public List<AppUserDto> getAllAvatarsBySuperAdmin(){
        return appUserService.getAllAvatarsBySuperAdmin();
    }*/
}
