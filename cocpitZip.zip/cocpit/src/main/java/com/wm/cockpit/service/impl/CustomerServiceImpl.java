
package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.CustomerDto;
import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.entity.Customer;
import com.wm.cockpit.enums.CustomerLevel;
import com.wm.cockpit.enums.Role;
import com.wm.cockpit.exceptions.BadRequestException;
import com.wm.cockpit.exceptions.DuplicateException;
import com.wm.cockpit.exceptions.IdNotFoundException;
import com.wm.cockpit.repositary.AppUserRepo;
import com.wm.cockpit.repositary.CurrencyRepository;
import com.wm.cockpit.repositary.CustomerRepository;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.security.LoggedInUser;
import com.wm.cockpit.service.CockpitValidation;
import com.wm.cockpit.service.CustomerService;
import com.wm.cockpit.service.impl.validations.CustomerValidations;
import com.wm.cockpit.utils.Constants;
import com.wm.cockpit.utils.DtoUtils;
import com.wm.cockpit.validation.UnprocessableEntityException;
import com.wm.cockpit.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CurrencyRepository currencyRepository;

    @Autowired
    private CockpitValidation cockpitValidation;
    @Autowired
    private AppUserRepo appUserRepo;

    @Override
    public GenericResponse createCustomer(CustomerDto customerDto) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            Optional<AppUser> appUser=appUserRepo.findByEmail(user.getEmail());
            if(appUser.isPresent()) {
            Map<String, Object> data = new CustomerValidations().validateDbDependencies(currencyRepository, customerDto);
            if (data.keySet().contains(Constants.ERROR)) {
                throw new UnprocessableEntityException(data.get(Constants.ERROR).toString(), true);
            }
            Long optionalCustomer = customerRepository.countByNameAndAppUserId(customerDto.getName(), user.getId());
            if (optionalCustomer >= 1) {
                throw new DuplicateException("Customer Already Exists ....");
            }
            Customer customer = new Customer();
            if (!DtoUtils.isEmpty(customerDto.getName())) {
                customer.setName(customerDto.getName());
            }
            if (!DtoUtils.isEmpty(customerDto.getPhoneNumber()))
                customer.setPhoneNumber(customerDto.getPhoneNumber());
            if (!DtoUtils.isEmpty(customerDto.getCurrencyId())) {
                if (data.get("currency") instanceof Currency) {
                    Currency currency = (Currency) data.get("currency");
                    customer.setCurrency(currency);
                }
            }
            customer.setEmail(customerDto.getEmail());
                if (customerDto.getLevel() != null) {
                    customer.setLevel(CustomerLevel.getEnum(customerDto.getLevel()));
                } else {
                    throw new BadRequestException("Please provide customer level");
                }
            if(user.getRole().equals(Role.SUPER_ADMIN) && customerDto.getAdminId()!=null){
                Optional<AppUser> optionalAppUser=appUserRepo.findById(customerDto.getAdminId());
                if(optionalAppUser.isPresent()) {
                    customer.setAppUser(optionalAppUser.get());
                }else throw new IdNotFoundException("No App user found with given id!!");
            }
            else {
                customer.setAppUser(appUser.get());
            }
            customerRepository.save(customer);
            return new GenericResponse(HttpStatus.OK,"Customer Created Successfully");
            }else throw new IdNotFoundException("No AppUser found with logged-in email !!");
        }else return null;
    }

    @Override
    public Customer getCustomerById(long id) {
        Optional<Customer> optional = customerRepository.findById(id);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new IdNotFoundException("Customer Id  is Not Found ");
        }
    }

    @Override
    public List<CustomerDto> getAllCustomer() throws Exception {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            List<Customer> customers = new ArrayList<>();
            customers = customerRepository.findAllByAppUserId(user.getId());
            if (customers != null && customers.size() > 0) {
                return customers.stream().sorted(Comparator.comparing(Customer::getUpdatedOn).reversed()).map(this::customerToDto).collect(Collectors.toList());
            } else {
                throw new Exception("There Is No Customer ");
            }
        }return null;
    }

    @Override
    public GenericResponse getAllCustomers() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            List<Customer> customers = new ArrayList<>();
            if (user.getRole().equals(Role.ADMIN)) {
                customers = customerRepository.findAllByAppUserId(user.getId());
                /*if (Validator.isValid(customers)) {
                    return new GenericResponse(HttpStatus.OK, "Found All Customers ",customers.stream().sorted(Comparator.comparing(Customer::getUpdatedOn).reversed()).map(this::customerToDto).collect(Collectors.toList()));
                } else {
                    return new GenericResponse(HttpStatus.OK, "There Is No Customer ");
                }*/
            }else if (user.getRole().equals(Role.SUPER_ADMIN)){
                List<AppUser> appUserList = appUserRepo.findAllByCreatedByAndIsActiveAndIsDeleted(user.getId(), Boolean.TRUE, Boolean.FALSE);
                if (Validator.isValid(appUserList)){
                List<Long> appUserIds = new ArrayList<>(appUserList.stream().map(AppUser::getId).toList());
                appUserIds.add(user.getId());
              //  if (Validator.isValid(appUserIds)){
                    customers = customerRepository.findAllByAppUserIdInAndIsActiveAndIsDeleted(appUserIds, Boolean.TRUE, Boolean.FALSE);
                }
             //   else return new GenericResponse(HttpStatus.OK, "There Is No Customer ");
            }
            if (Validator.isValid(customers)){
                return new GenericResponse(HttpStatus.OK, "Found All Customers ",customers.stream().sorted(Comparator.comparing(Customer::getUpdatedOn).reversed()).map(this::customerToDto).collect(Collectors.toList()));
            } else {
                return new GenericResponse(HttpStatus.OK, "There Is No Customer ");
            }

        }return null;
    }

    @Override
    public List<CustomerDto> getCustomerByAdminId(Long adminId) {
        Optional<AppUser> optionalAppUser=appUserRepo.findById(adminId);
        if(optionalAppUser.isPresent()){
            List<Customer> customerList=customerRepository.findAllByAppUserId(optionalAppUser.get().getId());
            if(!CollectionUtils.isEmpty(customerList)){
                return customerList.stream().map(this::customerToDto).toList();
            }else throw new NoSuchElementException("No Customers found !!");
        }else throw new IdNotFoundException("No User found with given id!!");
    }

    @Override
    public Customer getCustomerByName(String name) {
        return customerRepository.findByName(name);
    }

    @Override
    public String updateCustomerById(CustomerDto customerDto) {

        List<String> errors = new ArrayList<>();
        if (cockpitValidation.validate(customerDto).size() > 0) {
            throw new UnprocessableEntityException(errors.toString(), true);
        }
        Map<String, Object> data = new CustomerValidations().validateDbDependencies(currencyRepository, customerDto);
        if (data.keySet().contains(Constants.ERROR)) {
            throw new UnprocessableEntityException(data.get(Constants.ERROR).toString(), true);
        }
        Customer customer;
        if (customerDto != null) {
            Optional<Customer> customerId = customerRepository.findById(customerDto.getId());
            if (customerId.isPresent()) {
                customer = customerId.get();
                if (!DtoUtils.isEmpty(customerDto.getName())) {
                    customer.setName(customerDto.getName());
                }
                if(customerDto.getLevel()!=null && !customerDto.getLevel().isEmpty()) {
                    customer.setLevel(CustomerLevel.getEnum(customerDto.getLevel()));
                }
                Currency currency = (Currency) data.get("currency");
                if(currency.getCurrencyCode()!=null && !currency.getCurrencyCode().isEmpty()) {
                    customer.setCurrency(currency);
                }else {
                    return "Currency Code Must Not be null";
                }
                customerRepository.save(customer);
            }else return "No Customer found with given id !!";
        }
        return " Customer Updated Successfully...";
    }

    @Override
    public String deletedCustomerById(long id) {
        Optional<Customer> optional = customerRepository.findById(id);
        if (optional.isPresent()) {
            customerRepository.deleteById(id);
            return " Deleted Customer By Id Is Successfully " + id;
        } else throw new IdNotFoundException("No Customer found with given id !!");
    }

    private CustomerDto customerToDto(Customer customer) {
        CustomerDto dto= new CustomerDto();
        dto.setId(customer.getId());
        dto.setName(customer.getName());
        dto.setEmail(customer.getEmail());
        dto.setPhoneNumber(customer.getPhoneNumber());
        dto.setCurrencyId(customer.getCurrency().getId());
        dto.setCurrencyCode(customer.getCurrency().getCurrencyCode());
        dto.setCreatedBy(customer.getAppUser().getUserName());
        if(customer.getLevel()!=null) {
            dto.setLevel(CustomerLevel.getString(customer.getLevel()));
        }
        return dto;
    }
}
