package com.wm.cockpit.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  19/05/23
 * @Time >>  10:35 am
 * @Project >>  cocpit
 */

@NoArgsConstructor
@Data
public class CurrencyResponseDto {
    private Long id;
    private String name;
}
