package com.wm.cockpit.common.dto;

import com.wm.cockpit.entity.*;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
public class LiabilityReq {

    private String name;

    private double value;

    @ManyToOne
    private Customer customer;

    @OneToOne
    private Currency currency;

    private int costOfDebt;

    @OneToOne
    private Country countryOfLegalExposure;

    @OneToOne
    private Currency existingLending;

    private double existingValue;
    private Asset specificAsset;

    private List<LiabilityDependency> liabilityDependencies = new ArrayList<>();;
}
