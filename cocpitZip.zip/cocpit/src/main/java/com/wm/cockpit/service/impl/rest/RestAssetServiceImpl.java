package com.wm.cockpit.service.impl.rest;

import com.wm.cockpit.common.dto.AllAssets;
import com.wm.cockpit.dto.*;
import com.wm.cockpit.dto.rest.RestAssetDependencyDto;
import com.wm.cockpit.dto.rest.RestAssetDto;
import com.wm.cockpit.dto.rest.RestExistingLandingDto;
import com.wm.cockpit.entity.*;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.enums.ClimateChangeExposure;
import com.wm.cockpit.enums.CustomerLevel;
import com.wm.cockpit.enums.Role;
import com.wm.cockpit.exceptions.BadRequestException;
import com.wm.cockpit.exceptions.IdNotFoundException;
import com.wm.cockpit.repositary.*;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.security.LoggedInUser;
import com.wm.cockpit.service.rest.RestAssetService;
import com.wm.cockpit.utils.CockpitUtil;
import com.wm.cockpit.utils.CurrencyUtil;
import com.wm.cockpit.utils.DtoUtils;
import com.wm.cockpit.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class RestAssetServiceImpl implements RestAssetService {

    @Autowired
    AssetRepository assetRepository;

    @Autowired
    CurrencyRepository currencyRepository;
    @Autowired
    SectorRepository sectorRepository;
    @Autowired
    private CountryRepository countryRepositary;
    @Autowired
    private LegalExposureRepository legalExposureRepository;
    @Autowired
    LiabilityRepository liabilityRepository;
    @Autowired
    CustomerRepository customerRepository;
    @Autowired
    DependencyRepository dependencyRepository;

    @Autowired
    CurrencyUtil util;

    @Autowired
    AssetDependencyRepository assetDependencyRepository;

    @Autowired
    AppUserRepo appUserRepo;

    @Autowired

    private FileUploadRepository fileUploadRepository;

    @Autowired
    private Environment environment;

    @Override
    @Transactional
    public GenericResponse save(RestAssetDto dto) {

        Customer customer = customerRepository.getById(dto.getCustomerId());
        long optAsset = assetRepository.countByNameAndCustomer(dto.getName(), customer);
        if (optAsset >= 1) {
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Asset Is Already Existed ....");
        }
        Asset asset = new Asset();
        RestAssetDto assetsReq = dto;
        Currency currency = currencyRepository.getById(assetsReq.getCurrencyId());
        if (assetsReq != null && customer.getLevel().equals(CustomerLevel.LEVEL_1)) {
            if (!DtoUtils.isEmpty(assetsReq.getName())) {
                asset.setName(assetsReq.getName());
            }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Asset Name Is A Mandatory Field");
            if (!DtoUtils.isEmpty(assetsReq.getValue())) {
                asset.setValue(assetsReq.getValue());
            }else return new GenericResponse(HttpStatus.BAD_REQUEST," Asset Value Is A Mandatory Field");
            asset.setCurrency(currency);
            if (!DtoUtils.isEmpty(assetsReq.getDirectLiquidity())) {
                asset.setDirectLiquidity(assetsReq.getDirectLiquidity());
            }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Direct Liquidity Is A Mandatory Field");
            if (!DtoUtils.isEmpty(assetsReq.getIsFamilyHolding())) {
                asset.setIsFamilyHolding(assetsReq.getIsFamilyHolding());
            }else return new GenericResponse(HttpStatus.BAD_REQUEST,"IsFamilyHolding Is A Mandatory Field");
            if (assetsReq.getFileIds() != null) {
                List<FileUpload> fileUploads = new ArrayList<>();
                for (Long fileId : assetsReq.getFileIds()) {
                    Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                    if (optional.isPresent()) {
                        fileUploads.add(optional.get());
                    } else {
                        throw new IdNotFoundException("No File found with given id!!");
                    }
                }
                asset.setFileUploads(fileUploads);
            }
            asset.setCustomer(customer);
            assetRepository.save(asset);
        } else if (assetsReq != null && customer.getLevel().equals(CustomerLevel.LEVEL_2)) {
            if (!DtoUtils.isEmpty(assetsReq.getName())) {
                asset.setName(assetsReq.getName());
            }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Asset Name Is A Mandatory Field");
            if (!DtoUtils.isEmpty(assetsReq.getValue())) {
                asset.setValue(assetsReq.getValue());
            }else return new GenericResponse(HttpStatus.BAD_REQUEST," Asset Value Is A Mandatory Field");
            asset.setCurrency(currency);
            if (!DtoUtils.isEmpty(assetsReq.getDirectLiquidity())) {
                asset.setDirectLiquidity(assetsReq.getDirectLiquidity());
            }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Direct Liquidity Is A Mandatory Field");
            if (!DtoUtils.isEmpty(assetsReq.getIsFamilyHolding())) {
                asset.setIsFamilyHolding(assetsReq.getIsFamilyHolding());
            }else return new GenericResponse(HttpStatus.BAD_REQUEST,"IsFamilyHolding Is A Mandatory Field");
           if(assetsReq.getSectorId()!=null) {
               Sector sector = sectorRepository.getById(assetsReq.getSectorId());
               asset.setSector(sector);
           }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Sector Is A Mandatory Field");
           if(assetsReq.getCountryOfEconomicExposure()!=null) {
               Country economyExposer = countryRepositary.getById(assetsReq.getCountryOfEconomicExposure());
               asset.setCountryOfEconomicExposure(economyExposer);
           }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Country Of EconomyExposer Is A Mandatory Field");
            List<LegalExposure> legalExposer = new ArrayList<LegalExposure>();
            if(assetsReq.getCountryOfLegalExposure()!=null){
            for (CountryDto countryDto : assetsReq.getCountryOfLegalExposure()) {
                LegalExposure legalExposerData = new LegalExposure();
                legalExposerData.setCountry(countryRepositary.getById(countryDto.getId()));
                legalExposerData.setAsset(asset);
                legalExposer.add(legalExposerData);
            }
                asset.setCountryOfLegalExposure(legalExposer);
           }else return new GenericResponse(HttpStatus.BAD_REQUEST,"Country Of LegalExposure Is A Mandatory Field");
            if (assetsReq.getFileIds() != null) {
                List<FileUpload> fileUploads = new ArrayList<>();
                for (Long fileId : assetsReq.getFileIds()) {
                    Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                    if (optional.isPresent()) {
                        fileUploads.add(optional.get());
                    } else {
                        throw new IdNotFoundException("No File found with given id!!");
                    }
                }
                asset.setFileUploads(fileUploads);
            }
            asset.setCustomer(customer);
            assetRepository.save(asset);
        } else if (assetsReq != null && customer.getLevel().equals(CustomerLevel.LEVEL_3)) {

            Sector sector = sectorRepository.getById(assetsReq.getSectorId());
            Country economyExposer = countryRepositary.getById(assetsReq.getCountryOfEconomicExposure());
            List<LegalExposure> legalExposer = new ArrayList<LegalExposure>();
            for (CountryDto countryDto : assetsReq.getCountryOfLegalExposure()) {
                LegalExposure legalExposerData = new LegalExposure();

                legalExposerData.setCountry(countryRepositary.getById(countryDto.getId()));
                legalExposerData.setAsset(asset);
                legalExposer.add(legalExposerData);
            }
            Currency existingLending = null;
            if (assetsReq.getExistingLending() != null && dto.getExistingLending() != 0) {
                existingLending = currencyRepository.getById(assetsReq.getExistingLending());
            }
            //TODO
            if (!DtoUtils.isEmpty(assetsReq.getName())) {
                asset.setName(assetsReq.getName());
            }
            if (!DtoUtils.isEmpty(assetsReq.getValue())) {
                asset.setValue(assetsReq.getValue());
            }
            asset.setCurrency(currency);
            if (!DtoUtils.isEmpty(assetsReq.getDirectLiquidity())) {
                asset.setDirectLiquidity(assetsReq.getDirectLiquidity());
            }
            if (!DtoUtils.isEmpty(assetsReq.getIsFamilyHolding())) {
                asset.setIsFamilyHolding(assetsReq.getIsFamilyHolding());
            }
            asset.setSector(sector);
            asset.setCountryOfEconomicExposure(economyExposer);
            asset.setCountryOfLegalExposure(legalExposer);
            if (!DtoUtils.isEmpty(assetsReq.getCashDistributionRate())) {
                asset.setCashDistributionRate(assetsReq.getCashDistributionRate());
            }
            if (!DtoUtils.isEmpty(assetsReq.getAccruedDistributionRate())) {
                asset.setAccruedDistributionRate(assetsReq.getAccruedDistributionRate());
            }
            if (!DtoUtils.isEmpty(assetsReq.getIndirectLiquidity())) {
                asset.setIndirectLiquidity(assetsReq.getIndirectLiquidity());
            }
            asset.setExistingLending(existingLending);
            if (!DtoUtils.isEmpty(assetsReq.getExistingLending())) {
                asset.setExistingValue(assetsReq.getExistingValue());
            }
            asset.setCustomer(customer);
            if (assetsReq.getClimateChangeExposure() != null && !assetsReq.getClimateChangeExposure().isEmpty()) {
                asset.setClimateChangeExposure(ClimateChangeExposure.getEnum(assetsReq.getClimateChangeExposure()));
            }
            if (assetsReq.getFileIds() != null) {
                List<FileUpload> fileUploads = new ArrayList<>();
                for (Long fileId : assetsReq.getFileIds()) {
                    Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                    if (optional.isPresent()) {
                        fileUploads.add(optional.get());
                    } else {
                        throw new IdNotFoundException("No File found with given id!!");
                    }
                }
                asset.setFileUploads(fileUploads);
            }
            if (assetsReq.getAssetDependencyDtos() != null && !assetsReq.getAssetDependencyDtos().isEmpty()) {
                Float shareCount = 0F;
                for (AssetDependencyDto assetDependencyDto : dto.getAssetDependencyDtos()) {
                    shareCount += assetDependencyDto.getShare();
                }
                if (shareCount != 100) {
                    throw new BadRequestException("Sum Of Share must be 100");
                }
            }
            Asset savedAsset = assetRepository.save(asset);
            if (assetsReq.getSpecificLiability() != null && assetsReq.getSpecificLiability() != 0) {
                Liability liability = liabilityRepository.getById(assetsReq.getSpecificLiability());
                asset.setSpecificLiability(liability);
                liability.setSpecificAsset(savedAsset);
                liabilityRepository.save(liability);
            }
            if (assetsReq.getAssetDependencyDtos() != null && !assetsReq.getAssetDependencyDtos().isEmpty()) {
                List<AssetDependency> assetDependencies = new ArrayList<>();
                for (AssetDependencyDto assetDependencyDto : dto.getAssetDependencyDtos()) {
                    AssetDependency assetDependency = new AssetDependency();
                    assetDependency.setAsset(savedAsset);
                    assetDependency.setShare(assetDependencyDto.getShare());
                    assetDependency.setDependency(dependencyRepository.getById(assetDependencyDto.getId()));
                    assetDependencies.add(assetDependency);
                }
                assetDependencyRepository.saveAll(assetDependencies);
            }
        } else {
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide proper info");
        }
        return new GenericResponse(HttpStatus.OK, "Asset Added Successfully");
    }

    @Override
    @Transactional
    public GenericResponse updateById(RestAssetDto dto) {
        Optional<Asset> optionalAsset = assetRepository.findById(dto.getId());
        if(optionalAsset.isPresent()) {
            Asset asset = optionalAsset.get();
            if (!asset.getName().equals(dto.getName())) {
                long optAsset = assetRepository.countByNameAndCustomer(dto.getName(), asset.getCustomer());
                if (optAsset >= 1) {
                    return new GenericResponse(HttpStatus.BAD_REQUEST, "Asset Already Existed....");
                }
            }
            RestAssetDto assetsReq = dto;
            Customer customer = customerRepository.getById(assetsReq.getCustomerId());
            Currency currency = null;
            Sector sector = null;
            Country economyExposer = null;
            if (assetsReq != null && asset != null && customer.getLevel().equals(CustomerLevel.LEVEL_1)) {
                if (assetsReq.getCurrencyId() != null && assetsReq.getCurrencyId() != 0) {
                    currency = currencyRepository.getById(assetsReq.getCurrencyId());
                }
                if (!DtoUtils.isEmpty(assetsReq.getName())) {
                    asset.setName(assetsReq.getName());
                }
                if (!DtoUtils.isEmpty(assetsReq.getValue())) {
                    asset.setValue(assetsReq.getValue());
                }
                asset.setCurrency(currency);
                if (!DtoUtils.isEmpty(assetsReq.getDirectLiquidity())) {
                    asset.setDirectLiquidity(assetsReq.getDirectLiquidity());
                }
                if (!DtoUtils.isEmpty(assetsReq.getIsFamilyHolding())) {
                    asset.setIsFamilyHolding(assetsReq.getIsFamilyHolding());
                }
                if (assetsReq.getFileIds() != null) {
                    List<FileUpload> fileUploads = new ArrayList<>();
                    for (Long fileId : assetsReq.getFileIds()) {
                        Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                        if (optional.isPresent()) {
                            fileUploads.add(optional.get());
                        } else {
                            throw new IdNotFoundException("No File found with given id!!");
                        }
                    }
                    asset.setFileUploads(fileUploads);
                }
                asset.setCustomer(customer);
                assetRepository.save(asset);
            }
            else if (assetsReq != null && asset != null && customer.getLevel().equals(CustomerLevel.LEVEL_2)) {
                if (assetsReq.getCurrencyId() != null && assetsReq.getCurrencyId() != 0) {
                    currency = currencyRepository.getById(assetsReq.getCurrencyId());
                }
                if (!DtoUtils.isEmpty(assetsReq.getName())) {
                    asset.setName(assetsReq.getName());
                }
                if (!DtoUtils.isEmpty(assetsReq.getValue())) {
                    asset.setValue(assetsReq.getValue());
                }
                asset.setCurrency(currency);
                if (!DtoUtils.isEmpty(assetsReq.getDirectLiquidity())) {
                    asset.setDirectLiquidity(assetsReq.getDirectLiquidity());
                }
                if (!DtoUtils.isEmpty(assetsReq.getIsFamilyHolding())) {
                    asset.setIsFamilyHolding(assetsReq.getIsFamilyHolding());
                }
                if (assetsReq.getSectorId() != null && assetsReq.getSectorId() != 0) {
                    sector = sectorRepository.getById(assetsReq.getSectorId());
                }

                if (assetsReq.getCountryOfEconomicExposure() != null && assetsReq.getCountryOfEconomicExposure() != 0) {
                    economyExposer = countryRepositary.getById(assetsReq.getCountryOfEconomicExposure());
                }

                // Soft Delete Existing Records
                List<LegalExposure> legalExposures = legalExposureRepository.getCountryOfLegalExposureByAssetId(assetsReq.getId());
                for (LegalExposure exposure : legalExposures) {
                    exposure.setIsDeleted(true);
                    asset.getCountryOfLegalExposure().add(exposure);
                }

                List<LegalExposure> legalExposer = new ArrayList<LegalExposure>();
                for (CountryDto countryDto : assetsReq.getCountryOfLegalExposure()) {
                    LegalExposure legalExposerData = new LegalExposure();
                    legalExposerData.setCountry(countryRepositary.getById(countryDto.getId()));
                    legalExposerData.setAsset(asset);
                    legalExposer.add(legalExposerData);
                }
                asset.setSector(sector);
                asset.setCountryOfEconomicExposure(economyExposer);
                asset.setCountryOfLegalExposure(legalExposer);
                asset.setCustomer(customer);
                if (assetsReq.getFileIds() != null) {
                    List<FileUpload> fileUploads = new ArrayList<>();
                    for (Long fileId : assetsReq.getFileIds()) {
                        Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                        if (optional.isPresent()) {
                            fileUploads.add(optional.get());
                        } else {
                            throw new IdNotFoundException("No File found with given id!!");
                        }
                    }
                    asset.setFileUploads(fileUploads);
                }
                assetRepository.save(asset);
            }

          else if (assetsReq != null && asset != null && customer.getLevel().equals(CustomerLevel.LEVEL_3)) {
                if (assetsReq.getCurrencyId() != null && assetsReq.getCurrencyId() != 0) {
                    currency = currencyRepository.getById(assetsReq.getCurrencyId());
                }

                if (assetsReq.getSectorId() != null && assetsReq.getSectorId() != 0) {
                    sector = sectorRepository.getById(assetsReq.getSectorId());
                }

                if (assetsReq.getCountryOfEconomicExposure() != null && assetsReq.getCountryOfEconomicExposure() != 0) {
                    economyExposer = countryRepositary.getById(assetsReq.getCountryOfEconomicExposure());
                }

                // Soft Delete Existing Records
                List<LegalExposure> legalExposures = legalExposureRepository.getCountryOfLegalExposureByAssetId(assetsReq.getId());
                for (LegalExposure exposure : legalExposures) {
                    exposure.setIsDeleted(true);
                    asset.getCountryOfLegalExposure().add(exposure);
                }

                List<LegalExposure> legalExposer = new ArrayList<LegalExposure>();
                for (CountryDto countryDto : assetsReq.getCountryOfLegalExposure()) {
                    LegalExposure legalExposerData = new LegalExposure();
                    legalExposerData.setCountry(countryRepositary.getById(countryDto.getId()));
                    legalExposerData.setAsset(asset);
                    legalExposer.add(legalExposerData);
                }
                // Currency existingLending =currencyRepositarye.getById(assetsReq.getExistingLending());
                Currency existingLending = null;
                if (assetsReq.getExistingLending() != null && assetsReq.getExistingLending() != 0) {
                    existingLending = currencyRepository.getById(assetsReq.getExistingLending());
                }
                Liability liability = null;
                if (assetsReq.getSpecificLiability() != null && assetsReq.getSpecificLiability() != 0) {
                    liability = liabilityRepository.getById(assetsReq.getSpecificLiability());
                    liability.setSpecificAsset(asset);
                    liabilityRepository.save(liability);
                }
               /* //deleting previous asset dependencies
                List<AssetDependency> previousAssetDependencies = assetDependencyRepository.findAllByAssetId(dto.getId());
                if(!previousAssetDependencies.isEmpty()){
                    List<AssetDependency> assetDependencies=new ArrayList<>();
                    for(AssetDependency assetDependency:previousAssetDependencies){
                        assetDependency.setAsset(null);
                        assetDependencies.add(assetDependency);
                    }
                    assetDependencyRepository.saveAll(assetDependencies);
                }*/
                /*if (dto.getAssetDependencyDtos() != null && !dto.getAssetDependencyDtos().isEmpty()) {
                    List<AssetDependency> assetDependencies = new ArrayList<>();
                    for (AssetDependencyDto assetDependencyDto : dto.getAssetDependencyDtos()) {
                        if (Objects.isNull(assetDependencyDto.getId()) || assetDependencyDto.getId() == 0) {
                            AssetDependency assetDependency = new AssetDependency();
                            assetDependency.setShare(assetDependencyDto.getShare());
                            assetDependency.setDependency(dependencyRepository.getById(assetDependencyDto.getDependencyId()));
                            assetDependency.setAsset(asset);
                            assetDependencies.add(assetDependency);
                        }
                        for (int x = 0; x < asset.getAssetDependencies().size(); x++) {
                            if (assetDependencyDto.getId() == asset.getAssetDependencies().get(x).getId()) {
                                AssetDependency assetDependency = asset.getAssetDependencies().get(x);
                                assetDependency.setShare(assetDependencyDto.getShare());
                                assetDependency.setDependency(dependencyRepository.getById(assetDependencyDto.getDependencyId()));
                                assetDependencies.add(assetDependency);
                            }
                        }
                    }
                }*/

                if (dto.getAssetDependencyDtos() != null && !dto.getAssetDependencyDtos().isEmpty()) {
                    List<Long> previousAssetDependencyIds = asset.getAssetDependencies().stream().map(assetDependency -> assetDependency.getId()).collect(Collectors.toList());
                    List<Long> currentAssetDependencyIds = dto.getAssetDependencyDtos().stream().map(assetDependency -> assetDependency.getId()).collect(Collectors.toList());
                    List<Long> dependenciesToBeDeleted = new ArrayList<>(previousAssetDependencyIds);
                    dependenciesToBeDeleted.removeAll(currentAssetDependencyIds);
                    if (dependenciesToBeDeleted != null && !dependenciesToBeDeleted.isEmpty()) {
                        for (Long assetDependencyId : dependenciesToBeDeleted) {
                            Optional<AssetDependency> optionalToBeDeleted = assetDependencyRepository.findById(assetDependencyId);
                            if (optionalToBeDeleted.isPresent()) {
                                AssetDependency assetDependencyToBeDeleted = optionalToBeDeleted.get();
                                assetDependencyToBeDeleted.setAsset(null);
                                assetDependencyRepository.save(assetDependencyToBeDeleted);
                            }
                        }
                    }
                    Float shareCount = 0F;
                    List<AssetDependency> assetDependenciesList = new ArrayList<>();
                    for (AssetDependencyDto assetDependencyDto : dto.getAssetDependencyDtos()) {
                        AssetDependency assetDependency = new AssetDependency();
                        if ((Long) assetDependencyDto.getId() != null && assetDependencyDto.getId() != 0l) {
                            Optional<AssetDependency> optionalAssetDependency = assetDependencyRepository.findById(assetDependencyDto.getId());
                            if (optionalAssetDependency.isPresent()) {
                                assetDependency = optionalAssetDependency.get();
                            } else {
                                throw new IdNotFoundException("No Asset Dependency found with given id!!");
                            }
                        }
                        assetDependency.setAsset(asset);
                        assetDependency.setShare(assetDependencyDto.getShare());
                        Optional<Dependency> optionalAssetDependency = dependencyRepository.findById(assetDependencyDto.getDependencyId());
                        if (optionalAssetDependency.isPresent()) {
                            assetDependency.setDependency(optionalAssetDependency.get());
                        } else {
                            throw new IdNotFoundException("No Dependency found with given id!!");
                        }
                        shareCount += assetDependency.getShare();
                        assetDependenciesList.add(assetDependency);
                    }
                    if (shareCount == 100) {
                        assetDependencyRepository.saveAll(assetDependenciesList);
                    } else {
                        throw new BadRequestException("Sum Of Share must be 100");
                    }
                } else {
                    List<Long> previousAssetDependencyIds = asset.getAssetDependencies().stream().map(assetDependency -> assetDependency.getId()).collect(Collectors.toList());
                    for (Long assetDependencyId : previousAssetDependencyIds) {
                        Optional<AssetDependency> optionalToBeDeleted = assetDependencyRepository.findById(assetDependencyId);
                        if (optionalToBeDeleted.isPresent()) {
                            AssetDependency assetDependencyToBeDeleted = optionalToBeDeleted.get();
                            assetDependencyToBeDeleted.setIsDeleted(Boolean.TRUE);
                            assetDependencyToBeDeleted.setIsActive(Boolean.FALSE);
//                            assetDependencyToBeDeleted.setAsset(null);
                            assetDependencyRepository.save(assetDependencyToBeDeleted);
                        }
                    }
                }
                //TODO
                if (!DtoUtils.isEmpty(assetsReq.getName())) {
                    asset.setName(assetsReq.getName());
                }
                if (!DtoUtils.isEmpty(assetsReq.getValue())) {
                    asset.setValue(assetsReq.getValue());
                }
                asset.setCurrency(currency);
                if (!DtoUtils.isEmpty(assetsReq.getDirectLiquidity())) {
                    asset.setDirectLiquidity(assetsReq.getDirectLiquidity());
                }
                if (!DtoUtils.isEmpty(assetsReq.getIsFamilyHolding())) {
                    asset.setIsFamilyHolding(assetsReq.getIsFamilyHolding());
                }
                asset.setSector(sector);
                asset.setCountryOfEconomicExposure(economyExposer);
                asset.setCountryOfLegalExposure(legalExposer);
                if (!DtoUtils.isEmpty(assetsReq.getCashDistributionRate())) {
                    asset.setCashDistributionRate(assetsReq.getCashDistributionRate());
                }
                if (!DtoUtils.isEmpty(assetsReq.getAccruedDistributionRate())) {
                    asset.setAccruedDistributionRate(assetsReq.getAccruedDistributionRate());
                }
                if (!DtoUtils.isEmpty(assetsReq.getIndirectLiquidity())) {
                    asset.setIndirectLiquidity(assetsReq.getIndirectLiquidity());
                }
                asset.setExistingLending(existingLending);
                if (!DtoUtils.isEmpty(assetsReq.getExistingLending())) {
                    asset.setExistingValue(assetsReq.getExistingValue());
                }
                asset.setSpecificLiability(liability);
                asset.setCustomer(customer);
                asset.setClimateChangeExposure(ClimateChangeExposure.getEnum(assetsReq.getClimateChangeExposure()));
                if (assetsReq.getFileIds() != null) {
                    List<FileUpload> fileUploads = new ArrayList<>();
                    for (Long fileId : assetsReq.getFileIds()) {
                        Optional<FileUpload> optional = fileUploadRepository.findById(fileId);
                        if (optional.isPresent()) {
                            fileUploads.add(optional.get());
                        } else {
                            throw new IdNotFoundException("No File found with given id!!");
                        }
                    }
                    asset.setFileUploads(fileUploads);
                }
                assetRepository.save(asset);
            }
          else if (asset == null) {

                return new GenericResponse(HttpStatus.BAD_REQUEST, "Data Not found with Asset Id");
            } else {

                return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide proper info");
            }
            return new GenericResponse(HttpStatus.OK, "UPDATED SUCCESS");
        }
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Data Not found with Asset Id");
    }

    @Override
    @Transactional
    public GenericResponse deleteById(long id) {
        try {
            Asset asset = assetRepository.getById(id);
            Liability liability = liabilityRepository.findBySpecificAssetId(asset.getId());
            if (asset != null) {
                asset.setIsDeleted(true);
                assetRepository.save(asset);
                if (liability != null) {
                    liability.setSpecificAsset(null);
                    liabilityRepository.save(liability);
                }
            }
            return new GenericResponse(HttpStatus.OK, "DELETED SUCCESS");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide proper Asset id");

    }

    @Override
    @Transactional
    public GenericResponse getById(long id) {
        Asset asset = assetRepository.getById(id);
        if (asset != null) {
            RestAssetDto restAssetDto = new RestAssetDto();
            restAssetDto.setId(asset.getId());
            restAssetDto.setName(asset.getName());
            restAssetDto.setValue(asset.getValue());
            CurrencyDto currencyDto = new CurrencyDto();
            if (asset.getCurrency() != null) {
                currencyDto.setId(asset.getCurrency().getId());
                currencyDto.setCurrencyCode(asset.getCurrency().getCurrencyCode());
            }
            restAssetDto.setCurrencyDto(currencyDto);
            asset.getAssetDependencies();
            List<RestAssetDependencyDto> assetDependencyDtoList = new ArrayList<>();
            for (AssetDependency assetDependency : asset.getAssetDependencies()) {
                RestAssetDependencyDto assetDependencyDto = new RestAssetDependencyDto();
                assetDependencyDto.setId(assetDependency.getId());
                assetDependencyDto.setAssetId(assetDependency.getAsset().getId());
                assetDependencyDto.setShare(assetDependency.getShare());
                DependencyDto dependencyDto = new DependencyDto();
                dependencyDto.setId(assetDependency.getDependency().getId());
                dependencyDto.setName(assetDependency.getDependency().getName());
                assetDependencyDto.setDependencyDto(dependencyDto);
                assetDependencyDtoList.add(assetDependencyDto);
            }
            restAssetDto.setAssetDependency(assetDependencyDtoList);
            SectorDto sector = new SectorDto();
            if (asset.getSector() != null) {
                sector.setId(asset.getSector().getId());
                sector.setName(asset.getSector().getName());
                sector.setDescription(asset.getSector().getDescription());
            } else {
                sector.setId(0);
                sector.setName("");
                sector.setDescription("");
            }
            restAssetDto.setSectorDto(sector);
            restAssetDto.setAccruedDistributionRate(asset.getAccruedDistributionRate());
            restAssetDto.setCashDistributionRate(asset.getCashDistributionRate());
            restAssetDto.setDirectLiquidity(asset.getDirectLiquidity());
            RestExistingLandingDto restExistingLandingDto = new RestExistingLandingDto();
            if (asset.getExistingLending() != null) {
                restExistingLandingDto.setId(asset.getExistingLending().getId());
                restExistingLandingDto.setCurrencyCode(asset.getExistingLending().getCurrencyCode());
            } else {
                restExistingLandingDto.setId(0);
                restExistingLandingDto.setCurrencyCode("");
            }
            restAssetDto.setExistingLendingVal(restExistingLandingDto);
            restAssetDto.setExistingValue(asset.getExistingValue());
            restAssetDto.setIndirectLiquidity(asset.getIndirectLiquidity());
            restAssetDto.setIsFamilyHolding(asset.getIsFamilyHolding());
            LiabilityDto liabilityDto = new LiabilityDto();
            if (asset.getSpecificLiability() != null) {
                liabilityDto.setId(asset.getSpecificLiability().getId());
                liabilityDto.setName(asset.getSpecificLiability().getName());
                restAssetDto.setSpecificLiabilityDto(liabilityDto);
            }
            restAssetDto.setValue(asset.getValue());
            CountryDto countryOfEconomicExposureInfoDto = new CountryDto();
            if (asset.getCountryOfEconomicExposure() != null) {
                countryOfEconomicExposureInfoDto.setId(asset.getCountryOfEconomicExposure().getId());
                countryOfEconomicExposureInfoDto.setName(asset.getCountryOfEconomicExposure().getName());
                countryOfEconomicExposureInfoDto.setCode(asset.getCountryOfEconomicExposure().getCode());
                restAssetDto.setCountryOfEconomicExposureInfo(countryOfEconomicExposureInfoDto);
            }
            List<CountryDto> legalExposure = new ArrayList<>();
            for (LegalExposure LegalExposure : asset.getCountryOfLegalExposure()) {
                Country country = LegalExposure.getCountry();
                CountryDto countryDto = new CountryDto();
                countryDto.setId(country.getId());
                countryDto.setName(country.getName());
                countryDto.setCode(country.getCode());
                legalExposure.add(countryDto);
            }
            restAssetDto.setCountryOfLegalExposure(legalExposure);
            if(asset.getFileUploads()!=null && !asset.getFileUploads().isEmpty()) {
                restAssetDto.setFileDtos(asset.getFileUploads().stream().map(this::entityToDto).toList());
            }
            if(asset.getClimateChangeExposure()!=null) {
                restAssetDto.setClimateChangeExposure(ClimateChangeExposure.getString(asset.getClimateChangeExposure()));
            }
            return new GenericResponse(HttpStatus.BAD_REQUEST, restAssetDto);
        } else {
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide valid Asset id");
        }
    }

   /* @Override
    public GenericResponse countryAssets() {
        List<Currency> currencies = currencyRepositarye.findAll();
        List<Country> countryList = countryRepositary.findAll();
        Map<String, List<AllAssets>> resultMap = new HashMap<>();
        AllAssets countryAsset = null;
        AllAssets currencyAsset = null;
        List<AllAssets> countryAssetlist = new ArrayList<>();
        List<AllAssets> currencyAssetlist = new ArrayList<>();
        for (Currency currency : currencies) {
            List<Asset> assets = assetRepository.findAssetsByCountryOfEconomicExposureId(currency.getCountryCode().getId());
            if (assets != null && assets.size() > 0) {
                double sum = assets.stream().mapToDouble(o -> o.getValue()).sum();
                double valueInUsd = util.convert(currency.getCurrencyCode(), CurrencyUtil.BASE_CURRENCY, sum);
                if (valueInUsd != 0.0) {
                    countryAsset = new AllAssets();
                    countryAsset.setName(currency.getCountryCode().getName());
                    countryAsset.setValues(CockpitUtil.convertToMillions(valueInUsd));
                    countryAssetlist.add(countryAsset);
                }
                countryAsset = new AllAssets();
                countryAsset.setName(currency.getCurrencyCode());
                countryAsset.setValues(CockpitUtil.convertToMillions(valueInUsd));
                currencyAssetlist.add(countryAsset);
            }
        }
        Map<String, List<AllAssets>> currecymap = currencyAssetlist.stream().collect(Collectors.groupingBy(AllAssets::getName));
        List<AllAssets> currencyAssets = new ArrayList<>();
        for (String currecyCode : currecymap.keySet()) {
            List<AllAssets> assets = currecymap.get(currecyCode);
            currencyAsset = new AllAssets();
            double total = 0.0;
            for (AllAssets data : assets) {
                total = +data.getValues();
            }
            currencyAsset.setName(currecyCode);
            currencyAsset.setValues(CockpitUtil.convertToMillions(total));
            currencyAssets.add(countryAsset);
        }
        List<AllAssets> sortedAssets = countryAssetlist.stream().sorted(Comparator.comparing(AllAssets::getValues).reversed()).collect(Collectors.toList());
        System.out.println(currecymap);
        resultMap.put("countries", sortedAssets);
        resultMap.put("currencies", currencyAssets);
        return new GenericResponse(HttpStatus.OK, resultMap);
    }*/





    @Override
    @Transactional
    public GenericResponse countryAssets() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            LoggedInUser user = (LoggedInUser) authentication.getPrincipal();
            List<Customer> customerList = new ArrayList<>();
            if (user.getRole().equals(Role.SUPER_ADMIN)) {
                List<AppUser> appUserList = appUserRepo.findAllByCreatedByAndRoleAndIsActive(user.getId(), Role.ADMIN, Boolean.TRUE);
                List<Long> appUserIds = new ArrayList<>(appUserList.stream().map(AppUser::getId).toList());
                appUserIds.add(user.getId());
                customerList = customerRepository.findAllByAppUserIdInAndIsActiveAndIsDeleted(appUserIds, Boolean.TRUE, Boolean.FALSE);
            } else if (user.getRole().equals(Role.ADMIN)) {
                customerList = customerRepository.findAllByAppUserIdAndIsActiveAndIsDeleted(user.getId(), Boolean.TRUE, Boolean.FALSE);
            }
            List<Asset> assets = new ArrayList<>();
            Map<String, List<AllAssets>> resultMap = new HashMap<>();
            AllAssets countryAsset = null;
            AllAssets currencyAsset = null;
            List<AllAssets> countryAssetlist = new ArrayList<>();
            List<AllAssets> currencyAssetlist = new ArrayList<>();
            if (Validator.isValid(customerList)) {

                Set<Long> customerIds = customerList.stream().map(BaseEntity::getId).collect(Collectors.toSet());
                assets = assetRepository.findAllByCustomerIdInAndIsActiveAndIsDeleted(customerIds, Boolean.TRUE, Boolean.FALSE);
                DecimalFormat decimalFormat = new DecimalFormat("0.00");
                for(Asset asset : assets){

                    double valueInUsd = util.convert(asset.getCurrency().getCurrencyCode(), CurrencyUtil.BASE_CURRENCY, asset.getValue());
                    if (asset.getCountryOfEconomicExposure() != null) {
                        if (Validator.isValid(countryAssetlist)) {
                            Optional<AllAssets> matchedCountry = countryAssetlist.stream()
                                    .filter(allAssets -> allAssets.getName().equals(asset.getCountryOfEconomicExposure().getName()))
                                    .findFirst();
                            if (matchedCountry.isPresent()) {
                                countryAsset = matchedCountry.get();
                                countryAsset.setName(asset.getCountryOfEconomicExposure().getName());

                                // Format the number using DecimalFormat
                                String formattedNumber = countryAsset.getValues() != null ? decimalFormat.format((countryAsset.getValues() + CockpitUtil.convertToMillions(asset.getValue()))) :
                                        decimalFormat.format(CockpitUtil.convertToMillions(asset.getValue()));
                                // Parse the formatted string back to a double
                                double roundedNumber = Double.parseDouble(formattedNumber);

                                countryAsset.setValues(roundedNumber);
                                int index = countryAssetlist.indexOf(countryAsset);
                                countryAssetlist.set(index, countryAsset);
                            } else {
                                setCountryAsset(countryAsset, asset, valueInUsd, countryAssetlist);
                            }
                        } else {
                            setCountryAsset(countryAsset, asset, valueInUsd, countryAssetlist);
                        }
                    }


                    if (Validator.isValid(currencyAssetlist)) {
                        Optional<AllAssets> matchedCurrency = currencyAssetlist.stream()
                                .filter(allAssets -> allAssets.getName().equals(asset.getCurrency().getCurrencyCode()))
                                .findFirst();
                        if (matchedCurrency.isPresent()) {
                            currencyAsset = matchedCurrency.get();
                            currencyAsset.setName(asset.getCurrency().getCurrencyCode());
                            String formattedNumber = currencyAsset.getValues() != null ? decimalFormat.format((currencyAsset.getValues() + CockpitUtil.convertToMillions(asset.getValue()))) :
                                    decimalFormat.format( CockpitUtil.convertToMillions(asset.getValue()));
                            // Parse the formatted string back to a double
                            double roundedNumber = Double.parseDouble(formattedNumber);
                            currencyAsset.setValues(roundedNumber);
                            int index = currencyAssetlist.indexOf(currencyAsset);
                            currencyAssetlist.set(index, currencyAsset);
                        } else {
                            setCurrencyAsset(currencyAsset, asset, valueInUsd, currencyAssetlist);
                        }
                    } else {
                        setCurrencyAsset(currencyAsset, asset, valueInUsd, currencyAssetlist);
                    }
                }
                List<AllAssets> sortedAssets = countryAssetlist.stream().sorted(Comparator.comparing(AllAssets::getValues).reversed()).collect(Collectors.toList());
                resultMap.put("countries", sortedAssets);
                resultMap.put("currencies", currencyAssetlist);

                return new GenericResponse(HttpStatus.OK, resultMap);
                //return new GenericResponse(HttpStatus.OK, "Found All Countries Of Economic Exposure", resultMap);
            }
            return new GenericResponse(HttpStatus.OK, "No Customers Data Found");
        }
        return new GenericResponse(HttpStatus.BAD_REQUEST, "Un Authorized Access");
    }

    private static void setCountryAsset(AllAssets countryAsset, Asset asset, double valueInUsd, List<AllAssets> countryAssetlist) {
        countryAsset = new AllAssets();
        countryAsset.setName(asset.getCountryOfEconomicExposure().getName());
        countryAsset.setValues(CockpitUtil.convertToMillions(valueInUsd));
        countryAssetlist.add(countryAsset);
    }

    private static void setCurrencyAsset(AllAssets currencyAsset, Asset asset, double valueInUsd, List<AllAssets> currencyAssetList) {
        currencyAsset = new AllAssets();
        currencyAsset.setName(asset.getCurrency().getCurrencyCode());
        currencyAsset.setValues(Math.ceil(CockpitUtil.convertToMillions(valueInUsd)));
        currencyAssetList.add(currencyAsset);
    }
    private FileUploadDto entityToDto(FileUpload savedFile) {
        FileUploadDto dto = new FileUploadDto();
        dto.setId(savedFile.getId());
        dto.setName(savedFile.getName());
        if(savedFile.getOriginalFileName()!=null) {
            dto.setOriginalFileName(savedFile.getOriginalFileName());
        }
        dto.setType(savedFile.getType());
        dto.setFileSizeInBytes(savedFile.getFileSizeInBytes());
        dto.setFileSize(savedFile.getFileSize());
        dto.setFileData(savedFile.getFileData());
        String fileDownloadUrl = "/api/v1/file/get-by-id/"+savedFile.getId();
        String filePreviewUrl = "/api/v1/file/preview/"+savedFile.getId();
        dto.setDownloadUrl(fileDownloadUrl);
        dto.setPreviewUrl(filePreviewUrl);
        return dto;
    }
}
