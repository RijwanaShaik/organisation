package com.wm.cockpit.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;

@Entity
@NoArgsConstructor
@Data
public class TermsAndCondition  extends BaseEntity {
    private String text;
}
