package com.wm.cockpit.service.impl;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import com.wm.cockpit.dto.CountryCurrencyDto;
import com.wm.cockpit.dto.CountryCurrencyMsgDto;
import com.wm.cockpit.entity.Country;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.repositary.CountryRepository;
import com.wm.cockpit.repositary.CurrencyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

@Service
public class CountryCurrencyServiceImpl {
    @Autowired
    RestTemplate restTemplate;
    @Autowired
    private CountryRepository countryRepositary;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Value("classpath:/countries.csv")
    Resource resourceFile;

    public CountryCurrencyMsgDto getCountries() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        CountryCurrencyMsgDto dto = restTemplate.exchange("https://countriesnow.space/api/v0.1/countries/currency", HttpMethod.GET, entity, CountryCurrencyMsgDto.class).getBody();
        List<CountryCurrencyDto> countryCurrency = dto.getData();
        Map<String, Map<Double, Double>> countryLocation = getLocation();
        for (CountryCurrencyDto cDto : countryCurrency) {
            Map<Double, Double> locations = countryLocation.get(cDto.getIso2());
            if (locations != null && !locations.isEmpty()) {
                for (Double loc : locations.keySet()) {
                    cDto.setLatitude(loc);
                    cDto.setLongitude(locations.get(loc));
                }
            }
        }
        addAllCountry(countryCurrency);
        return dto;
    }


    public void updateLocation() {

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        CountryCurrencyMsgDto dto = restTemplate.exchange("https://countriesnow.space/api/v0.1/countries/currency", HttpMethod.GET, entity, CountryCurrencyMsgDto.class).getBody();
        Map<Double, Double> locs = new HashMap<>();
        Map<String, Map<Double, Double>> countryLocation = getLocation();
        List<Country> countryList = new ArrayList<>();
        for (CountryCurrencyDto countryDto :dto.getData()) {
            locs = countryLocation.get(countryDto.getIso2());
            System.out.println(countryDto.getIso3());
            List<Country> country = countryRepositary.findByCode(countryDto.getIso3());

            if(locs != null && country != null) {
                for (Country c: country) {
                    for (Double loc : locs.keySet()) {
                        c.setLongitude(loc);
                        c.setLatitude(locs.get(loc));
                        countryList.add(c);
                    }
                }

            }
        }
        countryRepositary.saveAll(countryList);

    }



    private Map<String, Map<Double, Double>> getLocation() {
        ClassPathResource resource = new ClassPathResource("countries.csv");
        try (CSVReader reader = new CSVReader(new FileReader(resource.getFile()))) {
            String[] lineInArray;
            Map<String, Map<Double, Double>> countriesmap = new HashMap<>();
            int i = 0;
            while ((lineInArray = reader.readNext()) != null) {
                Map<Double, Double> localtionMap = new HashMap<>();
                if (i != 0) {
                    System.out.println(lineInArray[0] + "-" + lineInArray[1] + "-" + lineInArray[3] + "etc...");
                    localtionMap.put(Double.valueOf(lineInArray[0]), Double.valueOf(lineInArray[1]));
                    countriesmap.put(lineInArray[3], localtionMap);
                }
                i++;
            }
            return countriesmap;
        } catch (FileNotFoundException | CsvValidationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Country> addAllCountry(List<CountryCurrencyDto> countryDtoList) {
        if (countryRepositary.count() == 0) {
            for (CountryCurrencyDto countryDto : countryDtoList) {
                Country country = new Country();
                country.setName(countryDto.getName());
                country.setCode(countryDto.getIso3());
                country.setLatitude(countryDto.getLatitude());
                country.setLongitude(countryDto.getLongitude());
                country = countryRepositary.save(country);
                Currency currency = new Currency();
                currency.setCountryCode(country);
                currency.setCurrencyCode(countryDto.getCurrency());
                currencyRepository.save(currency);
            }
        }
        return null;
    }
}
