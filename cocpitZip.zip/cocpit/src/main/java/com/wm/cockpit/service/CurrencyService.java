package com.wm.cockpit.service;


import com.wm.cockpit.dto.CurrencyResponseDto;
import com.wm.cockpit.entity.Currency;
import com.wm.cockpit.response.GenericResponse;

import java.util.List;

public interface CurrencyService {

    List<Currency> getAllCurrencies();

    List<Currency> getAllUniqueCurrencies();

    Currency getCurrencyById(long id) throws Exception;

    GenericResponse getAllRestCurrencies();
}
