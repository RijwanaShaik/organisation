package com.wm.cockpit.service;

import com.wm.cockpit.dto.AssetDependencyDto;
import com.wm.cockpit.entity.AssetDependency;

import java.util.List;

public interface AssetDependencyService {
    String createAssetDependency(AssetDependencyDto assetDependencyDto);
    List<AssetDependency> getAllAssetDependencies();
}
