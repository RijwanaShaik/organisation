package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.ApiResponse;
import com.wm.cockpit.dto.DependencyDto;
import com.wm.cockpit.entity.Customer;
import com.wm.cockpit.entity.Dependency;
import com.wm.cockpit.repositary.AssetRepository;
import com.wm.cockpit.repositary.CustomerRepository;
import com.wm.cockpit.repositary.DependencyRepository;
import com.wm.cockpit.repositary.LiabilityRepository;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.CockpitValidation;
import com.wm.cockpit.service.DependencyService;
import com.wm.cockpit.service.impl.validations.DependencyValidations;
import com.wm.cockpit.utils.DtoUtils;
import com.wm.cockpit.validation.UnprocessableEntityException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class DependencyServiceImpl implements DependencyService {
    @Autowired
    private DependencyRepository dependencyRepository;
    @Autowired
    private AssetRepository assetRepository;
    @Autowired
    private LiabilityRepository liabilityRepository;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private CockpitValidation cockpitValidation;

    @Override
    public ApiResponse createDependency(DependencyDto dependencyDto) throws Exception {
        Dependency dependency = new Dependency();
        Customer customer = customerRepository.getById(dependencyDto.getCustomer());
        if (customer != null) {
            long optDependency = dependencyRepository.countByNameAndCustomer(dependencyDto.getName(), customer);
            if (optDependency >= 1) {
                return new ApiResponse(HttpStatus.BAD_REQUEST, "Dependency Already Existing");
            }
            if (!DtoUtils.isEmpty(dependencyDto.getName())) {
                dependency.setName(dependencyDto.getName());
            }
            if (!DtoUtils.isEmpty(dependencyDto.getCustomer())) {
                dependency.setCustomer(customer);
            }
            if (cockpitValidation.validate(dependencyDto).size() == 0) {
                dependencyRepository.save(dependency);
            }
            return new ApiResponse(HttpStatus.BAD_REQUEST, " Dependency Is Created Successfully.");
        } else {
            return new ApiResponse(HttpStatus.NOT_FOUND, " Provide Valid Customer..");
        }
    }

    @Override
    public String updateDependencyById(DependencyDto dependencyDto) throws Exception {

        Dependency dependency;
        if (dependencyDto != null) {
            Optional<Dependency> optional = dependencyRepository.findById(dependencyDto.getId());
            if (optional.isPresent()) {
            long optDependency = dependencyRepository.countByNameAndCustomer(dependencyDto.getName(), optional.get().getCustomer());
            if (optDependency >= 1) {
                return new GenericResponse(HttpStatus.BAD_REQUEST, "Dependency Already Existed..").toString();
            }
                dependency = optional.get();
                dependency.setName(dependencyDto.getName());
                Customer customer =customerRepository.getById(dependencyDto.getCustomer());
                dependency.setCustomer(customer);
                dependencyRepository.save(dependency);
            } else {
                return new GenericResponse(HttpStatus.BAD_REQUEST, "Please Provide Valid ID ..").toString();
            }

        } else {
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please Provide Proper Info ...").toString();
        }
        return "Dependency Updated Successfully....";
    }

    @Override
    public String deletedDependencyById(long id) {
        Optional<Dependency> optional = dependencyRepository.findById(id);
        if (optional.isPresent()) {
            dependencyRepository.deleteById(id);
            return "Deleted By Dependency Is Successfully .....";
        } else {
            return " Id %id is Not found ....";
        }
    }

    @Override
    public List<Dependency> getAllDependencies() {
        List<Dependency> dependencies = new ArrayList<>();
        dependencies = dependencyRepository.findAll();
        return dependencies;
    }

}
