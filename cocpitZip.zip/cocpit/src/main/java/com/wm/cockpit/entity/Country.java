package com.wm.cockpit.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
@Entity
@Setter
@AllArgsConstructor
@Getter
@NoArgsConstructor
@Table(name = "mt_country")
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class Country extends BaseEntity {
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private String code;
    private Double longitude;
    private Double latitude;
    @OneToMany(mappedBy = "country")
    private List<LegalExposure> economicExposures = new ArrayList<>();
}
