package com.wm.cockpit.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ScenarioSettingsDto {

    private Long id;
    private Long customerId;

    private Long dependentId;
    private String dependentName;

    private Long sectorId;
    private String sectorName;

    private Long countryId;
    private String countryName;
    private String countryCode;
    private double costOfDebt;
    private double accuredStressAsset;
    private double accuredLiquidityEvent;
    private double cashStressAsset;
    private double cashLiquidityEvent;


    private double  swapCashDistributionRate;
    private double swapAccuredDistributionRate;
    private double swapCostOfDebt;

    private double leverageCashDistributionRate;
    private double leverageAccuredDistributionRate;
    private double leverageCostOfDebt;

    private double liquidityCashDistributionRate;
    private double liquidityAccuredDistributionRate;
    private double liquidityCostOfDebt;
    private String climateChangeExposure;

    private List<ScenariosSettingLegalExposureDto> countryOfLegalExposure = new ArrayList<>();
}
