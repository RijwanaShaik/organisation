package com.wm.cockpit.dto;

import com.wm.cockpit.entity.Customer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.validation.constraints.*;
;import java.util.HashMap;
import java.util.Map;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDto {
    private long id;
    private String name;
    private long phoneNumber;
    private String email;
    private Long currencyId;
    private String currencyCode;
    private String createdBy;
    private Long adminId;
    private Map<String, Double> wealthData = new HashMap<>();
    private String level;

    public CustomerDto(Customer customer) {
        this.id = customer.getId();
        this.name = customer.getName();
        if (customer.getCurrency() != null) {
            this.currencyCode = customer.getCurrency().getCurrencyCode();
        }
    }
}
