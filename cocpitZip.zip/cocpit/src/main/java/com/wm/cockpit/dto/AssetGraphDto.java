package com.wm.cockpit.dto;

import lombok.*;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssetGraphDto {
    private String currencyName;
    private double assetValue;
    private Boolean isReferenceCurrency;
}
