package com.wm.cockpit.repositary;

import java.util.List;
import java.util.Optional;

import com.wm.cockpit.enums.OtpStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wm.cockpit.entity.Otp;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface OtpRepository extends JpaRepository<Otp, Long> {

    Optional<Otp> findById(Long id);

    List<Otp> findByAppUserEmailOrderByCreatedOnDesc(String email);

    @Transactional
    @Modifying
    @Query("UPDATE Otp SET status = :status WHERE id = :id")
    Integer updateOtpStatus(OtpStatus status, Long id);
	@Transactional
	@Modifying
    @Query(value ="UPDATE tr_user_otp  SET status = 'EXPERIED' WHERE id IN(SELECT id FROM tr_user_otp  WHERE created_on <= NOW() - INTERVAL '5 minutes' AND ltrim(rtrim(status)) = 'ACTIVE')",nativeQuery = true)

   // @Query(value = "UPDATE tr_user_otp SET status = 'EXPERIED' WHERE id IN(SELECT id FROM tr_user_otp WHERE tr_user_otp.createdOn <= NOW() - INTERVAL '5 minutes' AND ltrim(rtrim(status)) = 'ACTIVE')",nativeQuery = true)
	Integer updateExpiryStatus();
    Otp findFirstByAppUserIdOrderByCreatedOnDesc(Long id);


}
