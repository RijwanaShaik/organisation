package com.wm.cockpit.enums;

public enum CustomerLevel {
    LEVEL_1,
    LEVEL_2,
    LEVEL_3,
    NONE;
    public static CustomerLevel getEnum(String values) {
        String upperCase = values.toUpperCase();
        return switch (upperCase) {
            case "LEVEL_1" -> LEVEL_1;
            case "LEVEL_2" -> LEVEL_2;
            case "LEVEL_3" -> LEVEL_3;
            default -> NONE;
        };
    }
    public static String getString(CustomerLevel enumValue){
        return switch (enumValue){
            case LEVEL_1 -> "Level_1";
            case LEVEL_2 -> "Level_2";
            case LEVEL_3 -> "Level_3";
            case NONE -> "None";
        };
    }
}
