package com.wm.cockpit.dto;

import java.sql.Timestamp;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Setter
@Getter
public class ApiResponse {

	private HttpStatus status;
	private String message;
	private String error;
	private Object data;
	private long timestamp = new Date().getTime();
	private int statusCode;

	public ApiResponse() {
	}

	public ApiResponse(HttpStatus status, String message) {
		this.status = status;
		this.message = message;
		this.statusCode = status.value();
	}

	public ApiResponse(HttpStatus status, Object data) {
		this.status = status;
		this.statusCode = status.value();
		this.data = data;
	}

	public ApiResponse(HttpStatus status, String message, Object data) {
		this.status = status;
		this.message = message;
		this.statusCode = status.value();
		this.data = data;
	}

	public ApiResponse(HttpStatus status, String error, String message, Object resultObject) {
		this.status = status;
		this.error = error;
		this.message = message;
		this.timestamp = new Timestamp(new Date().getTime()).getTime();
		this.statusCode = status.value();
	}

	public static ApiResponse getFailureResponse() {
		return new ApiResponse(HttpStatus.BAD_REQUEST, "Something Went wrong!");
	}

	public static ApiResponse getSuccessResponse() {
		return new ApiResponse(HttpStatus.OK, "");
	}

	public static ApiResponse getFailureResponse(String message) {
		return new ApiResponse(HttpStatus.BAD_REQUEST, message);
	}

}