package com.wm.cockpit.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  18/05/23
 * @Time >>  10:40 am
 * @Project >>  cocpit
 */
@NoArgsConstructor
@Data
public class AdminDetailsResponseDto {

    private Long id;
    private String name;
}
