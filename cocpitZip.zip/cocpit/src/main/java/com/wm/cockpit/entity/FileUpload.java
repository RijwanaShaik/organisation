package com.wm.cockpit.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Lob;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class FileUpload extends BaseEntity{

    private String name;

    private String type;

    private String originalFileName;

    @Lob
    private byte[] fileData;

    private Integer fileSizeInBytes;

    private Long fileSize;

}
