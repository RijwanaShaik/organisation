package com.wm.cockpit.dto;

import lombok.Data;

@Data
public class AppUserResponse {
    long id;
    String userName;
    String email;
    long phoneNumber;
    String role;
    String status;
}
