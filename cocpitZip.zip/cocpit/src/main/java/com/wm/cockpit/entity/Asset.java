package com.wm.cockpit.entity;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.wm.cockpit.enums.ClimateChangeExposure;
import com.wm.cockpit.enums.DirectLiquidity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

@Entity
@Table(name = "tr_asset")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor()
@SuppressWarnings("serial")
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class Asset extends BaseEntity {
    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private long value;

    @OneToOne
    private Sector sector;

    @ManyToOne(fetch=FetchType.LAZY)
    @JsonIgnoreProperties({"customer"})
    private Customer customer;

    @OneToOne
    private Currency currency;

    @Enumerated(EnumType.STRING)
    private DirectLiquidity directLiquidity;

    private float indirectLiquidity;

    private float cashDistributionRate;

    private float accruedDistributionRate;

    @OneToMany(mappedBy = "asset", cascade = CascadeType.MERGE)
    private List<LegalExposure> countryOfLegalExposure = new ArrayList<>();

    @OneToOne(cascade = CascadeType.ALL)
    private Country countryOfEconomicExposure;

    private Boolean isFamilyHolding;

    @OneToMany(mappedBy = "asset", cascade = CascadeType.MERGE)
    private List<AssetDependency> assetDependencies = new ArrayList<>();

    @OneToOne
    private Currency existingLending;

    private double existingValue;
    @OneToOne(cascade = CascadeType.ALL)
    private Liability specificLiability;

    @Enumerated(EnumType.STRING)
    private ClimateChangeExposure climateChangeExposure;

    @OneToMany
    private List<FileUpload> fileUploads = new ArrayList<>();
}

