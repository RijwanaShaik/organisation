package com.wm.cockpit.service;

import java.util.List;

import com.wm.cockpit.common.dto.GetAdminDto;
import com.wm.cockpit.dto.*;
import com.wm.cockpit.dto.rest.AdminResponseDto;
import com.wm.cockpit.entity.AppUser;
import com.wm.cockpit.dto.AppUserRequest;
import com.wm.cockpit.response.GenericResponse;

import javax.servlet.http.HttpServletRequest;

public interface AppUserService {

    String ChangeEncryptPwd(AppUser appUser);

    GenericResponse createUser(AppUserDto appUser);

    GenericResponse savedUserById(AdminResponseDto appUserDto);

    ApiResponse findByUserAppId(long id);

    //	ApiResponse logIn(AppUserRequest appUserRequest) throws Exception ;
    // String generateOtp(AppUserRequestDto userRequestDto) throws Exception;

    public ApiResponse getLoggedInUser();

    ApiResponse login(AppUserRequest appUserRequest);

    List<AppUser> getAllAppUser();

    String deletedAppUserById(long id) throws Exception;

    ApiResponse logout(HttpServletRequest request);

    GenericResponse getAllAdmins(GetAdminDto requestDto);

    GenericResponse inActiveAppUser(Long appUerId);

    GenericResponse changePassword(ChangePasswordRequest request);

    GenericResponse getAdminDetails();

    GenericResponse acceptTermsAndConditions(Long appUserId, Long termsCondtionId);

    // List<AppUserDto> getAllAvatarsBySuperAdmin();
}






