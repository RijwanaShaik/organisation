package com.wm.cockpit.utils;

import com.wm.cockpit.dto.ConvertCurrency;
import com.wm.cockpit.entity.ExchangeRate;
import com.wm.cockpit.repositary.ExchangeRateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class CurrencyUtil {

    @Autowired
    ExchangeRateRepository exchangeRateRepository;
    public static final String BASE_CURRENCY = "USD";

    public double convert(String source, String target, double value) {
        double returnValue = 0;
        if (source.equals(target)) {
            return  value;
        }
        System.out.println("source :::::::::::" + source);
        ExchangeRate sourceExchangeRate = exchangeRateRepository.findByCurrencyCode(source);
        ExchangeRate targetExchangeRate = exchangeRateRepository.findByCurrencyCode(target);
        returnValue = sourceExchangeRate!=null && targetExchangeRate!=null ?  (targetExchangeRate.getValue() / sourceExchangeRate.getValue()) * value : returnValue;
        return returnValue;
    }
}
