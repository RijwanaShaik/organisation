package com.wm.cockpit.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AppConfigurationResponseDto {
    private Long id;
    private String orgName;
    private FileUploadDto favIcon;
    private FileUploadDto organisationLogo;
    private FileUploadDto loginImage;
    private Boolean isCustomize;
}
