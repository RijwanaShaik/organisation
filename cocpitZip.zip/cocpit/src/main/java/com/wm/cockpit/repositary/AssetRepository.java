package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wm.cockpit.entity.Asset;

import java.util.List;
import java.util.Set;

@Repository
public interface AssetRepository extends JpaRepository<Asset, Long> {

    Asset findAssetsByCustomerId(long id);

    List<Asset> findByCustomerIdAndIsDeletedFalse(Long id);

    List<Asset> findAssetsByCountryOfEconomicExposureId(Long id);

    Asset findAssetBySpecificLiabilityId(Long id);

    Long countByName(String name);

    long countByNameAndCustomer(String name, Customer customer);

    List<Asset> findAllByCustomerIdInAndIsActiveAndIsDeleted(Set<Long> customerIds, Boolean aTrue, Boolean aFalse);
}
