package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.LegalExposure;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LegalExposureRepository extends JpaRepository<LegalExposure,Long> {
    List<LegalExposure> getCountryOfLegalExposureByAssetId(Long id);
}
