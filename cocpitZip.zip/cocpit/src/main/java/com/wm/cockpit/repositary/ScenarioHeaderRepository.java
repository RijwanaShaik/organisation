package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.Customer;
import com.wm.cockpit.entity.ScenarioHeader;
import org.springframework.boot.autoconfigure.security.oauth2.resource.OAuth2ResourceServerProperties;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ScenarioHeaderRepository extends JpaRepository<ScenarioHeader, Long> {
    Optional<List<ScenarioHeader>> findScenarioByCustomerId(long customerId);

    Long countByName(String name);

    long countByNameAndCustomer(String name, Customer customer);
}

