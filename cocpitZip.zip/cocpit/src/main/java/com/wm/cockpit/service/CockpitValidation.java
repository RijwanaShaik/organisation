package com.wm.cockpit.service;

import java.util.List;

public interface CockpitValidation {
    public  List<String> validate(Object object);
}
