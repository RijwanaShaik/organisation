package com.wm.cockpit.exception_handler;

import com.wm.cockpit.exceptions.*;
import com.wm.cockpit.response.GenericResponse;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.sql.SQLTimeoutException;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  18/05/23
 * @Time >>  2:10 pm
 * @Project >>  cocpit
 */

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(Exception.class)
    public ResponseEntity<GenericResponse> handleExceptions(Exception exception, WebRequest request) {

        if (exception instanceof BadRequestException) {
            return composeBadRequestResponse(exception, request);
        } else if (exception instanceof DuplicateException) {
            return composeDuplicateExceptionResponse(exception, request);
        } else if (exception instanceof IdNotFoundException) {
            return composeIdNotFoundExceptionResponse(exception, request);
        } else if (exception instanceof UnAuthorisedException) {
            return composeUnAuthorisedExceptionResponse(exception, request);
        } else if (exception instanceof CustomAuthenticationException) {
            return composeUnAuthorisedExceptionResponse(exception, request);
        } else {
            return composeGenericException(exception, request);
        }
    }

    private ResponseEntity<GenericResponse> composeGenericException(Exception exception, WebRequest request) {
        return new ResponseEntity<>(composeAppResponseDTO(HttpStatus.BAD_REQUEST, exception.getMessage()), HttpStatus.BAD_REQUEST);
    }

    private ResponseEntity<GenericResponse> composeUnAuthorisedExceptionResponse(Exception exception, WebRequest request) {
        return new ResponseEntity<>(composeAppResponseDTO(HttpStatus.UNAUTHORIZED, exception.getMessage()), HttpStatus.UNAUTHORIZED);
    }

    private ResponseEntity<GenericResponse> composeIdNotFoundExceptionResponse(Exception exception, WebRequest request) {
        return new ResponseEntity<>(composeAppResponseDTO(HttpStatus.NOT_FOUND, exception.getMessage()), HttpStatus.ALREADY_REPORTED);
    }

    private ResponseEntity<GenericResponse> composeDuplicateExceptionResponse(Exception exception, WebRequest request) {
        return new ResponseEntity<>(composeAppResponseDTO(HttpStatus.ALREADY_REPORTED, exception.getMessage()), HttpStatus.ALREADY_REPORTED);
    }


    private ResponseEntity<GenericResponse> composeBadRequestResponse(Exception exception, WebRequest request) {
        return new ResponseEntity<>(composeAppResponseDTO( HttpStatus.BAD_REQUEST,exception.getMessage()), HttpStatus.BAD_REQUEST);
    }

    private GenericResponse composeAppResponseDTO(HttpStatus status,String message) {
        return new GenericResponse(status, message);
    }

}
