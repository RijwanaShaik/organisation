package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.AssetDependencyDto;
import com.wm.cockpit.entity.Asset;
import com.wm.cockpit.entity.AssetDependency;
import com.wm.cockpit.entity.Dependency;
import com.wm.cockpit.repositary.AssetDependencyRepository;
import com.wm.cockpit.repositary.AssetRepository;
import com.wm.cockpit.repositary.DependencyRepository;
import com.wm.cockpit.service.AssetDependencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssetDependencyServiceImpl implements AssetDependencyService {
    @Autowired
    private AssetDependencyRepository assetDependencyRepository;
    @Autowired
    private AssetRepository assetRepository;
    @Autowired
    private DependencyRepository dependencyRepository;

    @Override
    public String createAssetDependency(AssetDependencyDto assetDependencyDto) {
        AssetDependency assetDependency = new AssetDependency();
        assetDependency.setShare(assetDependencyDto.getShare());
        Asset asset = assetRepository.findById(assetDependencyDto.getAssetId()).get();
        assetDependency.setAsset(asset);
        Dependency dependency = dependencyRepository.findById(assetDependencyDto.getDependencyId()).get();
        assetDependency.setDependency(dependency);
        assetDependencyRepository.save(assetDependency);
        return " Created AssetDependency Successfully.. ";
    }


    @Override
    public List<AssetDependency> getAllAssetDependencies() {
        return assetDependencyRepository.findAll();
    }
}