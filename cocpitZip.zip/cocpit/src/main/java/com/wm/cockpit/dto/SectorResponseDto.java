package com.wm.cockpit.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SectorResponseDto {
    private List<SectorGraphDto> thresholdList;
    private List<SectorGraphDto> countryOrSectorDtoList;
    private List<String>  thresholdMessage;
    private List<String> countryOrSectorMessage;
    private String responseMessage;
    private List<String> countrySectorList;
    private List<String> countryList;
    private List<String> sectorList;


}
