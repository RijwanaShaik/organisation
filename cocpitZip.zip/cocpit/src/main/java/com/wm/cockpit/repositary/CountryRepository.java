package com.wm.cockpit.repositary;

import com.wm.cockpit.dto.CountryDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wm.cockpit.entity.Country;

import java.util.List;

@Repository
public interface CountryRepository extends JpaRepository<Country, Long> {

    Country findByName(CountryDto countryOfLegalExposure);
    List<Country> findByCode(String code);

//    Country findByInventoryIds(List<CountryDto> countryOfLegalExposure);
}
