package com.wm.cockpit.entity;

import com.wm.cockpit.dto.SectorDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@SuppressWarnings("serial")
@Entity
@Table(name = "mt_sector")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Where(clause = "is_deleted=false OR  is_deleted is null ")
public class Sector extends BaseEntity {
    @NotEmpty(message = "name is required ")
    @NotNull(message = "name is required ")
    private String name;
    private String description;

}
