package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.CountryDto;
import com.wm.cockpit.entity.Country;
import com.wm.cockpit.repositary.CountryRepository;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CountryServiceImpl implements CountryService {


    @Autowired
    private CountryRepository countryRepositary;

    @Override

    public List<Country> getAllCountries() {
        List<Country> countries = countryRepositary.findAll(Sort.by(Sort.Direction.ASC, "name"));
        return countries;
    }

    @Override
    public Country getCountryById(long id) throws Exception {
        Optional<Country> optional = countryRepositary.findById(id);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new Exception("Country Id %id Is Not Found");

        }
    }

    @Override
    public GenericResponse getAllRestCountries() {
        List<CountryDto> countries = countryRepositary.findAll(Sort.by(Sort.Direction.ASC, "name")).stream().map(this::mapCountryToCountryDto).toList();
        return new GenericResponse(HttpStatus.OK, countries);
    }


    public CountryDto mapCountryToCountryDto(Country country) {
        CountryDto countryDto = new CountryDto();
        countryDto.setId(country.getId());
        countryDto.setName(country.getName());
        countryDto.setCode(country.getCode());
        return countryDto;
    }
}
