package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.CustomerDto;
import com.wm.cockpit.service.CockpitValidation;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Component
public class CockpitValidationImpl implements CockpitValidation {
    @Override
    public List<String> validate(Object object) {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> violations = validator.validate(object);
        List<String> errors = new ArrayList<>();
        for (ConstraintViolation<Object> violation : violations) {
            errors.add(violation.getMessage());
        }
        return errors;
    }
}
