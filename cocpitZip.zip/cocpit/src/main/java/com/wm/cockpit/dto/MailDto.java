package com.wm.cockpit.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class MailDto {

	private String from;
	private String to;
	private String subject;
	private String body;
	private Long app_user_id;

	private Boolean isTermsAndConditionsAccepted = Boolean.FALSE;

}
