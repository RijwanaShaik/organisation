package com.wm.cockpit.service.impl;

import com.wm.cockpit.dto.ScenarioSettingsDto;
import com.wm.cockpit.dto.ScenariosSettingLegalExposureDto;
import com.wm.cockpit.entity.*;
import com.wm.cockpit.enums.ClimateChangeExposure;
import com.wm.cockpit.enums.CustomerLevel;
import com.wm.cockpit.exceptions.BadRequestException;
import com.wm.cockpit.repositary.*;
import com.wm.cockpit.response.GenericResponse;
import com.wm.cockpit.service.ScenarioSettingsService;
import com.wm.cockpit.utils.DtoUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ScenarioSettingsServiceImpl implements ScenarioSettingsService {

    @Autowired
    private ScenarioSettingsRepository scenarioSettingsRepository;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private CountryRepository countryRepositary;
    @Autowired
    private DependencyRepository dependencyRepository;
    @Autowired
    private SectorRepository sectorRepository;
    @Autowired
    private ScenarioLegalExposureRepository scenarioLegalExposureRepository;


    @Override
    public GenericResponse saveOrUpdate(ScenarioSettingsDto dto) {
            ScenarioSettings scenarioSettings = null;
            if (dto.getId() != null) {
                scenarioSettings = scenarioSettingsRepository.findById(dto.getId()).orElseThrow(() -> new RuntimeException("Please provide valid id"));
            } else {
                scenarioSettings = new ScenarioSettings();
            }

            if (!DtoUtils.isEmpty(dto.getCustomerId())) {
                Customer  customer = customerRepository.getById(dto.getCustomerId());
                scenarioSettings.setCustomer(customer);

            if(customer.getLevel().equals(CustomerLevel.LEVEL_2)) {
                if (!DtoUtils.isEmpty(dto.getSectorId())) {
                    Sector sector = sectorRepository.getById(dto.getSectorId());
                    scenarioSettings.setSector(sector);
                    dto.setSectorName(sector.getName());
                }
                if (!DtoUtils.isEmpty(dto.getCountryId())) {
                    Country country = countryRepositary.getById(dto.getCountryId());
                    scenarioSettings.setCountry(country);
                    dto.setCountryName(country.getName());
                    dto.setCountryCode(country.getCode());
                }
                // Soft delete
                if (scenarioSettings.getId() != null) {
                    List<ScenarioLegalExposure> legalExposure = scenarioSettings.getCountryOfLegalExposure();//scenarioLegalExposureRepository.findByScenarioSettingsId(dto.getId());
                    for (ScenarioLegalExposure legal: legalExposure) {
                        legal.setIsDeleted(true);
                        // ScenarioLegalExposure scenarioLegalExposure = scenarioLegalExposureRepository.save(legal);
                        //  scenarioSettings.getCountryOfLegalExposure().add(legal);
                    }
                    //scenarioSettings.getCountryOfLegalExposure().clear();
                }


                List<ScenarioLegalExposure> scenarioLegalExposures = new ArrayList<ScenarioLegalExposure>();
                for (ScenariosSettingLegalExposureDto exposureDto : dto.getCountryOfLegalExposure()) {
                    ScenarioLegalExposure scenarioLegalExposureData = new ScenarioLegalExposure();
                    if (!DtoUtils.isEmpty(dto.getCountryOfLegalExposure())) {
                        scenarioLegalExposureData.setCountry(countryRepositary.getById(exposureDto.getCountryId()));
                        exposureDto.setCountryName(scenarioLegalExposureData.getCountry().getName());
                    }
                    if (!DtoUtils.isEmpty(scenarioSettings)) {
                        scenarioLegalExposureData.setScenarioSettings(scenarioSettings);
                    }
                    scenarioLegalExposures.add(scenarioLegalExposureData);
                }
                if (!DtoUtils.isEmpty(scenarioLegalExposures)) {
                    scenarioSettings.setCountryOfLegalExposure(scenarioLegalExposures);
                }
                ScenarioSettings settings = scenarioSettingsRepository.save(scenarioSettings);
                if (!DtoUtils.isEmpty(settings.getId())) {
                    dto.setId(settings.getId());
                }

            }
            if(customer.getLevel().equals(CustomerLevel.LEVEL_3)) {
                if (!DtoUtils.isEmpty(dto.getDependentId())) {
                    Dependency dependency = dependencyRepository.getById(dto.getDependentId());
                    scenarioSettings.setDependency(dependency);
                    dto.setDependentName(dependency.getName());
                }
                if (!DtoUtils.isEmpty(dto.getSectorId())) {
                    Sector sector = sectorRepository.getById(dto.getSectorId());
                    scenarioSettings.setSector(sector);
                    dto.setSectorName(sector.getName());
                }
                if (!DtoUtils.isEmpty(dto.getCountryId())) {
                    Country country = countryRepositary.getById(dto.getCountryId());
                    scenarioSettings.setCountry(country);
                    dto.setCountryName(country.getName());
                    dto.setCountryCode(country.getCode());
                }
                if (!DtoUtils.isEmpty(dto.getCostOfDebt())) {
                    scenarioSettings.setCostOfDebt(dto.getCostOfDebt());
                }
                if (!DtoUtils.isEmpty(dto.getAccuredStressAsset())) {
                    scenarioSettings.setAccuredStressAsset(dto.getAccuredStressAsset());
                }
                if (!DtoUtils.isEmpty(dto.getAccuredLiquidityEvent())) {
                    scenarioSettings.setAccuredLiquidityEvent(dto.getAccuredLiquidityEvent());
                }
                if (!DtoUtils.isEmpty(dto.getCashStressAsset())) {
                    scenarioSettings.setCashStressAsset(dto.getCashStressAsset());
                }
                if (!DtoUtils.isEmpty(dto.getCashLiquidityEvent())) {
                    scenarioSettings.setCashLiquidityEvent(dto.getCashLiquidityEvent());
                }
                if (!DtoUtils.isEmpty(dto.getSwapAccuredDistributionRate())) {
                    scenarioSettings.setSwapAccuredDistributionRate(dto.getSwapAccuredDistributionRate());
                }
                if (!DtoUtils.isEmpty(dto.getCostOfDebt())) {
                    scenarioSettings.setSwapCostOfDebt(dto.getCostOfDebt());
                }
                if (!DtoUtils.isEmpty(dto.getSwapCashDistributionRate())) {
                    scenarioSettings.setSwapCashDistributionRate(dto.getSwapCashDistributionRate());
                }

                if (!DtoUtils.isEmpty(dto.getLeverageCostOfDebt())) {
                    scenarioSettings.setLeverageCostOfDebt(dto.getLeverageCostOfDebt());
                }
                if (!DtoUtils.isEmpty(dto.getLeverageCashDistributionRate())) {
                    scenarioSettings.setLeverageCashDistributionRate(dto.getLeverageCashDistributionRate());
                }
                if (!DtoUtils.isEmpty(dto.getLeverageAccuredDistributionRate())) {
                    scenarioSettings.setLeverageAccuredDistributionRate(dto.getLeverageAccuredDistributionRate());
                }

                if (!DtoUtils.isEmpty(dto.getLiquidityCostOfDebt())) {
                    scenarioSettings.setLiquidityCostOfDebt(dto.getLiquidityCostOfDebt());
                }
                if (!DtoUtils.isEmpty(dto.getLiquidityCashDistributionRate())) {
                    scenarioSettings.setLiquidityCashDistributionRate(dto.getLiquidityCashDistributionRate());
                }
                if (!DtoUtils.isEmpty(dto.getLiquidityAccuredDistributionRate())) {
                    scenarioSettings.setLiquidityAccuredDistributionRate(dto.getLiquidityAccuredDistributionRate());
                }
                // Soft delete
                if (scenarioSettings.getId() != null) {
                    List<ScenarioLegalExposure> legalExposure = scenarioSettings.getCountryOfLegalExposure();//scenarioLegalExposureRepository.findByScenarioSettingsId(dto.getId());
                    for (ScenarioLegalExposure legal : legalExposure) {
                        legal.setIsDeleted(true);
                        // ScenarioLegalExposure scenarioLegalExposure = scenarioLegalExposureRepository.save(legal);
                        //  scenarioSettings.getCountryOfLegalExposure().add(legal);
                    }
                    //scenarioSettings.getCountryOfLegalExposure().clear();
                }


                List<ScenarioLegalExposure> scenarioLegalExposures = new ArrayList<ScenarioLegalExposure>();
                for (ScenariosSettingLegalExposureDto exposureDto : dto.getCountryOfLegalExposure()) {
                    ScenarioLegalExposure scenarioLegalExposureData = new ScenarioLegalExposure();
                    if (!DtoUtils.isEmpty(dto.getCountryOfLegalExposure())) {
                        scenarioLegalExposureData.setCountry(countryRepositary.getById(exposureDto.getCountryId()));
                        exposureDto.setCountryName(scenarioLegalExposureData.getCountry().getName());
                    }
                    if (!DtoUtils.isEmpty(scenarioSettings)) {
                        scenarioLegalExposureData.setScenarioSettings(scenarioSettings);
                    }
                    scenarioLegalExposures.add(scenarioLegalExposureData);
                }
                if (!DtoUtils.isEmpty(scenarioLegalExposures)) {
                    scenarioSettings.setCountryOfLegalExposure(scenarioLegalExposures);
                }
                if (dto.getClimateChangeExposure() != null && !dto.getClimateChangeExposure().trim().isEmpty()) {
                    scenarioSettings.setClimateChangeExposure(ClimateChangeExposure.getEnum(dto.getClimateChangeExposure()));
                } else {
                    throw new BadRequestException("Climate Change Exposure Must Not Be Null");
                }
                ScenarioSettings settings = scenarioSettingsRepository.save(scenarioSettings);
                if (!DtoUtils.isEmpty(settings.getId())) {
                    dto.setId(settings.getId());
                }
            }
            }
            else{
                throw new BadRequestException("Customer Id must not be null ");
            }
            return new GenericResponse(HttpStatus.OK, dto);
    }

    @Override
    public List<ScenarioSettingsDto> getScenarioSettingsList() {
        List<ScenarioSettings> settings = scenarioSettingsRepository.findAll();
        List<ScenarioSettingsDto> dtos = new ArrayList<>();

        for (ScenarioSettings setting : settings) {
            ScenarioSettingsDto dto = new ScenarioSettingsDto();
            if (!DtoUtils.isEmpty(setting.getId())) {
                dto.setId(setting.getId());
            }
            if (!DtoUtils.isEmpty(setting.getCustomer().getId())) {
                dto.setCustomerId(setting.getCustomer().getId());
            }
            if (!DtoUtils.isEmpty(setting.getCostOfDebt())) {
                dto.setCostOfDebt(setting.getCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getCountry().getId())) {
                dto.setCountryId(setting.getCountry().getId());
                dto.setCountryName(setting.getCountry().getName());
                dto.setCountryCode(setting.getCountry().getCode());
            }
            if (!DtoUtils.isEmpty(setting.getCashLiquidityEvent())) {
                dto.setCashLiquidityEvent(setting.getCashLiquidityEvent());
            }
            if (!DtoUtils.isEmpty(setting.getCashStressAsset())) {
                dto.setCashStressAsset(setting.getCashStressAsset());
            }
            if (!DtoUtils.isEmpty(setting.getAccuredLiquidityEvent())) {
                dto.setAccuredLiquidityEvent(setting.getAccuredLiquidityEvent());
            }
            if (!DtoUtils.isEmpty(setting.getSector().getId())) {
                dto.setSectorId(setting.getSector().getId());
                dto.setSectorName(setting.getSector().getName());
            }
            if (!DtoUtils.isEmpty(setting.getDependency().getId())) {
                dto.setDependentId(setting.getDependency().getId());
                dto.setDependentName(setting.getDependency().getName());
            }

            if (!DtoUtils.isEmpty(setting.getSwapAccuredDistributionRate())) {
                dto.setSwapAccuredDistributionRate(setting.getSwapAccuredDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getCostOfDebt())) {
                dto.setSwapCostOfDebt(setting.getCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getAccuredStressAsset())) {
                dto.setAccuredStressAsset(setting.getAccuredStressAsset());
            }
            if (!DtoUtils.isEmpty(setting.getSwapCashDistributionRate())) {
                dto.setSwapCashDistributionRate(setting.getSwapCashDistributionRate());
            }

            if (!DtoUtils.isEmpty(setting.getLeverageCostOfDebt())) {
                dto.setLeverageCostOfDebt(setting.getLeverageCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getLeverageCashDistributionRate())) {
                dto.setLeverageCashDistributionRate(setting.getLeverageCashDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getLeverageAccuredDistributionRate())) {
                dto.setLeverageAccuredDistributionRate(setting.getLeverageAccuredDistributionRate());
            }

            if (!DtoUtils.isEmpty(setting.getLiquidityCostOfDebt())) {
                dto.setLiquidityCostOfDebt(setting.getLiquidityCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getLiquidityCashDistributionRate())) {
                dto.setLiquidityCashDistributionRate(setting.getLiquidityCashDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getLiquidityAccuredDistributionRate())) {
                dto.setLiquidityAccuredDistributionRate(setting.getLiquidityAccuredDistributionRate());
            }
            if(setting.getClimateChangeExposure()!=null){
                dto.setClimateChangeExposure(ClimateChangeExposure.getString(setting.getClimateChangeExposure()));
            }

            List<ScenariosSettingLegalExposureDto> legalExposureDtos = new ArrayList<>();

            List<ScenarioLegalExposure> legalExposures = setting.getCountryOfLegalExposure();
            for (ScenarioLegalExposure exposure : legalExposures) {
                ScenariosSettingLegalExposureDto exposureDto = new ScenariosSettingLegalExposureDto();
                if (!DtoUtils.isEmpty(exposure.getCountry().getId())) {
                    exposureDto.setCountryId(exposure.getCountry().getId());
                    exposureDto.setCountryName(exposure.getCountry().getName());
                }
                legalExposureDtos.add(exposureDto);
            }
            if (!DtoUtils.isEmpty(legalExposureDtos)) {
                dto.setCountryOfLegalExposure(legalExposureDtos);
            }

            dtos.add(dto);
        }

        return dtos;
    }

    @Override
    public GenericResponse getByScenarioSettingsId(long id) {
        try {
            ScenarioSettings setting = scenarioSettingsRepository.findById(id).orElseThrow(() -> new RuntimeException("Please provide valid id"));
            ScenarioSettingsDto dto = new ScenarioSettingsDto();
            if (!DtoUtils.isEmpty(setting.getId())) {
                dto.setId(setting.getId());
            }
            if (!DtoUtils.isEmpty(setting.getCustomer().getId())) {
                dto.setCustomerId(setting.getCustomer().getId());
            }
            if (!DtoUtils.isEmpty(setting.getCostOfDebt())) {
                dto.setCostOfDebt(setting.getCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getCountry().getId())) {
                dto.setCountryId(setting.getCountry().getId());
                dto.setCountryName(setting.getCountry().getName());
                dto.setCountryCode(setting.getCountry().getCode());
            }
            if (!DtoUtils.isEmpty(setting.getCashLiquidityEvent())) {
                dto.setCashLiquidityEvent(setting.getCashLiquidityEvent());
            }
            if (!DtoUtils.isEmpty(setting.getCashStressAsset())) {
                dto.setCashStressAsset(setting.getCashStressAsset());
            }
            if (!DtoUtils.isEmpty(setting.getAccuredLiquidityEvent())) {
                dto.setAccuredLiquidityEvent(setting.getAccuredLiquidityEvent());
            }
            if (!DtoUtils.isEmpty(setting.getSector().getId())) {
                dto.setSectorId(setting.getSector().getId());
                dto.setSectorName(setting.getSector().getName());
            }
            if (!DtoUtils.isEmpty(setting.getDependency().getId())) {
                dto.setDependentId(setting.getDependency().getId());
                dto.setDependentName(setting.getDependency().getName());
            }

            if (!DtoUtils.isEmpty(setting.getSwapAccuredDistributionRate())) {
                dto.setSwapAccuredDistributionRate(setting.getSwapAccuredDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getCostOfDebt())) {
                dto.setSwapCostOfDebt(setting.getCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getAccuredStressAsset())) {
                dto.setAccuredStressAsset(setting.getAccuredStressAsset());
            }
            if (!DtoUtils.isEmpty(setting.getSwapCashDistributionRate())) {
                dto.setSwapCashDistributionRate(setting.getSwapCashDistributionRate());
            }

            if (!DtoUtils.isEmpty(setting.getLeverageCostOfDebt())) {
                dto.setLeverageCostOfDebt(setting.getLeverageCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getLeverageCashDistributionRate())) {
                dto.setLeverageCashDistributionRate(setting.getLeverageCashDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getLeverageAccuredDistributionRate())) {
                dto.setLeverageAccuredDistributionRate(setting.getLeverageAccuredDistributionRate());
            }

            if (!DtoUtils.isEmpty(setting.getLiquidityCostOfDebt())) {
                dto.setLiquidityCostOfDebt(setting.getLiquidityCostOfDebt());
            }
            if (!DtoUtils.isEmpty(setting.getLiquidityCashDistributionRate())) {
                dto.setLiquidityCashDistributionRate(setting.getLiquidityCashDistributionRate());
            }
            if (!DtoUtils.isEmpty(setting.getLiquidityAccuredDistributionRate())) {
                dto.setLiquidityAccuredDistributionRate(setting.getLiquidityAccuredDistributionRate());
            }
            if(setting.getClimateChangeExposure()!=null){
                dto.setClimateChangeExposure(ClimateChangeExposure.getString(setting.getClimateChangeExposure()));
            }

            List<ScenariosSettingLegalExposureDto> legalExposureDtos = new ArrayList<>();

            List<ScenarioLegalExposure> legalExposures = setting.getCountryOfLegalExposure();
            for (ScenarioLegalExposure exposure : legalExposures) {
                ScenariosSettingLegalExposureDto exposureDto = new ScenariosSettingLegalExposureDto();
                if (!DtoUtils.isEmpty(exposure.getCountry().getId())) {
                    exposureDto.setCountryId(exposure.getCountry().getId());
                    exposureDto.setCountryName(exposure.getCountry().getName());
                }
                legalExposureDtos.add(exposureDto);
            }
            if (!DtoUtils.isEmpty(legalExposureDtos)) {
                dto.setCountryOfLegalExposure(legalExposureDtos);
            }
            return new GenericResponse(HttpStatus.OK, dto);
        } catch (Exception e) {
            e.printStackTrace();
            return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide proper ScenarioSettings id");
        }
    }

    @Override
    public GenericResponse delete(Long id) {
        try {
            ScenarioSettings scenarioSettings = scenarioSettingsRepository.findById(id).orElseThrow(() -> new RuntimeException("Please provide valid id"));
            scenarioSettings.setIsDeleted(Boolean.TRUE);
            if (scenarioSettings.getId() != null) {
                scenarioLegalExposureRepository.isDeleteScenarioSettingsById(id);
            }
            return new GenericResponse(HttpStatus.OK, "DELETED SUCCESS");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new GenericResponse(HttpStatus.BAD_REQUEST, "Please provide proper ScenarioSettings id");
    }


    @Override
    public GenericResponse getScenarioSettingsByCustomer(Long customerId) {

            List<ScenarioSettings> settings = scenarioSettingsRepository.findScenarioSettingByCustomerId(customerId);

            if(settings.isEmpty()){
                return new GenericResponse(HttpStatus.BAD_REQUEST, "Please add scenario settings to view the graphs");
            }

            List<ScenarioSettingsDto> dtos = new ArrayList<>();
            for (ScenarioSettings setting : settings) {
                ScenarioSettingsDto dto = new ScenarioSettingsDto();

                if (!DtoUtils.isEmpty(setting.getId())) {
                    dto.setId(setting.getId());
                }
                if (!DtoUtils.isEmpty(setting.getCustomer().getId())) {
                    dto.setCustomerId(setting.getCustomer().getId());
                }
                if (!DtoUtils.isEmpty(setting.getCostOfDebt())) {
                    dto.setCostOfDebt(setting.getCostOfDebt());
                }
                if (!DtoUtils.isEmpty(setting.getCountry().getId())) {
                    dto.setCountryId(setting.getCountry().getId());
                    dto.setCountryName(setting.getCountry().getName());
                    dto.setCountryCode(setting.getCountry().getCode());

                }
                if (!DtoUtils.isEmpty(setting.getCashLiquidityEvent())) {
                    dto.setCashLiquidityEvent(setting.getCashLiquidityEvent());
                }
                if (!DtoUtils.isEmpty(setting.getCashStressAsset())) {
                    dto.setCashStressAsset(setting.getCashStressAsset());
                }
                if (!DtoUtils.isEmpty(setting.getAccuredLiquidityEvent())) {
                    dto.setAccuredLiquidityEvent(setting.getAccuredLiquidityEvent());
                }
                if (!DtoUtils.isEmpty(setting.getSector().getId())) {
                    dto.setSectorId(setting.getSector().getId());
                    dto.setSectorName(setting.getSector().getName());
                }
                if (!DtoUtils.isEmpty(setting.getDependency().getId())) {
                    dto.setDependentId(setting.getDependency().getId());
                    dto.setDependentName(setting.getDependency().getName());
                }
                if (!DtoUtils.isEmpty(setting.getSwapAccuredDistributionRate())) {
                    dto.setSwapAccuredDistributionRate(setting.getSwapAccuredDistributionRate());
                }
                if (!DtoUtils.isEmpty(setting.getCostOfDebt())) {
                    dto.setSwapCostOfDebt(setting.getCostOfDebt());
                }
                if (!DtoUtils.isEmpty(setting.getAccuredStressAsset())) {
                    dto.setAccuredStressAsset(setting.getAccuredStressAsset());
                }
                if (!DtoUtils.isEmpty(setting.getSwapCashDistributionRate())) {
                    dto.setSwapCashDistributionRate(setting.getSwapCashDistributionRate());
                }
                if (!DtoUtils.isEmpty(setting.getLeverageCostOfDebt())) {
                    dto.setLeverageCostOfDebt(setting.getLeverageCostOfDebt());
                }
                if (!DtoUtils.isEmpty(setting.getLeverageCashDistributionRate())) {
                    dto.setLeverageCashDistributionRate(setting.getLeverageCashDistributionRate());
                }
                if (!DtoUtils.isEmpty(setting.getLeverageAccuredDistributionRate())) {
                    dto.setLeverageAccuredDistributionRate(setting.getLeverageAccuredDistributionRate());
                }
                if (!DtoUtils.isEmpty(setting.getLiquidityCostOfDebt())) {
                    dto.setLiquidityCostOfDebt(setting.getLiquidityCostOfDebt());
                }
                if (!DtoUtils.isEmpty(setting.getLiquidityCashDistributionRate())) {
                    dto.setLiquidityCashDistributionRate(setting.getLiquidityCashDistributionRate());
                }
                if (!DtoUtils.isEmpty(setting.getLiquidityAccuredDistributionRate())) {
                    dto.setLiquidityAccuredDistributionRate(setting.getLiquidityAccuredDistributionRate());
                }
                if(setting.getClimateChangeExposure()!=null){
                    dto.setClimateChangeExposure(ClimateChangeExposure.getString(setting.getClimateChangeExposure()));
                }
                List<ScenariosSettingLegalExposureDto> legalExposureDtos = new ArrayList<>();
                List<ScenarioLegalExposure> legalExposures = setting.getCountryOfLegalExposure();
                for (ScenarioLegalExposure exposure : legalExposures) {
                    ScenariosSettingLegalExposureDto exposureDto = new ScenariosSettingLegalExposureDto();
                    if (!DtoUtils.isEmpty(exposure.getCountry().getId())) {
                        exposureDto.setCountryId(exposure.getCountry().getId());
                        exposureDto.setCountryName(exposure.getCountry().getName());
                    }
                    legalExposureDtos.add(exposureDto);
                }
                if (!DtoUtils.isEmpty(legalExposureDtos)) {
                    dto.setCountryOfLegalExposure(legalExposureDtos);
                }
                dtos.add(dto);
            }
            return new GenericResponse(HttpStatus.OK, dtos);
    }
}
