package com.wm.cockpit.repositary;

import com.wm.cockpit.entity.ExchangeRate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface ExchangeRateRepository extends JpaRepository<ExchangeRate , Long> {

    @Transactional
    @Modifying
    @Query(value ="UPDATE tr_exchange_rate a SET is_deleted = true WHERE is_deleted = false", nativeQuery = true)
    void disablePreviousExchangneRates();

    ExchangeRate findByCurrencyCode(String code);

    List<ExchangeRate> findByIsDeletedFalse();

}