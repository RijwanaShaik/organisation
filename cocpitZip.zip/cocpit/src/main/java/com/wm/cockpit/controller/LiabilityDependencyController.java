package com.wm.cockpit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wm.cockpit.dto.LiabilityDependencyDto;
import com.wm.cockpit.entity.LiabilityDependency;
import com.wm.cockpit.service.LiabilityDependencyService;

@Controller
@RequestMapping("/api/v1/liabilityDependency")
public class LiabilityDependencyController {

    @Autowired
    private LiabilityDependencyService liabilityDependencyService;

    @MutationMapping(name = "createLiabilityDependency")
    public String createLiabilityDependency(@Argument(name = "input") LiabilityDependencyDto liabilityDependencyDto) {
        return liabilityDependencyService.createLiabilityDependency(liabilityDependencyDto);
    }

    @QueryMapping(name = "getAllLiabilityDependency")
    public List<LiabilityDependency> getAllLiabilityDependency() {
        return liabilityDependencyService.getAllLiabilityDependency();
    }

}
