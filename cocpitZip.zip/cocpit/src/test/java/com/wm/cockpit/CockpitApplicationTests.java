package com.wm.cockpit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CockpitApplicationTests {

	@Test
	void contextLoads() {
	}

}
