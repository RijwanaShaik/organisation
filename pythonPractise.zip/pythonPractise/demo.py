

from calc import sum


def fun1():
  sum()
  print("print fun 1")

def fun2():
  print("print fun 2")

def demoMain():
  fun1()
  fun2()


demoMain()















# print("Hello "+__name__)
#
# def demoMethod():
#
#   print("Demo"+__name__)

# if __name__ ==  "__main__" :
#  demoMethod()