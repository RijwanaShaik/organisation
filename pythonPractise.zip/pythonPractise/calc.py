
def sum():
    print("sum is from" +__name__)

def substraction():
    print("substraction")

def calMain():
    sum()
    substraction()

if __name__ == "__main__":
 calMain()