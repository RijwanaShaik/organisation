class Father:
    fathername = ""

    def father(self):
        print(self.fathername)