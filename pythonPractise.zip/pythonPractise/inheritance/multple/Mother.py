class Mother:
    mothername = ""

    def mother(self):
        print(self.mothername)