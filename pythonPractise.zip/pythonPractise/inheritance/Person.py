class Person:

    def __init__(self,name,age):
        self.name=name
        self.age=age

    def display(self):
        print("Person name is " , self.name , "and age is " ,self.age)

p1 = Person("John",56)
p1.display()