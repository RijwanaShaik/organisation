from inheritance.Person import Person


class Employee(Person):

    def employee(self):

        print("Employee class is called")

emp=Employee("Nick",34)
emp.display()

emp.employee()
