class Car:
    #class or static variables
    wheels=4


 # instance variables
    def __init__(self):
        self.name="BMW"
        self.mil=5


c1=Car()
c2=Car()

c1.mil=6

Car.wheels=5

print(c1.name,c1.mil,c1.wheels)
print(c2.name,c2.mil,c2.wheels)