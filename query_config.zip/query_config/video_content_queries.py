# Method to query VideoContent by video_id, user_id, and is_active
from sqlalchemy import func

from main_config.database_config.database import get_db_session
from main_config.database_config.models import VideoContent
from sqlalchemy.orm import Session



def getVideoContent(video_id: str,db:Session):
    return db.query(VideoContent).filter(VideoContent.video_id == video_id,
                                         VideoContent.is_active == True).first()


# Method to query VideoContent by user_id and is_active with pagination and ordering
def getVideoContentForUserPagination(current_user_id: int, offset: int, limit: int,db:Session):
    return db.query(VideoContent).where(VideoContent.user_id == current_user_id,
                                        VideoContent.is_active == True, VideoContent.is_example == False).order_by(
        VideoContent.id.desc()).offset(offset).limit(limit).all()


def getVideoContentForUser(user_id: int, is_active: bool, is_example: bool,db:Session):
    return db.query(VideoContent).where(VideoContent.user_id == user_id, VideoContent.is_active == is_active,
                                        VideoContent.is_example == is_example).all()


# Method to query VideoContent by user_id and video_id
def getVideoContentForUserAndVideo(video_id: str, current_user_id: int,db:get_db_session):
    return db.query(VideoContent).where(VideoContent.video_id == video_id,
                                        VideoContent.user_id == current_user_id,VideoContent.is_example == False).first()


# Method to calculate the sum of tokens_utilized for a given user_id
def calculateSumOfTokensUtilized(user_id,db:Session):
    sum_of_tokens_utilized = db.query(func.sum(VideoContent.tokens_utilized)).filter(
        VideoContent.user_id == user_id).scalar()
    return sum_of_tokens_utilized or 0


def getVideoIdIsExample(video_id: str, is_example: bool,db:Session):
    return db.query(VideoContent).where(VideoContent.video_id == video_id,
                                        VideoContent.is_example == is_example).first()


def getVideoIsExample(video_id: str, current_user_id: int, is_example: bool,db:Session):
    return db.query(VideoContent).where(VideoContent.video_id == video_id, VideoContent.user_id == current_user_id,
                                        VideoContent.is_active == True, VideoContent.is_example == is_example).first()


def getVideosIsExampleTrue(db:Session):
    return db.query(VideoContent).where(VideoContent.is_example == True).all()


def getVideoIsExampleTrue(video_id:str,db:Session):
    return db.query(VideoContent).filter(VideoContent.video_id == video_id).where(VideoContent.is_example == True).first()


def getVideoById(video_id: str,db:Session):
    return db.query(VideoContent).where(VideoContent.video_id == video_id).first()


def getVideoByIsActiveIsExample( is_example: bool,db:Session):
    return db.query(VideoContent).where(
                                        VideoContent.is_example == is_example).all()
    
def getVideosOfAUser(user_id:int,db:Session):
    return db.query(VideoContent).filter(VideoContent.user_id == user_id, VideoContent.is_active == True).all()

def getExampleVidoes(db:Session):
     return db.query(VideoContent).where(VideoContent.is_example == True).all()