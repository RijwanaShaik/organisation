from main_config.database_config import models
from main_config.database_config.database import get_db_session
from sqlalchemy import func
from sqlalchemy.orm import Session


def findUserByUsername(email: str,db: Session):
    return db.query(models.AppUser).where(models.AppUser.email == email.lower(),models.AppUser.is_active == True).first()


def findUserById(user_id: int,db: Session):
    return db.query(models.AppUser).where(models.AppUser.id == user_id,models.AppUser.is_active == True).first()

