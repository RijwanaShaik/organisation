from sqlalchemy.exc import NoResultFound

from main_config.database_config.database import get_db_session
from main_config.database_config.models import AdminConfiguration
from sqlalchemy.orm import Session



def getAdminConfigurationByEmail(email: str,db:Session):
    try:
        return db.query(AdminConfiguration).filter(AdminConfiguration.admin_email == email).first()
    except NoResultFound:
        return None


def getAdmin(db:Session):
    return db.query(AdminConfiguration).first()
