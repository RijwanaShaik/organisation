# Method to query UserSearchResult by user_search_id and video_id
from sqlalchemy import func, desc

from main_config.database_config.database import get_db_session
from main_config.database_config.models import UserSearchResult
from sqlalchemy.orm import Session



def getUserSearchResultsForUserAndVideo(current_user_id: int, video_id: str,db:Session):
    return db.query(UserSearchResult).filter(UserSearchResult.user_search_id == current_user_id,
                                             UserSearchResult.video_id == video_id).all()


def filterUserSearchResults(current_user_id: int, video_id: str, user_query: str,db:Session):
    return db.query(UserSearchResult).filter(UserSearchResult.user_search_id == current_user_id,
                                             UserSearchResult.video_id == video_id,
                                             func.lower(UserSearchResult.query) == func.lower(user_query)).first()


def getUserSearchResultsForUserAndVideoOrderBy(current_user_id: int, video_id: str,db:Session):
    return db.query(UserSearchResult).filter(UserSearchResult.user_search_id == current_user_id,
                                             UserSearchResult.video_id == video_id).order_by(
        desc(UserSearchResult.updated_on)).all()


# Method to query UserSearchResult by user_search_id and video_id, ordered by updated_on descending
def getLatestUserSearchResult(current_user_id: int, video_id: str,db:Session):
    return db.query(UserSearchResult).filter(UserSearchResult.user_search_id == current_user_id,
                                             UserSearchResult.video_id == video_id).order_by(
        desc(UserSearchResult.updated_on)).all()


def getUserSearchResult(video_id: str,db:Session):
    return db.query(UserSearchResult).filter(UserSearchResult.video_id == video_id).all()


def getUserByUserSearch(current_user_id: int,video_id: str,db:Session):
    return db.query(UserSearchResult).filter(UserSearchResult.user_search_id == current_user_id,UserSearchResult.video_id == video_id).first()
