# Method to query TokenPurchase by user_id, created_on between from_date and to_date, and purchase_status
from main_config.database_config.database import get_db_session
from main_config.database_config.models import TokenPurchase
from sqlalchemy.orm import Session



def getTokenPurchasesUserStatus(user_id: int, from_date, to_date, status: str,db:Session):
    return db.query(TokenPurchase).filter(TokenPurchase.user_id == user_id, TokenPurchase.created_on.between(from_date, to_date), TokenPurchase.purchase_status == status.strip()).all()


# Method to query TokenPurchase by user_id and created_on between from_date and to_date
def getTokenPurchasesByUser(user_id: int, from_date, to_date,db:Session):
    return db.query(TokenPurchase).filter((TokenPurchase.user_id == user_id) & (TokenPurchase.created_on.between(from_date, to_date))).all()


# Method to query TokenPurchase by user_id or purchase_status
def getTokenPurchases(user_id: int, status: str,db:Session):
    return db.query(TokenPurchase).filter((TokenPurchase.user_id == user_id) |(TokenPurchase.purchase_status == status.strip())).all()

def getTransactionId(transaction_id:str,db:Session):
    return db.query(TokenPurchase).filter(TokenPurchase.transaction_id == transaction_id).first()
