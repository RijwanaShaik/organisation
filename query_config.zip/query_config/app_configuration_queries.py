# Method to query APPConfiguration by name
from main_config.database_config.database import get_db_session
from main_config.database_config.models import APPConfiguration
from sqlalchemy.orm import Session



def getAppConfigurationByName(name: str,db:Session):
    return db.query(APPConfiguration).filter(APPConfiguration.name == name).first()

