package org.example.delegation;
import org.example.getCertificate.Login;
import org.testng.annotations.Test;

import java.io.IOException;

public class DelegationTest {

    @Test
    public static void main(String[] args) throws InterruptedException, IOException {
        Login login = new Login();
        login.getTDISUrl();
        login.loginCredentials();

        Delegation delegation=new Delegation();
        delegation.enteringIntoUnderWriterAndInsurer();
        delegation.clickUnderwriter();
        delegation.selectUnderwriter();
        delegation.scrollUpTheWindowToDown();
        delegation.addDelegationButton();
        delegation.inceptionDate();
        delegation.expiryDate();
        delegation.limit();
        delegation.currencyList();
        delegation.delegationNumber();
        delegation.insuranceCompany();
        delegation.sharePercent();
        delegation.addMoreSecurity();
        delegation.signature();
        delegation.save();

    }
}
