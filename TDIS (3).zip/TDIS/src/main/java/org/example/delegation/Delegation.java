package org.example.delegation;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.getCertificate.Login;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

public class Delegation {
    public WebDriver driver;

    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    Row rows = null;
    Cell cell = null;

    List<WebElement> elementList=new ArrayList<>();
    String xpath=null;
    DataFormatter df=new DataFormatter();

    public void enteringIntoUnderWriterAndInsurer(){
        try{
            xpath="//img[@alt='Data Management']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//clickable on data management
            Thread.sleep(1000);
            xpath="//a[@routerlink='data-management/insurance-company']//span[@class='sidenav-image']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//clickable on underwriter and insurer module
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void clickUnderwriter(){
        try {
            xpath="//a[normalize-space()='Underwriters']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void selectUnderwriter(){
        try {
            FileInputStream inputStream = new FileInputStream("C:\\demo\\DelegationFile.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("DelegationFile");
            System.out.println("--selectUnderwriter--");
            rows = sheet.getRow(1);
            cell=rows.getCell(0);
            int row= Integer.parseInt(df.formatCellValue(cell));
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-underwriter-my-suffix/div/div/div[2]/table/tbody/tr[" + row+ "]/td[1]/a";
            Login.getDriver().findElement(By.xpath(xpath)).click();

            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void scrollUpTheWindowToDown(){
        try {
            JavascriptExecutor js1 = (JavascriptExecutor) Login.getDriver();
            Thread.sleep(2000);
            js1.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Thread.sleep(2000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void addDelegationButton(){
        try{
            System.out.println("--click on add delegation button--");
            xpath="//span[normalize-space()='Add Delegation']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void inceptionDate()  {
        try {
            System.out.println("--inception date--");
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-delegation-my-suffix-update/section/div[1]/div/form/div[2]/div[1]/div/div/my-date-picker/div/div/input";

            WebElement inceptionDate = Login.getDriver().findElement(By.xpath(xpath));
            inceptionDate.click();
            Thread.sleep(1000);
            rows=sheet.getRow(4);
            cell=rows.getCell(0);
            String startDate=df.formatCellValue(cell);
            inceptionDate.sendKeys(startDate);
            Thread.sleep(1000);

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void expiryDate() {
        try{
            System.out.println("--expiry date--");
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-delegation-my-suffix-update/section/div[1]/div/form/div[2]/div[2]/div/div/my-date-picker/div/div/input";

            WebElement expiryDate=Login.getDriver().findElement(By.xpath(xpath));
            expiryDate.click();
            Thread.sleep(1000);
            rows=sheet.getRow(4);
            cell=rows.getCell(2);
            String endDate=df.formatCellValue(cell);
            expiryDate.sendKeys(endDate);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void limit(){
        try{
            System.out.println("--add limit--");
            xpath="//input[@id='limit']";
            WebElement limit= Login.getDriver().findElement(By.xpath(xpath));
            limit.click();

            rows=sheet.getRow(7);
            cell=rows.getCell(0);
            String value=df.formatCellValue(cell);
            limit.sendKeys(value);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void currencyList(){
        try{
            System.out.println("--choose currency list--");
            WebElement currency=Login.getDriver().findElement(By.xpath("//span[contains(text(),'Select Currency')]"));
            currency.click();
            xpath="//*[@id=\"currency\"]/div/div[2]/ul[2]/li";
            elementList=Login.getDriver().findElements(By.xpath(xpath));
            rows=sheet.getRow(7);
            cell=rows.getCell(1);
            String currencyType=cell.getStringCellValue();
            Login.getDriver().findElement(By.xpath("//*[@id=\"currency\"]/div/div[2]/ul[1]/li/input")).sendKeys(currencyType);
            Thread.sleep(1000);
            Login.getDriver().findElement(By.xpath("//*[@id=\"currency\"]/div/div[2]/ul[2]/li/div")).click();

            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void delegationNumber(){
        try {
            System.out.println("--delegation number--");
            xpath="//input[@id='delegationNumber']";
            WebElement delegationNumber=Login.getDriver().findElement(By.xpath(xpath));
            delegationNumber.click();
            rows=sheet.getRow(7);
            cell=rows.getCell(2);
            String delegationNo=df.formatCellValue(cell);
            delegationNumber.sendKeys(delegationNo);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void insuranceCompany(){
        try{
            System.out.println("--choose insurance company--");
            xpath="(//*[@class='dropdown-btn'])[2]";
            WebElement selectPath=Login.getDriver().findElement(By.xpath(xpath));
            selectPath.click();
            Thread.sleep(1000);

            xpath="(//*[@placeholder='Search'])[2]";

            WebElement searchPath=Login.getDriver().findElement(By.xpath(xpath));
            rows=sheet.getRow(10);
            cell=rows.getCell(0);
            String company=cell.getStringCellValue();
            searchPath.sendKeys(company);
            Thread.sleep(1000);

            xpath="(//*[@class='item2'])[2]/li";

            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void sharePercent(){
        try {
            System.out.println("--give share percent--");
            xpath="//input[@id='share0']";
            WebElement sharePercent=Login.getDriver().findElement(By.xpath(xpath));
            sharePercent.click();
            rows=sheet.getRow(10);
            cell=rows.getCell(2);
            String share=df.formatCellValue(cell);
            sharePercent.sendKeys(share);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void insuranceCompanyOne(){
        try{
            System.out.println("--choose insurance company--");
            xpath="(//*[@class='dropdown-btn'])[3]";
            WebElement selectPath=Login.getDriver().findElement(By.xpath(xpath));
            selectPath.click();
            Thread.sleep(1000);

            xpath="(//*[@placeholder='Search'])[3]";

            WebElement searchPath=Login.getDriver().findElement(By.xpath(xpath));
            rows=sheet.getRow(13);
            cell=rows.getCell(0);
            String company=cell.getStringCellValue();
            searchPath.sendKeys(company);
            Thread.sleep(1000);

            xpath="(//*[@class='item2'])[3]/li";

            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void sharePercentOne(){
        try {
            System.out.println("--give share percent--");
            xpath="(//input[@id='share1'])[1]";
            WebElement sharePercent=Login.getDriver().findElement(By.xpath(xpath));
            sharePercent.click();
            rows=sheet.getRow(13);
            cell=rows.getCell(2);
            String share=df.formatCellValue(cell);
            sharePercent.clear();
            sharePercent.sendKeys(share+"0000");
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void insuranceCompanyTwo(){
        try{
            System.out.println("--choose insurance company--");
            xpath="(//*[@class='dropdown-btn'])[4]";
            WebElement selectPath=Login.getDriver().findElement(By.xpath(xpath));
            selectPath.click();
            Thread.sleep(1000);

            xpath="(//*[@placeholder='Search'])[4]";

            WebElement searchPath=Login.getDriver().findElement(By.xpath(xpath));
            rows=sheet.getRow(14);
            cell=rows.getCell(0);
            String company=cell.getStringCellValue();
            searchPath.sendKeys(company);
            Thread.sleep(1000);

            xpath="(//*[@class='item2'])[4]/li";

            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void sharePercentTwo(){
        try {
            System.out.println("--give share percent--");
            xpath="(//input[@id='share2'])[1]";
            WebElement sharePercent=Login.getDriver().findElement(By.xpath(xpath));
            sharePercent.click();
            rows=sheet.getRow(14);
            cell=rows.getCell(2);
            String share=df.formatCellValue(cell);
            sharePercent.clear();
            sharePercent.sendKeys(share+"0000");
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void insuranceCompanyThree(){
        try{
            System.out.println("--choose insurance company--");
            xpath="(//*[@class='dropdown-btn'])[5]";
            WebElement selectPath=Login.getDriver().findElement(By.xpath(xpath));
            selectPath.click();
            Thread.sleep(1000);

            xpath="(//*[@placeholder='Search'])[5]";

            WebElement searchPath=Login.getDriver().findElement(By.xpath(xpath));
            rows=sheet.getRow(15);
            cell=rows.getCell(0);
            String company=cell.getStringCellValue();
            searchPath.sendKeys(company);
            Thread.sleep(1000);

            xpath="(//*[@class='item2'])[5]/li";

            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void sharePercentThree(){
        try {
            System.out.println("--give share percent--");
            xpath="(//input[@id='share3'])[1]";
            WebElement sharePercent=Login.getDriver().findElement(By.xpath(xpath));
            sharePercent.click();
            rows=sheet.getRow(15);
            cell=rows.getCell(2);
            String share=df.formatCellValue(cell);
            sharePercent.clear();
            sharePercent.sendKeys(share+"0000");
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void addMoreSecurity(){//add button
        try {
            rows=sheet.getRow(1);
            cell=rows.getCell(2);
            int row= Integer.parseInt(df.formatCellValue(cell));
            for(int i=1;i<=row;i++) {
                xpath = "//fa-icon[@ng-reflect-icon-prop='plus']//*[name()='svg']";
                WebElement addButton = Login.getDriver().findElement(By.xpath(xpath));
                addButton.click();
            }
            xpath="(//*[@class='dropdown-btn'])[3]";
            WebElement selectPath=Login.getDriver().findElement(By.xpath(xpath));
            if(selectPath.isDisplayed()) {
                insuranceCompanyOne();
                sharePercentOne();
            }
            xpath="(//*[@class='dropdown-btn'])[4]";
            WebElement selectPath1=Login.getDriver().findElement(By.xpath(xpath));
            if(selectPath1.isDisplayed()){
                insuranceCompanyTwo();
                sharePercentTwo();

            }
            xpath="(//*[@class='dropdown-btn'])[5]";
            WebElement selectPath2=Login.getDriver().findElement(By.xpath(xpath));
            if(selectPath2.isDisplayed()){
                insuranceCompanyThree();
                sharePercentThree();

            }

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void signature(){
        try {
            rows=sheet.getRow(17);
            cell=rows.getCell(0);
            String filePath=cell.getStringCellValue();
            xpath="//a[contains(text(),'Upload')]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            StringSelection ss = new StringSelection(filePath);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

            Robot robot = new Robot();
            robot.delay(250);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.delay(90);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.delay(90);
            robot.keyRelease(KeyEvent.VK_ENTER);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void save(){
        try {
            xpath="//*[@id=\"save-entity\"]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
