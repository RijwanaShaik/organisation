package org.example.getCertificate;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

public class GetCertificate {
    public WebDriver driver;
    XSSFWorkbook workbook = null;
    static Row rows = null;
    static Cell cell = null;
    String xpath = null;

    public void pageEnterIntoGetCertificate() throws InterruptedException {
        xpath = "//*[@id=\"field_PolicyManagement\"]";
        Login.getDriver().findElement(By.xpath(xpath)).click();
        Thread.sleep(1000);
        xpath = "//*[@id=\"navbarResponsive\"]/ul/li[4]/ul/li[4]/a/span[2]";
        Login.getDriver().findElement(By.xpath(xpath)).click();
        Login.getDriver().manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
        Thread.sleep(1000);
    }


    public void getCertificateCilck() throws InterruptedException {
        xpath = "//*[@id=\"jh-create-entity\"]/span";
        Login.getDriver().findElement(By.xpath(xpath)).click();
        Thread.sleep(1000);
    }

    public void selectUser() {
        try {
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            XSSFSheet sheet = workbook.getSheet("GetCertificate");
            rows = sheet.getRow(1);
            cell = rows.getCell(2);

            DataFormatter formatter = new DataFormatter();
            int clientNo = Integer.parseInt(formatter.formatCellValue(cell));
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-broker-get-certificate/div/div[2]/table/tbody/tr[" + clientNo + "]/td[5]/div/button/span")).click();


        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
