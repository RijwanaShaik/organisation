package org.example.getCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.IOException;

public class WebDriverSetup {

    @Test
    public static void main(String[] args) throws IOException, InterruptedException {
        Login login = new Login();
        login.getTDISUrl();
        login.loginCredentials();
        GetCertificate gc=new GetCertificate();


        FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        XSSFSheet sheet = workbook.getSheet("GetCertificate");
        Row rows = sheet.getRow(1);// put row number of your packing type no from excel
        Cell cell = rows.getCell(0);

        DataFormatter formatter=new DataFormatter();
        int noOfCertificates = Integer.parseInt(formatter.formatCellValue(cell));

        for(int i=1;i<=noOfCertificates;i++) {
            gc.pageEnterIntoGetCertificate();
            gc.getCertificateCilck();
            gc.selectUser();
            TradeDetails td = new TradeDetails();

            td.traderDetailsFilling();

            ShippingDetails sd = new ShippingDetails();
            sd.meansOfConveyance();

            CargoDetails cd = new CargoDetails();
            cd.chooseCargo();
            cd.loadingType();
            cd.subType();
            cd.cargoValue();
            cd.scrollUpWindow();
            cd.next();
            SummaryDetails sm = new SummaryDetails();
            sm.clickOnContinue();
            sm.cancelPopUP();
            sm.addSurveyorDetails();
            sm.additionalPremium();
            sm.tickOnCheckBoxes();
            sm.noOfCopies();
            sm.downloadAndViewCertificate();
        }
    }
}