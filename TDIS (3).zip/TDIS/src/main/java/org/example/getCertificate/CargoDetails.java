package org.example.getCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.io.FileInputStream;

public class CargoDetails {
    public WebDriver driver;
    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;

    Row rows = null;
    Cell cell = null;
    String xpath=null;

    public void chooseCargo(){
        try{
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("GetCertificate");
            xpath = "//ng-multiselect-dropdown[@name='cargoObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            System.out.println("---cargo's list enter into excel--");

            rows = sheet.getRow(13);
            cell = rows.getCell(0);
            String cargo = cell.getStringCellValue();
            //cargos
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement cargoSearch = Login.getDriver().findElement(By.xpath(xpath));
            cargoSearch.click();
            cargoSearch.sendKeys(cargo);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            System.out.println("---cargo is entered---");


        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void loadingType(){
        try{
            //loadingType
            System.out.println("Choose loading type");
            //loading type list
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();//click on search box
            Thread.sleep(1000);
            rows = sheet.getRow(13);
            cell = rows.getCell(1);
            String loadType = cell.getStringCellValue();

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement loadingType = Login.getDriver().findElement(By.xpath(xpath));
            loadingType.sendKeys(loadType);
            Thread.sleep(1000);
            if(loadType.equalsIgnoreCase("Machines")) {
                xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[2]/div";
                Login.getDriver().findElement(By.xpath(xpath)).click();
            }else {
                xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[2]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
                Login.getDriver().findElement(By.xpath(xpath)).click();
            }

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void subType() throws InterruptedException {
        try{
            //subType
            System.out.println("Choose sub type");
            xpath="//ng-multiselect-dropdown[@name='subTypeObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']";

            Login.getDriver().findElement(By.xpath(xpath)).click();//click on search box
            Thread.sleep(1000);

            System.out.println("---subtype---");
            rows = sheet.getRow(13);
            cell = rows.getCell(2);
            String loadSubtype = cell.getStringCellValue();
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement subType = Login.getDriver().findElement(By.xpath(xpath));
            subType.sendKeys(loadSubtype);
            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[3]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            Login.getDriver().findElement(By.xpath(xpath)).click(); //subtype
            Thread.sleep(1000);

            //packing type
            System.out.println("Choose packing type");

            xpath="//ng-multiselect-dropdown[@name='packingTypeObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//click on search box

            Thread.sleep(1000);

            System.out.println("---packingtype----");

            xpath="//ng-multiselect-dropdown[@name='packingTypeObj']//input[@placeholder='Search']";
            WebElement packingType = Login.getDriver().findElement(By.xpath(xpath));
            rows = sheet.getRow(13);
            cell = rows.getCell(3);
            String packType = cell.getStringCellValue();
            packingType.sendKeys(packType);
            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[1]/div[1]/div[4]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[1]/div";
            Login.getDriver().findElement(By.xpath(xpath)).click(); //packing type
            Thread.sleep(1000);

        }catch (Exception e){
            System.out.println("Choose packing type");

            xpath="//ng-multiselect-dropdown[@name='packingTypeObj']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//click on search box

            Thread.sleep(1000);

            System.out.println("---packingtype----");

            xpath="//ng-multiselect-dropdown[@name='packingTypeObj']//input[@placeholder='Search']";
            WebElement packingType = Login.getDriver().findElement(By.xpath(xpath));
            rows = sheet.getRow(13);
            cell = rows.getCell(3);
            String packType = cell.getStringCellValue();
            packingType.sendKeys(packType);
            Thread.sleep(1000);
            xpath="(//*[@class='item2'])[3]/li[1]";
            Login.getDriver().findElement(By.xpath(xpath)).click(); //packing type
            Thread.sleep(1000);
            System.out.println(e.getMessage());
        }
    }

    public void cargoValue(){
        try{
            //cargo value
            System.out.println("Enter cargo value");
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-cargo-details/section/form/article[2]/div/article/div[2]/div[1]/div/div/div[1]/input";
            WebElement cargoValue = Login.getDriver().findElement(By.xpath(xpath)); //cargo value

            rows = sheet.getRow(13);
            cell = rows.getCell(4);

            DataFormatter formatter=new DataFormatter();
            String cargoAmount = formatter.formatCellValue(cell);
            cargoValue.sendKeys(cargoAmount);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void scrollUpWindow(){
        try{
            JavascriptExecutor js1 = (JavascriptExecutor) Login.getDriver();
            Thread.sleep(2000);
            js1.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Thread.sleep(2000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void next(){
        try{
            xpath="//button[normalize-space()='Next']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//clicked next button and entered into shipping details
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
