package org.example.getCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;

public class Login {
 public static WebDriver driver;
    XSSFSheet sheet=null;
    XSSFRow row = null;
    Cell cell = null;
    public static WebDriver getDriver() {
        return driver;
    }
    public void getTDISUrl() {
        System.setProperty("webdriver.chrome.driver", "/home/thrymr123/Desktop/chromedriver");

         driver = new ChromeDriver();
        driver.get("https://qa.tdis-marine.com/login");

        driver.manage().window().maximize();
    }
    public void loginCredentials() throws InterruptedException {

        WebElement usernameField=driver.findElement(By.id("username"));
        WebElement passwordField=driver.findElement(By.id("password"));
        usernameField.sendKeys("Adam@mailinator.com");
        passwordField.sendKeys("Adam@123");
        WebElement loginButton=driver.findElement(By.xpath("//*[text()='Login']"));;
        loginButton.click();

        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        Thread.sleep(2000);
    }
    public void loginCredentialsOfAdmin() throws InterruptedException {

        WebElement usernameField=driver.findElement(By.id("username"));
        WebElement passwordField=driver.findElement(By.id("password"));
        usernameField.sendKeys("info@tdis.net");
        passwordField.sendKeys("admin");
        WebElement loginButton=driver.findElement(By.xpath("//*[text()='Login']"));;
        loginButton.click();

        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        Thread.sleep(2000);
    }
}
