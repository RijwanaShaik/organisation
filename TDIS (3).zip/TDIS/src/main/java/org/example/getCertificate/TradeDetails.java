package org.example.getCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.io.FileInputStream;

public class TradeDetails {
    public WebDriver driver;
    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    Row rows = null;
    Cell cell = null;
    String xpath=null;
    DataFormatter formatter=new DataFormatter();


    public void traderDetailsFilling(){
        try{

            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("GetCertificate");
            rows=sheet.getRow(1);
            cell=rows.getCell(4);
            String text=cell.getStringCellValue();
            if(text.equalsIgnoreCase("trader")){
                trader();
            }else {
                freightForwarder();
                freightForwarder();
                rows = sheet.getRow(21);
                cell = rows.getCell(1);
                String product=cell.getStringCellValue();
                if(product.equalsIgnoreCase("Sellers interest")||product.equalsIgnoreCase("Buyers interest")){
                    iam();
                    incoterm();
                    xpath="//button[normalize-space()='Continue to Shipping Details']";
                    Login.getDriver().findElement(By.xpath(xpath)).click();
                }
            }

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void trader(){
        try{
            iam();
            incoterm();
            next();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void iam(){
        try{
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("GetCertificate");

            System.out.println("--select seller or buyer");
            xpath = "//select[@name='clientType']";
            WebElement select = Login.getDriver().findElement(By.xpath(xpath));
            select.click();

            rows = sheet.getRow(3);
            cell = rows.getCell(0);
            String iam = cell.getStringCellValue();
            select.sendKeys(iam);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void incoterm(){
        try{
            System.out.println("--select incoterm--");
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-trader-details/section/form/article[2]/div/article/div[1]/div[2]/div/select";
            WebElement incoterms = Login.getDriver().findElement(By.xpath(xpath));
            incoterms.click();

            rows=sheet.getRow(3);
            cell = rows.getCell(1);
            String incoterm = cell.getStringCellValue();
            incoterms.sendKeys(incoterm);

            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }


    /////-------------freight forwarder------------/////
    public void freightForwarder(){
        addCertificate();
        clientName();
        product();
        internalReference();
        policyHolderReferenceNo();
        next();
    }
    public void addCertificate(){
        try{
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("FrieghtForwarder");
            Login.getDriver().findElement(By.xpath("//button[normalize-space()='Add Certificate Client']")).click();
            xpath="//*[@id=\"field_activeStatus\"]";
            WebElement TypeOfClient=Login.getDriver().findElement(By.xpath(xpath));
            TypeOfClient.click();
            Thread.sleep(1000);

            rows = sheet.getRow(1);
            cell = rows.getCell(0);
            String iam = cell.getStringCellValue();
            TypeOfClient.sendKeys(iam);

            try {
                //company name
                xpath = "//*[@id=\"field_name\"]";
                rows = sheet.getRow(4);
                cell = rows.getCell(0);
                String companyName = cell.getStringCellValue();
                Login.getDriver().findElement(By.xpath(xpath)).sendKeys(companyName);
                Thread.sleep(1000);
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            try {
                //contact person
                xpath = "//*[@id=\"field_contactPerson\"]";
                rows = sheet.getRow(7);
                cell = rows.getCell(0);
                String contactPerson = cell.getStringCellValue();
                Login.getDriver().findElement(By.xpath(xpath)).sendKeys(contactPerson);
                Thread.sleep(1000);
            }catch (Exception e){
                System.out.println(e.getMessage());
            }

            try {
                //contact email
                xpath = "//*[@id=\"field_email\"]";
                rows = sheet.getRow(10);
                cell = rows.getCell(0);
                String contactEmail = cell.getStringCellValue();
                Login.getDriver().findElement(By.xpath(xpath)).sendKeys(contactEmail);
                Thread.sleep(1000);
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            try{
                //contact number select country
                xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/div[3]/div[1]/ng-multiselect-dropdown/div/div[1]/span";
                Login.getDriver().findElement(By.xpath(xpath)).click();
                Thread.sleep(1000);

                rows = sheet.getRow(14);
                cell = rows.getCell(0);
                String contactNumber = cell.getStringCellValue();
                xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/div[3]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
                Login.getDriver().findElement(By.xpath(xpath)).sendKeys(contactNumber);
                if(contactNumber.equalsIgnoreCase("india")) {
                    Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/div[3]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li[2]/div")).click();
                }else {
                    Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/div[3]/div[1]/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();

                }
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            try{
                //contact number
                rows = sheet.getRow(14);
                cell = rows.getCell(1);String number = formatter.formatCellValue(cell);

                Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/div[3]/div[2]/div/input")).sendKeys(number);
                Thread.sleep(1000);
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            try {
                //address-street address
                rows = sheet.getRow(17);
                cell = rows.getCell(0);
                String address = cell.getStringCellValue();
                Login.getDriver().findElement(By.xpath("//*[@id=\"field_streetAddress\"]")).sendKeys(address);
                Thread.sleep(1000);
            }
            catch (Exception e){
                System.out.println(e.getMessage());
            }
            try {
                //city
                rows = sheet.getRow(17);
                cell = rows.getCell(1);
                String city = formatter.formatCellValue(cell);
                Login.getDriver().findElement(By.xpath("//*[@id=\"field_city\"]")).sendKeys(city);
                Thread.sleep(1000);
            }catch (Exception e){
                System.out.println(e.getMessage());
            }

            try {
                //select country
                Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/article/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[1]/span/span[1]")).click();

                rows = sheet.getRow(17);
                cell = rows.getCell(2);
                String country = cell.getStringCellValue();
                Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/article/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input")).sendKeys(country);
                if (country.equalsIgnoreCase("india")) {
                    Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/article/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li[2]/div")).click();
                } else {
                    Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-client-update/section/div/div/form/div[1]/article/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
                }
                Thread.sleep(1000);
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            try {
                //postal code
                rows = sheet.getRow(17);
                cell = rows.getCell(3);
                String postalCode = formatter.formatCellValue(cell);
                Login.getDriver().findElement(By.xpath("//*[@id=\"field_postalCode\"]")).sendKeys(postalCode);
                Thread.sleep(1000);
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            try {
                Login.getDriver().findElement(By.xpath("//*[@id=\"save-entity\"]/span")).submit();
                Thread.sleep(1000);
            }catch (Exception e){
                System.out.println(e.getMessage());
            }

            try {
                xpath = "(//*[@class='btn btn-primary button-right'])[2]";
                Login.getDriver().findElement(By.xpath(xpath)).click();
                Thread.sleep(1000);
            }catch (Exception e){
                e.getMessage();
            }
            inputStream.close();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void clientName(){
        try {
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("FrieghtForwarder");
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-trade-details/section/form/article[2]/div/article/div[1]/div[1]/div/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();

            rows = sheet.getRow(21);
            cell = rows.getCell(0);
            String clientName=cell.getStringCellValue();
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-trade-details/section/form/article[2]/div/article/div[1]/div[1]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            Login.getDriver().findElement(By.xpath(xpath)).sendKeys(clientName);
            Thread.sleep(1000);
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-trade-details/section/form/article[2]/div/article/div[1]/div[1]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            inputStream.close();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void product(){
        try {
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("FrieghtForwarder");
            rows = sheet.getRow(21);
            cell = rows.getCell(1);
            String product=cell.getStringCellValue();
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-trade-details/section/form/article[2]/div/article/div[2]/div[1]/div/select";
            Login.getDriver().findElement(By.xpath(xpath)).sendKeys(product);
            Thread.sleep(1000);
            inputStream.close();

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public  void internalReference(){
        try {
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("FrieghtForwarder");
            rows = sheet.getRow(24);
            cell = rows.getCell(0);
            DataFormatter formatter=new DataFormatter();
            String internalReference=formatter.formatCellValue(cell);
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-trade-details/section/form/article[2]/div/article/div[2]/div[2]/div/input";
            Login.getDriver().findElement(By.xpath(xpath)).sendKeys(internalReference);
            Thread.sleep(1000);
            inputStream.close();

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public  void policyHolderReferenceNo(){
        try {
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("FrieghtForwarder");
            rows = sheet.getRow(24);
            cell = rows.getCell(2);
            DataFormatter formatter=new DataFormatter();
            String ref=formatter.formatCellValue(cell);
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-trade-details/section/form/article[2]/div/article/div[3]/div[2]/div/input";
            Login.getDriver().findElement(By.xpath(xpath)).sendKeys(ref);
            Thread.sleep(1000);
            inputStream.close();

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void next(){
        try{
            xpath="//button[normalize-space()='Next']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//clicked next button and entered into shipping details
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
