package org.example.vesselScreeening;

import org.example.getCertificate.Login;
import org.testng.annotations.Test;


public class VesselScreening {

    @Test
    public static void main(String[] args) throws  InterruptedException {

        Login login=new Login();
        login.getTDISUrl();
        login.loginCredentials();
        TestVessel testVessel=new TestVessel();
        testVessel.getIntoVesselScreeningpage();
        testVessel.enterVesselNoOrVesselName();
        testVessel.selectPolicyHolders();
        testVessel.selectProduct();
        testVessel.selectLoadingType();
        testVessel.submitButton();
        testVessel.backToVesselScreeningPage();
    }
}
