package org.example.vesselScreeening;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.getCertificate.Login;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TestVessel {

    public WebDriver driver;
    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    Row rows = null;
    Cell cell = null;
    String xpath=null;
    DataFormatter df=new DataFormatter();
    public void getIntoVesselScreeningpage() throws InterruptedException {
        try {
            xpath="//*[@id=\"field_PolicyManagement\"]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            xpath="//span[contains(text(),'Vessel Screening')]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void enterVesselNoOrVesselName() {
        try{
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening-my-suffix/section";
            if( Login.getDriver().findElement(By.xpath(xpath)).isDisplayed()) {
                Thread.sleep(1000);
                xpath="//span[normalize-space()='Screen Vessel']";
                Login.getDriver().findElement(By.xpath(xpath)).click();
                Thread.sleep(1000);


                FileInputStream inputStream = new FileInputStream("C:\\demo\\VesselScreening.xlsx");

                workbook = new XSSFWorkbook(inputStream);
                sheet = workbook.getSheet("VesselScreening");

                xpath="//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[1]/div[2]/input";
                WebElement vesselName = Login.getDriver().findElement(By.xpath(xpath));
                vesselName.click();
                Thread.sleep(1000);
                rows=sheet.getRow(2);
                cell = rows.getCell(0);

                String vesselNo = df.formatCellValue(cell);
                vesselName.sendKeys(vesselNo);//1000241or1000069


            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void selectPolicyHolders() {
        try{
            xpath="//ng-multiselect-dropdown[@name='client']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']";
            WebElement select=Login.getDriver().findElement(By.xpath(xpath));
            select.click();
            Thread.sleep(1000);
            rows=sheet.getRow(2);
            cell=rows.getCell(1);
            String holderName= cell.getStringCellValue();
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[2]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            Login.getDriver().findElement(By.xpath(xpath)).sendKeys(holderName);
            Thread.sleep(1000);
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[2]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            select.click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void selectProduct()  {
        try {
            //product
            WebElement product = Login.getDriver().findElement(By.xpath("//select[@placeholder='Select product']"));
            product.click();
            rows = sheet.getRow(5);
            cell = rows.getCell(0);
            String productType = cell.getStringCellValue();
            Thread.sleep(1000);
            product.sendKeys(productType);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    public void selectLoadingType() {
        try {
            WebElement loadingType = Login.getDriver().findElement(By.xpath("//ng-multiselect-dropdown[@name='loadingTypeObjName']//div[@class='multiselect-dropdown']//div//span[@class='dropdown-btn']"));
            loadingType.click();
            WebElement selectLT = Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[4]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input"));
            selectLT.click();
            rows = sheet.getRow(5);
            cell = rows.getCell(1);
            String selectLoading = cell.getStringCellValue();
            selectLT.sendKeys(selectLoading);
            Thread.sleep(1000);
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[1]/div[4]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void submitButton(){
        try {
            WebElement submit=Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[3]/div[2]/button"));
            submit.click();
            WebElement details=Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div[2]"));
            if(details.isDisplayed()){
                System.out.println("Test has been passed");
            }else {
                System.out.println("Test failed");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void backToVesselScreeningPage(){
        Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-vessel-screening/section/div/div/form/article/div/div[3]/div[1]/button")).click();
    }
}
