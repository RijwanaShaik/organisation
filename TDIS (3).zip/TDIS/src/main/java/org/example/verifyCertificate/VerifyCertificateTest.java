package org.example.verifyCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.getCertificate.GetCertificate;
import org.example.getCertificate.Login;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.IOException;

public class VerifyCertificateTest {
    public WebDriver driver;
    XSSFWorkbook workbook = null;
    XSSFSheet sheet = null;
    XSSFRow row = null;
    static Row rows = null;
    static Cell cell = null;
    String xpath = null;

     static DataFormatter formatter=new DataFormatter();
    public void selectCertificate(int rowNo){
        try {
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-my-certificate/section[2]/div/article/div[1]/div/div/table/tbody/tr[" + rowNo+ "]/td[1]/a";
          WebElement certificateNo= Login.getDriver().findElement(By.xpath(xpath));
            JavascriptExecutor js = (JavascriptExecutor) Login.getDriver();
            Thread.sleep(2000);
            // Scrolling down the page to bottom of the page
            js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
            Thread.sleep(1000);
            certificateNo.click();
        }catch (Exception e){

        }
    }
    public void reviseCertificate(){
        try {
            xpath="//button[@id='button-basic']";//add button
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            xpath="//a[normalize-space()='Revise Certificate']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            //pop-up
            //xpath="//*[@class='btn btn-danger']";
            xpath="//div[@class='modal fade material-custom-modal in show']//span[contains(text(),'Continue')]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    @Test
    public static void main(String[] args) throws InterruptedException, IOException {
        Login login = new Login();
        login.getTDISUrl();
        login.loginCredentials();
        FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        XSSFSheet sheet = workbook.getSheet("GetCertificate");
        GetCertificate gc=new GetCertificate();
        VerifyCertificateTest vc=new VerifyCertificateTest();
        try {

            //---------verify certificate---------//
            rows = sheet.getRow(24);
            cell = rows.getCell(0);
            String verify = cell.getStringCellValue();
            rows = sheet.getRow(27);
            cell = rows.getCell(0);
            int certificateRow = Integer.parseInt(formatter.formatCellValue(cell));
            if (verify.equalsIgnoreCase("yes") && certificateRow != 0) {

                //verifiy steps
                gc.pageEnterIntoGetCertificate();

                //mycerificate click
                vc.selectCertificate(certificateRow);

                //sumarry page action click on revise certificate
                vc.reviseCertificate();

                //repeat get certificate step from trader to end
                TradeDetails td = new TradeDetails();

                td.traderDetailsFilling();

                ShippingDetails sd = new ShippingDetails();
                sd.meansOfConveyance();
             CargoDetails cd = new CargoDetails();
                cd.chooseCargo();
                cd.loadingType();
                cd.subType();
                cd.cargoValue();
                cd.scrollUpWindow();
                cd.next();
                SummaryDetails sm = new SummaryDetails();
                sm.clickOnContinue();
                sm.cancelPopUP();
                sm.addSurveyorDetails();
                sm.additionalPremium();
                sm.tickOnCheckBoxes();
                sm.noOfCopies();
                sm.downloadAndViewCertificate();
            } else {
                System.out.println("verify certificate is chosen : "+verify+ " and row of certificate no given is : " + certificateRow);
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
