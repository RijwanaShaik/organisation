package org.example.verifyCertificate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.getCertificate.Login;
import org.openqa.selenium.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ShippingDetails {
    public WebDriver driver;

    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    Row rows = null;
    Cell cell = null;
    int rowNo=0;
    String xpath=null;


    public void meansOfConveyance() throws InterruptedException {
        try {

            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("GetCertificate");
            System.out.println("--select your mode of transport--");
            rows=sheet.getRow(9);
            cell = rows.getCell(0);
            String transportBy = cell.getStringCellValue();

            System.out.println("successfully enter the mode of transport");
            if(transportBy.equalsIgnoreCase("Air")||transportBy.equalsIgnoreCase("Rail")){
                   placeOfOrigin();
                   fromStation();
                   toStation();
                   placeOfDestination();
                   shipmentDate();
                   scrollUpWindow();
                   next();
            }

            else if(transportBy.equalsIgnoreCase("Road")){
               fromRoad();
               toRoad();
               shipmentDateOfRoad();
               scrollUpWindow();
                next();
            }
           else if(transportBy.equalsIgnoreCase("Vessel")){
                vesselImoOrName();
                  vesselVoyageNo();
                  placeOfOriginOfVessel();
                  fromPort();
                  toPort();
                  placeOfFinalDestinationOfVessel();
                  shipmentDateOfVessel();
                  scrollUpWindow();
                  next();
                  vesselNamePopUp();
            }

        }catch (Exception e){

            System.out.println(e.getMessage());
        }
    }
    public void vesselImoOrName(){
        try {
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[1]/div[2]/div[2]/input";
            WebElement vesselInfo= Login.getDriver().findElement(By.xpath(xpath));
            vesselInfo.clear();
            vesselInfo.click();
            xpath="//input[@id='vesselImo']";
            WebElement vesselImo= Login.getDriver().findElement(By.xpath(xpath));
            xpath="//input[@id='vesselName']";
            WebElement vesselName=Login.getDriver().findElement(By.xpath(xpath));
            if(vesselImo.isSelected()) {
                rows = sheet.getRow(6); // put row number of your vessel no from excel

                cell = rows.getCell(0);
            }
            else if(vesselName.isSelected()) {
                rows = sheet.getRow(6); // put row number of your vessel no from excel

                cell = rows.getCell(1);
            }
            DataFormatter formatter=new DataFormatter();

            String origin = formatter.formatCellValue(cell);
            vesselInfo.sendKeys(origin);
            Thread.sleep(2000);

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void vesselVoyageNo(){
        try {
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[1]/div[3]/div/input";
            WebElement vesselVoyageNo= Login.getDriver().findElement(By.xpath(xpath));
            vesselVoyageNo.clear();
            vesselVoyageNo.click();
             rows = sheet.getRow(6); // put row number of your vessel no from excel

            cell = rows.getCell(2);
            DataFormatter formatter=new DataFormatter();

            String origin = formatter.formatCellValue(cell);
            vesselVoyageNo.sendKeys(origin);
            Thread.sleep(2000);

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void placeOfOriginOfVessel()  {
        try {
            xpath="//input[@name='placeOfOrigin']";
            WebElement placeOfOrigin =Login.getDriver().findElement(By.xpath(xpath));
            placeOfOrigin.click();
            rows = sheet.getRow(6);

            cell = rows.getCell(4);

            String origin = cell.getStringCellValue();

            placeOfOrigin.sendKeys(origin);
            Thread.sleep(1000);
            placeOfOrigin.sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(1000);
            placeOfOrigin.sendKeys(Keys.ENTER);
        }catch (Exception e){
            try {
                xpath = "(//*[name()='svg'][@class='svg-inline--fa fa-times fa-w-12'])[1]";
                Login.getDriver().findElement(By.xpath(xpath)).click();
                xpath = "//input[@name='placeOfOrigin']";
                WebElement placeOfOrigin = Login.getDriver().findElement(By.xpath(xpath));
                placeOfOrigin.click();
                rows = sheet.getRow(6);
                cell = rows.getCell(4);

                String origin = cell.getStringCellValue();

                placeOfOrigin.sendKeys(origin);
                Thread.sleep(1000);
                placeOfOrigin.sendKeys(Keys.ARROW_DOWN);
                Thread.sleep(1000);
                placeOfOrigin.sendKeys(Keys.ENTER);
            }catch (Exception ex){
                System.out.println(ex.getMessage());
            }
            System.out.println(e.getMessage());
        }
    }
    public void placeOfFinalDestinationOfVessel()  {
        try {
            xpath="//input[@name='finalDestination']";
            WebElement placeOfDestination =Login.getDriver().findElement(By.xpath(xpath));
            placeOfDestination.click();
            rows = sheet.getRow(6);

            cell = rows.getCell(6);

            String destination = cell.getStringCellValue();

            placeOfDestination.sendKeys(destination);
            Thread.sleep(1000);
            placeOfDestination.sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(1000);
            placeOfDestination.sendKeys(Keys.ENTER);
        }catch (Exception e){
            try {
                xpath = "(//*[name()='svg'][@class='svg-inline--fa fa-times fa-w-12'])[2]";
                Login.getDriver().findElement(By.xpath(xpath)).click();
                xpath = "//input[@name='finalDestination']";
                WebElement placeOfDestination = Login.getDriver().findElement(By.xpath(xpath));
                placeOfDestination.click();
                rows = sheet.getRow(6);
                cell = rows.getCell(6);
                String destination = cell.getStringCellValue();
                placeOfDestination.sendKeys(destination);
                Thread.sleep(1000);
                placeOfDestination.sendKeys(Keys.ARROW_DOWN);
                Thread.sleep(1000);
                placeOfDestination.sendKeys(Keys.ENTER);
            }catch (Exception ex){
                System.out.println(ex.getMessage());
            }
            System.out.println(e.getMessage());
        }
    }
    public void fromPort(){
        try{
            xpath = "//ng-multiselect-dropdown[@name='portOfLoadingObj']//div//a[contains(text(),'x')]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
                xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[1]/div/ng-multiselect-dropdown/div/div[1]/span";
                Login.getDriver().findElement(By.xpath(xpath)).click();
                xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[1]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
                WebElement fromVessel = Login.getDriver().findElement(By.xpath(xpath));
                fromVessel.click();
                rows = sheet.getRow(9);
                cell = rows.getCell(1);
                String origin = cell.getStringCellValue();
                fromVessel.sendKeys(origin);
                Thread.sleep(2000);
                Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[1]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
                Thread.sleep(2000);

            System.out.println("place of origin is completed");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void toPort(){
        try{

            xpath = "//ng-multiselect-dropdown[@name='portOfDischargeObj']//div//a[contains(text(),'x')]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[2]/div/ng-multiselect-dropdown/div/div[1]/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();

            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[2]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            WebElement toPort= Login.getDriver().findElement(By.xpath(xpath));
            toPort.click();

             rows = sheet.getRow(9);
            cell = rows.getCell(2);

            String discharge = cell.getStringCellValue();
            toPort.sendKeys(discharge);
            Thread.sleep(2000);
         Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[2]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
            Thread.sleep(2000);

            System.out.println("place of discharge is completed");

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void shipmentDateOfVessel(){
        try{
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[2]/div/div/my-date-picker/div/div/input";

            WebElement shipmentDate = Login.getDriver().findElement(By.xpath(xpath));

            rows = sheet.getRow(9);
            cell = rows.getCell(3);
            DataFormatter formatter=new DataFormatter();
            String date = formatter.formatCellValue(cell);
            shipmentDate.sendKeys(date);
            Thread.sleep(2000);
            System.out.println("--shipment date--");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void placeOfOrigin() {
        try {
            xpath = "//div[@class='form-details admin-section-details']//div[1]//div[1]//div[2]//fa-icon[1]//*[name()='svg']";
            WebElement xButton=Login.getDriver().findElement(By.xpath(xpath));
                xButton.click();
                xpath="//input[@name='placeOfOrigin']";
                WebElement placeOfOrigin =Login.getDriver().findElement(By.xpath(xpath));
                placeOfOrigin.click();
                rows = sheet.getRow(6);
                cell = rows.getCell(4);
                String origin = cell.getStringCellValue();
                placeOfOrigin.sendKeys(origin);
                Thread.sleep(1000);
                placeOfOrigin.sendKeys(Keys.ARROW_DOWN);
                Thread.sleep(1000);
                placeOfOrigin.sendKeys(Keys.ENTER);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void placeOfDestination(){
        try {
            xpath="//div[1]//div[5]//div[1]//fa-icon[1]//*[name()='svg']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            xpath="//input[@name='finalDestination']";
            WebElement placeOfDestination =Login.getDriver().findElement(By.xpath(xpath));
            placeOfDestination.click();
            rows = sheet.getRow(6);
            cell = rows.getCell(6);
            String destination = cell.getStringCellValue();
            placeOfDestination.sendKeys(destination);
            Thread.sleep(1000);
            placeOfDestination.sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(1000);
            placeOfDestination.sendKeys(Keys.ENTER);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void fromStation() {
        try{
            xpath="//div[@class='form-details admin-section-details']//div[1]//div[1]//div[1]//fa-icon[1]//*[name()='svg']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div[1]/div/input";
            WebElement fromStation =Login.getDriver().findElement(By.xpath(xpath));
            fromStation.click();
            rows = sheet.getRow(9);
            cell = rows.getCell(1);
            String origin = cell.getStringCellValue();
            Login.getDriver().findElement(By.xpath("//input[@name='fromStation']")).sendKeys(origin);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='fromStation']")).sendKeys(Keys.ENTER);
            Thread.sleep(2000);
            System.out.println("from station is completed");
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void toStation() {
        try{
            xpath="//div[2]//div[1]//div[1]//fa-icon[1]//*[name()='svg'] ";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            xpath="//*[@name='toStation']";
            rows = sheet.getRow(9);
            cell = rows.getCell(2);
            String discharge = cell.getStringCellValue();
            Login.getDriver().findElement(By.xpath(xpath)).sendKeys(discharge);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath(xpath)).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath(xpath)).sendKeys(Keys.ENTER);
            Thread.sleep(2000);
            System.out.println("to station is completed");

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void shipmentDate(){
        try{

            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[5]/div[2]/div/div/my-date-picker/div/div/input";
            WebElement shipmentDate = Login.getDriver().findElement(By.xpath(xpath));

            rows = sheet.getRow(9);
            cell = rows.getCell(3);
            DataFormatter formatter=new DataFormatter();
            String date = formatter.formatCellValue(cell);
            shipmentDate.sendKeys(date);
            Thread.sleep(2000);
            System.out.println("--shipment date--");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

     public void fromRoad()  {
        try{
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("GetCertificate");
            xpath="(//*[name()='svg'][@role='img'])[45]";
            Login.getDriver().findElement(By.xpath(xpath)).click();

            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[1]/div/input";
             WebElement fromRoad= Login.getDriver().findElement(By.xpath(xpath));

             fromRoad.click();
              rows = sheet.getRow(9);
            cell = rows.getCell(1);
            String origin = cell.getStringCellValue();
         Login.getDriver().findElement(By.xpath("//input[@name='placeOfOrigin']")).sendKeys(origin);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='placeOfOrigin']")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            Login.getDriver().findElement(By.xpath("//input[@name='placeOfOrigin']")).sendKeys(Keys.ENTER);
            Thread.sleep(2000);
            System.out.println("place of origin is completed");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
     }
    public void toRoad() {
        try{
            FileInputStream inputStream = new FileInputStream("C:\\demo\\GetCertificate.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("GetCertificate");
            xpath="(//*[name()='svg'][@role='img'])[46]";
            Login.getDriver().findElement(By.xpath(xpath)).click();

            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[3]/div[2]/div/input";
            WebElement toRoad= Login.getDriver().findElement(By.xpath(xpath));
            toRoad.click();

             rows = sheet.getRow(9);
            cell = rows.getCell(2);
            String discharge = cell.getStringCellValue();
            toRoad.sendKeys(discharge);
            Thread.sleep(2000);
            toRoad.sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(2000);
            toRoad.sendKeys(Keys.ENTER);
            Thread.sleep(2000);

            System.out.println("place of discharge is completed");

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void shipmentDateOfRoad(){
        try{
            xpath = "//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/section/form/article[2]/div/article/div[4]/div/div/div/my-date-picker/div/div/input";

            WebElement shipmentDate = Login.getDriver().findElement(By.xpath(xpath));

            rows = sheet.getRow(9);
            cell = rows.getCell(3);
            DataFormatter formatter=new DataFormatter();
            String date = formatter.formatCellValue(cell);
            shipmentDate.sendKeys(date);
            Thread.sleep(2000);
            System.out.println("--shipment date--");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void scrollUpWindow(){
        try{
            JavascriptExecutor js1 = (JavascriptExecutor)Login.getDriver();
            Thread.sleep(2000);
            js1.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Thread.sleep(2000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void next(){
        try{
            xpath="//button[normalize-space()='Next']";
            Login.getDriver().findElement(By.xpath(xpath)).click();//clicked next button and entered into shipping details
            Thread.sleep(1000);

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void vesselNamePopUp(){
        try{
            xpath="//*[@id=\"focusDiv\"]/div/div/table/tbody/tr[1]/td[1]/div/label/span";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            //submit the pop up
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-certificate-shipping-details/div/div/div/div[3]/div/button[2]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
