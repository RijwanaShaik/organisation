package org.example.twoFactor;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.getCertificate.Login;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import java.io.FileInputStream;

public class TwoFactorAuthentication {
    String xpath=null;
    Row rows=null;
    Cell cell=null;

    public void enterIntoClientsPage(){
        try{
            FileInputStream inputStream = new FileInputStream("C:\\demo\\TwoFactor.xlsx");

            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            XSSFSheet sheet = workbook.getSheet("TwoFactor");

            xpath="//a[normalize-space()='User Management']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);

            xpath="//span[normalize-space()='Clients']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);

            //select the broker/underwirter/insurer clients
             rows=sheet.getRow(1);
             cell=rows.getCell(0);
             String section=cell.getStringCellValue();
             if(section.equalsIgnoreCase("Broker")){
               brokerSection();
             }else if(section.equalsIgnoreCase("Underwriter")){
               underWriterSection();
             }else if(section.equalsIgnoreCase("insurer")){
               insurerSection();
             }


           //client name
            rows=sheet.getRow(4);
            cell=rows.getCell(0);
            String name=cell.getStringCellValue();
            xpath="(//a[normalize-space()="  + "'"+name +"'" + "])[1]";
            JavascriptExecutor js = (JavascriptExecutor)Login.getDriver();
            Thread.sleep(2000);
            // Scrolling down the page to bottom of the page
            js.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);


            //edit button
            xpath="(//button[@type='button'])[3]";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);

            js.executeScript("window.scrollBy(0, document.documentElement.scrollHeight)", "");
            Thread.sleep(2000);

            xpath="//span[normalize-space()='Enable Two Factor Authentication']";

            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);

            xpath="//button[normalize-space()='submit']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);


        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void brokerSection(){
        try {
            xpath="//a[normalize-space()='Broker']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
 public void underWriterSection(){
        try {
            xpath="//a[normalize-space()='Underwriter']";
            Login.getDriver().findElement(By.xpath(xpath)).click();

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
 }
    public void insurerSection(){
        try {
            xpath="//a[normalize-space()='Insurer']";
            Login.getDriver().findElement(By.xpath(xpath)).click();

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

}
