package org.example.twoFactor;


import org.example.getCertificate.Login;
import org.testng.annotations.Test;

public class TwoFactorAuthTest {
    @Test
    public static void main(String[] args) throws InterruptedException {

        Login login = new Login();
        login.getTDISUrl();
        login.loginCredentialsOfAdmin();

        TwoFactorAuthentication tf=new TwoFactorAuthentication();
        tf.enterIntoClientsPage();
        login.getTDISUrl();
        login.loginCredentials();

    }
}
