package org.example.billing;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.getCertificate.Login;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.FileInputStream;

public class BillingFlow {
    public WebDriver driver;

    XSSFWorkbook workbook=null;
    XSSFSheet sheet = null;
    Row rows = null;
    Cell cell = null;
    DataFormatter df=new DataFormatter();

    String xpath=null;

    public void enterIntoBillingModule()  {
        try {
            xpath = "//*[@id=\"navbarResponsive\"]/ul/li[3]/a";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            xpath = "//*[@id=\"navbarResponsive\"]/ul/li[3]/ul/li[1]/a";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void addBillingContractButton()  {
        try{
            xpath="//button[@id='jh-create-entity']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void fromDate()  {
        try {
            FileInputStream inputStream = new FileInputStream("C:\\demo\\BillingFile.xlsx");

            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet("Billing");
            WebElement popUp=Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-billing-my-suffix/div[2]/div/div"));
            if(popUp.isDisplayed()) {
                xpath = "//my-date-picker[@id='field_fromDate']//input";
                WebElement fromCal = Login.getDriver().findElement(By.xpath(xpath));
                fromCal.click();
                Thread.sleep(1000);
                rows=sheet.getRow(2);
                cell=rows.getCell(0);
                String fromDate=df.formatCellValue(cell);
                fromCal.sendKeys(fromDate);
                Thread.sleep(1000);
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void toDate() {
        try{
            xpath="//my-date-picker[@id='field_toDate']//input";

            WebElement toCal=Login.getDriver().findElement(By.xpath(xpath));
            toCal.click();
            Thread.sleep(1000);
            rows=sheet.getRow(2);
            cell=rows.getCell(1);
            String toDate=df.formatCellValue(cell);
            toCal.sendKeys(toDate);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void client()  {
        try{
            xpath="//span[@class='dropdown-btn']";
            WebElement searchPath=Login.getDriver().findElement(By.xpath(xpath));
            searchPath.click();
            Thread.sleep(1000);

            //send the client name
            xpath="//*[@id=\"main_section\"]/section/div/div/jhi-billing-my-suffix/div[2]/div/div/div[2]/form/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[2]/ul[1]/li/input";
            rows=sheet.getRow(5);
            WebElement selectClientName=Login.getDriver().findElement(By.xpath(xpath));
            cell=rows.getCell(0);
            String name=cell.getStringCellValue();
            selectClientName.sendKeys(name);
            Thread.sleep(1000);
            Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-billing-my-suffix/div[2]/div/div/div[2]/form/div[2]/div[3]/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li/div")).click();
            searchPath.click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void billingCycle() {
        try{
            xpath="//select[@placeholder='Select Billing Cycle']";
            WebElement billingCycle=Login.getDriver().findElement(By.xpath(xpath));
            billingCycle.click();
            Thread.sleep(1000);
            rows=sheet.getRow(5);
            cell=rows.getCell(1);
            String payment=cell.getStringCellValue();
            billingCycle.sendKeys(payment);
            Thread.sleep(1000);

            billingCycle.click();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public  void totalTransactions()  {
        try{
            WebElement transaction=Login.getDriver().findElement(By.xpath("//*[@id=\"field_transactionCount\"]"));
            transaction.click();
            rows=sheet.getRow(8);
            cell=rows.getCell(0);
            String totalTransactions= df.formatCellValue(cell);
            transaction.sendKeys(totalTransactions);
            Thread.sleep(1000);

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void totalUsers(){
        try{
            WebElement totalUsers=Login.getDriver().findElement(By.xpath("//*[@id=\"field_userCount\"]"));
            totalUsers.click();
            rows.getCell(8);
            cell=rows.getCell(2);
            String noOfUsers=df.formatCellValue(cell);
            Thread.sleep(1000);
            totalUsers.sendKeys(noOfUsers);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    public void currencyList(){
        try{
            //select
            WebElement currency=Login.getDriver().findElement(By.xpath("//*[@id=\"field_Currency\"]"));
            currency.click();
            rows=sheet.getRow(11);
            cell=rows.getCell(0);
            DataFormatter df=new DataFormatter();
            String currencyType=df.formatCellValue(cell);
            currency.sendKeys(currencyType);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void basicCost() {
        try{
            System.out.println("----basic cost----");
            WebElement cost=Login.getDriver().findElement(By.xpath("//*[@id=\"field_basicCost\"]"));
            cost.click();
            rows=sheet.getRow(11);
            cell=rows.getCell(1);
            String basicCost=df.formatCellValue(cell);
            cost.sendKeys(basicCost);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void additionalCost(){
        try{
            System.out.println("----additional cost----");
            xpath="//input[@id='field_additionalPerTransaction']";
            WebElement additionalCost=Login.getDriver().findElement(By.xpath(xpath));
            additionalCost.click();
            rows=sheet.getRow(11);
            cell=rows.getCell(3);
            String additionalCharges=df.formatCellValue(cell);
            additionalCost.sendKeys(additionalCharges);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void rebate() {
        try{
            System.out.println("----rebate----");
            xpath="//input[@id='field_rebate']";
            WebElement rebate=Login.getDriver().findElement(By.xpath(xpath));
            rebate.click();
            rows=sheet.getRow(11);
            cell=rows.getCell(6);
            String discount= df.formatCellValue(cell);
            rebate.sendKeys(discount);
            Thread.sleep(2000);
            Actions act = new Actions(Login.getDriver());
            act.sendKeys(Keys.PAGE_DOWN).build().perform();
            // act.sendKeys(Keys.PAGE_UP).build().perform(); //for scroll up the pop-up

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void VesselScreeningIncludedInCost(){
        try{
            xpath="//span[normalize-space()='Vessel Screening Included in Cost']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void VesselScreeningFreeTransactions(){
        try{
            System.out.println("----free transactions----");
            xpath="//input[@id='field_vesselScreeningLimit']";
            WebElement screening=Login.getDriver().findElement(By.xpath(xpath));
            screening.click();
            rows=sheet.getRow(14);
            cell=rows.getCell(0);
            String limit= df.formatCellValue(cell);
            screening.sendKeys(limit);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void CostPerCallVesselScreening(){
        try{
            System.out.println("----cost per transactions----");
            xpath="//input[@id='field_vesselScreeningCost']";
            WebElement screening=Login.getDriver().findElement(By.xpath(xpath));
            screening.click();
            rows=sheet.getRow(14);
            cell=rows.getCell(3);
            DataFormatter df=new DataFormatter();
            String cost= df.formatCellValue(cell);
            screening.sendKeys(cost);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void SanctionScreeningCost(){
        try{
            System.out.println("----screening cost----");
            xpath="//input[@id='field_ScreeningCost']";
            WebElement screening=Login.getDriver().findElement(By.xpath(xpath));
            screening.click();
            rows=sheet.getRow(14);
            cell=rows.getCell(6);
            String cost= df.formatCellValue(cell);
            screening.sendKeys(cost);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void provisionSpot(){
        try{
            System.out.println("----provision spot checkbox----");
            xpath="//span[normalize-space()='Do you want provision spot market for this client?']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(2000);
            Actions act = new Actions(Login.getDriver());
            act.sendKeys(Keys.PAGE_DOWN).build().perform();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void flatPrice(){
        try{
            System.out.println("----flat price----");
            xpath="//input[@id='field_flatPrice']";
            WebElement flatPrice=Login.getDriver().findElement(By.xpath(xpath));
            flatPrice.click();
            rows=sheet.getRow(18);
            cell=rows.getCell(0);
            DataFormatter df=new DataFormatter();
            String price= df.formatCellValue(cell);
            flatPrice.sendKeys(price);
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void netPremium(){
        try{
            System.out.println("----net premium----");
            xpath="//input[@id='field_PercentageOnNetPremium']";
            WebElement netPremium=Login.getDriver().findElement(By.xpath(xpath));
            netPremium.click();
            rows=sheet.getRow(18);
            cell=rows.getCell(1);
            DataFormatter df=new DataFormatter();
            String cost=df.formatCellValue(cell);
            netPremium.sendKeys(cost);
            Thread.sleep(2000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void confirm() {
        try {
            System.out.println("----confirm button----");
            xpath = "//button[normalize-space()='Confirm']";
            Login.getDriver().findElement(By.xpath(xpath)).click();
            Thread.sleep(1000);
            WebElement popUp=Login.getDriver().findElement(By.xpath("//*[@id=\"main_section\"]/section/div/div/jhi-billing-my-suffix/div[2]/div/div"));
            if(popUp.isDisplayed()){
                System.out.println("Test failed");
            }else {
                System.out.println("Test has passed");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void cancel() {
        try {
            System.out.println("----cancel button----");
            xpath = "//button[normalize-space()='Cancel']";
            WebElement cancel= Login.getDriver().findElement(By.xpath(xpath));
            cancel.click();
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}