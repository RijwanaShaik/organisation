package org.example.billing;

import org.example.getCertificate.Login;
import org.testng.annotations.Test;

import java.io.IOException;

public class BillingTest {

    @Test
    public static void main(String[] args) throws InterruptedException, IOException {

        Login login=new Login();
        login.getTDISUrl();
        login.loginCredentialsOfAdmin();

        BillingFlow billingFlow=new BillingFlow();
        billingFlow.enterIntoBillingModule();
        billingFlow.addBillingContractButton();
        billingFlow.fromDate();
        billingFlow.toDate();
        billingFlow.client();
        billingFlow.billingCycle();
        billingFlow.totalTransactions();
        billingFlow.totalUsers();
        billingFlow.currencyList();
        billingFlow.basicCost();
        billingFlow.additionalCost();
        billingFlow.rebate();
        //billingFlow.VesselScreeningIncludedInCost();
        billingFlow.VesselScreeningFreeTransactions();
        billingFlow.CostPerCallVesselScreening();
        billingFlow.SanctionScreeningCost();
        billingFlow.provisionSpot();
        billingFlow.flatPrice();
        billingFlow.netPremium();
       billingFlow.confirm();
        billingFlow.cancel();
    }
}
