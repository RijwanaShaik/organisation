package com.net.thrymr.qh_cc_poc.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BubbleChartResponse {
    private Long value;
    private String name;
    private String color;
}
