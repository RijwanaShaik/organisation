package com.net.thrymr.qh_cc_poc.service.impl;

import com.net.thrymr.qh_cc_poc.repository.DepartmentDataSourceRepo;
import com.net.thrymr.qh_cc_poc.response.GenericResponse;
import com.net.thrymr.qh_cc_poc.service.DepartmentDataSourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class DepartmentDataSourceServiceImpl implements DepartmentDataSourceService {

    @Autowired
    private DepartmentDataSourceRepo departmentDataSourceRepo;


}
