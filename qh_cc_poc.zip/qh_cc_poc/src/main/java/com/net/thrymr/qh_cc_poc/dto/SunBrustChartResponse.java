package com.net.thrymr.qh_cc_poc.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class SunBrustChartResponse {
    private List<Object> sunBrustChartData;
}
