package com.net.thrymr.qh_cc_poc.dto;

import com.net.thrymr.qh_cc_poc.enums.ChartType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ChartSuggestionDto {

    private Long id;

    private ChartType type;

    private String suggestedCharts;
}
