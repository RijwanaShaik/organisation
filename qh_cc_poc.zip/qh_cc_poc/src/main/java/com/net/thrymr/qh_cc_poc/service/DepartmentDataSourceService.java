package com.net.thrymr.qh_cc_poc.service;

import com.net.thrymr.qh_cc_poc.response.GenericResponse;

public interface DepartmentDataSourceService {

}
