package com.net.thrymr.qh_cc_poc.controller;

import com.net.thrymr.qh_cc_poc.enums.TableNames;
import com.net.thrymr.qh_cc_poc.response.GenericResponse;
import com.net.thrymr.qh_cc_poc.service.ChartSuggestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/chat/suggestion")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class ChartSuggestionController {
    @Autowired
    private ChartSuggestionService chartSuggestionService;


    @GetMapping("/get-all-tables")
    public TableNames[] getAllTablesNames(){
      return   TableNames.values();
    }


    @GetMapping("/get-all-table-data/{tableName}")
    public GenericResponse getAllTableData(@PathVariable  String tableName){
        return chartSuggestionService.getAllTableData(tableName);
    }
}
