package com.net.thrymr.qh_cc_poc.response;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QueryParser {

    public static String parseParameter(String queryString, String parameterName) {
        String[] keyValuePairs = queryString.split(",");
        for (String keyValuePair : keyValuePairs) {
            String[] parts = keyValuePair.trim().split("=");
            if (parts.length == 2 && parts[0].trim().equalsIgnoreCase(parameterName)) {
                return parts[1].trim();
            }
        }
        return null;
    }

    public static Long parseLongParameter(String queryString, String parameterName) {
        String value = parseParameter(queryString, parameterName);
        if (value != null) {
            try {
                return Long.parseLong(value);
            } catch (NumberFormatException e) {
                // Handle parsing error
                return null;
            }
        }
        return null;
    }

    public static Date parseDateParameter(String queryString, String parameterName) {
        String value = parseParameter(queryString, parameterName);
        if (value != null) {
            try {
                // You need to implement date parsing logic based on the format of your date string
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                return dateFormat.parse(value);
            } catch (ParseException e) {
                // Handle parsing error
                return null;
            }
        }
        return null;
    }
    public static List<String> parseColumnNames(String query) {
        List<String> columnNames = new ArrayList<>();

        // Regular expression to match column names in a SELECT query
        String regex = "(?i)\\bselect\\b\\s+(.*?)\\s+\\bfrom\\b";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(query);

        if (matcher.find()) {
            String columnClause = matcher.group(1);
            String[] columns = columnClause.split(",");
            for (String column : columns) {
                // Remove leading and trailing spaces from each column name
                String columnName = column.trim();
                columnNames.add(columnName);
            }
        }

        return columnNames;
    }

    public static void main(String[] args) {
        String userQuery = "select id, name from employee_data_source";

        List<String> columnNames = parseColumnNames(userQuery);

        // Print the extracted column names
        System.out.println("Column Names: " + columnNames);
    }
}

