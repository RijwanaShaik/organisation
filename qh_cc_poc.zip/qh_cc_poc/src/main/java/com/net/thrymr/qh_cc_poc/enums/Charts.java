package com.net.thrymr.qh_cc_poc.enums;

import java.util.HashMap;
import java.util.Map;

public enum Charts {
    BAR_CHART,
    PIE_CHART,
    AREA_CHART,
    LINE_CHART,
    DONUT_CHART,
    FUNNEL_CHART,
    BUBBLE_CHART,
    GROUPED_BAR_CHART,
    MULTI_LINE_CHART,
    STACKED_BAR_CHART,
    DUAL_AXIS_CHART,
    CONNECTED_SCATTERPLOT,
    TABLE_CHART,
    TREE_MAP,
    SUN_BRUST,
    BAR_CHART_AXIS;


    public static Map<Charts,String> getContinuousAndContinuousDataCharts() {
        Map<Charts,String> area=new HashMap<>();

        area.put(Charts.AREA_CHART,"Area Chart") ;
        return area;
    }

    public static Map<Charts,String> getDiscreteAndDiscreteDataCharts() {
        Map<Charts,String> table=new HashMap<>();

        table.put(Charts.TABLE_CHART,"Table Chart") ;
        return table;
    }

    public static Map<Charts,String> getContinuousAndOneDiscreteDataCharts() {
        Map<Charts,String> charts=new HashMap<>();
        charts.put(Charts.BAR_CHART,"Bar Chart");
        charts.put(Charts.LINE_CHART,"Line Chart");
        charts.put(Charts.DONUT_CHART,"Donut Chart");
        charts.put(Charts.PIE_CHART, "Pie Chart");
        charts.put(Charts.FUNNEL_CHART,"Funnel Chart");
        charts.put(Charts.BUBBLE_CHART,"Bubble Chart");
        charts.put(Charts.BAR_CHART_AXIS,"Bar Chart Axis");
        return charts;
    }
    public static Map<Charts,String> getMoreThanOneContinuousAndOneDiscrete(){
        Map<Charts,String> charts=new HashMap<>();
        charts.put(Charts.GROUPED_BAR_CHART,"Grouped Bar Chart");
        charts.put(Charts.MULTI_LINE_CHART, "Multi Line Chart");
        charts.put(Charts.STACKED_BAR_CHART,"Stacked Bar Chart");
        return charts;
    }
    public static Map<Charts,String> getDiscreteAndTwoContinuous(){
        Map<Charts,String> charts=new HashMap<>();
        charts.put(Charts.DUAL_AXIS_CHART,"Dual Axis Chart");
        charts.put(Charts.CONNECTED_SCATTERPLOT, "Connected Scatterplot");
        return charts;
    }

    public static Map<Charts,String> getDiscreteAndOneContinuousDataCharts() {
        Map<Charts,String> charts=new HashMap<>();
        charts.put(Charts.STACKED_BAR_CHART,"Stacked Bar Chart");
        charts.put(Charts.TREE_MAP, "Tree Map");
        charts.put(Charts.SUN_BRUST,"Sun Burst");

        return charts;
    }
}
