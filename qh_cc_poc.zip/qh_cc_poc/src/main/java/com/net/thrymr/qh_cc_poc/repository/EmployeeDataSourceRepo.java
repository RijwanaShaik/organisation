package com.net.thrymr.qh_cc_poc.repository;

import com.net.thrymr.qh_cc_poc.dto.EmployeeDataSourceDto;
import com.net.thrymr.qh_cc_poc.entity.EmployeeDataSource;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface EmployeeDataSourceRepo extends JpaRepository<EmployeeDataSource,Long> {

    @Query(value = "SELECT e FROM EmployeeDataSource e ")
    List<EmployeeDataSource> findByUserQuery(String userQuery);
//    @Autowired
//    EntityManager getEntityManager();
//    @Query(value = "SELECT * FROM employee_data_source e WHERE " +
//            "(:name IS NULL OR e.name = :name) AND " +
//            "(:id IS NULL OR e.id = :id) AND " +
//        //    "(:doj IS NULL OR e.doj = :doj) AND " +
//            "(:status IS NULL OR e.status = :status) "
//          //  "(:resignedDate IS NULL OR e.resigned_date = CAST(:resignedDate AS timestamp with time zone))"
//            , nativeQuery = true)
//    // Add columns for other fields as needed
//
//    List<EmployeeDataSource> findByCustomQuery(
//            @Param("name") String name,
//            @Param("id") Long id,
//            @Param("status") String status
//    );
//    @Transactional
//    default List<EmployeeDataSource> executeCustomQuery(String customQuery) {
//
//        List<EmployeeDataSource> resultList = getEntityManager().createNativeQuery(customQuery, EmployeeDataSource.class).getResultList();
//        return resultList;
//    }


}


