package com.net.thrymr.qh_cc_poc.repository;


import com.net.thrymr.qh_cc_poc.entity.ChartColor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChartColorRepo  extends JpaRepository<ChartColor, Long> {
}
