package com.net.thrymr.qh_cc_poc.repository;

import com.net.thrymr.qh_cc_poc.entity.ChartSuggestion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChartSuggestionRepo extends JpaRepository<ChartSuggestion,Long> {
}
