package com.net.thrymr.qh_cc_poc.response;

import com.net.thrymr.qh_cc_poc.dto.AttendanceDataSourceDto;
import com.net.thrymr.qh_cc_poc.dto.DepartmentDataSourceDto;
import com.net.thrymr.qh_cc_poc.dto.EmployeeDataSourceDto;
import com.net.thrymr.qh_cc_poc.entity.AttendanceDataSource;
import com.net.thrymr.qh_cc_poc.entity.DepartmentDataSource;
import com.net.thrymr.qh_cc_poc.entity.EmployeeDataSource;

import java.util.ArrayList;
import java.util.List;

public class DataConversion {



    public static List<EmployeeDataSource> EmployeeDtoToEntity(List<EmployeeDataSourceDto> employeeDataSourceDtoList){

        List<EmployeeDataSource> employeeDataSourceList = new ArrayList<>();
        for(EmployeeDataSourceDto employeeDataSourceDto :employeeDataSourceDtoList) {
            EmployeeDataSource employeeDataSource = new EmployeeDataSource();
            if (employeeDataSourceDto.getId() != null) {
                employeeDataSource.setId(employeeDataSourceDto.getId());
            }
            employeeDataSource.setName(employeeDataSourceDto.getName());
            employeeDataSource.setDoj(employeeDataSourceDto.getDoj());
            employeeDataSource.setStatus(employeeDataSourceDto.getStatus());
            employeeDataSource.setSalary(employeeDataSourceDto.getSalary());
            employeeDataSource.setResignedDate(employeeDataSourceDto.getResignedDate());
            employeeDataSource.setAttendanceCount(employeeDataSourceDto.getAttendanceCount());
            employeeDataSource.setNoOfLeavesRemaining(employeeDataSourceDto.getNoOfLeavesRemaining());
            employeeDataSource.setRating(employeeDataSourceDto.getRating());
            employeeDataSourceList.add(employeeDataSource);
        }
        return employeeDataSourceList;
    }

    public static List<EmployeeDataSourceDto> EmployeeEntityToDto(List<EmployeeDataSource> employeeDataSource){

        List<EmployeeDataSourceDto> employeeDataSourceDto = new ArrayList<>();
        for(EmployeeDataSource employeeDataSource1 : employeeDataSource) {
            EmployeeDataSourceDto employeeDataSourceDto1 = new EmployeeDataSourceDto();
            employeeDataSourceDto1.setId(employeeDataSource1.getId());
            employeeDataSourceDto1.setName(employeeDataSource1.getName());
            employeeDataSourceDto1.setDoj(employeeDataSource1.getDoj());
            employeeDataSourceDto1.setStatus(employeeDataSource1.getStatus());
            employeeDataSourceDto1.setSalary(employeeDataSource1.getSalary());
            employeeDataSourceDto1.setResignedDate(employeeDataSource1.getResignedDate());
            employeeDataSourceDto1.setAttendanceCount(employeeDataSource1.getAttendanceCount());
            employeeDataSourceDto1.setNoOfLeavesRemaining(employeeDataSource1.getNoOfLeavesRemaining());
            employeeDataSourceDto1.setRating(employeeDataSource1.getRating());
            employeeDataSourceDto.add(employeeDataSourceDto1);
        }
        return employeeDataSourceDto;
    }

    public static List<AttendanceDataSourceDto> attendanceEntityToDto(List<AttendanceDataSource> attendanceDataSourceList)  {
        List<AttendanceDataSourceDto> attendanceDataSourceDtoList = new ArrayList<>();
        for (AttendanceDataSource attendanceDataSource : attendanceDataSourceList) {
            AttendanceDataSourceDto attendanceDataSourceDto = new AttendanceDataSourceDto();
            attendanceDataSourceDto.setId(attendanceDataSource.getId());
            attendanceDataSourceDto.setName(attendanceDataSource.getName());
            attendanceDataSourceDto.setDate(attendanceDataSource.getDate());
            attendanceDataSourceDto.setIsPresent(attendanceDataSource.getIsPresent());
            attendanceDataSourceDtoList.add(attendanceDataSourceDto);
        }
            return attendanceDataSourceDtoList;

    }

    public static List<AttendanceDataSource> attendanceDtoToEntity(List<AttendanceDataSourceDto> attendanceDataSourceDtoList){
        List<AttendanceDataSource> attendanceDataSourceList = new ArrayList<>();

        for(AttendanceDataSourceDto attendanceDataSourceDto : attendanceDataSourceDtoList) {
            AttendanceDataSource attendanceDataSource = new AttendanceDataSource();
            if (attendanceDataSourceDto.getId() != null) {
                attendanceDataSource.setId(attendanceDataSourceDto.getId());
            }
            attendanceDataSource.setName(attendanceDataSourceDto.getName());
            attendanceDataSource.setDate(attendanceDataSourceDto.getDate());
            attendanceDataSource.setIsPresent(attendanceDataSourceDto.getIsPresent());
            attendanceDataSourceList.add(attendanceDataSource);
        }
        return attendanceDataSourceList;

    }


    public static List<DepartmentDataSource> departmentDtoToEntity(List<DepartmentDataSourceDto> departmentDataSourceDtoList) {
        List<DepartmentDataSource> departmentDataSourceDtoList1 = new ArrayList<>();
        DepartmentDataSource departmentDataSource = new DepartmentDataSource();
        for (DepartmentDataSourceDto departmentDataSourceDto1 : departmentDataSourceDtoList) {
            if (departmentDataSourceDto1.getId() != null) {
                departmentDataSource.setId(departmentDataSourceDto1.getId());
            }
            departmentDataSource.setDepartmentName(departmentDataSourceDto1.getDepartmentName());
            departmentDataSource.setLocation(departmentDataSourceDto1.getLocation());
            departmentDataSource.setEmployeeCount(departmentDataSourceDto1.getEmployeeCount());
            departmentDataSourceDtoList1.add(departmentDataSource);
        }

        return departmentDataSourceDtoList1;
    }

    public static List<DepartmentDataSourceDto> departmentEntityToDto(List<DepartmentDataSource> departmentDataSourceList){
        List<DepartmentDataSourceDto> departmentDataSourceDtoList = new ArrayList<>();
        for (DepartmentDataSource departmentDataSource : departmentDataSourceList) {
            DepartmentDataSourceDto dto = new DepartmentDataSourceDto();
            dto.setId(departmentDataSource.getId());
            dto.setDepartmentName(departmentDataSource.getDepartmentName());
            dto.setLocation(departmentDataSource.getLocation());
            dto.setEmployeeCount(departmentDataSource.getEmployeeCount());
            departmentDataSourceDtoList.add(dto);
        }
        return departmentDataSourceDtoList;
    }

}
