package com.net.thrymr.qh_cc_poc.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class AreaChartResponse {
 private String name,color;
 private Long value;
}
