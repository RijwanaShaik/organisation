package com.net.thrymr.qh_cc_poc.dto;


import com.net.thrymr.qh_cc_poc.enums.DataType;
import com.net.thrymr.qh_cc_poc.enums.TableNames;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ChartSuggestionRequestDto {

   private String entityClassName;
   private String[] selectedColumns;
   private String userQuery;

   public Map<String, String> getFieldDataTypes(String entityClassName, String[] selectedColumns) {
      Map<String, String> fieldDataTypes = new HashMap<>();
      String packageName = "com.net.thrymr.qh_cc_poc.dto.";

      try {
         TableNames tableName = TableNames.valueOf(entityClassName);
         String convertedString = tableName.toCamelCaseString();
         Class<?> entityClass = Class.forName(packageName + convertedString + "Dto");
         Field[] fields = entityClass.getDeclaredFields();

         for (Field field : fields) {
            String fieldName = field.getName();

            if (contains(selectedColumns, fieldName)) {
               Class<?> fieldType = field.getType();
               String simpleTypeName = fieldType.getSimpleName();
               fieldDataTypes.put(fieldName, simpleTypeName);
            }
         }

      } catch (ClassNotFoundException e) {
         System.err.println("Class not found: " + entityClassName);
      }

      return fieldDataTypes;
   }

   public Map<String, DataType> classifyDataTypes(Map<String, String> fieldDataTypes) {
      Map<String, DataType> dataTypes = new HashMap<>();

      for (Map.Entry<String, String> entry : fieldDataTypes.entrySet()) {
         String fieldName = entry.getKey();
         String dataTypeStr = entry.getValue();
         DataType dataType = classifyDataType(dataTypeStr);
         dataTypes.put(fieldName, dataType);
      }

      return dataTypes;
   }


   private static boolean contains(String[] array, String key) {
      for (String item : array) {
         if (item.equals(key)) {
            return true;
         }
      }
      return false;
   }
   private static DataType classifyDataType(String dataTypeStr) {
      if ("Integer".equals(dataTypeStr) || "Double".equals(dataTypeStr) || "Float".equals(dataTypeStr) || "Long".equals(dataTypeStr)) {
         return DataType.CONTINUOUS;
      } else if ("String".equals(dataTypeStr) || "Date".equals(dataTypeStr) || "Boolean".equals(dataTypeStr)) {
         return DataType.DISCRETE;
      }
      return null;
   }

}
