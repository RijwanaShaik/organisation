package com.net.thrymr.qh_cc_poc.service;

import com.net.thrymr.qh_cc_poc.response.GenericResponse;

import java.text.ParseException;

import java.util.List;

public interface ChartSuggestionService {
    GenericResponse getAllChartSuggestionData();

    GenericResponse getAllTableData(String tableName);
    List<Object> getTableData(String tableName);
}
