package com.net.thrymr.qh_cc_poc.entity;

import com.net.thrymr.qh_cc_poc.enums.ChartType;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class ChartSuggestion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private ChartType type;

    private String suggestedCharts;

}