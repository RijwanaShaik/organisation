package com.net.thrymr.qh_cc_poc.enums;

import java.util.Collection;
import java.util.Map;

public enum ChartType {

    CONTINUOUS_AND_CONTINUOUS_DATA,
    DISCRETE_AND_DISCRETE_DATA,
    CONTINUOUS_AND_ONE_DISCRETE_DATA,
    DISCRETE_AND_MORE_THAN_ONE_CONTINUOUS_DATA,
    DISCRETE_AND_TWO_CONTINUOUS_DATA,
    DISCRETE_AND_ONE_CONTINUOUS_DATA;

    public static Map<Charts,String> getChartNames(ChartType type) {
        return switch (type) {
            case CONTINUOUS_AND_CONTINUOUS_DATA -> Charts.getContinuousAndContinuousDataCharts();
            case DISCRETE_AND_DISCRETE_DATA -> Charts.getDiscreteAndDiscreteDataCharts();
            case CONTINUOUS_AND_ONE_DISCRETE_DATA -> Charts.getContinuousAndOneDiscreteDataCharts();
            case DISCRETE_AND_MORE_THAN_ONE_CONTINUOUS_DATA -> Charts.getMoreThanOneContinuousAndOneDiscrete();
            case DISCRETE_AND_TWO_CONTINUOUS_DATA -> Charts.getDiscreteAndTwoContinuous();
            case DISCRETE_AND_ONE_CONTINUOUS_DATA -> Charts.getDiscreteAndOneContinuousDataCharts();
            default -> null;
        };
    }


}
