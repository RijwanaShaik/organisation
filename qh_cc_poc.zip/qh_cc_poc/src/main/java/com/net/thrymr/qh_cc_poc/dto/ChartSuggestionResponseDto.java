package com.net.thrymr.qh_cc_poc.dto;

import com.net.thrymr.qh_cc_poc.enums.ChartType;
import com.net.thrymr.qh_cc_poc.enums.Charts;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ChartSuggestionResponseDto {
    private List<ChartType> types=new ArrayList<>();
    private Map<Charts,String> suggestedCharts;
    private List<ChartResponse> chartResponses;

}
