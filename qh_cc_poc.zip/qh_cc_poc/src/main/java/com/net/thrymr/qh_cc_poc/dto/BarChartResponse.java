package com.net.thrymr.qh_cc_poc.dto;

import lombok.Getter;
import lombok.Setter;
import org.apache.poi.ss.formula.functions.T;

import java.util.List;

@Getter
@Setter
public class BarChartResponse {
   private Long value;
   private String name;
   private String color;
}
