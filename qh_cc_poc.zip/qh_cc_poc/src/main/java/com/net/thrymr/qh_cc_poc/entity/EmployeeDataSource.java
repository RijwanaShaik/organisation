package com.net.thrymr.qh_cc_poc.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

import java.util.Date;

@Entity
@Data
public class EmployeeDataSource {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private Double salary;

    private Date doj;

    private String status;

    private Date resignedDate;

    private Long attendanceCount;

    private Integer noOfLeavesRemaining;

    private Integer rating;


}
