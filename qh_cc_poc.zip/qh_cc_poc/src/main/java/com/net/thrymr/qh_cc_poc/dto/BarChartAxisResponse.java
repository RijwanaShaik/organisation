package com.net.thrymr.qh_cc_poc.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BarChartAxisResponse {

    private Long value;
    private String name;
    private String color;
}
