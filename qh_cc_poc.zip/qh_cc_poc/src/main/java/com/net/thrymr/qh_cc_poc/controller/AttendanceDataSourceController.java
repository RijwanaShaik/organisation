package com.net.thrymr.qh_cc_poc.controller;

import com.net.thrymr.qh_cc_poc.service.AttendanceDataSourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/attendance")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class AttendanceDataSourceController {

    @Autowired
    private AttendanceDataSourceService attendanceDataSourceService;
}
