package com.net.thrymr.qh_cc_poc.dto;

import com.net.thrymr.qh_cc_poc.enums.Charts;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ChartResponse<T> {
    private Charts chartType;
    private List<T> chartData;
}
