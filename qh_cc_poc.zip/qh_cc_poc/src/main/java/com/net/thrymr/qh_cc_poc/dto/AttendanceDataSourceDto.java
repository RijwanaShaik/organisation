package com.net.thrymr.qh_cc_poc.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class AttendanceDataSourceDto {

    private Long id;

    private String name;

    private Date date;

    private  Boolean isPresent;
    public AttendanceDataSourceDto(Map<String, Object> map) {
        this.setId((Long) map.get("id"));
        this.setName((String) map.get("name"));
        this.setDate((Date) map.get("date"));
        this.setIsPresent((Boolean) map.get("is_present"));
    }
}
