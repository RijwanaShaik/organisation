package com.net.thrymr.qh_cc_poc.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.bind.annotation.Mapping;

import java.util.Date;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class EmployeeDataSourceDto {

    private Long id;

    private String name;


    private Double salary;

    private Date doj;

    private String status;

    private Date resignedDate;
    private Long attendanceCount;

    private Integer noOfLeavesRemaining;

    private Integer rating;

    public EmployeeDataSourceDto(Map<String, Object> map) {
        this.setId((Long) map.get("id"));
        this.setName((String) map.get("name"));
        this.setSalary((Double) map.get("salary"));
        this.setDoj((Date) map.get("doj"));
        this.setStatus((String) map.get("status"));
        this.setResignedDate((Date) map.get("resigned_date"));
        this.setAttendanceCount((Long) map.get("attendance_count"));
        this.setNoOfLeavesRemaining((Integer) map.get("no_of_leaves_remaining"));
        this.setRating((Integer) map.get("rating"));
    }

}
