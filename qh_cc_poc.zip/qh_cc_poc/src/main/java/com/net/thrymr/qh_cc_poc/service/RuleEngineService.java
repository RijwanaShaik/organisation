package com.net.thrymr.qh_cc_poc.service;

import com.net.thrymr.qh_cc_poc.dto.ChartResponse;
import com.net.thrymr.qh_cc_poc.dto.ChartSuggestionRequestDto;
import com.net.thrymr.qh_cc_poc.entity.EmployeeDataSource;
import com.net.thrymr.qh_cc_poc.enums.Charts;
import com.net.thrymr.qh_cc_poc.response.GenericResponse;

import java.util.List;
import java.util.Map;

public interface RuleEngineService {

    GenericResponse getSuggestedCharts(ChartSuggestionRequestDto requestDto);
    List<ChartResponse> composeCharts(ChartSuggestionRequestDto requestDto, Map<Charts,String> chartsStringMap);

    GenericResponse getResultsWithQuery(ChartSuggestionRequestDto requestDto);
    List<Object[]> executeCustomQuery(String query);
    List<Map<String, Object>> executeQuery(String entityClassName, String userQuery);
}
