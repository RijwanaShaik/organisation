package com.net.thrymr.qh_cc_poc.controller;

import com.net.thrymr.qh_cc_poc.dto.ChartSuggestionRequestDto;
import com.net.thrymr.qh_cc_poc.entity.EmployeeDataSource;
import com.net.thrymr.qh_cc_poc.response.GenericResponse;
import com.net.thrymr.qh_cc_poc.service.RuleEngineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/rule/engine")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class RuleEngineController {
    @Autowired
    private RuleEngineService ruleEngineService;

    @PostMapping("/suggest-charts")
    public GenericResponse getSuggestedCharts(@RequestBody ChartSuggestionRequestDto requestDto){
        return ruleEngineService.getSuggestedCharts(requestDto);
    }
    @PostMapping("/executeQuery")
    public List<Map<String, Object>> executeQuery(@RequestBody ChartSuggestionRequestDto requestDto) {
        return ruleEngineService.executeQuery(requestDto.getEntityClassName(), requestDto.getUserQuery());
    }
    @PostMapping("/suggest-query")
    public GenericResponse getSuggestQuery(@RequestBody ChartSuggestionRequestDto requestDto){
        return ruleEngineService.getResultsWithQuery(requestDto);
    }
}