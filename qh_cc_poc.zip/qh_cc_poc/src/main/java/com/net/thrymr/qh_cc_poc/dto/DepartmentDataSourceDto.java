package com.net.thrymr.qh_cc_poc.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class DepartmentDataSourceDto {

    private Long id;

    private String departmentName;

    private String location;
    private Long employeeCount;
    public DepartmentDataSourceDto(Map<String, Object> map) {
        this.setId((Long) map.get("id"));
        this.setDepartmentName((String) map.get("department_name"));
        this.setLocation((String) map.get("location"));
        this.setEmployeeCount((Long) map.get("employeeCount"));
    }
}
