package com.net.thrymr.qh_cc_poc.service.impl;

import com.net.thrymr.qh_cc_poc.enums.TableNames;
import com.net.thrymr.qh_cc_poc.repository.AttendanceDataSourceRepo;
import com.net.thrymr.qh_cc_poc.repository.ChartSuggestionRepo;
import com.net.thrymr.qh_cc_poc.repository.DepartmentDataSourceRepo;
import com.net.thrymr.qh_cc_poc.repository.EmployeeDataSourceRepo;
import com.net.thrymr.qh_cc_poc.response.DataConversion;
import com.net.thrymr.qh_cc_poc.response.GenericResponse;
import com.net.thrymr.qh_cc_poc.service.ChartSuggestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

import static com.net.thrymr.qh_cc_poc.response.DataConversion.*;

@Service
public class ChartSuggestionServiceImpl implements ChartSuggestionService {
    @Autowired
    private ChartSuggestionRepo chartSuggestionRepo;

    @Autowired
    private EmployeeDataSourceRepo employeeDataSourceRepo;

    @Autowired
    private DepartmentDataSourceRepo departmentDataSourceRepo;

    @Autowired
    private AttendanceDataSourceRepo attendanceDataSourceRepo;


    public GenericResponse getAllChartSuggestionData(){
        return new GenericResponse(HttpStatus.OK,chartSuggestionRepo.findAll());
    }

    @Override
    public GenericResponse getAllTableData(String tableName) {
        return new GenericResponse(HttpStatus.BAD_REQUEST, getTableData(tableName));
    }

    public List<Object> getTableData(String tableName){
        if(tableName.equals(TableNames.EMPLOYEE_DATA_SOURCE.toString())){
            return Collections.singletonList(EmployeeEntityToDto(employeeDataSourceRepo.findAll()));
        } else if(tableName.equals(TableNames.ATTENDANCE_DATA_SOURCE.toString())){
            return Collections.singletonList(attendanceEntityToDto(attendanceDataSourceRepo.findAll()));
        } else if(tableName.equals(TableNames.DEPARTMENT_DATA_SOURCE.toString())){
            return Collections.singletonList(departmentEntityToDto(departmentDataSourceRepo.findAll()));
        }
        return null;
    }
}
