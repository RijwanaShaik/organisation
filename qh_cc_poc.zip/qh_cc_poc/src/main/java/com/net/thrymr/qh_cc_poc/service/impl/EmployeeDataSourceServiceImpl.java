package com.net.thrymr.qh_cc_poc.service.impl;

import com.net.thrymr.qh_cc_poc.dto.EmployeeDataSourceDto;
import com.net.thrymr.qh_cc_poc.entity.EmployeeDataSource;
import com.net.thrymr.qh_cc_poc.repository.EmployeeDataSourceRepo;
import com.net.thrymr.qh_cc_poc.response.GenericResponse;
import com.net.thrymr.qh_cc_poc.service.EmployeeDataSourceService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.net.thrymr.qh_cc_poc.response.DataConversion.EmployeeEntityToDto;

@Service
public class EmployeeDataSourceServiceImpl implements EmployeeDataSourceService {

    @Autowired
    private EmployeeDataSourceRepo employeeDataSourceRepo;


    @PersistenceContext
    private EntityManager entityManager;
//    public List<EmployeeDataSourceDto> executeUserQuery(String userQuery) {
//        List<EmployeeDataSourceDto> result= EmployeeEntityToDto(employeeDataSourceRepo.findByUserQuery(userQuery));
//        return result;
//    }
    public List<EmployeeDataSourceDto> executeUserQuery(String userQuery) throws SQLException {
        Query nativeQuery = entityManager.createNativeQuery(userQuery);

        // Execute the native query and retrieve the result list
        List<Object[]> result = nativeQuery.getResultList();

        return mapToDto(result);
    }

    private List<EmployeeDataSourceDto> mapToDto(List<Object[]> result) throws SQLException {
        List<EmployeeDataSourceDto> dtos = new ArrayList<>();
        for (Object[] row : result) {
            EmployeeDataSourceDto dto = new EmployeeDataSourceDto();

            // Assuming the order of columns in the result set matches the order in the SELECT clause
            ResultSetMetaData metaData = ((ResultSet) row[3]).getMetaData(); // Assuming metadata is at index 3

            for (int i = 1; i <= metaData.getColumnCount(); i++) {
                String columnName = metaData.getColumnName(i);
                Object columnValue = row[i - 1];

                // Map the column dynamically based on its name
                switch (columnName.toLowerCase()) {
                    case "id":
                        dto.setId(columnValue != null ? Long.valueOf(columnValue.toString()) : null);
                        break;
                    case "name":
                        dto.setName(columnValue != null ? columnValue.toString() : null);
                        break;
                    case "salary":
                        dto.setSalary(columnValue != null ? Double.valueOf(columnValue.toString()) : null);
                        break;
                    case "doj":
                        dto.setDoj(columnValue instanceof java.sql.Date ? (java.sql.Date) columnValue : null);
                        break;
                    case "status":
                        dto.setStatus(columnValue != null ? columnValue.toString() : null);
                        break;
                    case "resigned_date":
                        dto.setResignedDate(columnValue instanceof java.sql.Date ? (java.sql.Date) columnValue : null);
                        break;
                    case "attendance_count":
                        dto.setAttendanceCount(columnValue != null ? Long.valueOf(columnValue.toString()) : null);
                        break;
                    case "no_of_leaves_remaining":
                        dto.setNoOfLeavesRemaining(columnValue != null ? Integer.valueOf(columnValue.toString()) : null);
                        break;
                    case "rating":
                        dto.setRating(columnValue != null ? Integer.valueOf(columnValue.toString()) : null);
                        break;
                }
            }

            dtos.add(dto);
        }
        return dtos;
    }


}

