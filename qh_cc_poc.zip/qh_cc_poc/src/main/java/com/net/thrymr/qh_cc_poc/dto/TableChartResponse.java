package com.net.thrymr.qh_cc_poc.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class TableChartResponse {
    private List<Object> tableChartData;
}
