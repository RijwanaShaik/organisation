package com.net.thrymr.qh_cc_poc.dto;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class DualAxisChartResponse {
    private Long countForLineGraph;
    private Long countForBarGraph;
    private String colorForLineGraph;
    private String colorForBarGraph;
    private String name;
}
