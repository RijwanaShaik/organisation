package com.net.thrymr.qh_cc_poc.service.impl;

import com.net.thrymr.qh_cc_poc.repository.AttendanceDataSourceRepo;
import com.net.thrymr.qh_cc_poc.response.GenericResponse;
import com.net.thrymr.qh_cc_poc.service.AttendanceDataSourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class AttendanceDataSourceServiceImpl implements AttendanceDataSourceService {

    @Autowired
    private AttendanceDataSourceRepo attendanceDataSourceRepo;


}
