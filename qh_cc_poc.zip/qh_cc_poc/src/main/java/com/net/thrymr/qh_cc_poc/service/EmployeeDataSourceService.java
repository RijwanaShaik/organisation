package com.net.thrymr.qh_cc_poc.service;

import com.net.thrymr.qh_cc_poc.dto.EmployeeDataSourceDto;
import com.net.thrymr.qh_cc_poc.response.GenericResponse;

import java.sql.SQLException;
import java.util.List;

public interface EmployeeDataSourceService {
    List<EmployeeDataSourceDto> executeUserQuery(String userQuery) throws SQLException;
}
