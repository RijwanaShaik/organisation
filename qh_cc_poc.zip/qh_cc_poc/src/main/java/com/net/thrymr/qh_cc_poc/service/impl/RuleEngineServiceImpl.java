package com.net.thrymr.qh_cc_poc.service.impl;

import com.net.thrymr.qh_cc_poc.dto.*;
import com.net.thrymr.qh_cc_poc.entity.ChartColor;
import com.net.thrymr.qh_cc_poc.entity.EmployeeDataSource;
import com.net.thrymr.qh_cc_poc.enums.Charts;
import com.net.thrymr.qh_cc_poc.enums.TableNames;
import com.net.thrymr.qh_cc_poc.repository.AttendanceDataSourceRepo;
import com.net.thrymr.qh_cc_poc.repository.ChartColorRepo;
import com.net.thrymr.qh_cc_poc.repository.DepartmentDataSourceRepo;
import com.net.thrymr.qh_cc_poc.repository.EmployeeDataSourceRepo;
import com.net.thrymr.qh_cc_poc.response.GenericResponse;
import com.net.thrymr.qh_cc_poc.response.QueryParser;
import com.net.thrymr.qh_cc_poc.service.RuleEngineService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.io.ResourceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.net.thrymr.qh_cc_poc.response.DataConversion.*;


@Service
public class RuleEngineServiceImpl implements RuleEngineService {
    @Autowired
    private EmployeeDataSourceRepo employeeRepo;

    @Autowired
    private AttendanceDataSourceRepo attendanceDataRepo;

    @Autowired
    private DepartmentDataSourceRepo departmentDataSourceRepo;
    @Autowired
    private ChartColorRepo chartColorRepo;

    @Autowired    
    private EntityManager entityManager;

    @Override
    public GenericResponse getSuggestedCharts(ChartSuggestionRequestDto requestDto) {
        ChartSuggestionResponseDto responseDto = new ChartSuggestionResponseDto();
            KieSession kieSession = kiaSession("rules/charts.drl");
            kieSession.insert(requestDto);
            kieSession.setGlobal("responseDto", responseDto);
            kieSession.insert(requestDto);
            kieSession.fireAllRules();
            kieSession.dispose();

            List<ChartResponse> suggestedChart = new ArrayList<>();

            Map<Charts, String> charts = responseDto.getSuggestedCharts();
            if (!charts.isEmpty()) {
                suggestedChart = composeCharts(requestDto, charts);
                responseDto.setChartResponses(suggestedChart);
            } else {
                return new GenericResponse(HttpStatus.OK, "No Suggested Graphs");
            }
            return new GenericResponse(HttpStatus.OK, responseDto);
    }
    @Override
    public GenericResponse getResultsWithQuery(ChartSuggestionRequestDto requestDto) {

        TableNames tableName = TableNames.valueOf(requestDto.getEntityClassName());
        String convertedString = tableName.toCamelCaseString();
        List<Map<String, Object>> result=executeQuery(convertedString,requestDto.getUserQuery());
        Set<String> uniqueColumnNames = new HashSet<>();
        List<EmployeeDataSourceDto> employeeData=new ArrayList<>();
        List<AttendanceDataSourceDto> attendanceDataSourceDtoList=new ArrayList<>();
        List<DepartmentDataSourceDto> departmentDataSourceDtoList=new ArrayList<>();
        for (Map<String, Object> row : result) {
            uniqueColumnNames.addAll(row.keySet());
            if(convertedString.equals("EmployeeDataSource")) {
                employeeData.add(new EmployeeDataSourceDto(row));
            }
            if(convertedString.equals("AttendanceDataSource")){
                attendanceDataSourceDtoList.add(new AttendanceDataSourceDto(row));
            }
            if(convertedString.equals("DepartmentDataSource")){
                departmentDataSourceDtoList.add(new DepartmentDataSourceDto(row));
            }
        }
        String[] uniqueColumnNamesArray = convertUnderscoreToCamelCase(uniqueColumnNames);

        requestDto.setSelectedColumns(uniqueColumnNamesArray);

        ChartSuggestionResponseDto responseDto = new ChartSuggestionResponseDto();
        KieSession kieSession = kiaSession("rules/charts.drl");
        kieSession.insert(requestDto);
        kieSession.setGlobal("responseDto", responseDto);
        kieSession.insert(requestDto);
        kieSession.fireAllRules();
        kieSession.dispose();

        List<ChartResponse> suggestedChart = new ArrayList<>();

        Map<Charts, String> charts = responseDto.getSuggestedCharts();
        if (!charts.isEmpty()) {
            suggestedChart = basedOnQueryComposeCharts(requestDto, charts,employeeData,attendanceDataSourceDtoList,departmentDataSourceDtoList);
            responseDto.setChartResponses(suggestedChart);
        } else {
            return new GenericResponse(HttpStatus.OK, "No Suggested Graphs");
        }
        return new GenericResponse(HttpStatus.OK, responseDto);
    }
    public static String[] convertUnderscoreToCamelCase(Set<String> columnNames) {
        Set<String> camelCaseColumnNames = new HashSet<>();

        for (String columnName : columnNames) {
            StringBuilder result = new StringBuilder();
            boolean capitalizeNext = false;

            for (char ch : columnName.toCharArray()) {
                if (ch == '_') {
                    capitalizeNext = true;
                } else {
                    result.append(capitalizeNext ? Character.toUpperCase(ch) : ch);
                    capitalizeNext = false;
                }
            }

            camelCaseColumnNames.add(result.toString());
        }

        return camelCaseColumnNames.toArray(new String[0]);
    }
    public List<Map<String, Object>> executeQuery(String entityClassName, String userQuery) {
        // Execute the user query
        Query query = entityManager.createNativeQuery(userQuery);

        // Result list will contain Object arrays for each row
        List<Object[]> resultList = query.getResultList();

        // Retrieve the column names from the query
        List<String> columnNames = getColumnNames(userQuery);

        // Convert the result to a list of maps using the actual column names
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object[] row : resultList) {
            Map<String, Object> rowMap = new HashMap<>();
            for (int i = 0; i < row.length && i < columnNames.size(); i++) {
                // Use the actual column names as keys
                rowMap.put(columnNames.get(i), row[i]);
                System.out.println(columnNames.get(i));
            }
            result.add(rowMap);
        }
        return result;
    }

    private List<String> getColumnNames(String userQuery) {
        String[] tokens = userQuery.split("\\s+");
        List<String> columnNames = new ArrayList<>();

        int selectIndex = -1;
        for (int i = 0; i < tokens.length; i++) {
            if ("SELECT".equalsIgnoreCase(tokens[i])) {
                selectIndex = i;
                break;
            }
        }

        // Collect column names after the SELECT keyword
        if (selectIndex != -1 && selectIndex < tokens.length - 1) {
            String columns = tokens[selectIndex + 1];
            // Assuming that the user specifies columns immediately after the SELECT keyword
            columnNames.addAll(Arrays.asList(columns.split(",")));
        }

        return columnNames;
    }

    @Override
    public List<Object[]> executeCustomQuery(String query) {
        Query nativeQuery = entityManager.createNativeQuery(query);
        return nativeQuery.getResultList();
    }
    @Override
    public List<ChartResponse> composeCharts(ChartSuggestionRequestDto requestDto, Map<Charts, String> chartsStringMap) {
        List<ChartResponse> chartResponses = new ArrayList<>();
        TableNames tableName = TableNames.valueOf(requestDto.getEntityClassName());
        String convertedString = tableName.toCamelCaseString();
        List<Object> dataSourceList = new ArrayList<>();
        List<EmployeeDataSource> result=new ArrayList<>();
        List<EmployeeDataSourceDto> employeeDataSourceList = new ArrayList<>();
        List<AttendanceDataSourceDto> attendanceDataSourceDtoList = new ArrayList<>();
        List<DepartmentDataSourceDto> departmentDataSourceDtoList = new ArrayList<>();
        if (convertedString.equals("EmployeeDataSource")) {
            employeeDataSourceList = EmployeeEntityToDto(employeeRepo.findAll());
            List<String> selectedColumns = Arrays.asList(requestDto.getSelectedColumns());
            employeeData(employeeDataSourceList, selectedColumns);
            dataSourceList = Collections.singletonList(employeeDataSourceList.stream().toList());

        }

        if (convertedString.equals("AttendanceDataSource")) {
            attendanceDataSourceDtoList = attendanceEntityToDto(attendanceDataRepo.findAll());
            List<String> selectedColumns = Arrays.asList(requestDto.getSelectedColumns());

            attendanceData(attendanceDataSourceDtoList, selectedColumns);

            dataSourceList = Collections.singletonList(attendanceDataSourceDtoList.stream().toList());
        }
        if (convertedString.equals("DepartmentDataSource")) {
            departmentDataSourceDtoList = departmentEntityToDto(departmentDataSourceRepo.findAll());
            List<String> selectedColumns = Arrays.asList(requestDto.getSelectedColumns());

            departmentData(departmentDataSourceDtoList, selectedColumns);

            dataSourceList = Collections.singletonList(departmentDataSourceDtoList.stream().toList());
        }
        chartResponses=chartsByQuery(chartsStringMap,employeeDataSourceList,attendanceDataSourceDtoList,departmentDataSourceDtoList,convertedString,dataSourceList);
        return chartResponses;
    }


    public List<ChartResponse> basedOnQueryComposeCharts(ChartSuggestionRequestDto requestDto, Map<Charts, String> chartsStringMap,List<EmployeeDataSourceDto> employeeDataSourceList,List<AttendanceDataSourceDto> attendanceDataSourceDtoList,List<DepartmentDataSourceDto> departmentDataSourceDtoList) {
        List<ChartResponse> chartResponses = new ArrayList<>();
        TableNames tableName = TableNames.valueOf(requestDto.getEntityClassName());
        String convertedString = tableName.toCamelCaseString();
        List<Object> dataSourceList = new ArrayList<>();
        if (convertedString.equals("EmployeeDataSource")) {
            List<String> selectedColumns = Arrays.asList(requestDto.getSelectedColumns());
            employeeData(employeeDataSourceList, selectedColumns);
            dataSourceList = Collections.singletonList(employeeDataSourceList.stream().toList());

        }

        if (convertedString.equals("AttendanceDataSource")) {
            List<String> selectedColumns = Arrays.asList(requestDto.getSelectedColumns());

            attendanceData(attendanceDataSourceDtoList, selectedColumns);

            dataSourceList = Collections.singletonList(attendanceDataSourceDtoList.stream().toList());
        }
        if (convertedString.equals("DepartmentDataSource")) {
            List<String> selectedColumns = Arrays.asList(requestDto.getSelectedColumns());

            departmentData(departmentDataSourceDtoList, selectedColumns);

            dataSourceList = Collections.singletonList(departmentDataSourceDtoList.stream().toList());
        }
       chartResponses= chartsByQuery(chartsStringMap, employeeDataSourceList, attendanceDataSourceDtoList, departmentDataSourceDtoList, convertedString, dataSourceList);
        return chartResponses;
    }

    private List<ChartResponse> chartsByQuery(Map<Charts, String> chartsStringMap, List<EmployeeDataSourceDto> employeeDataSourceList, List<AttendanceDataSourceDto> attendanceDataSourceDtoList, List<DepartmentDataSourceDto> departmentDataSourceDtoList, String convertedString, List<Object> dataSourceList) {
        List<ChartResponse> chartResponses = new ArrayList<>();

        for (Map.Entry<Charts, String> entry : chartsStringMap.entrySet()) {
            Charts chartType = entry.getKey();
            String chartData = entry.getValue();


            switch (chartType) {
                case AREA_CHART:
                    List <AreaChartResponse> areaChartResponse=new ArrayList<>();
                    areaChartResponse = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeAreaChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentAreaChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceAreaChartData(attendanceDataSourceDtoList);
                        default -> areaChartResponse;
                    };
                    chartResponses.add(new ChartResponse(chartType, areaChartResponse));
                    break;

                case TABLE_CHART:
                    chartResponses.add(new ChartResponse<>(chartType, dataSourceList.stream().toList()));
                    break;
                case BAR_CHART:
                    List<BarChartResponse> barChartResponses = new ArrayList<>();
                    barChartResponses = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeBarChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentBarChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceBarChartData(attendanceDataSourceDtoList);
                        default -> barChartResponses;
                    };
                    chartResponses.add(new ChartResponse(chartType, barChartResponses));
                    break;
                case PIE_CHART:
                    List<PieChartResponse> pieChartResponses = new ArrayList<>();
                    pieChartResponses = switch (convertedString) {
                        case "EmployeeDataSource" -> employeePieChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentPieChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendancePieChartData(attendanceDataSourceDtoList);
                        default -> pieChartResponses;
                    };
                    chartResponses.add(new ChartResponse(chartType, pieChartResponses));
                    break;
                case LINE_CHART:
                    List<LineChartResponse> lineChartResponses = new ArrayList<>();
                    lineChartResponses = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeLineChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentLineChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceLineChartData(attendanceDataSourceDtoList);
                        default -> lineChartResponses;
                    };
                    chartResponses.add(new ChartResponse(chartType, lineChartResponses));
                    break;
                case DONUT_CHART:
                    List<DonutChartResponse> donutChartResponses = new ArrayList<>();
                    donutChartResponses = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeDonutChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentDonutChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceDonutChartData(attendanceDataSourceDtoList);
                        default -> donutChartResponses;
                    };

                    chartResponses.add(new ChartResponse(chartType, donutChartResponses));
                    break;
                case FUNNEL_CHART:
                    List <FunnelChartResponse> funnelChartResponse=new ArrayList<>();
                    funnelChartResponse = switch (convertedString){
                        case "EmployeeDataSource" -> employeeFunnelChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentFunnelChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceFunnelChartData(attendanceDataSourceDtoList);
                        default -> funnelChartResponse;
                    };
                    chartResponses.add(new ChartResponse(chartType, funnelChartResponse));
                    break;
                case BUBBLE_CHART:
                    List<BubbleChartResponse> bubbleChartResponse=new ArrayList<>();
                    bubbleChartResponse = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeBubbleChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentBubbleChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceBubbleChartData(attendanceDataSourceDtoList);
                        default -> bubbleChartResponse;
                    };
                    chartResponses.add(new ChartResponse(chartType, bubbleChartResponse));
                    break;

                case DUAL_AXIS_CHART:
                    List<DualAxisChartResponse> dualAxisChartResponse=new ArrayList<>();
                    dualAxisChartResponse = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeDualAxisChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentDualAxisData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceDualAxisData(attendanceDataSourceDtoList);
                        default -> dualAxisChartResponse;
                    };
                    chartResponses.add(new ChartResponse(chartType, dualAxisChartResponse));
                    break;

                case CONNECTED_SCATTERPLOT:
                    List<ScatterPlotChartResponse> scatterPlotChartResponses = new ArrayList<>();
                    scatterPlotChartResponses = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeScatterPlotChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentScatterPlotChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceScatterPlotChartData(attendanceDataSourceDtoList);
                        default -> scatterPlotChartResponses;
                    };
                    chartResponses.add(new ChartResponse(chartType, scatterPlotChartResponses));
                    break;

                case GROUPED_BAR_CHART:
                    List<GroupedBarChartResponse> groupedBarChartResponses = new ArrayList<>();
                    groupedBarChartResponses = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeGroupedBarChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentGroupedBarChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceGroupedBarChartData(attendanceDataSourceDtoList);
                        default -> groupedBarChartResponses;
                    };
                    chartResponses.add(new ChartResponse(chartType, groupedBarChartResponses));
                    break;
                case STACKED_BAR_CHART:
                    List<StackedBarChartResponse> stackedBarChartResponses = new ArrayList<>();
                    stackedBarChartResponses = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeStackedBarChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentStackedBarChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceStackedBarChartData(attendanceDataSourceDtoList);
                        default -> stackedBarChartResponses;
                    };
                    chartResponses.add(new ChartResponse(chartType, stackedBarChartResponses));
                    break;


                    /*
                case MULTI_LINE_CHART:
                    MultiLineChartResponse multiLineChartResponse=new MultiLineChartResponse();
                    multiLineChartResponse.setMultiLineChartData(dataSourceList.stream().toList());
                    chartResponses.add(new ChartResponse(chartType, multiLineChartResponse));
                    break;*/


                case TREE_MAP:
                    List<TreeMapChartResponse> treeMapChartResponses = new ArrayList<>();
                    treeMapChartResponses = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeTreeChartData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentTreeChartData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceTreeChartData(attendanceDataSourceDtoList);
                        default -> treeMapChartResponses;
                    };
                    chartResponses.add(new ChartResponse(chartType, treeMapChartResponses));
                    break;
              /*  case SUN_BRUST:
                    SunBrustChartResponse sunBrustChartResponse=new SunBrustChartResponse();
                    sunBrustChartResponse.setSunBrustChartData(dataSourceList.stream().toList());
                    chartResponses.add(new ChartResponse<>(chartType,sunBrustChartResponse));
                    break;*/

                case BAR_CHART_AXIS:
                    List<BarChartAxisResponse> barChartAxisResponses = new ArrayList<>();
                    barChartAxisResponses = switch (convertedString) {
                        case "EmployeeDataSource" -> employeeBarChartAxisData(employeeDataSourceList);
                        case "DepartmentDataSource" -> departmentBarChartAxisData(departmentDataSourceDtoList);
                        case "AttendanceDataSource" -> attendanceBarCharAxisData(attendanceDataSourceDtoList);
                        default -> barChartAxisResponses;
                    };
                    chartResponses.add(new ChartResponse(chartType, barChartAxisResponses));
                    break;
                default:
                    break;

            }

        }
        return new ArrayList<>(chartResponses);
    }


    private static void employeeData(List<EmployeeDataSourceDto> employeeDataSourceList, List<String> selectedColumns) {
        for (EmployeeDataSourceDto employeeDto : employeeDataSourceList) {
            if (!selectedColumns.contains("id")) {
                employeeDto.setId(null);
            }
            if (!selectedColumns.contains("name")) {
                employeeDto.setName(null);
            }
            if (!selectedColumns.contains("salary")) {
                employeeDto.setSalary(null);
            }
            if (!selectedColumns.contains("doj")) {
                employeeDto.setDoj(null);
            }
            if (!selectedColumns.contains("resignedDate")) {
                employeeDto.setResignedDate(null);
            }
            if (!selectedColumns.contains("status")) {
                employeeDto.setStatus(null);
            }
            if (!selectedColumns.contains("attendanceCount")) {
                employeeDto.setAttendanceCount(null);
            }
            if (!selectedColumns.contains("noOfLeavesRemaining")) {
                employeeDto.setNoOfLeavesRemaining(null);
            }
            if (!selectedColumns.contains("rating")) {
                employeeDto.setRating(null);
            }
        }
    }

    private static void attendanceData(List<AttendanceDataSourceDto> attendanceDataSourceDtoList, List<String> selectedColumns) {
        for (AttendanceDataSourceDto attendanceDto : attendanceDataSourceDtoList) {
            if (!selectedColumns.contains("id")) {
                attendanceDto.setId(null);
            }
            if (!selectedColumns.contains("name")) {
                attendanceDto.setName(null);
            }
            if (!selectedColumns.contains("date")) {
                attendanceDto.setDate(null);
            }
            if (!selectedColumns.contains("isPresent")) {
                attendanceDto.setIsPresent(null);
            }
        }
    }

    private static void departmentData(List<DepartmentDataSourceDto> departmentDataSourceDtoList, List<String> selectedColumns) {
        for (DepartmentDataSourceDto departmentDto : departmentDataSourceDtoList) {
            if (!selectedColumns.contains("id")) {
                departmentDto.setId(null);
            }
            if (!selectedColumns.contains("departmentName")) {
                departmentDto.setDepartmentName(null);
            }
            if (!selectedColumns.contains("location")) {
                departmentDto.setLocation(null);
            }
            if (!selectedColumns.contains("employeeCount")) {
                departmentDto.setEmployeeCount(null);
            }
        }
    }

    public KieSession kiaSession(String rdlFile) {
        KieFileSystem kieFileSystem = getKieFileSystem(rdlFile);
        KieBuilder kieBuilder = KieServices.Factory.get().newKieBuilder(kieFileSystem);
        kieBuilder.buildAll();
        KieModule kieModule = kieBuilder.getKieModule();
        KieContainer kieContainer = KieServices.Factory.get().newKieContainer(kieModule.getReleaseId());
        KieSession kieSession = kieContainer.newKieSession();
        return kieSession;
    }

    private KieFileSystem getKieFileSystem(String rdlFile) {
        KieFileSystem kieFileSystem = KieServices.Factory.get().newKieFileSystem();
        kieFileSystem.write(ResourceFactory.newClassPathResource(rdlFile));
        return kieFileSystem;
    }


    public List<BarChartResponse> employeeBarChartData(List<EmployeeDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<BarChartResponse> barChartResponses = new ArrayList<>();
//        int i = 0;
        if (!objectList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : objectList) {
                BarChartResponse barChartResponse = new BarChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    barChartResponse.setValue(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    barChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    barChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null) {
                    barChartResponse.setValue(Math.round(employeeDataSourceDto.getSalary()));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    barChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    barChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null){
                    barChartResponse.setValue(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    barChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null){
                    barChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getRating()));
                }
                barChartResponse.setColor("#5249EB");
                barChartResponses.add(barChartResponse);
//                i++;
            }
        } else return new ArrayList<>();
        return barChartResponses;
    }

    public List<BarChartResponse> attendanceBarChartData(List<AttendanceDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<BarChartResponse> barChartResponses = new ArrayList<>();
        if (!objectList.isEmpty()) {
//            int i = 0;
            for (AttendanceDataSourceDto attendanceDataSourceDto : objectList) {
                BarChartResponse barChartResponse = new BarChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    barChartResponse.setValue(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    barChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    barChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    barChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                barChartResponse.setColor("#5249EB");
                barChartResponses.add(barChartResponse);
//                i++;
            }
        } else return new ArrayList<>();

        return barChartResponses;
    }

    public List<BarChartResponse> departmentBarChartData(List<DepartmentDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<BarChartResponse> barChartResponses = new ArrayList<>();
//        int i = 0;
        if (!objectList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : objectList) {
                BarChartResponse barChartResponse = new BarChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    barChartResponse.setValue(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    barChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    barChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    barChartResponse.setValue(departmentDataSourceDto.getEmployeeCount());
                }
                barChartResponse.setColor("#5249EB");
                barChartResponses.add(barChartResponse);
//                i++;
            }
        } else return new ArrayList<>();

        return barChartResponses;
    }

    public List<PieChartResponse> employeePieChartData(List<EmployeeDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<PieChartResponse> pieChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : objectList) {
                PieChartResponse pieChartResponse = new PieChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    pieChartResponse.setValue(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    pieChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    pieChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null) {
                    pieChartResponse.setValue(Math.round(employeeDataSourceDto.getSalary()));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    pieChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    pieChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null){
                    pieChartResponse.setValue(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    pieChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null){
                    pieChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getRating()));
                }
                pieChartResponse.setColor(chartColor.get(i).getColorCode());
                pieChartResponses.add(pieChartResponse);
                i++;
            }
        } else return new ArrayList<>();
        return pieChartResponses;
    }

    public List<PieChartResponse> attendancePieChartData(List<AttendanceDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<PieChartResponse> pieChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : objectList) {
                PieChartResponse pieChartResponse = new PieChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    pieChartResponse.setValue(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    pieChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    pieChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    pieChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                pieChartResponse.setColor(chartColor.get(i).getColorCode());
                pieChartResponses.add(pieChartResponse);
                i++;
            }
        } else return new ArrayList<>();

        return pieChartResponses;
    }

    public List<PieChartResponse> departmentPieChartData(List<DepartmentDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<PieChartResponse> pieChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : objectList) {
                PieChartResponse pieChartResponse = new PieChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    pieChartResponse.setValue(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    pieChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    pieChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    pieChartResponse.setValue(departmentDataSourceDto.getEmployeeCount());
                }
                pieChartResponse.setColor(chartColor.get(i).getColorCode());
                pieChartResponses.add(pieChartResponse);
                i++;
            }
        } else return new ArrayList<>();

        return pieChartResponses;
    }


    public List<LineChartResponse> employeeLineChartData(List<EmployeeDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<LineChartResponse> lineChartResponses = new ArrayList<>();
//        int i = 0;
        if (!objectList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : objectList) {
                LineChartResponse lineChartResponse = new LineChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    lineChartResponse.setValue(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    lineChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    lineChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null) {
                    lineChartResponse.setValue(Math.round(employeeDataSourceDto.getSalary()));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    lineChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    lineChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null){
                    lineChartResponse.setValue(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    lineChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null){
                    lineChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getRating()));
                }
                lineChartResponse.setColor("#5249EB");
                lineChartResponses.add(lineChartResponse);
//                i++;
            }
        } else return new ArrayList<>();
        return lineChartResponses;
    }

    public List<LineChartResponse> attendanceLineChartData(List<AttendanceDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<LineChartResponse> lineChartResponses = new ArrayList<>();
//        int i = 0;
        if (!objectList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : objectList) {
                LineChartResponse lineChartResponse = new LineChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    lineChartResponse.setValue(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    lineChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    lineChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    lineChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                lineChartResponse.setColor("#5249EB");
                lineChartResponses.add(lineChartResponse);
//                i++;
            }
        } else return new ArrayList<>();

        return lineChartResponses;
    }

    public List<LineChartResponse> departmentLineChartData(List<DepartmentDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<LineChartResponse> lineChartResponses = new ArrayList<>();
//        int i = 0;
        if (!objectList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : objectList) {
                LineChartResponse lineChartResponse = new LineChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    lineChartResponse.setValue(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    lineChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    lineChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    lineChartResponse.setValue(departmentDataSourceDto.getEmployeeCount());
                }
                lineChartResponse.setColor("#5249EB");
                lineChartResponses.add(lineChartResponse);
//                i++;
            }
        } else return new ArrayList<>();

        return lineChartResponses;
    }


    public List<DonutChartResponse> employeeDonutChartData(List<EmployeeDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<DonutChartResponse> donutChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : objectList) {
                DonutChartResponse donutChartResponse = new DonutChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    donutChartResponse.setValue(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    donutChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    donutChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null) {
                    donutChartResponse.setValue(Math.round(employeeDataSourceDto.getSalary()));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    donutChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    donutChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null){
                    donutChartResponse.setValue(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    donutChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null){
                    donutChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getRating()));
                }
                donutChartResponse.setColor(chartColor.get(i).getColorCode());
                donutChartResponses.add(donutChartResponse);
                i++;
            }
        } else return new ArrayList<>();
        return donutChartResponses;
    }

    public List<DonutChartResponse> attendanceDonutChartData(List<AttendanceDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<DonutChartResponse> donutChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : objectList) {
                DonutChartResponse donutChartResponse = new DonutChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    donutChartResponse.setValue(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    donutChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    donutChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    donutChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                donutChartResponse.setColor(chartColor.get(i).getColorCode());
                donutChartResponses.add(donutChartResponse);
                i++;
            }
        } else return new ArrayList<>();

        return donutChartResponses;
    }

    public List<DonutChartResponse> departmentDonutChartData(List<DepartmentDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<DonutChartResponse> donutChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : objectList) {
                DonutChartResponse donutChartResponse = new DonutChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    donutChartResponse.setValue(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    donutChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    donutChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    donutChartResponse.setValue(departmentDataSourceDto.getEmployeeCount());
                }
                donutChartResponse.setColor(chartColor.get(i).getColorCode());
                donutChartResponses.add(donutChartResponse);
                i++;
            }
        } else return new ArrayList<>();

        return donutChartResponses;
    }
    private List<FunnelChartResponse> employeeFunnelChartData(List<EmployeeDataSourceDto> employeeDataSourceList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<FunnelChartResponse> funnelChartResponses = new ArrayList<>();
        int i=0;
        if(!employeeDataSourceList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : employeeDataSourceList) {
                FunnelChartResponse funnelChartResponse = new FunnelChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    funnelChartResponse.setValue(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    funnelChartResponse.setLabel(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    funnelChartResponse.setLabel(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null) {
                    funnelChartResponse.setValue(Math.round(employeeDataSourceDto.getSalary()));
                }
                if(employeeDataSourceDto.getDoj()!= null){
                    funnelChartResponse.setLabel(dateToString(employeeDataSourceDto.getDoj()));
                }if(employeeDataSourceDto.getResignedDate()!= null){
                    funnelChartResponse.setLabel(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null){
                    funnelChartResponse.setValue(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    funnelChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null){
                    funnelChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getRating()));
                }
                funnelChartResponse.setColor(chartColor.get(i).getColorCode());
                funnelChartResponses.add(funnelChartResponse);
                i++;
            }
        }else return new ArrayList<>();
        return funnelChartResponses;
    }
    private List<FunnelChartResponse> attendanceFunnelChartData(List<AttendanceDataSourceDto> attendanceDataSourceDtoList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<FunnelChartResponse> funnelChartResponses = new ArrayList<>();
        int i=0;
        if(!attendanceDataSourceDtoList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : attendanceDataSourceDtoList) {
                FunnelChartResponse funnelChartResponse = new FunnelChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    funnelChartResponse.setValue(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    funnelChartResponse.setLabel(attendanceDataSourceDto.getName());
                }
                if(attendanceDataSourceDto.getDate()!= null){
                    funnelChartResponse.setLabel(dateToString(attendanceDataSourceDto.getDate()));
                }if(attendanceDataSourceDto.getIsPresent()!= null){
                    funnelChartResponse.setLabel(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                funnelChartResponse.setColor(chartColor.get(i).getColorCode());
                funnelChartResponses.add(funnelChartResponse);
                i++;
            }
        }else return new ArrayList<>();

        return funnelChartResponses;
    }


    private List<FunnelChartResponse> departmentFunnelChartData(List<DepartmentDataSourceDto> departmentDataSourceDtoList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<FunnelChartResponse> funnelChartResponses = new ArrayList<>();
        int i=0;
        if(!departmentDataSourceDtoList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : departmentDataSourceDtoList) {
                FunnelChartResponse funnelChartResponse = new FunnelChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    funnelChartResponse.setValue(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    funnelChartResponse.setLabel(departmentDataSourceDto.getDepartmentName());
                }
                if(departmentDataSourceDto.getLocation()!= null){
                    funnelChartResponse.setLabel(departmentDataSourceDto.getLocation());
                }
                if(departmentDataSourceDto.getEmployeeCount()!= null){
                    funnelChartResponse.setValue(departmentDataSourceDto.getEmployeeCount());
                }
                funnelChartResponse.setColor(chartColor.get(i).getColorCode());
                funnelChartResponses.add(funnelChartResponse);
                i++;
            }
        }else return new ArrayList<>();

        return funnelChartResponses;
    }
    private List<BubbleChartResponse> employeeBubbleChartData(List<EmployeeDataSourceDto> employeeDataSourceList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<BubbleChartResponse> bubbleChartResponses = new ArrayList<>();
        int i=0;
        if(!employeeDataSourceList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : employeeDataSourceList) {
                BubbleChartResponse bubbleChartResponse = new BubbleChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    bubbleChartResponse.setValue(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    bubbleChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    bubbleChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null) {
                    bubbleChartResponse.setValue(Math.round(employeeDataSourceDto.getSalary()));
                }
                if(employeeDataSourceDto.getDoj()!= null){
                    bubbleChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }if(employeeDataSourceDto.getResignedDate()!= null){
                    bubbleChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null){
                    bubbleChartResponse.setValue(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    bubbleChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null){
                    bubbleChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getRating()));
                }
                bubbleChartResponse.setColor(chartColor.get(i).getColorCode());
                bubbleChartResponses.add(bubbleChartResponse);
                i++;
            }
        }else return new ArrayList<>();
        return bubbleChartResponses;
    }
    private List<BubbleChartResponse> attendanceBubbleChartData(List<AttendanceDataSourceDto> attendanceDataSourceDtoList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<BubbleChartResponse> bubbleChartResponses = new ArrayList<>();
        int i=0;
        if(!attendanceDataSourceDtoList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : attendanceDataSourceDtoList) {
                BubbleChartResponse bubbleChartResponse = new BubbleChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    bubbleChartResponse.setValue(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    bubbleChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if(attendanceDataSourceDto.getDate()!= null){
                    bubbleChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }if(attendanceDataSourceDto.getIsPresent()!= null){
                    bubbleChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                bubbleChartResponse.setColor(chartColor.get(i).getColorCode());
                bubbleChartResponses.add(bubbleChartResponse);
                i++;
            }
        }else return new ArrayList<>();

        return bubbleChartResponses;
    }

    private List<BubbleChartResponse> departmentBubbleChartData(List<DepartmentDataSourceDto> departmentDataSourceDtoList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<BubbleChartResponse> bubbleChartResponses = new ArrayList<>();
        int i=0;
        if(!departmentDataSourceDtoList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : departmentDataSourceDtoList) {
                BubbleChartResponse bubbleChartResponse = new BubbleChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    bubbleChartResponse.setValue(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    bubbleChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if(departmentDataSourceDto.getLocation()!= null){
                    bubbleChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if(departmentDataSourceDto.getEmployeeCount()!= null){
                    bubbleChartResponse.setValue(departmentDataSourceDto.getEmployeeCount());
                }
                bubbleChartResponse.setColor(chartColor.get(i).getColorCode());
                bubbleChartResponses.add(bubbleChartResponse);
                i++;
            }
        }else return new ArrayList<>();

        return bubbleChartResponses;
    }


    public List<ScatterPlotChartResponse> employeeScatterPlotChartData(List<EmployeeDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<ScatterPlotChartResponse> scatterPlotChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : objectList) {
                ScatterPlotChartResponse scatterPlotChartResponse = new ScatterPlotChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    scatterPlotChartResponse.setValueOne(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    scatterPlotChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    scatterPlotChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null && scatterPlotChartResponse.getValueOne()!=null) {
                    scatterPlotChartResponse.setValueTwo(Math.round(employeeDataSourceDto.getSalary()));
                } else if(employeeDataSourceDto.getSalary() != null){
                    scatterPlotChartResponse.setValueOne(Math.round(employeeDataSourceDto.getSalary()));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    scatterPlotChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    scatterPlotChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null && scatterPlotChartResponse.getValueOne()!=null){
                    scatterPlotChartResponse.setValueTwo(employeeDataSourceDto.getAttendanceCount());
                }else if(employeeDataSourceDto.getAttendanceCount()!=null && scatterPlotChartResponse.getValueTwo()!=null){
                    scatterPlotChartResponse.setValueThree(employeeDataSourceDto.getAttendanceCount());
                }else if(employeeDataSourceDto.getAttendanceCount() !=null){
                    scatterPlotChartResponse.setValueOne(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null && scatterPlotChartResponse.getValueOne()!=null){
                    scatterPlotChartResponse.setValueTwo(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }else if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null && scatterPlotChartResponse.getValueTwo()!=null){
                    scatterPlotChartResponse.setValueThree(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }else if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    scatterPlotChartResponse.setValueOne(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null && scatterPlotChartResponse.getValueTwo()!=null) {
                    scatterPlotChartResponse.setValueThree(Long.valueOf(employeeDataSourceDto.getRating()));
                }
//                }else if(employeeDataSourceDto.getRating()!=null && scatterPlotChartResponse.getValueTwo()!=null){
//                    scatterPlotChartResponse.setValueThree(Long.valueOf(employeeDataSourceDto.getRating()));
//                }else if(employeeDataSourceDto.getRating()!=null){
//                    scatterPlotChartResponse.setValueOne(Long.valueOf(employeeDataSourceDto.getRating()));
//                }
                scatterPlotChartResponse.setColor(chartColor.get(i).getColorCode());
                scatterPlotChartResponses.add(scatterPlotChartResponse);
                i++;
            }
        } else return new ArrayList<>();
        return scatterPlotChartResponses;
    }

    public List<ScatterPlotChartResponse> attendanceScatterPlotChartData(List<AttendanceDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<ScatterPlotChartResponse> scatterPlotChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : objectList) {
                ScatterPlotChartResponse scatterPlotChartResponse = new ScatterPlotChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    scatterPlotChartResponse.setValueOne(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    scatterPlotChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    scatterPlotChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    scatterPlotChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                scatterPlotChartResponse.setColor(chartColor.get(i).getColorCode());
                scatterPlotChartResponses.add(scatterPlotChartResponse);
                i++;
            }
        } else return new ArrayList<>();

        return scatterPlotChartResponses;
    }

    public List<ScatterPlotChartResponse> departmentScatterPlotChartData(List<DepartmentDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<ScatterPlotChartResponse> scatterPlotChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : objectList) {
                ScatterPlotChartResponse scatterPlotChartResponse = new ScatterPlotChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    scatterPlotChartResponse.setValueOne(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    scatterPlotChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    scatterPlotChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    scatterPlotChartResponse.setValueTwo(departmentDataSourceDto.getEmployeeCount());
                }
                scatterPlotChartResponse.setColor(chartColor.get(i).getColorCode());
                scatterPlotChartResponses.add(scatterPlotChartResponse);
                i++;
            }
        } else return new ArrayList<>();

        return scatterPlotChartResponses;
    }

    public List<StackedBarChartResponse> employeeStackedBarChartData(List<EmployeeDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<StackedBarChartResponse> stackedBarChartResponses = new ArrayList<>();

        int i = 0;
        if (!objectList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : objectList) {
                StackedBarChartResponse stackedBarChartResponse = new StackedBarChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    stackedBarChartResponse.setValueOne(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    stackedBarChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    stackedBarChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null && stackedBarChartResponse.getValueOne()!=null) {
                    stackedBarChartResponse.setValueTwo(Math.round(employeeDataSourceDto.getSalary()));
                } else if(employeeDataSourceDto.getSalary() != null){
                    stackedBarChartResponse.setValueOne(Math.round(employeeDataSourceDto.getSalary()));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    stackedBarChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    stackedBarChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null && stackedBarChartResponse.getValueOne()!=null){
                    stackedBarChartResponse.setValueTwo(employeeDataSourceDto.getAttendanceCount());
                }else if(employeeDataSourceDto.getAttendanceCount()!=null && stackedBarChartResponse.getValueTwo()!=null){
                    stackedBarChartResponse.setValueThree(employeeDataSourceDto.getAttendanceCount());
                }else if(employeeDataSourceDto.getAttendanceCount() !=null){
                    stackedBarChartResponse.setValueOne(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null && stackedBarChartResponse.getValueOne()!=null){
                    stackedBarChartResponse.setValueTwo(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }else if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null && stackedBarChartResponse.getValueTwo()!=null){
                    stackedBarChartResponse.setValueThree(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }else if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    stackedBarChartResponse.setValueOne(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null && stackedBarChartResponse.getValueTwo()!=null){
                    stackedBarChartResponse.setValueThree(Long.valueOf(employeeDataSourceDto.getRating()));
                }
//                else if(employeeDataSourceDto.getRating()!=null && stackedBarChartResponse.getValueTwo()!=null){
//                    stackedBarChartResponse.setValueThree(Long.valueOf(employeeDataSourceDto.getRating()));
//                }else if(employeeDataSourceDto.getRating()!=null){
//                    stackedBarChartResponse.setValueOne(Long.valueOf(employeeDataSourceDto.getRating()));
//                }
                stackedBarChartResponse.setColor(chartColor.get(i).getColorCode());
                stackedBarChartResponses.add(stackedBarChartResponse);
                i++;
            }
        } else return new ArrayList<>();
        return stackedBarChartResponses;
    }

    public List<StackedBarChartResponse> attendanceStackedBarChartData(List<AttendanceDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<StackedBarChartResponse> stackedBarChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : objectList) {
                StackedBarChartResponse stackedBarChartResponse = new StackedBarChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    stackedBarChartResponse.setValueOne(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    stackedBarChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    stackedBarChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    stackedBarChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                stackedBarChartResponse.setColor(chartColor.get(i).getColorCode());
                stackedBarChartResponses.add(stackedBarChartResponse);
                i++;

            }
        } else return new ArrayList<>();

        return stackedBarChartResponses;
    }

    public List<StackedBarChartResponse> departmentStackedBarChartData(List<DepartmentDataSourceDto> objectList) {
        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<StackedBarChartResponse> stackedBarChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : objectList) {
                StackedBarChartResponse stackedBarChartResponse = new StackedBarChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    stackedBarChartResponse.setValueOne(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    stackedBarChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    stackedBarChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    stackedBarChartResponse.setValueTwo(departmentDataSourceDto.getEmployeeCount());
                }
                stackedBarChartResponse.setColor(chartColor.get(i).getColorCode());
                stackedBarChartResponses.add(stackedBarChartResponse);
                i++;
            }
        } else return new ArrayList<>();

        return stackedBarChartResponses;
    }
    private List<DualAxisChartResponse> employeeDualAxisChartData(List<EmployeeDataSourceDto> employeeDataSourceList) {
        List<DualAxisChartResponse> dualAxisChartResponses = new ArrayList<>();
        if (!employeeDataSourceList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : employeeDataSourceList) {
                DualAxisChartResponse dualAxisChartResponse = new DualAxisChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    dualAxisChartResponse.setCountForLineGraph(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    dualAxisChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    dualAxisChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null && dualAxisChartResponse.getCountForLineGraph()!=null) {
                    dualAxisChartResponse.setCountForBarGraph(Math.round(employeeDataSourceDto.getSalary()));
                } else if (employeeDataSourceDto.getSalary()!=null) {
                    dualAxisChartResponse.setCountForLineGraph(Math.round(employeeDataSourceDto.getSalary()));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    dualAxisChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    dualAxisChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null && dualAxisChartResponse.getCountForLineGraph()!=null){
                    dualAxisChartResponse.setCountForBarGraph(employeeDataSourceDto.getAttendanceCount());
                }else if(employeeDataSourceDto.getAttendanceCount()!=null){
                    dualAxisChartResponse.setCountForLineGraph(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null && dualAxisChartResponse.getCountForLineGraph()!=null){
                    dualAxisChartResponse.setCountForBarGraph(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }else if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    dualAxisChartResponse.setCountForLineGraph(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null && dualAxisChartResponse.getCountForBarGraph()!=null){
                    dualAxisChartResponse.setCountForBarGraph(Long.valueOf(employeeDataSourceDto.getRating()));
                }else if(employeeDataSourceDto.getRating()!=null ){
                    dualAxisChartResponse.setCountForLineGraph(Long.valueOf(employeeDataSourceDto.getRating()));
                }
                dualAxisChartResponse.setColorForLineGraph("#36CB79");
                dualAxisChartResponse.setColorForBarGraph("#5249EB");
                dualAxisChartResponses.add(dualAxisChartResponse);

            }
        } else return new ArrayList<>();
        return dualAxisChartResponses;
    }

    private List<DualAxisChartResponse> attendanceDualAxisData(List<AttendanceDataSourceDto> attendanceDataSourceDtoList) {
        List<DualAxisChartResponse> dualAxisChartResponses = new ArrayList<>();
        if (!attendanceDataSourceDtoList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : attendanceDataSourceDtoList) {
                DualAxisChartResponse dualAxisChartResponse = new DualAxisChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    dualAxisChartResponse.setCountForLineGraph(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    dualAxisChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    dualAxisChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    dualAxisChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                dualAxisChartResponse.setColorForLineGraph("#36CB79");
                dualAxisChartResponse.setColorForBarGraph("#5249EB");
                dualAxisChartResponses.add(dualAxisChartResponse);
            }
        } else return new ArrayList<>();

        return dualAxisChartResponses;
    }

    private List<DualAxisChartResponse> departmentDualAxisData(List<DepartmentDataSourceDto> departmentDataSourceDtoList) {
        List<DualAxisChartResponse> dualAxisChartResponses = new ArrayList<>();
        if (!departmentDataSourceDtoList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : departmentDataSourceDtoList) {
                DualAxisChartResponse dualAxisChartResponse = new DualAxisChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    dualAxisChartResponse.setCountForLineGraph(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    dualAxisChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    dualAxisChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    dualAxisChartResponse.setCountForBarGraph(departmentDataSourceDto.getEmployeeCount());
                }
                dualAxisChartResponse.setColorForLineGraph("#36CB79");
                dualAxisChartResponse.setColorForBarGraph("#5249EB");
                dualAxisChartResponses.add(dualAxisChartResponse);
            }
        } else return new ArrayList<>();

        return dualAxisChartResponses;
    }
    public List<GroupedBarChartResponse> employeeGroupedBarChartData(List<EmployeeDataSourceDto> objectList) {

        List<GroupedBarChartResponse> groupedBarChartResponses = new ArrayList<>();
        if (!objectList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : objectList) {
                GroupedBarChartResponse groupedBarChartResponse = new GroupedBarChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    groupedBarChartResponse.setValueOne(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    groupedBarChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    groupedBarChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null && groupedBarChartResponse.getValueOne()!=null) {
                    groupedBarChartResponse.setValueTwo(Math.round(employeeDataSourceDto.getSalary()));
                } else if(employeeDataSourceDto.getSalary() != null){
                    groupedBarChartResponse.setValueOne(Math.round(employeeDataSourceDto.getSalary()));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    groupedBarChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    groupedBarChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null && groupedBarChartResponse.getValueOne()!=null){
                    groupedBarChartResponse.setValueTwo(employeeDataSourceDto.getAttendanceCount());
                }else if(employeeDataSourceDto.getAttendanceCount()!=null && groupedBarChartResponse.getValueTwo()!=null){
                    groupedBarChartResponse.setValueThree(employeeDataSourceDto.getAttendanceCount());
                }else if(employeeDataSourceDto.getAttendanceCount() !=null){
                    groupedBarChartResponse.setValueOne(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null && groupedBarChartResponse.getValueOne()!=null){
                    groupedBarChartResponse.setValueTwo(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }else if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null && groupedBarChartResponse.getValueTwo()!=null){
                    groupedBarChartResponse.setValueThree(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }else if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    groupedBarChartResponse.setValueOne(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null && groupedBarChartResponse.getValueTwo()!=null){
                    groupedBarChartResponse.setValueThree(Long.valueOf(employeeDataSourceDto.getRating()));
                }
//                else if(employeeDataSourceDto.getRating()!=null && groupedBarChartResponse.getValueTwo()!=null){
//                    groupedBarChartResponse.setValueThree(Long.valueOf(employeeDataSourceDto.getRating()));
//                }else if(employeeDataSourceDto.getRating()!=null){
//                    groupedBarChartResponse.setValueOne(Long.valueOf(employeeDataSourceDto.getRating()));
//                }
                groupedBarChartResponses.add(groupedBarChartResponse);

            }
        } else return new ArrayList<>();
        return groupedBarChartResponses;
    }

    public List<GroupedBarChartResponse> attendanceGroupedBarChartData(List<AttendanceDataSourceDto> objectList) {
        List<GroupedBarChartResponse> groupedBarChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : objectList) {
                GroupedBarChartResponse groupedBarChartResponse = new GroupedBarChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    groupedBarChartResponse.setValueOne(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    groupedBarChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    groupedBarChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    groupedBarChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                groupedBarChartResponses.add(groupedBarChartResponse);


            }
        } else return new ArrayList<>();

        return groupedBarChartResponses;
    }

    public List<GroupedBarChartResponse> departmentGroupedBarChartData(List<DepartmentDataSourceDto> objectList) {
        List<GroupedBarChartResponse> groupedBarChartResponses = new ArrayList<>();
        int i = 0;
        if (!objectList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : objectList) {
                GroupedBarChartResponse groupedBarChartResponse = new GroupedBarChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    groupedBarChartResponse.setValueOne(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    groupedBarChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    groupedBarChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    groupedBarChartResponse.setValueTwo(departmentDataSourceDto.getEmployeeCount());
                }
                groupedBarChartResponses.add(groupedBarChartResponse);
            }
        } else return new ArrayList<>();

        return groupedBarChartResponses;
    }

    public List<TreeMapChartResponse> employeeTreeChartData(List<EmployeeDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<TreeMapChartResponse> treeMapChartResponses = new ArrayList<>();
//        int i = 0;
        if (!objectList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : objectList) {
                TreeMapChartResponse treeMapChartResponse = new TreeMapChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    treeMapChartResponse.setValue(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    treeMapChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    treeMapChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null) {
                    treeMapChartResponse.setValue(Math.round(employeeDataSourceDto.getSalary()));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    treeMapChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    treeMapChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                treeMapChartResponse.setColor("#5249EB");
                treeMapChartResponses.add(treeMapChartResponse);
//                i++;
            }
        } else return new ArrayList<>();
        return treeMapChartResponses;
    }

    public List<TreeMapChartResponse> attendanceTreeChartData(List<AttendanceDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<TreeMapChartResponse> treeMapChartResponses = new ArrayList<>();
//        int i = 0;
        if (!objectList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : objectList) {
                TreeMapChartResponse treeMapChartResponse = new TreeMapChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    treeMapChartResponse.setValue(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    treeMapChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    treeMapChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    treeMapChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                treeMapChartResponse.setColor("#5249EB");
                treeMapChartResponses.add(treeMapChartResponse);
//                i++;
            }
        } else return new ArrayList<>();

        return treeMapChartResponses;
    }

    public List<TreeMapChartResponse> departmentTreeChartData(List<DepartmentDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<TreeMapChartResponse> treeMapChartResponses = new ArrayList<>();
//        int i = 0;
        if (!objectList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : objectList) {
                TreeMapChartResponse treeMapChartResponse = new TreeMapChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    treeMapChartResponse.setValue(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    treeMapChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    treeMapChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    treeMapChartResponse.setValue(departmentDataSourceDto.getEmployeeCount());
                }
                treeMapChartResponse.setColor("#5249EB");
                treeMapChartResponses.add(treeMapChartResponse);
//                i++;
            }
        } else return new ArrayList<>();

        return treeMapChartResponses;
    }


    private List<AreaChartResponse> employeeAreaChartData(List<EmployeeDataSourceDto> employeeDataSourceList) {
        List<AreaChartResponse> areaChartResponses = new ArrayList<>();

        if (!employeeDataSourceList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : employeeDataSourceList) {
                AreaChartResponse areaChartResponse = new AreaChartResponse();
                if (employeeDataSourceDto.getId() != null) {
                    areaChartResponse.setName(String.valueOf(employeeDataSourceDto.getId()));
                }
                if (employeeDataSourceDto.getName() != null) {
                    areaChartResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    areaChartResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null && areaChartResponse.getName()!=null) {
                    areaChartResponse.setValue(Math.round(employeeDataSourceDto.getSalary()));
                }else if(employeeDataSourceDto.getSalary() != null) {
                    areaChartResponse.setName(String.valueOf(Math.round(employeeDataSourceDto.getSalary())));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    areaChartResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    areaChartResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null && areaChartResponse.getName()!=null){
                    areaChartResponse.setValue(employeeDataSourceDto.getAttendanceCount());
                } else if (employeeDataSourceDto.getAttendanceCount() != null) {
                    areaChartResponse.setName(String.valueOf(employeeDataSourceDto.getAttendanceCount()));

                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null && areaChartResponse.getName()!=null){
                    areaChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                } else if (employeeDataSourceDto.getNoOfLeavesRemaining() != null) {
                    areaChartResponse.setName(String.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null && areaChartResponse.getName()!=null){
                    areaChartResponse.setValue(Long.valueOf(employeeDataSourceDto.getRating()));
                } else if (employeeDataSourceDto.getRating()!=null) {
                   areaChartResponse.setName(String.valueOf(employeeDataSourceDto.getRating()));
                }
                areaChartResponses.add(areaChartResponse);
            }
        } else return new ArrayList<>();
        return areaChartResponses;
    }

    private List<AreaChartResponse> attendanceAreaChartData(List<AttendanceDataSourceDto> attendanceDataSourceDtoList) {
        List<AreaChartResponse> areaChartResponses = new ArrayList<>();
        if (!attendanceDataSourceDtoList.isEmpty()) {
            for (AttendanceDataSourceDto attendanceDataSourceDto : attendanceDataSourceDtoList) {
                AreaChartResponse areaChartResponse = new AreaChartResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    areaChartResponse.setName(String.valueOf(attendanceDataSourceDto.getId()));
                }
                if (attendanceDataSourceDto.getName() != null) {
                    areaChartResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    areaChartResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    areaChartResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                areaChartResponses.add(areaChartResponse);

            }
        } else return new ArrayList<>();

        return areaChartResponses;
    }

    private List<AreaChartResponse> departmentAreaChartData(List<DepartmentDataSourceDto> departmentDataSourceDtoList) {
        List<AreaChartResponse> areaChartResponses = new ArrayList<>();
        if (!departmentDataSourceDtoList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : departmentDataSourceDtoList) {
                AreaChartResponse areaChartResponse = new AreaChartResponse();
                if (departmentDataSourceDto.getId() != null) {
                    areaChartResponse.setName(String.valueOf(departmentDataSourceDto.getId()));
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    areaChartResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    areaChartResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    areaChartResponse.setValue(departmentDataSourceDto.getEmployeeCount());
                }
                areaChartResponses.add(areaChartResponse);
            }
        } else return new ArrayList<>();

        return areaChartResponses;
    }

    public List<BarChartAxisResponse> employeeBarChartAxisData(List<EmployeeDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<BarChartAxisResponse> barChartAxisResponses = new ArrayList<>();
//        int i = 0;
        if (!objectList.isEmpty()) {
            for (EmployeeDataSourceDto employeeDataSourceDto : objectList) {
                BarChartAxisResponse barChartAxisResponse = new BarChartAxisResponse();
                if (employeeDataSourceDto.getId() != null) {
                    barChartAxisResponse.setValue(employeeDataSourceDto.getId());
                }
                if (employeeDataSourceDto.getName() != null) {
                    barChartAxisResponse.setName(employeeDataSourceDto.getName());
                }
                if (employeeDataSourceDto.getStatus() != null) {
                    barChartAxisResponse.setName(employeeDataSourceDto.getStatus());
                }
                if (employeeDataSourceDto.getSalary() != null) {
                    barChartAxisResponse.setValue(Math.round(employeeDataSourceDto.getSalary()));
                }
                if (employeeDataSourceDto.getDoj() != null) {
                    barChartAxisResponse.setName(dateToString(employeeDataSourceDto.getDoj()));
                }
                if (employeeDataSourceDto.getResignedDate() != null) {
                    barChartAxisResponse.setName(dateToString(employeeDataSourceDto.getResignedDate()));
                }
                if(employeeDataSourceDto.getAttendanceCount()!=null){
                    barChartAxisResponse.setValue(employeeDataSourceDto.getAttendanceCount());
                }
                if(employeeDataSourceDto.getNoOfLeavesRemaining()!=null){
                    barChartAxisResponse.setValue(Long.valueOf(employeeDataSourceDto.getNoOfLeavesRemaining()));
                }
                if(employeeDataSourceDto.getRating()!=null){
                    barChartAxisResponse.setValue(Long.valueOf(employeeDataSourceDto.getRating()));
                }
                barChartAxisResponse.setColor("#5249EB");
                barChartAxisResponses.add(barChartAxisResponse);
//                i++;
            }
        } else return new ArrayList<>();
        return barChartAxisResponses;
    }

    public List<BarChartAxisResponse> attendanceBarCharAxisData(List<AttendanceDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<BarChartAxisResponse> barChartAxisResponses = new ArrayList<>();
        if (!objectList.isEmpty()) {
//            int i = 0;
            for (AttendanceDataSourceDto attendanceDataSourceDto : objectList) {
                BarChartAxisResponse barChartAxisResponse = new BarChartAxisResponse();
                if (attendanceDataSourceDto.getId() != null) {
                    barChartAxisResponse.setValue(attendanceDataSourceDto.getId());
                }
                if (attendanceDataSourceDto.getName() != null) {
                    barChartAxisResponse.setName(attendanceDataSourceDto.getName());
                }
                if (attendanceDataSourceDto.getDate() != null) {
                    barChartAxisResponse.setName(dateToString(attendanceDataSourceDto.getDate()));
                }
                if (attendanceDataSourceDto.getIsPresent() != null) {
                    barChartAxisResponse.setName(String.valueOf(attendanceDataSourceDto.getIsPresent()));
                }
                barChartAxisResponse.setColor("#5249EB");
                barChartAxisResponses.add(barChartAxisResponse);
//                i++;
            }
        } else return new ArrayList<>();


        return barChartAxisResponses;
    }

    public List<BarChartAxisResponse> departmentBarChartAxisData(List<DepartmentDataSourceDto> objectList) {
//        List<ChartColor> chartColor = chartColorRepo.findAll();
        List<BarChartAxisResponse> barChartAxisResponses = new ArrayList<>();
//        int i = 0;
        if (!objectList.isEmpty()) {
            for (DepartmentDataSourceDto departmentDataSourceDto : objectList) {
                BarChartAxisResponse barChartAxisResponse = new BarChartAxisResponse();
                if (departmentDataSourceDto.getId() != null) {
                    barChartAxisResponse.setValue(departmentDataSourceDto.getId());
                }
                if (departmentDataSourceDto.getDepartmentName() != null) {
                    barChartAxisResponse.setName(departmentDataSourceDto.getDepartmentName());
                }
                if (departmentDataSourceDto.getLocation() != null) {
                    barChartAxisResponse.setName(departmentDataSourceDto.getLocation());
                }
                if (departmentDataSourceDto.getEmployeeCount() != null) {
                    barChartAxisResponse.setValue(departmentDataSourceDto.getEmployeeCount());
                }
                barChartAxisResponse.setColor("#5249EB");
                barChartAxisResponses.add(barChartAxisResponse);
//                i++;
            }
        } else return new ArrayList<>();

        return barChartAxisResponses;
    }

    public String dateToString(Date date) {
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        return dateFormat.format(date);
    }

}
