package com.net.thrymr.qh_cc_poc.enums;

public enum TableNames {
    ATTENDANCE_DATA_SOURCE,
    DEPARTMENT_DATA_SOURCE,
    EMPLOYEE_DATA_SOURCE;

    public static String[] getAllTableNames() {
        TableNames[] tableNames = values();
        String[] tableNamesAsString = new String[tableNames.length];

        for (int i = 0; i < tableNames.length; i++) {
            tableNamesAsString[i] = tableNames[i].toString();
        }

        return tableNamesAsString;
    }
    public String toCamelCaseString() {
        String[] parts = name().toLowerCase().split("_");
        StringBuilder camelCase = new StringBuilder();
        for (String part : parts) {
            camelCase.append(part.substring(0, 1).toUpperCase()).append(part.substring(1));
        }
        return camelCase.toString();
    }

}
