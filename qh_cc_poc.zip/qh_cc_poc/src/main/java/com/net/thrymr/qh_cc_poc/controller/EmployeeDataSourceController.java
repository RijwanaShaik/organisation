package com.net.thrymr.qh_cc_poc.controller;

import com.net.thrymr.qh_cc_poc.dto.ChartSuggestionRequestDto;
import com.net.thrymr.qh_cc_poc.dto.EmployeeDataSourceDto;
import com.net.thrymr.qh_cc_poc.response.GenericResponse;
import com.net.thrymr.qh_cc_poc.service.EmployeeDataSourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RestController
@RequestMapping("/api/v1/employee")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class EmployeeDataSourceController {
    @Autowired
    private EmployeeDataSourceService employeeDataSourceService;
    @PostMapping("/executeQuery")
    public List<EmployeeDataSourceDto> executeQuery(@RequestBody ChartSuggestionRequestDto requestDto) throws SQLException {
        return employeeDataSourceService.executeUserQuery(requestDto.getUserQuery());
    }
}
