package com.net.thrymr.qh_cc_poc.enums;

public enum DataType {
    CONTINUOUS,
    DISCRETE,
}
