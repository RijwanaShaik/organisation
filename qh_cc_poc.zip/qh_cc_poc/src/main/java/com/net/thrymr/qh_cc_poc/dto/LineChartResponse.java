package com.net.thrymr.qh_cc_poc.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
public class LineChartResponse {


    private Long value;
    private String name, color;
}
