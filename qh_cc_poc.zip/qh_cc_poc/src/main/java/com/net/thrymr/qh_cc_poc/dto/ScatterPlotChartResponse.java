package com.net.thrymr.qh_cc_poc.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ScatterPlotChartResponse {


  private Long  valueOne, valueTwo,valueThree;
    private String name, color;
}
