package com.net.thrymr.qh_cc_poc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QhCcPocApplicationTests {

	@Test
	void contextLoads() {
	}

}
