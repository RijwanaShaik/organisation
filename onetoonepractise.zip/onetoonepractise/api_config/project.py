from typing import List
from fastapi import APIRouter, Depends, HTTPException,status
from database_config.database import get_db
from responseDto import responseClass
from sqlalchemy.orm import Session
from loggers_config.file_log import logger
from schema import models

router =APIRouter(tags=['Project'])

def create_project(db:Session, project: responseClass.ProjectCreate):
    db_project=models.Project(**project.dict())
    db.add(db_project)
    db.commit()
    db.refresh(db_project)
    return db_project

@router.post("/projects/", response_model= responseClass.Project)
def create_project_endpoint(project:responseClass.ProjectCreate,db: Session = Depends(get_db)):
    return create_project(db,project)

def assign_project(db: Session, aadhar_id: int, project_id: int):
    aadhar_details = db.query(models.AadharDetails).filter(models.AadharDetails.id == aadhar_id).first() # Query profile by ID
    if not aadhar_details:
        raise HTTPException(status_code=404, detail="Profile not found")
    projects = db.query(models.Project).filter(models.Project.id == project_id).first() # Query project by ID
    if not projects:
        raise HTTPException(status_code=404, detail="Project not found") # Append project to profile's projects
    aadhar_details.project.append(projects)
    db.commit()
    return {"message": "Project assigned to profile successfully"}

@router.post("/aadhar/{aadhar_id}/projects/{project_id}")
def assign_project_profile(aadhar_id: int, project_id: int, db: Session = Depends(get_db)):
    return assign_project(db, aadhar_id, project_id)

def get_projects_by_profile_id(aadhar_id: int, db: Session):
    profile = db.query(models.AadharDetails).filter(models.AadharDetails.id == aadhar_id).first()
    if profile is None:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile.project

@router.get("/projects/{aadhar_id}")
def get_projects(aadhar_id: int, db: Session = Depends(get_db)):
    return get_projects_by_profile_id(aadhar_id, db)



def get_profiles_by_project_id(project_id: int, db: Session):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return [profile.app_user for profile in project.aadhar_project_details if profile.app_user is not None]

@router.get("/users/{project_id}")
def get_profile_users(project_id: int, db: Session = Depends(get_db)):
    return get_profiles_by_project_id(project_id, db)
