from typing import List
from fastapi import APIRouter, Depends, HTTPException,status
from database_config.database import get_db
from responseDto import responseClass
from sqlalchemy.orm import Session
from loggers_config.file_log import logger
from schema import models

router =APIRouter(tags=['AadharDetails'])


@router.post("/employee-address")
def create_user_aadhar(aadhar: responseClass.AadharCreate, db: Session = Depends(get_db)):
    user = db.query(models.AppUser).filter(models.AppUser.username == aadhar.full_name).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    db_profile = models.AadharDetails(**aadhar.dict(), user_id=user.id)
    db.add(db_profile)
    db.commit()
    db.refresh(db_profile)
    return db_profile


@router.post("/aadhar/{aadhar_id}/addresses/", response_model=responseClass.Address)
def create_address_for_aadhar(aadhar_id: int, address: responseClass.AddressCreate, db: Session = Depends(get_db)):
    db_address = models.Address(**address.dict(), aadhar_id=aadhar_id)
    db.add(db_address)
    db.commit()
    db.refresh(db_address)
    return db_address


@router.get("/aadhar/{aadhar_id}/addresses/", response_model=List[responseClass.Address])
def get_addresses_for_aadhar(aadhar_id: int, db: Session = Depends(get_db)):
    return db.query(models.Address).filter(models.Address.aadhar_id == aadhar_id).all()