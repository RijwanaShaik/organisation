
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from database_config.database import get_db
from responseDto import responseClass
from sqlalchemy.orm import Session
from loggers_config.file_log import logger
from schema import models
from securityConfig.security import get_current_user_role


router =APIRouter(tags=['Employee'])


def has_role(roles: list):
    def decorator(func):
        def wrapper(role: str = Depends(get_current_user_role)):
            print(role,"vvvvvvvvvvvvvvvvvvvvvvvvv")
            print(roles,"ddddddddddddddddddddd")
            if role not in roles:
                raise HTTPException(status_code=403, detail="You are not authorized to access this resource.")
            return func()
        return wrapper
    return decorator


@router.post("/users/", response_model=responseClass.AppUser)
def createUser(user:responseClass.UserBase, db: Session = Depends(get_db)):
    db_user = models.AppUser(username=user.username, password=user.password)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


@router.get("/get_users/",response_model=List[responseClass.AppUserList])
@has_role(["admin"])
def getUsers(db: Session = Depends(get_db)):
    logger.info("Get Users process Started....")
    print("enterted into get users method..............")
    # Authorize.jwt_required()
    db_users=db.query(models.AppUser).all()
    logger.info("Get Users process Completed....")
    return [responseClass.AppUserList(id=user.id, username=user.username, password=user.password, role = user.role) for user in db_users]


@router.get("/projects/{user_id}")
def get_projects_by_user_id(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.AppUser).filter(models.AppUser.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found") 
    projects = [project.name for project in user.empProfile.projects]
    return {"user_id": user_id, "projects": projects}


@router.delete("/user/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.AppUser).filter(models.AppUser.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(user)
    db.commit()
    return {"message": "User deleted successfully"}