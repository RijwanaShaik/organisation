from pydantic import BaseModel


class UserBase(BaseModel):
    username: str
    password: str
    role: str


class AppUser(UserBase):
    id: int

    class Config:
        orm_mode = True
        
        
class AppUserList(UserBase):
    username: str
    password: str
    id: int
    


class AadharBase(BaseModel):
    full_name: str
    aadharNumber: int


class AadharCreate(AadharBase):
    pass


class AadharDetails(AadharBase):
    id: int
    user_id: int

    class Config:
        orm_mode = True


class AddressBase(BaseModel):
    address_line: str
    city: str
    state: str
    country: str


class AddressCreate(AddressBase):
    pass


class Address(AddressBase):
    id: int
    aadhar_id: int

    class Config:
        orm_mode = True
        
        
class ProjectBase(BaseModel):
    name:str
    
class ProjectCreate(ProjectBase):
    pass

class Project(ProjectBase):
    id: int
    
    class Config:
        orm_mode = True
        
        
class UserLogin(BaseModel):
    username: str
    password: str