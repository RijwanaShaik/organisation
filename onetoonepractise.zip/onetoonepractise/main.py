from datetime import timedelta
from typing import List
from fastapi import FastAPI, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from sqlalchemy.orm import Session
from schema.models import AppUser
from database_config.database import engine, get_db
from schema import models
from responseDto import responseClass
import os
from fastapi_jwt_auth import AuthJWT
from fastapi_jwt_auth.exceptions import AuthJWTException
from loggers_config.file_log import logger
from dotenv import load_dotenv
from api_config.appUser import router as appUser
from api_config.aadhar import router as aadhar_details
from api_config.project import router as project
from passlib.context import CryptContext
from securityConfig.security import authenticate_user

load_dotenv()

app = FastAPI()
models.Base.metadata.create_all(engine)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

class Settings(BaseModel):
  authjwt_secret_key: str =os.getenv("AUTHJWT_SECRET_KEY")

@AuthJWT.load_config
def get_config():
    return Settings()

@app.exception_handler(AuthJWTException)
def authjwt_exception_handler(request: Request, exc: AuthJWTException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.message}
    )
    

def login_response(access_token):
    return {
        "access_token": access_token, 
        "token_type": "bearer"
        }
# @app.post('/login')
# def login(user:responseClass.UserLogin, Authorize: AuthJWT = Depends(),db: Session = Depends(get_db)):
#     app_user=db.query(models.AppUser).where(models.AppUser.username ==user.username).first()
#     if app_user is None or app_user.password != user.password :
#         raise HTTPException(status_code=401,detail="Bad username or password")
#     expires = timedelta(minutes=2)
#     access_token = Authorize.create_access_token(subject=app_user.username, expires_time=expires)
#     # refresh_token = Authorize.create_refresh_token(subject=app_user.username)
#     return login_response(access_token)

@app.post("/login")
def login(user: responseClass.UserLogin, Authorize: AuthJWT = Depends(),db: Session = Depends(get_db)):
    authenticated_user = authenticate_user(user.username, user.password,db)
    if authenticated_user:
        # Providing a unique identifier (such as username) as subject
        access_token = Authorize.create_access_token(subject=authenticated_user.username)
        return {"access_token": access_token, "token_type": "bearer"}
    raise HTTPException(status_code=401, detail="Invalid username or password")

@app.post("/refresh-token")
async def refresh_token(Authorize: AuthJWT = Depends()):
    Authorize.jwt_refresh_token_required()
    current_user = Authorize.get_jwt_subject()


# app.include_router(employee,dependencies=[Depends(oauth2_scheme)])
# app.include_router(aadhar_details,dependencies=[Depends(oauth2_scheme)])
# app.include_router(project,dependencies=[Depends(oauth2_scheme)])



app.include_router(appUser)
app.include_router(aadhar_details)
app.include_router(project)
