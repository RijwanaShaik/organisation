class UserRoleEnum:
    ADMIN = "admin" 
    USER = "user"