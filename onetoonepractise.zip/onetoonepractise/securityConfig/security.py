from sqlalchemy import Column, Integer, String, ForeignKey, Table
from sqlalchemy.orm import relationship, Session 
from database_config.database import Base, get_db
from schema import models
from fastapi import Depends, HTTPException
from fastapi_jwt_auth import AuthJWT
from fastapi_jwt_auth.exceptions import AuthJWTException



def authenticate_user(username: str, password: str,db: Session):
    print("entered into authenticate_user method ....")
    user_data = db.query(models.AppUser).filter(models.AppUser.username == username).first()
    if user_data and user_data.password == password:
        return user_data
    
    
def get_current_user_role(Authorize: AuthJWT = Depends(),db: Session = Depends(get_db))->str:
    try:
        Authorize.jwt_required()
        current_user = Authorize.get_jwt_subject()
        print(current_user,'Ccccccccccc')
        user_data = db.query(models.AppUser).filter(models.AppUser.username == current_user).first()
        print(user_data.role,'rrrrrrrrrrrrrrr')
        return user_data.role
    except AuthJWTException as e:
        print("error")
        raise HTTPException(status_code=401, detail=str(e))
    
    
    
    
    
    
    