
from database_config.database import Base
from sqlalchemy import Column,Integer,String,ForeignKey,Table
from sqlalchemy.orm import relationship

from enumConfig.enum import UserRoleEnum


class AppUser(Base):
    __tablename__= "app_user"
    
    id=Column(Integer,primary_key=True,index =True)
    username=Column(String,unique=True,index=True)
    password = Column(String)
    role = Column(String, nullable=False, server_default= UserRoleEnum.USER)
    aadhar_details = relationship("AadharDetails", uselist=False, back_populates="app_user")
    
Aadhar_Project=Table('Aadhar_project',Base.metadata,
    Column('aadhar_id',Integer,ForeignKey('aadhar_details.id')) ,          
                      
    Column('project_id',Integer, ForeignKey('project.id')) 
 )  
class AadharDetails(Base):
    __tablename__= "aadhar_details"
    
    id=Column(Integer,primary_key=True,index =True)
    full_name=Column(String,unique=True,index=True)
    aadharNumber=Column(Integer,unique=True)
    user_id=Column(Integer,ForeignKey("app_user.id"))
    address = relationship("Address", back_populates="aadhar_address_details")
    app_user = relationship("AppUser", back_populates="aadhar_details")
    project= relationship("Project",secondary =Aadhar_Project,back_populates='aadhar_project_details')
    
class Address(Base):
    __tablename__="address"
    
    id=Column(Integer,primary_key= True,index=True)
    address_line = Column(String)
    city = Column(String)
    state = Column(String)
    country = Column(String)
    aadhar_id = Column(Integer, ForeignKey("aadhar_details.id"))
    aadhar_address_details = relationship("AadharDetails", back_populates="address")
    
    
class Project(Base):
    __tablename__= 'project'
    
    id= Column(Integer,primary_key= True,index= True)
    name=Column(String,unique= True)
    aadhar_project_details=relationship("AadharDetails",secondary = Aadhar_Project,back_populates='project')


    
    